import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. حذف "الحيوانات والأصوات" (30066) - غير تعليمية ───
await conn.execute('DELETE FROM educational_games WHERE id = 30066');
console.log('✅ حُذفت "الحيوانات والأصوات"');

// ─── 2. حذف "رتّب الأحداث" (30037) - مكررة مع الأنشطة اليومية ───
await conn.execute('DELETE FROM educational_games WHERE id = 30037');
console.log('✅ حُذفت "رتّب الأحداث" المكررة');

// ─── 3. نقل "أكمل الجملة" (30038) للمستوى المبتدئ ───
await conn.execute('UPDATE educational_games SET level = "easy" WHERE id = 30038');
console.log('✅ نُقلت "أكمل الجملة" للمستوى المبتدئ');

// ─── 4. إضافة "أكمل الجملة" أصعب للمستوى المتوسط ───
const completeSentenceMedium = {
  instructions: "اختر الكلمة الصحيحة لإكمال الجملة",
  rounds: [
    { letter: "الطيور _____ في السماء", question: "اختر الفعل الصحيح", options: ["تطير 🦅", "تسبح 🐟", "تزحف 🐛", "تقفز 🐸"], correct: 0 },
    { letter: "الأسماك تعيش في _____", question: "أين تعيش الأسماك؟", options: ["الغابة 🌳", "الصحراء 🏜️", "الماء 🌊", "الجبل ⛰️"], correct: 2 },
    { letter: "الشمس تشرق من _____", question: "من أين تشرق الشمس؟", options: ["الغرب 🌅", "الشمال ❄️", "الجنوب 🌴", "الشرق 🌄"], correct: 3 },
    { letter: "نحتاج _____ للتنفس", question: "ماذا نحتاج للتنفس؟", options: ["الماء 💧", "الهواء 💨", "الطعام 🍎", "الضوء ☀️"], correct: 1 },
    { letter: "الثلج _____ جداً", question: "صف الثلج", options: ["حار 🔥", "بارد ❄️", "حلو 🍬", "مالح 🧂"], correct: 1 },
    { letter: "القلب يضخ _____", question: "ماذا يضخ القلب؟", options: ["الهواء 💨", "الماء 💧", "الدم 🩸", "الطعام 🍎"], correct: 2 },
    { letter: "النباتات تصنع غذاءها من _____", question: "من أين تصنع النباتات غذاءها؟", options: ["الظلام 🌑", "الشمس ☀️", "الريح 💨", "الثلج ❄️"], correct: 1 },
    { letter: "الأرض تدور حول _____", question: "ماذا تدور الأرض حوله؟", options: ["القمر 🌙", "النجوم ⭐", "الشمس ☀️", "المريخ 🔴"], correct: 2 },
  ]
};
await conn.execute(
  'INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, gameData, isPublished, orderIndex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
  ["أكمل الجملة - متوسط", "أكمل الجملة باختيار الكلمة الصحيحة", "letter_match", "medium", "6-8", "📝", 25, JSON.stringify(completeSentenceMedium), 1, 20]
);
console.log('✅ أُضيفت "أكمل الجملة - متوسط" الأصعب');

// ─── 5. تحديث "الجسم والصحة" (30062) بأسئلة أصعب ───
const bodyHealthData = {
  instructions: "اختر الإجابة الصحيحة عن جسم الإنسان",
  rounds: [
    { emoji: "❤️", question: "ما وظيفة القلب؟", options: ["ضخ الدم 🩸", "التنفس 💨", "الهضم 🍎", "الرؤية 👁️"], correct: 0 },
    { emoji: "🫁", question: "ما اسم عضو التنفس؟", options: ["القلب ❤️", "الكبد 🫀", "الرئتان 🫁", "المعدة 🫃"], correct: 2 },
    { emoji: "🧠", question: "ما وظيفة المخ؟", options: ["ضخ الدم 🩸", "التفكير والتحكم 🧠", "الهضم 🍎", "التنفس 💨"], correct: 1 },
    { emoji: "🦷", question: "كم عدد أسنان الإنسان البالغ؟", options: ["20 سناً", "28-32 سناً", "15 سناً", "40 سناً"], correct: 1 },
    { emoji: "🦴", question: "ما وظيفة العظام؟", options: ["ضخ الدم 🩸", "التنفس 💨", "دعم الجسم وحمايته 🦴", "الهضم 🍎"], correct: 2 },
    { emoji: "👁️", question: "ما الحاسة التي تستخدمها للرؤية؟", options: ["السمع 👂", "البصر 👁️", "الشم 👃", "اللمس ✋"], correct: 1 },
    { emoji: "🫀", question: "أين يقع الكبد في الجسم؟", options: ["في الرأس 🧠", "في الصدر ❤️", "في البطن 🫃", "في الساق 🦵"], correct: 2 },
    { emoji: "💪", question: "ما وظيفة العضلات؟", options: ["التنفس 💨", "الحركة والقوة 💪", "الهضم 🍎", "ضخ الدم 🩸"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30062', [JSON.stringify(bodyHealthData)]);
console.log('✅ تم تحديث "الجسم والصحة" بأسئلة أصعب');

// ─── 6. تحديث "الكلمة الغريبة" (30058) - إضافة إيموجي لجميع الخيارات ───
const [rows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30058');
const existingData = typeof rows[0].gameData === 'string' ? JSON.parse(rows[0].gameData) : rows[0].gameData;
console.log('بيانات الكلمة الغريبة الحالية:', JSON.stringify(existingData.rounds?.slice(0,1), null, 2));

const oddOneOutData = {
  instructions: "اختر الكلمة التي لا تنتمي للمجموعة",
  rounds: [
    { emoji: "🍎🍊🍋🚗", question: "أي الكلمات لا تنتمي للمجموعة؟", options: ["🍎 تفاحة", "🍊 برتقالة", "🚗 سيارة", "🍋 ليمون"], correct: 2 },
    { emoji: "🐕🐈🐟🚂", question: "أي الكلمات لا تنتمي للمجموعة؟", options: ["🐕 كلب", "🐈 قطة", "🐟 سمكة", "🚂 قطار"], correct: 3 },
    { emoji: "📚✏️🎒🍕", question: "أي الكلمات لا تنتمي للمجموعة؟", options: ["📚 كتاب", "✏️ قلم", "🎒 حقيبة", "🍕 بيتزا"], correct: 3 },
    { emoji: "🌹🌷🌻🍌", question: "أي الكلمات لا تنتمي للمجموعة؟", options: ["🌹 وردة", "🌷 زنبق", "🌻 عباد شمس", "🍌 موزة"], correct: 3 },
    { emoji: "🔴🔵🟢🐘", question: "أي الكلمات لا تنتمي للمجموعة؟", options: ["🔴 أحمر", "🔵 أزرق", "🟢 أخضر", "🐘 فيل"], correct: 3 },
    { emoji: "🚗🚌🚲✈️", question: "أي وسيلة لا تسير على الأرض؟", options: ["🚗 سيارة", "🚌 حافلة", "🚲 دراجة", "✈️ طائرة"], correct: 3 },
    { emoji: "🌊🏖️🏊🏔️", question: "أي الكلمات لا تنتمي لموضوع البحر؟", options: ["🌊 موج", "🏖️ شاطئ", "🏊 سباحة", "🏔️ جبل"], correct: 3 },
    { emoji: "🍞🧀🥛🔑", question: "أي الكلمات لا تنتمي للطعام؟", options: ["🍞 خبز", "🧀 جبن", "🥛 حليب", "🔑 مفتاح"], correct: 3 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30058', [JSON.stringify(oddOneOutData)]);
console.log('✅ تم تحديث "الكلمة الغريبة" بإيموجي لجميع الخيارات');

// ─── 7. تحديث "تكوين الجمل" (30059) - كلمات تكوّن جملة (ليس حروف) ───
const sentenceBuildData = {
  instructions: "رتّب الكلمات لتكوين جملة صحيحة",
  rounds: [
    { letter: "يلعب - الولد - بالكرة", question: "رتّب الكلمات لتكوين جملة", options: ["الولد يلعب بالكرة ✅", "بالكرة الولد يلعب", "يلعب بالكرة الولد", "الكرة يلعب الولد"], correct: 0 },
    { letter: "تشرب - البنت - الحليب", question: "رتّب الكلمات لتكوين جملة", options: ["تشرب البنت الحليب", "البنت تشرب الحليب ✅", "الحليب تشرب البنت", "البنت الحليب تشرب"], correct: 1 },
    { letter: "تطير - الطيور - في السماء", question: "رتّب الكلمات لتكوين جملة", options: ["السماء تطير الطيور", "الطيور في السماء تطير", "تطير الطيور في السماء ✅", "في السماء الطيور تطير"], correct: 2 },
    { letter: "الأسد - يعيش - في الغابة", question: "رتّب الكلمات لتكوين جملة", options: ["الأسد يعيش في الغابة ✅", "في الغابة الأسد يعيش", "يعيش الأسد الغابة في", "الغابة يعيش الأسد في"], correct: 0 },
    { letter: "أحب - أنا - الفواكه", question: "رتّب الكلمات لتكوين جملة", options: ["الفواكه أنا أحب", "أنا أحب الفواكه ✅", "أحب الفواكه أنا", "الفواكه أحب أنا"], correct: 1 },
    { letter: "النجوم - تضيء - بالليل", question: "رتّب الكلمات لتكوين جملة", options: ["بالليل تضيء النجوم", "النجوم تضيء بالليل ✅", "تضيء بالليل النجوم", "النجوم بالليل تضيء"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30059', [JSON.stringify(sentenceBuildData)]);
console.log('✅ تم تحديث "تكوين الجمل" لترتيب كلمات بدلاً من حروف');

// ─── 8. حذف "الأنشطة اليومية" (30065) - مكررة مع "رتّب الأحداث" ───
await conn.execute('DELETE FROM educational_games WHERE id = 30065');
console.log('✅ حُذفت "الأنشطة اليومية" المكررة');

// ─── 9. إضافة لعبة بديلة عن "الحيوانات والأصوات" - "التضاد" ───
const antonymsData = {
  instructions: "اختر كلمة التضاد (العكس)",
  rounds: [
    { emoji: "☀️", question: "ما عكس النهار؟", options: ["الليل 🌙", "الصباح 🌅", "الظهر ☀️", "المساء 🌆"], correct: 0 },
    { emoji: "🔥", question: "ما عكس الحار؟", options: ["الدافئ 🌡️", "البارد ❄️", "الساخن 🔥", "الحار 🌶️"], correct: 1 },
    { emoji: "🐘", question: "ما عكس الكبير؟", options: ["الضخم 🐘", "الصغير 🐭", "الطويل 🦒", "الثقيل ⚖️"], correct: 1 },
    { emoji: "⬆️", question: "ما عكس فوق؟", options: ["أمام ⬆️", "تحت ⬇️", "يمين ➡️", "يسار ⬅️"], correct: 1 },
    { emoji: "😊", question: "ما عكس السعيد؟", options: ["المبتسم 😊", "الحزين 😢", "المتعب 😴", "الغاضب 😠"], correct: 1 },
    { emoji: "🌞", question: "ما عكس المضيء؟", options: ["الساطع 🌞", "المعتم 🌑", "الملوّن 🌈", "الجميل ✨"], correct: 1 },
    { emoji: "🏃", question: "ما عكس السريع؟", options: ["النشيط 🏃", "البطيء 🐢", "القوي 💪", "الخفيف 🪶"], correct: 1 },
    { emoji: "🆕", question: "ما عكس الجديد؟", options: ["الحديث 🆕", "القديم 📜", "المميز ⭐", "الجيد 👍"], correct: 1 },
  ]
};
await conn.execute(
  'INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, gameData, isPublished, orderIndex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
  ["التضاد والعكس", "تعلم كلمات التضاد والعكس", "image_match", "medium", "6-8", "🔄", 25, JSON.stringify(antonymsData), 1, 21]
);
console.log('✅ أُضيفت "التضاد والعكس" بدلاً من الحيوانات والأصوات');

await conn.end();
console.log('\n✅ تم الانتهاء من إصلاح المستوى المتوسط');
