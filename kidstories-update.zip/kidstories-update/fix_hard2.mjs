import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. إصلاح "جمع ثلاثة أرقام" (60008) - سؤال واحد فقط! ───
const add3Data = {
  instructions: "احسب مجموع الأرقام الثلاثة",
  rounds: [
    { letter: "3 + 4 + 5", question: "ما المجموع؟", options: ["10", "11", "12", "13"], correct: 2 },
    { letter: "2 + 3 + 4", question: "ما المجموع؟", options: ["7", "8", "9", "10"], correct: 2 },
    { letter: "5 + 3 + 2", question: "ما المجموع؟", options: ["8", "9", "10", "11"], correct: 2 },
    { letter: "4 + 4 + 2", question: "ما المجموع؟", options: ["8", "9", "10", "11"], correct: 2 },
    { letter: "6 + 2 + 3", question: "ما المجموع؟", options: ["9", "10", "11", "12"], correct: 2 },
    { letter: "1 + 5 + 4", question: "ما المجموع؟", options: ["8", "9", "10", "11"], correct: 2 },
    { letter: "7 + 2 + 1", question: "ما المجموع؟", options: ["8", "9", "10", "11"], correct: 2 },
    { letter: "3 + 3 + 3", question: "ما المجموع؟", options: ["7", "8", "9", "10"], correct: 2 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 60008', [JSON.stringify(add3Data)]);
console.log('✅ تم إصلاح "جمع ثلاثة أرقام" (8 أسئلة)');

// ─── 2. تخفيف "الخريطة الذهنية" (30044) ───
const mindMapData = {
  categories: ["حيوانات 🐾", "فواكه 🍎", "مواصلات 🚗"],
  instructions: "صنّف كل عنصر في المجموعة الصحيحة",
  items: [
    { correct: 0, name: "🐱 قطة" },
    { correct: 1, name: "🍌 موزة" },
    { correct: 2, name: "🚌 حافلة" },
    { correct: 0, name: "🐶 كلب" },
    { correct: 1, name: "🍎 تفاحة" },
    { correct: 2, name: "✈️ طائرة" },
    { correct: 0, name: "🐘 فيل" },
    { correct: 1, name: "🍊 برتقالة" },
    { correct: 2, name: "🚲 دراجة" },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30044', [JSON.stringify(mindMapData)]);
console.log('✅ تم تخفيف "الخريطة الذهنية"');

// ─── 3. تخفيف "لعبة الذاكرة المتقدمة" (30071) ───
const advMemoryData = {
  instructions: "احفظ الترتيب ثم اختر الصحيح",
  rounds: [
    { emoji: "🍎🍊🍋", question: "ما الترتيب الصحيح؟", options: ["🍎🍊🍋", "🍊🍎🍋", "🍋🍎🍊", "🍎🍋🍊"], correct: 0 },
    { emoji: "🐱🐶🐰", question: "ما الترتيب الصحيح؟", options: ["🐶🐱🐰", "🐱🐶🐰", "🐰🐱🐶", "🐶🐰🐱"], correct: 1 },
    { emoji: "🔴🔵🟢", question: "ما الترتيب الصحيح؟", options: ["🔵🔴🟢", "🟢🔴🔵", "🔴🔵🟢", "🔵🟢🔴"], correct: 2 },
    { emoji: "⭐🌙☀️", question: "ما الترتيب الصحيح؟", options: ["⭐🌙☀️", "🌙⭐☀️", "☀️⭐🌙", "🌙☀️⭐"], correct: 0 },
    { emoji: "🏠🌳🚗", question: "ما الترتيب الصحيح؟", options: ["🌳🏠🚗", "🚗🌳🏠", "🏠🌳🚗", "🌳🚗🏠"], correct: 2 },
    { emoji: "🎈🎁🎂", question: "ما الترتيب الصحيح؟", options: ["🎁🎈🎂", "🎂🎁🎈", "🎈🎂🎁", "🎈🎁🎂"], correct: 3 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30071', [JSON.stringify(advMemoryData)]);
console.log('✅ تم تخفيف "لعبة الذاكرة المتقدمة"');

// ─── 4. تخفيف "رتّب أحداث القصة" (30045) ───
const storyOrderData = {
  correctOrder: [0, 1, 2, 3],
  instructions: "رتّب أحداث القصة بالترتيب الصحيح",
  items: [
    "🌅 استيقظ الولد صباحاً",
    "🍳 أكل الإفطار مع عائلته",
    "🎒 حمل حقيبته وذهب للمدرسة",
    "📚 تعلّم دروساً جديدة في الفصل"
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30045', [JSON.stringify(storyOrderData)]);
console.log('✅ تم تخفيف "رتّب أحداث القصة"');

await conn.end();
console.log('\n✅ تم الانتهاء من إصلاح الألعاب المتبقية');
