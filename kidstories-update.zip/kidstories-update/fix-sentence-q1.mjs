import { createConnection } from 'mysql2/promise';

const conn = await createConnection(process.env.DATABASE_URL);

// الحصول على البيانات الحالية
const [rows] = await conn.execute('SELECT id, gameData FROM educational_games WHERE id = 30059');
const r = rows[0];
const gd = typeof r.gameData === 'string' ? JSON.parse(r.gameData) : r.gameData;

// السؤال الجديد عن الصحة وقوة الجسم بدلاً من "يلعب - الولد - بالكرة"
const newQuestion = {
  correctIndex: 0,
  emoji: "🥗",
  options: [
    "الرياضة تقوّي الجسم",
    "تقوّي الجسم الرياضة",
    "الجسم الرياضة تقوّي",
    "تقوّي الرياضة الجسم"
  ],
  question: "رتّب الكلمات: \"الرياضة - تقوّي - الجسم\""
};

// استبدال السؤال الأول
gd.rounds[0] = newQuestion;

// تحديث قاعدة البيانات
await conn.execute(
  'UPDATE educational_games SET gameData = ? WHERE id = 30059',
  [JSON.stringify(gd)]
);

console.log('✅ تم استبدال السؤال الأول بسؤال عن الصحة والرياضة');
console.log('السؤال الجديد:', JSON.stringify(newQuestion, null, 2));

await conn.end();
