CREATE TABLE `recording_reactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recordingId` int NOT NULL,
	`emoji` varchar(10) NOT NULL,
	`label` varchar(100) NOT NULL,
	`seenByChild` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `recording_reactions_id` PRIMARY KEY(`id`)
);
