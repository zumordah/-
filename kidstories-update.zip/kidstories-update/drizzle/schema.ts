import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  json,
  float,
} from "drizzle-orm/mysql-core";

// ─── Users (Admin/Teacher accounts via OAuth) ───────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Children (registered learners) ────────────────────────────────────────
export const children = mysqlTable("children", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  ageGroup: mysqlEnum("ageGroup", ["4-6", "6-8", "8-10"]).notNull(),
  avatarEmoji: varchar('avatarEmoji', { length: 10 }).default('🧒'),
  avatarUrl: text('avatarUrl'),
  totalPoints: int("totalPoints").default(0).notNull(),
  level: int("level").default(1).notNull(),
  storyLevel: mysqlEnum("storyLevel", ["easy", "medium", "hard"]).default("easy").notNull(),
  readingStreak: int("readingStreak").default(0).notNull(),
  isKindergartenStudent: boolean("isKindergartenStudent").default(false),
  classroom: mysqlEnum("classroom", ["فصل المرح", "فصل الغيوم", "فصل الألوان", "فصل النجوم"]),
  referralSource: mysqlEnum("referralSource", ["الأهل", "الأصدقاء", "العمل", "مواقع التواصل"]),
  gender: mysqlEnum("gender", ["boy", "girl"]).default("boy"),
  schoolId: int("schoolId"),
  schoolClassroom: varchar("schoolClassroom", { length: 100 }),
  password: varchar("password", { length: 200 }),
  lastActiveAt: timestamp("lastActiveAt").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Child = typeof children.$inferSelect;
export type InsertChild = typeof children.$inferInsert;

// ─── Stories ────────────────────────────────────────────────────────────────
export const stories = mysqlTable("stories", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  coverImage: text("coverImage"),
  ageGroup: mysqlEnum("ageGroup", ["4-6", "6-8", "8-10", "all"]).default("all").notNull(),
  totalPages: int("totalPages").default(0).notNull(),
  audioUrl: text("audioUrl"),
  voiceGender: mysqlEnum("voiceGender", ["male", "female"]).default("female"),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("easy"),
  pointsReward: int("pointsReward").default(10).notNull(),
  isPublished: boolean("isPublished").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Story = typeof stories.$inferSelect;
export type InsertStory = typeof stories.$inferInsert;

// ─── Story Pages ─────────────────────────────────────────────────────────────
export const storyPages = mysqlTable("story_pages", {
  id: int("id").autoincrement().primaryKey(),
  storyId: int("storyId").notNull(),
  pageNumber: int("pageNumber").notNull(),
  text: text("text").notNull(),
  imageUrl: text("imageUrl"),
  audioUrl: text("audioUrl"),
});

export type StoryPage = typeof storyPages.$inferSelect;
export type InsertStoryPage = typeof storyPages.$inferInsert;

// ─── Activities (linked to stories) ─────────────────────────────────────────
export const activities = mysqlTable("activities", {
  id: int("id").autoincrement().primaryKey(),
  storyId: int("storyId").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  type: mysqlEnum("type", ["quiz", "matching", "puzzle"]).notNull(),
  description: text("description"),
  pointsReward: int("pointsReward").default(20).notNull(),
  ageGroup: mysqlEnum("ageGroup", ["4-6", "6-8", "8-10", "all"]).default("all"),
  isPublished: boolean("isPublished").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;

// ─── Activity Questions ───────────────────────────────────────────────────────
export const activityQuestions = mysqlTable("activity_questions", {
  id: int("id").autoincrement().primaryKey(),
  activityId: int("activityId").notNull(),
  questionText: text("questionText").notNull(),
  questionType: mysqlEnum("questionType", ["multiple_choice", "matching", "puzzle"]).notNull(),
  options: json("options"),
  correctAnswer: text("correctAnswer").notNull(),
  explanation: text("explanation"),
  orderIndex: int("orderIndex").default(0),
});

export type ActivityQuestion = typeof activityQuestions.$inferSelect;
export type InsertActivityQuestion = typeof activityQuestions.$inferInsert;

// ─── Child Story Progress ─────────────────────────────────────────────────────
export const childStoryProgress = mysqlTable("child_story_progress", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  storyId: int("storyId").notNull(),
  currentPage: int("currentPage").default(1).notNull(),
  isCompleted: boolean("isCompleted").default(false).notNull(),
  completedAt: timestamp("completedAt"),
  pointsEarned: int("pointsEarned").default(0),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChildStoryProgress = typeof childStoryProgress.$inferSelect;

// ─── Child Activity Results ───────────────────────────────────────────────────
export const childActivityResults = mysqlTable("child_activity_results", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  activityId: int("activityId").notNull(),
  score: int("score").default(0).notNull(),
  maxScore: int("maxScore").default(100).notNull(),
  isCompleted: boolean("isCompleted").default(false).notNull(),
  completedAt: timestamp("completedAt"),
  pointsEarned: int("pointsEarned").default(0),
  attempts: int("attempts").default(1),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
});

export type ChildActivityResult = typeof childActivityResults.$inferSelect;

// ─── Achievements / Badges ────────────────────────────────────────────────────
export const achievements = mysqlTable("achievements", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 50 }).notNull().unique(),
  title: varchar("title", { length: 100 }).notNull(),
  description: text("description"),
  emoji: varchar("emoji", { length: 10 }).notNull(),
  condition: varchar("condition", { length: 50 }).notNull(),
  conditionValue: int("conditionValue").default(1),
  pointsReward: int("pointsReward").default(50),
});

export type Achievement = typeof achievements.$inferSelect;

// ─── Child Achievements (earned) ─────────────────────────────────────────────
export const childAchievements = mysqlTable("child_achievements", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  achievementId: int("achievementId").notNull(),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

export type ChildAchievement = typeof childAchievements.$inferSelect;

// ─── Site Reviews (تقييمات الموقع) ──────────────────────────────────────────
export const siteReviews = mysqlTable("site_reviews", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  review: text("review").notNull(),
  rating: int("rating").default(5).notNull(),
  isApproved: boolean("isApproved").default(false).notNull(),
  isDeleted: boolean("isDeleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SiteReview = typeof siteReviews.$inferSelect;
export type InsertSiteReview = typeof siteReviews.$inferInsert;

// ─── Educational Games (ألعاب تعليمية) ────────────────────────────────────────────────
export const educationalGames = mysqlTable("educational_games", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["letter_match", "number_order", "word_build", "classification", "image_match", "letter_sound", "count_objects", "missing_letter", "memory_game", "math_addition", "math_subtraction", "compare_symbols", "landmark_match"]).notNull(),
  level: mysqlEnum("level", ["easy", "medium", "hard"]).default("easy").notNull(),
  ageGroup: mysqlEnum("ageGroup", ["4-6", "6-8", "8-10", "all"]).default("all").notNull(),
  emoji: varchar("emoji", { length: 10 }).default("🎮"),
  pointsReward: int("pointsReward").default(15).notNull(),
  gameData: json("gameData").notNull(),
  isPublished: boolean("isPublished").default(true).notNull(),
  isLocked: boolean("isLocked").default(false).notNull(),
  lockCost: int("lockCost").default(0).notNull(),
  orderIndex: int("orderIndex").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type EducationalGame = typeof educationalGames.$inferSelect;
export type InsertEducationalGame = typeof educationalGames.$inferInsert;

// ─── Child Unlocked Games ─────────────────────────────────────────────────────
export const childUnlockedGames = mysqlTable("child_unlocked_games", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  gameId: int("gameId").notNull(),
  unlockedAt: timestamp("unlockedAt").defaultNow().notNull(),
});
export type ChildUnlockedGame = typeof childUnlockedGames.$inferSelect;

// ─── Child Game Progress ─────────────────────────────────────────────────────────────────────────
export const childGameProgress = mysqlTable("child_game_progress", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  gameId: int("gameId").notNull(),
  score: int("score").default(0).notNull(),
  maxScore: int("maxScore").default(100).notNull(),
  isCompleted: boolean("isCompleted").default(false).notNull(),
  pointsEarned: int("pointsEarned").default(0),
  completedAt: timestamp("completedAt"),
  attempts: int("attempts").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChildGameProgress = typeof childGameProgress.$inferSelect;

// ─── Story Adventures (مغامرات القصة التفاعلية) ──────────────────────────────────────────
export const storyAdventures = mysqlTable("story_adventures", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  emoji: varchar("emoji", { length: 20 }).default("🌟"),
  level: mysqlEnum("level", ["easy", "medium", "hard"]).default("easy").notNull(),
  ageGroup: mysqlEnum("ageGroup", ["4-6", "6-8", "8-10", "all"]).default("all").notNull(),
  pointsReward: int("pointsReward").default(50).notNull(),
  totalEndings: int("totalEndings").default(2).notNull(),
  adventureData: json("adventureData").notNull(),
  isPublished: boolean("isPublished").default(true).notNull(),
  isLocked: boolean("isLocked").default(false).notNull(),
  lockCost: int("lockCost").default(0).notNull(),
  orderIndex: int("orderIndex").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StoryAdventure = typeof storyAdventures.$inferSelect;
export type InsertStoryAdventure = typeof storyAdventures.$inferInsert;

// ─── Child Adventure Progress ──────────────────────────────────────────────────────
export const childAdventureProgress = mysqlTable("child_adventure_progress", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  adventureId: int("adventureId").notNull(),
  isCompleted: boolean("isCompleted").default(false).notNull(),
  endingsDiscovered: json("endingsDiscovered").$type<string[]>().default([]),
  pointsEarned: int("pointsEarned").default(0),
  attempts: int("attempts").default(1),
  lastChoices: json("lastChoices").$type<string[]>().default([]),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChildAdventureProgress = typeof childAdventureProgress.$inferSelect;

// ─── Daily Challenges ──────────────────────────────────────────────────────────
export const dailyChallenges = mysqlTable("daily_challenges", {
  id: int("id").autoincrement().primaryKey(),
  dateKey: varchar("dateKey", { length: 20 }).notNull(), // YYYY-MM-DD or YYYY-MM-DD-L1
  readStoryId: int("readStoryId"), // optional specific story
  playGameId: int("playGameId"),   // optional specific game
  playAdventureId: int("playAdventureId"), // optional specific adventure
  bonusPoints: int("bonusPoints").default(50).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type DailyChallenge = typeof dailyChallenges.$inferSelect;

// ─── Child Daily Challenge Progress ───────────────────────────────────────────
export const childDailyChallengeProgress = mysqlTable("child_daily_challenge_progress", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  dateKey: varchar("dateKey", { length: 20 }).notNull(),
  readStoryDone: boolean("readStoryDone").default(false).notNull(),
  playGameDone: boolean("playGameDone").default(false).notNull(),
  playAdventureDone: boolean("playAdventureDone").default(false).notNull(),
  bonusAwarded: boolean("bonusAwarded").default(false).notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ChildDailyChallengeProgress = typeof childDailyChallengeProgress.$inferSelect;

// ─── Shop Items ────────────────────────────────────────────────────────────────
export const shopItems = mysqlTable("shop_items", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["avatar", "theme", "adventure_unlock", "avatar_frame", "game_pack", "adventure_pack", "game_unlock", "adventure_item_unlock"]).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }).default("🎁"),
  value: varchar("value", { length: 200 }).notNull(), // emoji for avatar, hex/gradient for theme, adventureId for unlock
  levelRequired: int("levelRequired").default(1).notNull(),
  pointsCost: int("pointsCost").default(0).notNull(),
  isEnabled: boolean("isEnabled").default(true).notNull(),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ShopItem = typeof shopItems.$inferSelect;

// ─── Child Inventory (owned shop items) ───────────────────────────────────────
export const childInventory = mysqlTable("child_inventory", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  shopItemId: int("shopItemId").notNull(),
  acquiredVia: mysqlEnum("acquiredVia", ["purchase", "level_reward", "admin_grant"]).default("purchase").notNull(),
  isEquipped: boolean("isEquipped").default(false).notNull(),
  acquiredAt: timestamp("acquiredAt").defaultNow().notNull(),
});
export type ChildInventory = typeof childInventory.$inferSelect;

// ─── Level Rewards (what reward was chosen at each level-up) ──────────────────
export const childLevelRewards = mysqlTable("child_level_rewards", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  level: int("level").notNull(),
  shopItemId: int("shopItemId").notNull(),
  chosenAt: timestamp("chosenAt").defaultNow().notNull(),
});
export type ChildLevelReward = typeof childLevelRewards.$inferSelect;

// ─── Interactive Lab Game Progress ───────────────────────────────────────────
export const interactiveGameProgress = mysqlTable("interactive_game_progress", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  gameId: varchar("gameId", { length: 100 }).notNull(), // e.g. "memory-animals", "sort-land-sea"
  category: mysqlEnum("category", ["memory", "sorting", "sequencing", "build_logic", "logic_puzzle", "coloring"]).notNull(),
  isCompleted: boolean("isCompleted").default(false).notNull(),
  score: int("score").default(0).notNull(),
  pointsEarned: int("pointsEarned").default(0).notNull(),
  attempts: int("attempts").default(0).notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type InteractiveGameProgress = typeof interactiveGameProgress.$inferSelect;
export type InsertInteractiveGameProgress = typeof interactiveGameProgress.$inferInsert;

// ─── Child Unlocked Adventures ────────────────────────────────────────────────
export const childUnlockedAdventures = mysqlTable("child_unlocked_adventures", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  adventureId: int("adventureId").notNull(),
  unlockedAt: timestamp("unlockedAt").defaultNow().notNull(),
});
export type ChildUnlockedAdventure = typeof childUnlockedAdventures.$inferSelect;

// ─── Child Companion Character (الشخصية المرافقة المختارة) ──────────────────────
export const childCompanion = mysqlTable("child_companion", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull().unique(),
  characterId: varchar("characterId", { length: 50 }).notNull(), // e.g. "sami", "badr", "lajen"
  equippedAt: timestamp("equippedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ChildCompanion = typeof childCompanion.$inferSelect;

// ─── Child Owned Characters (الشخصيات المشتراة) ──────────────────────────────
export const childOwnedCharacters = mysqlTable("child_owned_characters", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  characterId: varchar("characterId", { length: 50 }).notNull(),
  acquiredVia: mysqlEnum("acquiredVia", ["purchase", "level_reward", "admin_grant"]).default("purchase").notNull(),
  acquiredAt: timestamp("acquiredAt").defaultNow().notNull(),
});
export type ChildOwnedCharacter = typeof childOwnedCharacters.$inferSelect;

// ─── Child Color Theme (ثيم الألوان المختار) ─────────────────────────────────
export const childColorTheme = mysqlTable("child_color_theme", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull().unique(),
  themeId: varchar("themeId", { length: 50 }).notNull().default("default"),
  equippedAt: timestamp("equippedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ChildColorTheme = typeof childColorTheme.$inferSelect;

// ─── Child Voice Recordings (تسجيلات الطفل الصوتية) ──────────────────────────────────────────────
export const childVoiceRecordings = mysqlTable("child_voice_recordings", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  audioUrl: text("audioUrl").notNull(),
  audioKey: text("audioKey").notNull(),
  durationSeconds: int("durationSeconds").default(0),
  transcription: text("transcription"),
  storyId: int("storyId"), // القصة المرتبطة (اختياري)
  pageNumber: int("pageNumber"), // رقم الصفحة (اختياري - لتسجيلات الصفحات)
  isApproved: boolean("isApproved").default(false).notNull(), // للمشرف
  rating: int("rating"), // تقييم الأدمن 1-5 نجوم
  ratingComment: varchar("ratingComment", { length: 300 }), // تعليق الأدمن
  ratingSeenAt: timestamp("ratingSeenAt"), // وقت رؤية الطفل للتقييم
  isDeleted: boolean("isDeleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ChildVoiceRecording = typeof childVoiceRecordings.$inferSelect;
export type InsertChildVoiceRecording = typeof childVoiceRecordings.$inferInsert;

// ─── Admin Accounts (Multi-admin support) ────────────────────────────────────
export const adminAccounts = mysqlTable("admin_accounts", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  password: varchar("password", { length: 200 }).notNull(),
  addedBy: varchar("addedBy", { length: 320 }), // email of who added this admin
  role: mysqlEnum("role", ["founder", "school_admin"]).default("school_admin").notNull(),
  schoolId: int("schoolId"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AdminAccount = typeof adminAccounts.$inferSelect;
export type InsertAdminAccount = typeof adminAccounts.$inferInsert;

// ─── Schools (Multi-Tenant Support) ──────────────────────────────────────────
export const schools = mysqlTable("schools", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  adminEmail: varchar("adminEmail", { length: 320 }).notNull(), // email of school admin
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type School = typeof schools.$inferSelect;
export type InsertSchool = typeof schools.$inferInsert;

// ─── School Classrooms ────────────────────────────────────────────────────────
export const schoolClassrooms = mysqlTable("school_classrooms", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  name: varchar("name", { length: 100 }).notNull(), // "فصل 1", "فصل 2", etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type SchoolClassroom = typeof schoolClassrooms.$inferSelect;
export type InsertSchoolClassroom = typeof schoolClassrooms.$inferInsert;

// ─── Email Subscriptions ──────────────────────────────────────────────────────
export const emailSubscriptions = mysqlTable("email_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  childId: int("childId"),           // ربط بالطفل إن وُجد
  childName: varchar("childName", { length: 100 }),
  token: varchar("token", { length: 64 }).notNull().unique(), // رمز إلغاء الاشتراك
  isSubscribed: boolean("isSubscribed").default(true).notNull(),
  subscribedAt: timestamp("subscribedAt").defaultNow().notNull(),
  unsubscribedAt: timestamp("unsubscribedAt"),
});
export type EmailSubscription = typeof emailSubscriptions.$inferSelect;
export type InsertEmailSubscription = typeof emailSubscriptions.$inferInsert;

// ─── Recording Reactions (Teacher Emoji Reactions) ───────────────────────────
export const recordingReactions = mysqlTable("recording_reactions", {
  id: int("id").autoincrement().primaryKey(),
  recordingId: int("recordingId").notNull(),           // معرف التسجيل
  emoji: varchar("emoji", { length: 10 }).notNull(),   // الرمز التعبيري
  label: varchar("label", { length: 100 }).notNull(),  // النص التوضيحي مثل "أحسنت"
  seenByChild: boolean("seenByChild").default(false).notNull(), // هل رآه الطفل؟
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type RecordingReaction = typeof recordingReactions.$inferSelect;
export type InsertRecordingReaction = typeof recordingReactions.$inferInsert;

// ─── School Registrations (طلبات تسجيل المدارس) ─────────────────────────────
export const schoolRegistrations = mysqlTable("school_registrations", {
  id: int("id").autoincrement().primaryKey(),
  schoolName: varchar("schoolName", { length: 200 }).notNull(),
  adminName: varchar("adminName", { length: 100 }).notNull(),
  adminEmail: varchar("adminEmail", { length: 320 }).notNull(),
  passwordHash: varchar("passwordHash", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 30 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  rejectionReason: varchar("rejectionReason", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});
export type SchoolRegistration = typeof schoolRegistrations.$inferSelect;
export type InsertSchoolRegistration = typeof schoolRegistrations.$inferInsert;

// ─── Child Drawings (لوحة الفنان الصغير) ────────────────────────────────────
export const childDrawings = mysqlTable("child_drawings", {
  id: int("id").autoincrement().primaryKey(),
  childId: int("childId").notNull(),
  childName: varchar("childName", { length: 100 }).notNull(),
  schoolName: varchar("schoolName", { length: 200 }),
  storyId: int("storyId").notNull(),
  storyTitle: varchar("storyTitle", { length: 200 }).notNull(),
  imageUrl: text("imageUrl").notNull(),
  rating: int("rating").default(0),           // تقييم المعلمة 1-5
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(), // أفضل رسمة
  likesCount: int("likesCount").default(0).notNull(),
  adminNote: text("adminNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});
export type ChildDrawing = typeof childDrawings.$inferSelect;
export type InsertChildDrawing = typeof childDrawings.$inferInsert;

// ─── Drawing Likes (إعجابات الرسومات - مرة واحدة لكل طفل) ──────────────────
export const drawingLikes = mysqlTable("drawing_likes", {
  id: int("id").autoincrement().primaryKey(),
  drawingId: int("drawingId").notNull(),
  childId: int("childId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type DrawingLike = typeof drawingLikes.$inferSelect;


