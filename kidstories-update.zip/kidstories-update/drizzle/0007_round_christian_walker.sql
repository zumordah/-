CREATE TABLE `child_color_theme` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`themeId` varchar(50) NOT NULL DEFAULT 'default',
	`equippedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `child_color_theme_id` PRIMARY KEY(`id`),
	CONSTRAINT `child_color_theme_childId_unique` UNIQUE(`childId`)
);
--> statement-breakpoint
CREATE TABLE `child_companion` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`characterId` varchar(50) NOT NULL,
	`equippedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `child_companion_id` PRIMARY KEY(`id`),
	CONSTRAINT `child_companion_childId_unique` UNIQUE(`childId`)
);
--> statement-breakpoint
CREATE TABLE `child_owned_characters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`characterId` varchar(50) NOT NULL,
	`acquiredVia` enum('purchase','level_reward','admin_grant') NOT NULL DEFAULT 'purchase',
	`acquiredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_owned_characters_id` PRIMARY KEY(`id`)
);
