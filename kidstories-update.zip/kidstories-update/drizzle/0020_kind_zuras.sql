CREATE TABLE `child_drawings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`childName` varchar(100) NOT NULL,
	`schoolName` varchar(200),
	`storyId` int NOT NULL,
	`storyTitle` varchar(200) NOT NULL,
	`imageUrl` text NOT NULL,
	`rating` int DEFAULT 0,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`isFeatured` boolean NOT NULL DEFAULT false,
	`likesCount` int NOT NULL DEFAULT 0,
	`adminNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `child_drawings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `drawing_likes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`drawingId` int NOT NULL,
	`childId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `drawing_likes_id` PRIMARY KEY(`id`)
);
