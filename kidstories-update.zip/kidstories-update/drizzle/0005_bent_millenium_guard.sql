ALTER TABLE `educational_games` ADD `isLocked` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `educational_games` ADD `lockCost` int DEFAULT 0 NOT NULL;