CREATE TABLE `child_adventure_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`adventureId` int NOT NULL,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`endingsDiscovered` json DEFAULT ('[]'),
	`pointsEarned` int DEFAULT 0,
	`attempts` int DEFAULT 1,
	`lastChoices` json DEFAULT ('[]'),
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `child_adventure_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `story_adventures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`description` text,
	`emoji` varchar(20) DEFAULT '🌟',
	`level` enum('easy','medium','hard') NOT NULL DEFAULT 'easy',
	`ageGroup` enum('4-6','6-8','8-10','all') NOT NULL DEFAULT 'all',
	`pointsReward` int NOT NULL DEFAULT 50,
	`totalEndings` int NOT NULL DEFAULT 2,
	`adventureData` json NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT true,
	`orderIndex` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `story_adventures_id` PRIMARY KEY(`id`)
);
