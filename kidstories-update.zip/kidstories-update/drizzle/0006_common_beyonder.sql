CREATE TABLE `child_unlocked_adventures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`adventureId` int NOT NULL,
	`unlockedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_unlocked_adventures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_unlocked_games` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`gameId` int NOT NULL,
	`unlockedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_unlocked_games_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `child_daily_challenge_progress` MODIFY COLUMN `dateKey` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `daily_challenges` MODIFY COLUMN `dateKey` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `interactive_game_progress` MODIFY COLUMN `category` enum('memory','sorting','sequencing','build_logic','logic_puzzle','coloring') NOT NULL;--> statement-breakpoint
ALTER TABLE `shop_items` MODIFY COLUMN `type` enum('avatar','theme','adventure_unlock','avatar_frame','game_pack','adventure_pack','game_unlock','adventure_item_unlock') NOT NULL;--> statement-breakpoint
ALTER TABLE `story_adventures` ADD `isLocked` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `story_adventures` ADD `lockCost` int DEFAULT 0 NOT NULL;