CREATE TABLE `interactive_game_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`gameId` varchar(100) NOT NULL,
	`category` enum('memory','sorting','sequencing','build_logic') NOT NULL,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`score` int NOT NULL DEFAULT 0,
	`pointsEarned` int NOT NULL DEFAULT 0,
	`attempts` int NOT NULL DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `interactive_game_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `shop_items` MODIFY COLUMN `type` enum('avatar','theme','adventure_unlock','avatar_frame') NOT NULL;