CREATE TABLE `child_voice_recordings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`title` varchar(200) NOT NULL,
	`audioUrl` text NOT NULL,
	`audioKey` text NOT NULL,
	`durationSeconds` int DEFAULT 0,
	`transcription` text,
	`storyId` int,
	`isApproved` boolean NOT NULL DEFAULT false,
	`isDeleted` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `child_voice_recordings_id` PRIMARY KEY(`id`)
);
