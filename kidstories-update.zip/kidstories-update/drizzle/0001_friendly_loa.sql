CREATE TABLE `achievements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(50) NOT NULL,
	`title` varchar(100) NOT NULL,
	`description` text,
	`emoji` varchar(10) NOT NULL,
	`condition` varchar(50) NOT NULL,
	`conditionValue` int DEFAULT 1,
	`pointsReward` int DEFAULT 50,
	CONSTRAINT `achievements_id` PRIMARY KEY(`id`),
	CONSTRAINT `achievements_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `activities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storyId` int NOT NULL,
	`title` varchar(200) NOT NULL,
	`type` enum('quiz','matching','puzzle') NOT NULL,
	`description` text,
	`pointsReward` int NOT NULL DEFAULT 20,
	`ageGroup` enum('4-6','6-8','8-10','all') DEFAULT 'all',
	`isPublished` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activities_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `activity_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`activityId` int NOT NULL,
	`questionText` text NOT NULL,
	`questionType` enum('multiple_choice','matching','puzzle') NOT NULL,
	`options` json,
	`correctAnswer` text NOT NULL,
	`explanation` text,
	`orderIndex` int DEFAULT 0,
	CONSTRAINT `activity_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_achievements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`achievementId` int NOT NULL,
	`earnedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_achievements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_activity_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`activityId` int NOT NULL,
	`score` int NOT NULL DEFAULT 0,
	`maxScore` int NOT NULL DEFAULT 100,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`completedAt` timestamp,
	`pointsEarned` int DEFAULT 0,
	`attempts` int DEFAULT 1,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_activity_results_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_game_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`gameId` int NOT NULL,
	`score` int NOT NULL DEFAULT 0,
	`maxScore` int NOT NULL DEFAULT 100,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`pointsEarned` int DEFAULT 0,
	`completedAt` timestamp,
	`attempts` int DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_game_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_story_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`storyId` int NOT NULL,
	`currentPage` int NOT NULL DEFAULT 1,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`completedAt` timestamp,
	`pointsEarned` int DEFAULT 0,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `child_story_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `children` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`email` varchar(320) NOT NULL,
	`ageGroup` enum('4-6','6-8','8-10') NOT NULL,
	`avatarEmoji` varchar(10) DEFAULT '🧒',
	`totalPoints` int NOT NULL DEFAULT 0,
	`level` int NOT NULL DEFAULT 1,
	`storyLevel` enum('easy','medium','hard') NOT NULL DEFAULT 'easy',
	`readingStreak` int NOT NULL DEFAULT 0,
	`isKindergartenStudent` boolean DEFAULT false,
	`classroom` enum('فصل المرح','فصل الغيوم','فصل الألوان','فصل النجوم'),
	`referralSource` enum('الأهل','الأصدقاء','العمل','مواقع التواصل'),
	`lastActiveAt` timestamp DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `children_id` PRIMARY KEY(`id`),
	CONSTRAINT `children_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `educational_games` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`description` text,
	`type` enum('letter_match','number_order','word_build','classification','image_match','letter_sound','count_objects','missing_letter','memory_game','math_addition','math_subtraction') NOT NULL,
	`level` enum('easy','medium','hard') NOT NULL DEFAULT 'easy',
	`ageGroup` enum('4-6','6-8','8-10','all') NOT NULL DEFAULT 'all',
	`emoji` varchar(10) DEFAULT '🎮',
	`pointsReward` int NOT NULL DEFAULT 15,
	`gameData` json NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT true,
	`orderIndex` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `educational_games_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `site_reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`review` text NOT NULL,
	`rating` int NOT NULL DEFAULT 5,
	`isApproved` boolean NOT NULL DEFAULT false,
	`isDeleted` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `site_reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`description` text,
	`coverImage` text,
	`ageGroup` enum('4-6','6-8','8-10','all') NOT NULL DEFAULT 'all',
	`totalPages` int NOT NULL DEFAULT 0,
	`audioUrl` text,
	`voiceGender` enum('male','female') DEFAULT 'female',
	`difficulty` enum('easy','medium','hard') DEFAULT 'easy',
	`pointsReward` int NOT NULL DEFAULT 10,
	`isPublished` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `story_pages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storyId` int NOT NULL,
	`pageNumber` int NOT NULL,
	`text` text NOT NULL,
	`imageUrl` text,
	`audioUrl` text,
	CONSTRAINT `story_pages_id` PRIMARY KEY(`id`)
);
