DROP TABLE `child_drawings`;--> statement-breakpoint
DROP TABLE `drawing_likes`;