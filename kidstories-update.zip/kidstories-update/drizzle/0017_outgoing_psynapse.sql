ALTER TABLE `admin_accounts` ADD `role` enum('founder','school_admin') DEFAULT 'school_admin' NOT NULL;--> statement-breakpoint
ALTER TABLE `admin_accounts` ADD `schoolId` int;--> statement-breakpoint
ALTER TABLE `children` ADD `schoolId` int;--> statement-breakpoint
ALTER TABLE `children` ADD `schoolClassroom` varchar(100);--> statement-breakpoint
ALTER TABLE `children` ADD `password` varchar(200);