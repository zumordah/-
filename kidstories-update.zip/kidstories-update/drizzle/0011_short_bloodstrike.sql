ALTER TABLE `child_voice_recordings` ADD `rating` int;--> statement-breakpoint
ALTER TABLE `child_voice_recordings` ADD `ratingComment` varchar(300);