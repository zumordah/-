CREATE TABLE `school_registrations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolName` varchar(200) NOT NULL,
	`adminName` varchar(100) NOT NULL,
	`adminEmail` varchar(320) NOT NULL,
	`passwordHash` varchar(100) NOT NULL,
	`phone` varchar(30),
	`notes` text,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`rejectionReason` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `school_registrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `children` ADD `avatarUrl` text;