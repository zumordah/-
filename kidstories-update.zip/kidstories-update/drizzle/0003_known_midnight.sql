CREATE TABLE `child_daily_challenge_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`dateKey` varchar(10) NOT NULL,
	`readStoryDone` boolean NOT NULL DEFAULT false,
	`playGameDone` boolean NOT NULL DEFAULT false,
	`playAdventureDone` boolean NOT NULL DEFAULT false,
	`bonusAwarded` boolean NOT NULL DEFAULT false,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `child_daily_challenge_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_inventory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`shopItemId` int NOT NULL,
	`acquiredVia` enum('purchase','level_reward','admin_grant') NOT NULL DEFAULT 'purchase',
	`isEquipped` boolean NOT NULL DEFAULT false,
	`acquiredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_inventory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `child_level_rewards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childId` int NOT NULL,
	`level` int NOT NULL,
	`shopItemId` int NOT NULL,
	`chosenAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `child_level_rewards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `daily_challenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`dateKey` varchar(10) NOT NULL,
	`readStoryId` int,
	`playGameId` int,
	`playAdventureId` int,
	`bonusPoints` int NOT NULL DEFAULT 50,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `daily_challenges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shop_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` enum('avatar','theme','adventure_unlock') NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(50) DEFAULT '🎁',
	`value` varchar(200) NOT NULL,
	`levelRequired` int NOT NULL DEFAULT 1,
	`pointsCost` int NOT NULL DEFAULT 0,
	`isEnabled` boolean NOT NULL DEFAULT true,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shop_items_id` PRIMARY KEY(`id`)
);
