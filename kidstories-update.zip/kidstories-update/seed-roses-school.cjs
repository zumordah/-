const mysql = require('./node_modules/mysql2/promise');
const bcrypt = require('./node_modules/bcrypt');

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  // 1. إضافة المدرسة
  const [schoolResult] = await conn.execute(
    `INSERT INTO schools (name, email, adminEmail, isActive, createdAt, updatedAt) VALUES (?, ?, ?, 1, NOW(), NOW())`,
    ['روضة الورود', 'zuza-77@hotmail.com', 'zuza-77@hotmail.com']
  );
  const schoolId = schoolResult.insertId;
  console.log(`✅ School created: روضة الورود (id=${schoolId})`);

  // 2. إضافة الفصول الثلاثة
  const classrooms = ['فصل الشمعة', 'فصل السيارة', 'فصل الدب'];
  const classroomIds = [];
  for (const name of classrooms) {
    const [cr] = await conn.execute(
      `INSERT INTO school_classrooms (schoolId, name, createdAt) VALUES (?, ?, NOW())`,
      [schoolId, name]
    );
    classroomIds.push(cr.insertId);
    console.log(`✅ Classroom created: ${name} (id=${cr.insertId})`);
  }

  // 3. إضافة حساب المدير في admin_accounts
  const hashedPassword = await bcrypt.hash('Roses2026!', 10);
  const [existingAdmin] = await conn.execute(
    `SELECT id FROM admin_accounts WHERE email = ?`,
    ['zuza-77@hotmail.com']
  );
  if (existingAdmin.length > 0) {
    await conn.execute(
      `UPDATE admin_accounts SET schoolId = ?, role = 'school_admin', name = ?, password = ? WHERE email = ?`,
      [schoolId, 'مديرة روضة الورود', hashedPassword, 'zuza-77@hotmail.com']
    );
    console.log(`✅ Admin account updated for zuza-77@hotmail.com`);
  } else {
    await conn.execute(
      `INSERT INTO admin_accounts (email, name, password, addedBy, schoolId, role, isActive, createdAt) VALUES (?, ?, ?, ?, ?, ?, 1, NOW())`,
      ['zuza-77@hotmail.com', 'مديرة روضة الورود', hashedPassword, 'founder', schoolId, 'school_admin']
    );
    console.log(`✅ Admin account created for zuza-77@hotmail.com`);
  }

  // 4. إضافة طلاب تجريبيين (6 طلاب، 2 لكل فصل، مستويات مختلفة)
  const studentPassword = await bcrypt.hash('Test1234!', 10);
  const students = [
    // فصل الشمعة
    { name: 'سارة أحمد', email: 'sara.test1@demo.com', ageGroup: '4-6', gender: 'girl', level: 1, storyLevel: 'easy', classroom: 'فصل الشمعة', totalPoints: 120 },
    { name: 'يوسف محمد', email: 'yousef.test1@demo.com', ageGroup: '6-8', gender: 'boy', level: 3, storyLevel: 'medium', classroom: 'فصل الشمعة', totalPoints: 450 },
    // فصل السيارة
    { name: 'ليلى خالد', email: 'layla.test1@demo.com', ageGroup: '4-6', gender: 'girl', level: 2, storyLevel: 'easy', classroom: 'فصل السيارة', totalPoints: 280 },
    { name: 'عمر سعد', email: 'omar.test1@demo.com', ageGroup: '8-10', gender: 'boy', level: 5, storyLevel: 'hard', classroom: 'فصل السيارة', totalPoints: 890 },
    // فصل الدب
    { name: 'نورة علي', email: 'noura.test1@demo.com', ageGroup: '6-8', gender: 'girl', level: 4, storyLevel: 'medium', classroom: 'فصل الدب', totalPoints: 620 },
    { name: 'فهد ناصر', email: 'fahad.test1@demo.com', ageGroup: '4-6', gender: 'boy', level: 1, storyLevel: 'easy', classroom: 'فصل الدب', totalPoints: 95 },
  ];

  for (const s of students) {
    // تحقق إذا كان الطالب موجوداً
    const [existing] = await conn.execute(`SELECT id FROM children WHERE email = ?`, [s.email]);
    if (existing.length > 0) {
      await conn.execute(
        `UPDATE children SET schoolId = ?, schoolClassroom = ? WHERE email = ?`,
        [schoolId, s.classroom, s.email]
      );
      console.log(`✅ Student updated: ${s.name}`);
    } else {
      await conn.execute(
        `INSERT INTO children (name, email, ageGroup, avatarEmoji, totalPoints, level, storyLevel, gender, schoolId, schoolClassroom, isKindergartenStudent, classroom, referralSource, password, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'فصل المرح', 'الأهل', ?, NOW(), NOW())`,
        [s.name, s.email, s.ageGroup, s.gender === 'girl' ? '👧' : '👦', s.totalPoints, s.level, s.storyLevel, s.gender, schoolId, s.classroom, studentPassword]
      );
      console.log(`✅ Student created: ${s.name} (${s.classroom})`);
    }
  }

  console.log('\n📊 Summary:');
  console.log(`School ID: ${schoolId}`);
  console.log(`Admin Email: zuza-77@hotmail.com`);
  console.log(`Admin Password: Roses2026!`);
  console.log(`Classrooms: ${classrooms.join(', ')}`);
  console.log(`Students: ${students.length} demo students added`);

  await conn.end();
}

main().catch(e => { console.error(e.message); process.exit(1); });
