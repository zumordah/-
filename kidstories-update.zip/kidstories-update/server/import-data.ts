/**
 * سكربت نقل البيانات من الملف المستخرج إلى قاعدة البيانات الجديدة
 * يُشغَّل مرة واحدة فقط عبر: npx tsx server/import-data.ts
 */
import { readFileSync } from 'fs';
import { getDb } from './db';
import { stories, storyPages, activities, activityQuestions, educationalGames, achievements } from '../drizzle/schema';
import { sql } from 'drizzle-orm';

const OLD_CONTENT_PATH = '/home/ubuntu/old_content.json';
const NEW_GAMES_PATH = '/home/ubuntu/new_games.json';

interface OldPage {
  id: number;
  storyId: number;
  pageNumber: number;
  text: string;
  imageUrl?: string;
  audioUrl?: string;
}

interface OldQuestion {
  id: number;
  activityId: number;
  questionText: string;
  questionType: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
  orderIndex: number;
}

interface OldActivity {
  id: number;
  storyId: number;
  title: string;
  type: string;
  description?: string;
  pointsReward: number;
  ageGroup?: string;
  isPublished: boolean;
  questions: OldQuestion[];
}

interface OldStory {
  id: number;
  title: string;
  description?: string;
  coverImage?: string;
  ageGroup: string;
  totalPages: number;
  audioUrl?: string;
  voiceGender?: string;
  difficulty?: string;
  pointsReward: number;
  isPublished: boolean;
  pages: OldPage[];
}

interface NewGame {
  title: string;
  description?: string;
  type: string;
  level: string;
  difficulty?: string;
  emoji?: string;
  ageGroup?: string;
  gameData: Record<string, unknown>;
  pointsReward: number;
}

async function importData() {
  console.log('🚀 بدء نقل البيانات...\n');
  
  const db = await getDb();
  if (!db) {
    console.error('❌ لا يمكن الاتصال بقاعدة البيانات');
    process.exit(1);
  }

  // قراءة الملفات
  const content = JSON.parse(readFileSync(OLD_CONTENT_PATH, 'utf8'));
  const oldStories: OldStory[] = content.stories;
  const oldActivities: OldActivity[] = content.activities;
  
  let newGames: NewGame[] = [];
  try {
    newGames = JSON.parse(readFileSync(NEW_GAMES_PATH, 'utf8'));
  } catch {
    console.warn('⚠️  ملف الألعاب الجديدة غير موجود، سيتم تخطيه');
  }

  // 1. مسح البيانات القديمة بالترتيب الصحيح
  console.log('🗑️  مسح البيانات القديمة...');
  await db.execute(sql`DELETE FROM child_achievements`);
  await db.execute(sql`DELETE FROM achievements`);
  await db.execute(sql`DELETE FROM child_game_progress`);
  await db.execute(sql`DELETE FROM educational_games`);
  await db.execute(sql`DELETE FROM child_activity_results`);
  await db.execute(sql`DELETE FROM activity_questions`);
  await db.execute(sql`DELETE FROM activities`);
  await db.execute(sql`DELETE FROM child_story_progress`);
  await db.execute(sql`DELETE FROM story_pages`);
  await db.execute(sql`DELETE FROM stories`);
  console.log('   ✅ تم المسح\n');

  // 2. إدراج القصص والصفحات
  console.log('📚 إدراج القصص والصفحات...');
  let storyCount = 0;
  let pageCount = 0;

  for (const story of oldStories) {
    // إدراج القصة
    await db.execute(sql`
      INSERT INTO stories (id, title, description, coverImage, ageGroup, totalPages, audioUrl, voiceGender, difficulty, pointsReward, isPublished, createdAt, updatedAt)
      VALUES (
        ${story.id},
        ${story.title},
        ${story.description || null},
        ${story.coverImage || null},
        ${story.ageGroup || 'all'},
        ${story.totalPages || (story.pages?.length ?? 5)},
        ${story.audioUrl || null},
        ${story.voiceGender || 'female'},
        ${story.difficulty || 'easy'},
        ${story.pointsReward || 10},
        ${story.isPublished !== false ? 1 : 0},
        NOW(),
        NOW()
      )
    `);
    storyCount++;

    // إدراج صفحات القصة
    for (const page of (story.pages || [])) {
      await db.execute(sql`
        INSERT INTO story_pages (storyId, pageNumber, text, imageUrl, audioUrl)
        VALUES (${story.id}, ${page.pageNumber}, ${page.text}, ${page.imageUrl || null}, ${page.audioUrl || null})
      `);
      pageCount++;
    }

    console.log(`   📖 [${story.id}] ${story.title} - ${story.pages?.length || 0} صفحة`);
  }
  console.log(`\n   ✅ ${storyCount} قصة و ${pageCount} صفحة\n`);

  // 3. إدراج الأنشطة والأسئلة
  console.log('🎯 إدراج الأنشطة والأسئلة...');
  let actCount = 0;
  let qCount = 0;

  for (const act of oldActivities) {
    // إدراج النشاط
    await db.execute(sql`
      INSERT INTO activities (id, storyId, title, description, type, pointsReward, ageGroup, isPublished, createdAt)
      VALUES (
        ${act.id},
        ${act.storyId},
        ${act.title},
        ${act.description || null},
        ${act.type || 'quiz'},
        ${act.pointsReward || 10},
        ${act.ageGroup || 'all'},
        ${act.isPublished !== false ? 1 : 0},
        NOW()
      )
    `);
    actCount++;

    // إدراج الأسئلة
    for (const q of (act.questions || [])) {
      await db.execute(sql`
        INSERT INTO activity_questions (activityId, questionText, questionType, options, correctAnswer, explanation, orderIndex)
        VALUES (
          ${act.id},
          ${q.questionText},
          ${q.questionType || 'multiple_choice'},
          ${JSON.stringify(q.options || [])},
          ${q.correctAnswer || '0'},
          ${q.explanation || null},
          ${q.orderIndex || 0}
        )
      `);
      qCount++;
    }

    console.log(`   🎯 [${act.id}] ${act.title} - ${act.questions?.length || 0} سؤال`);
  }
  console.log(`\n   ✅ ${actCount} نشاط و ${qCount} سؤال\n`);

  // 4. إدراج الألعاب الجديدة المعدّلة
  console.log('🎮 إدراج الألعاب التعليمية الجديدة...');
  let gameCount = 0;

  for (const game of newGames) {
    await db.execute(sql`
      INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, gameData, isPublished, orderIndex, createdAt)
      VALUES (
        ${game.title},
        ${game.description || null},
        ${game.type},
        ${game.level || 'easy'},
        ${'all'},
        ${game.emoji || '🎮'},
        ${game.pointsReward || 10},
        ${JSON.stringify(game.gameData || {})},
        ${1},
        ${0},
        NOW()
      )
    `);
    gameCount++;
    console.log(`   🎮 ${game.title} (${game.level || game.difficulty})`);
  }
  console.log(`\n   ✅ ${gameCount} لعبة\n`);

  // 5. إدراج الإنجازات
  console.log('🏆 إدراج الإنجازات...');
  const defaultAchievements = [
    { key: 'first_story', title: 'القارئ المبتدئ', description: 'أكمل أول قصة', emoji: '📚', condition: 'stories_completed', conditionValue: 1, pointsReward: 10 },
    { key: 'five_stories', title: 'محب القراءة', description: 'أكمل 5 قصص', emoji: '📖', condition: 'stories_completed', conditionValue: 5, pointsReward: 25 },
    { key: 'ten_stories', title: 'نجم القراءة', description: 'أكمل 10 قصص', emoji: '⭐', condition: 'stories_completed', conditionValue: 10, pointsReward: 50 },
    { key: 'first_activity', title: 'المتعلم النشيط', description: 'أكمل أول نشاط', emoji: '✏️', condition: 'activities_completed', conditionValue: 1, pointsReward: 10 },
    { key: 'five_activities', title: 'المجتهد', description: 'أكمل 5 أنشطة', emoji: '🎯', condition: 'activities_completed', conditionValue: 5, pointsReward: 25 },
    { key: 'first_game', title: 'اللاعب الذكي', description: 'العب أول لعبة', emoji: '🎮', condition: 'games_played', conditionValue: 1, pointsReward: 10 },
    { key: 'fifty_points', title: 'نقطة البداية', description: 'اجمع 50 نقطة', emoji: '💫', condition: 'points_earned', conditionValue: 50, pointsReward: 15 },
    { key: 'two_hundred_points', title: 'المتميز', description: 'اجمع 200 نقطة', emoji: '🌟', condition: 'points_earned', conditionValue: 200, pointsReward: 30 },
  ];

  for (const ach of defaultAchievements) {
    await db.insert(achievements).values({
      key: ach.key,
      title: ach.title,
      description: ach.description,
      emoji: ach.emoji,
      condition: ach.condition,
      conditionValue: ach.conditionValue,
      pointsReward: ach.pointsReward,
    });
  }
  console.log(`   ✅ ${defaultAchievements.length} إنجاز\n`);

  console.log('🎉 تم نقل كل المحتوى بنجاح!');
  console.log(`\n=== الملخص ===`);
  console.log(`القصص: ${storyCount}`);
  console.log(`الصفحات: ${pageCount}`);
  console.log(`الأنشطة: ${actCount}`);
  console.log(`الأسئلة: ${qCount}`);
  console.log(`الألعاب: ${gameCount}`);
  console.log(`الإنجازات: ${defaultAchievements.length}`);

  process.exit(0);
}

importData().catch(err => {
  console.error('❌ خطأ:', err);
  process.exit(1);
});
