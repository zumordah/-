#!/usr/bin/env python3
"""
تحويل النص العربي إلى صوت بشري طبيعي باستخدام Microsoft Edge TTS
يُستدعى من Node.js ويُرسل الصوت كـ stdout
"""
import sys
import asyncio
import edge_tts

async def generate(text: str, voice: str = "ar-SA-ZariyahNeural"):
    communicate = edge_tts.Communicate(text, voice, rate="-5%", pitch="+2Hz")
    audio_data = b""
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio_data += chunk["data"]
    sys.stdout.buffer.write(audio_data)
    sys.stdout.buffer.flush()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(1)
    text = sys.argv[1]
    voice = sys.argv[2] if len(sys.argv) > 2 else "ar-SA-ZariyahNeural"
    asyncio.run(generate(text, voice))
