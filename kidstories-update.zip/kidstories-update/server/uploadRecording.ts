import { Request, Response } from 'express';
import { storagePut } from './storage';
import Busboy from 'busboy';
import { Readable } from 'stream';

interface UploadedFile {
  buffer: Buffer;
  mimetype: string;
  originalname: string;
}

function parseMultipart(req: Request): Promise<{ file: UploadedFile | null; fields: Record<string, string> }> {
  return new Promise((resolve, reject) => {
    const contentType = req.headers['content-type'] || '';
    if (!contentType.includes('multipart/form-data')) {
      return reject(new Error('Expected multipart/form-data'));
    }

    const busboy = Busboy({ headers: req.headers });
    const fields: Record<string, string> = {};
    let file: UploadedFile | null = null;

    busboy.on('field', (name: string, value: string) => {
      fields[name] = value;
    });

    busboy.on('file', (_fieldname: string, fileStream: Readable, info: { filename: string; mimeType: string }) => {
      const chunks: Buffer[] = [];
      fileStream.on('data', (chunk: Buffer) => chunks.push(chunk));
      fileStream.on('end', () => {
        file = {
          buffer: Buffer.concat(chunks),
          mimetype: info.mimeType || 'audio/webm',
          originalname: info.filename,
        };
      });
    });

    busboy.on('finish', () => resolve({ file, fields }));
    busboy.on('error', reject);

    req.pipe(busboy);
  });
}

export async function handleUploadRecording(req: Request, res: Response) {
  try {
    const { file, fields } = await parseMultipart(req);

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    if (file.buffer.length > 16 * 1024 * 1024) {
      return res.status(400).json({ error: 'File too large (max 16MB)' });
    }

    const childId = fields.childId || 'unknown';
    const timestamp = Date.now();
    const ext = file.originalname.split('.').pop() || 'webm';
    const key = `recordings/child-${childId}/${timestamp}.${ext}`;

    const { url } = await storagePut(key, file.buffer, file.mimetype);

    return res.json({ url, key });
  } catch (err: any) {
    console.error('Upload recording error:', err);
    return res.status(500).json({ error: err.message || 'Upload failed' });
  }
}
