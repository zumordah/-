/**
 * اختبارات التجارب العلمية
 * تتحقق من:
 * 1. وجود audioText لكل خطوة
 * 2. وجود رموز توضيحية (emoji) لكل خطوة
 * 3. صحة هيكل البيانات
 */

import { describe, it, expect } from "vitest";
import { scienceGames } from "../client/src/lib/scienceGamesData";

describe("scienceGamesData", () => {
  it("يجب أن تحتوي على 8 تجارب على الأقل", () => {
    expect(scienceGames.length).toBeGreaterThanOrEqual(8);
  });

  it("كل تجربة يجب أن تحتوي على خطوات", () => {
    for (const game of scienceGames) {
      expect(game.steps.length).toBeGreaterThan(0);
    }
  });

  it("كل خطوة يجب أن تحتوي على emoji توضيحي", () => {
    for (const game of scienceGames) {
      for (const step of game.steps) {
        expect(step.emoji).toBeTruthy();
        expect(step.emoji.length).toBeGreaterThan(0);
      }
    }
  });

  it("كل خطوة يجب أن تحتوي على audioText للصوت", () => {
    for (const game of scienceGames) {
      for (const step of game.steps) {
        // إما audioText موجود أو instruction موجود (يُستخدم كبديل)
        const hasAudio = step.audioText || step.instruction;
        expect(hasAudio).toBeTruthy();
      }
    }
  });

  it("كل تجربة يجب أن تحتوي على أسئلة", () => {
    for (const game of scienceGames) {
      expect(game.questions.length).toBeGreaterThan(0);
    }
  });

  it("كل سؤال يجب أن يحتوي على 4 خيارات", () => {
    for (const game of scienceGames) {
      for (const q of game.questions) {
        expect(q.options.length).toBe(4);
        expect(q.correct).toBeGreaterThanOrEqual(0);
        expect(q.correct).toBeLessThan(4);
      }
    }
  });

  it("كل تجربة يجب أن تحتوي على videoUrl", () => {
    for (const game of scienceGames) {
      expect(game.videoUrl).toBeTruthy();
    }
  });

  it("كل تجربة يجب أن تحتوي على materials", () => {
    for (const game of scienceGames) {
      expect(game.materials.length).toBeGreaterThan(0);
    }
  });

  it("التجارب يجب أن تحتوي على IDs فريدة", () => {
    const ids = scienceGames.map(g => g.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });

  it("كل تجربة يجب أن تحتوي على hypothesisOptions", () => {
    for (const game of scienceGames) {
      if (game.hypothesisOptions) {
        expect(game.hypothesisOptions.length).toBeGreaterThanOrEqual(2);
      }
    }
  });
});
