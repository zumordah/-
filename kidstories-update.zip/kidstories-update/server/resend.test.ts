/**
 * اختبار التحقق من صحة RESEND_API_KEY
 * المفتاح مقيّد بالإرسال فقط (sending-only) - وهو الأنسب لأغراض الموقع
 */
import { describe, it, expect } from "vitest";

describe("Resend API Key Validation", () => {
  it("should have RESEND_API_KEY set in environment", () => {
    const key = process.env.RESEND_API_KEY;
    expect(key).toBeDefined();
    expect(key).not.toBe("");
    expect(key!.startsWith("re_")).toBe(true);
  });

  it("should successfully send a test email via Resend API", async () => {
    const key = process.env.RESEND_API_KEY;
    if (!key) {
      throw new Error("RESEND_API_KEY is not set");
    }

    // إرسال إيميل تجريبي إلى عنوان Resend المخصص للاختبار
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: ["delivered@resend.dev"],
        subject: "اختبار نظام الإيميل - عالم القصص التعليمي",
        html: "<p>هذا إيميل تجريبي للتحقق من عمل نظام الإيميلات.</p>",
      }),
    });

    // 200 أو 201 = تم الإرسال بنجاح
    expect(response.status).toBeLessThan(300);
    const data = await response.json() as any;
    expect(data.id).toBeDefined(); // يجب أن يعيد معرّف الإيميل
  }, 15000);
});
