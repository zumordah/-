import { Request, Response } from "express";
import { storagePut } from "./storage";
import { jwtVerify } from "jose";
import { ENV } from "./_core/env";

// Simple multipart parser using busboy
import busboy from "busboy";

export async function handleUploadImage(req: Request, res: Response) {
  // Verify admin token
  const adminToken = req.headers["x-admin-token"] as string | undefined;
  if (!adminToken) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  try {
    const secret = new TextEncoder().encode(ENV.cookieSecret);
    await jwtVerify(adminToken, secret);
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }

  const contentType = req.headers["content-type"] || "";
  if (!contentType.includes("multipart/form-data")) {
    return res.status(400).json({ error: "Expected multipart/form-data" });
  }

  return new Promise<void>((resolve) => {
    const bb = busboy({ headers: req.headers, limits: { fileSize: 10 * 1024 * 1024 } });
    let fileBuffer: Buffer | null = null;
    let fileMime = "image/jpeg";
    let fileExt = "jpg";

    bb.on("file", (_fieldname, file, info) => {
      fileMime = info.mimeType || "image/jpeg";
      const ext = info.filename?.split(".").pop() || "jpg";
      fileExt = ["jpg", "jpeg", "png", "gif", "webp"].includes(ext.toLowerCase()) ? ext.toLowerCase() : "jpg";
      const chunks: Buffer[] = [];
      file.on("data", (chunk) => chunks.push(chunk));
      file.on("end", () => { fileBuffer = Buffer.concat(chunks); });
    });

    bb.on("finish", async () => {
      if (!fileBuffer) {
        res.status(400).json({ error: "No file uploaded" });
        return resolve();
      }
      try {
        const randomSuffix = Math.random().toString(36).substring(2, 10);
        const key = `story-images/${Date.now()}-${randomSuffix}.${fileExt}`;
        const { url } = await storagePut(key, fileBuffer, fileMime);
        res.json({ url });
      } catch (err: any) {
        res.status(500).json({ error: err.message || "Upload failed" });
      }
      resolve();
    });

    bb.on("error", (err: any) => {
      res.status(500).json({ error: err.message });
      resolve();
    });

    req.pipe(bb);
  });
}
