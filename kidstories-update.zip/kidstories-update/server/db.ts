import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  InsertSiteReview,
  InsertEducationalGame,
  achievements,
  activities,
  activityQuestions,
  childAchievements,
  childActivityResults,
  childStoryProgress,
  childGameProgress,
  childAdventureProgress,
  storyAdventures,
  children,
  stories,
  storyPages,
  users,
  siteReviews,
  educationalGames,
  childUnlockedGames,
  shopItems,
  childInventory,
  childUnlockedAdventures,
  adminAccounts,
  schools,
  schoolClassrooms,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import bcrypt from "bcrypt";

const BCRYPT_ROUNDS = 10;

// تشفير كلمة المرور
async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

// مقارنة كلمة المرور (تدعم النص العادي والمشفّر للتوافق مع البيانات القديمة)
async function comparePassword(plain: string, stored: string): Promise<boolean> {
  if (stored.startsWith("$2b$") || stored.startsWith("$2a$")) {
    return bcrypt.compare(plain, stored);
  }
  // كلمة مرور نص عادي (قديمة) - مقارنة مباشرة
  return plain === stored;
}

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value !== undefined) {
      values[field] = value ?? null;
      updateSet[field] = value ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Children ────────────────────────────────────────────────────────────────
export async function getChildByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(children).where(eq(children.email, email)).limit(1);
  return result[0];
}

export async function createChild(data: {
  name: string;
  email: string;
  ageGroup: "4-6" | "6-8" | "8-10";
  avatarEmoji?: string;
  isKindergartenStudent?: boolean;
  classroom?: string;
  schoolId?: number;
  referralSource?: string;
  gender?: "boy" | "girl";
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(children).values({
    name: data.name,
    email: data.email,
    ageGroup: data.ageGroup,
    avatarEmoji: data.avatarEmoji ?? "🧒",
    isKindergartenStudent: data.isKindergartenStudent ?? false,
    classroom: data.classroom as any,
    referralSource: data.referralSource as any,
    gender: data.gender ?? "boy",
    schoolId: data.schoolId ?? null,
  });
  const result = await db.select().from(children).where(eq(children.email, data.email)).limit(1);
  return result[0];
}

export async function updateChildActivity(childId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(children)
    .set({ lastActiveAt: new Date() })
    .where(eq(children.id, childId));
}

export async function addPointsToChild(childId: number, points: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(children)
    .set({
      totalPoints: sql`${children.totalPoints} + ${points}`,
      lastActiveAt: new Date(),
    })
    .where(eq(children.id, childId));
  // Update level based on points (every 100 points = 1 level)
  const result = await db.select().from(children).where(eq(children.id, childId)).limit(1);
  if (result[0]) {
    const newLevel = Math.floor(result[0].totalPoints / 100) + 1;
    if (newLevel !== result[0].level) {
      await db.update(children).set({ level: newLevel }).where(eq(children.id, childId));
    }
  }
}

export async function getAllChildren() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(children).orderBy(desc(children.createdAt));
}

export async function getChildById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(children).where(eq(children.id, id)).limit(1);
  return result[0];
}

export async function deleteChild(id: number) {
  const db = await getDb();
  if (!db) return;
  // Delete related data first
  await db.delete(childStoryProgress).where(eq(childStoryProgress.childId, id));
  await db.delete(childActivityResults).where(eq(childActivityResults.childId, id));
  await db.delete(childAchievements).where(eq(childAchievements.childId, id));
  await db.delete(childGameProgress).where(eq(childGameProgress.childId, id));
  await db.delete(children).where(eq(children.id, id));
}

// ─── Stories ─────────────────────────────────────────────────────────────────
export async function getAllStories(ageGroup?: string) {
  const db = await getDb();
  if (!db) return [];
  const allStories = await db.select().from(stories).where(eq(stories.isPublished, true)).orderBy(desc(stories.createdAt));
  const storiesWithCover = await Promise.all(
    allStories.map(async (story) => {
      const firstPage = await db
        .select({ imageUrl: storyPages.imageUrl })
        .from(storyPages)
        .where(eq(storyPages.storyId, story.id))
        .orderBy(storyPages.pageNumber)
        .limit(1);
      const firstPageImage = firstPage[0]?.imageUrl || story.coverImage || null;
      return { ...story, firstPageImage };
    })
  );
  return storiesWithCover;
}

export async function getStoryById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(stories).where(eq(stories.id, id)).limit(1);
  return result[0];
}

export async function getStoryPages(storyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(storyPages)
    .where(eq(storyPages.storyId, storyId))
    .orderBy(storyPages.pageNumber);
}

export async function createStory(data: {
  title: string;
  description?: string;
  coverImage?: string;
  ageGroup: "4-6" | "6-8" | "8-10" | "all";
  audioUrl?: string;
  voiceGender?: "male" | "female";
  difficulty?: "easy" | "medium" | "hard";
  pointsReward?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(stories).values(data);
  const result = await db.select().from(stories).orderBy(desc(stories.id)).limit(1);
  return result[0];
}

export async function createStoryPage(data: {
  storyId: number;
  pageNumber: number;
  text: string;
  imageUrl?: string;
  audioUrl?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(storyPages).values(data);
  const count = await db
    .select({ count: sql<number>`count(*)` })
    .from(storyPages)
    .where(eq(storyPages.storyId, data.storyId));
  await db
    .update(stories)
    .set({ totalPages: count[0]?.count ?? 0 })
    .where(eq(stories.id, data.storyId));
}

export async function deleteStory(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(storyPages).where(eq(storyPages.storyId, id));
  await db.delete(childStoryProgress).where(eq(childStoryProgress.storyId, id));
  await db.delete(stories).where(eq(stories.id, id));
}

// ─── Story Progress ───────────────────────────────────────────────────────────
export async function getChildStoryProgress(childId: number, storyId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(childStoryProgress)
    .where(and(eq(childStoryProgress.childId, childId), eq(childStoryProgress.storyId, storyId)))
    .limit(1);
  return result[0] ?? null;
}

export async function upsertStoryProgress(data: {
  childId: number;
  storyId: number;
  currentPage: number;
  isCompleted?: boolean;
  pointsEarned?: number;
}) {
  const db = await getDb();
  if (!db) return;
  const existing = await getChildStoryProgress(data.childId, data.storyId);
  if (existing) {
    const updateData: Record<string, unknown> = {
      currentPage: data.currentPage,
      updatedAt: new Date(),
    };
    if (data.isCompleted !== undefined) updateData.isCompleted = data.isCompleted;
    if (data.isCompleted) updateData.completedAt = new Date();
    if (data.pointsEarned !== undefined) updateData.pointsEarned = data.pointsEarned;
    await db
      .update(childStoryProgress)
      .set(updateData)
      .where(eq(childStoryProgress.id, existing.id));
  } else {
    await db.insert(childStoryProgress).values({
      childId: data.childId,
      storyId: data.storyId,
      currentPage: data.currentPage,
      isCompleted: data.isCompleted ?? false,
      completedAt: data.isCompleted ? new Date() : undefined,
      pointsEarned: data.pointsEarned ?? 0,
    });
  }
}

export async function getChildAllProgress(childId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(childStoryProgress)
    .where(eq(childStoryProgress.childId, childId))
    .orderBy(desc(childStoryProgress.updatedAt));
}

// ─── Activities ───────────────────────────────────────────────────────────────
export async function getActivitiesByStory(storyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(activities)
    .where(and(eq(activities.storyId, storyId), eq(activities.isPublished, true)));
}

export async function getActivityById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(activities).where(eq(activities.id, id)).limit(1);
  return result[0];
}

export async function getActivityQuestions(activityId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(activityQuestions)
    .where(eq(activityQuestions.activityId, activityId))
    .orderBy(activityQuestions.orderIndex);
}

export async function getAllActivities(ageGroup?: string) {
  const db = await getDb();
  if (!db) return [];
  if (ageGroup) {
    return db
      .select()
      .from(activities)
      .where(
        and(
          eq(activities.isPublished, true),
          sql`(${activities.ageGroup} = ${ageGroup} OR ${activities.ageGroup} = 'all')`
        )
      );
  }
  return db.select().from(activities).where(eq(activities.isPublished, true));
}

export async function saveActivityResult(data: {
  childId: number;
  activityId: number;
  score: number;
  maxScore: number;
  isCompleted: boolean;
  pointsEarned: number;
}) {
  const db = await getDb();
  if (!db) return;
  const existing = await db
    .select()
    .from(childActivityResults)
    .where(
      and(
        eq(childActivityResults.childId, data.childId),
        eq(childActivityResults.activityId, data.activityId)
      )
    )
    .limit(1);
  if (existing[0]) {
    await db
      .update(childActivityResults)
      .set({
        score: data.score,
        isCompleted: data.isCompleted,
        completedAt: data.isCompleted ? new Date() : undefined,
        pointsEarned: data.pointsEarned,
        attempts: sql`${childActivityResults.attempts} + 1`,
      })
      .where(eq(childActivityResults.id, existing[0].id));
  } else {
    await db.insert(childActivityResults).values({
      childId: data.childId,
      activityId: data.activityId,
      score: data.score,
      maxScore: data.maxScore,
      isCompleted: data.isCompleted,
      completedAt: data.isCompleted ? new Date() : undefined,
      pointsEarned: data.pointsEarned,
    });
  }
}

export async function getChildActivityResults(childId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(childActivityResults)
    .where(eq(childActivityResults.childId, childId))
    .orderBy(desc(childActivityResults.startedAt));
}

export async function createActivity(data: {
  storyId: number;
  title: string;
  type: "quiz" | "matching" | "puzzle";
  description?: string;
  pointsReward?: number;
  ageGroup?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(activities).values(data as any);
  const result = await db.select().from(activities).orderBy(desc(activities.id)).limit(1);
  return result[0];
}

export async function createActivityQuestion(data: {
  activityId: number;
  questionText: string;
  questionType: "multiple_choice" | "matching" | "puzzle";
  options: any;
  correctAnswer: string;
  explanation?: string;
  orderIndex?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(activityQuestions).values(data);
}

export async function deleteActivity(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(activityQuestions).where(eq(activityQuestions.activityId, id));
  await db.delete(childActivityResults).where(eq(childActivityResults.activityId, id));
  await db.delete(activities).where(eq(activities.id, id));
}

// ─── Achievements ─────────────────────────────────────────────────────────────
export async function getAllAchievements() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(achievements);
}

export async function getChildAchievements(childId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: childAchievements.id,
      childId: childAchievements.childId,
      achievementId: childAchievements.achievementId,
      earnedAt: childAchievements.earnedAt,
      key: achievements.key,
      title: achievements.title,
      description: achievements.description,
      emoji: achievements.emoji,
      pointsReward: achievements.pointsReward,
    })
    .from(childAchievements)
    .innerJoin(achievements, eq(childAchievements.achievementId, achievements.id))
    .where(eq(childAchievements.childId, childId))
    .orderBy(desc(childAchievements.earnedAt));
}

export async function awardAchievement(childId: number, achievementId: number) {
  const db = await getDb();
  if (!db) return false;
  const existing = await db
    .select()
    .from(childAchievements)
    .where(
      and(
        eq(childAchievements.childId, childId),
        eq(childAchievements.achievementId, achievementId)
      )
    )
    .limit(1);
  if (existing[0]) return false;
  await db.insert(childAchievements).values({ childId, achievementId });
  return true;
}

export async function checkAndAwardAchievements(childId: number) {
  const db = await getDb();
  if (!db) return [];
  const child = await getChildById(childId);
  if (!child) return [];

  const allAchievements = await getAllAchievements();
  const earned = await getChildAchievements(childId);
  const earnedIds = new Set(earned.map((e) => e.achievementId));
  const newlyEarned: typeof allAchievements = [];

  const completedStories = await db
    .select({ count: sql<number>`count(*)` })
    .from(childStoryProgress)
    .where(and(eq(childStoryProgress.childId, childId), eq(childStoryProgress.isCompleted, true)));
  const storiesCount = Number(completedStories[0]?.count ?? 0);

  const completedActivities = await db
    .select({ count: sql<number>`count(*)` })
    .from(childActivityResults)
    .where(
      and(eq(childActivityResults.childId, childId), eq(childActivityResults.isCompleted, true))
    );
  const activitiesCount = Number(completedActivities[0]?.count ?? 0);

  for (const achievement of allAchievements) {
    if (earnedIds.has(achievement.id)) continue;
    let isEarned = false;
    const val = achievement.conditionValue ?? 1;
    switch (achievement.condition) {
      case "stories_read":
        isEarned = storiesCount >= val;
        break;
      case "activities_completed":
        isEarned = activitiesCount >= val;
        break;
      case "total_points":
        isEarned = child.totalPoints >= val;
        break;
      case "level_reached":
        isEarned = child.level >= val;
        break;
      case "first_story":
        isEarned = storiesCount >= 1;
        break;
      case "first_activity":
        isEarned = activitiesCount >= 1;
        break;
      case "complete_specific_games": {
        // gameIds stored in description field as "...| gameIds:90006,70021"
        let gameIds: number[] = [];
        const descMatch = achievement.description?.match(/gameIds:([\d,]+)/);
        if (descMatch) {
          gameIds = descMatch[1].split(',').map(Number).filter(Boolean);
        }
        if (!Array.isArray(gameIds) || gameIds.length === 0) break;
        const completedSpecific = await db
          .select({ count: sql<number>`count(distinct ${childGameProgress.gameId})` })
          .from(childGameProgress)
          .where(and(
            eq(childGameProgress.childId, childId),
            eq(childGameProgress.isCompleted, true),
            sql`${childGameProgress.gameId} IN (${gameIds.join(',')})`
          ));
        isEarned = Number(completedSpecific[0]?.count ?? 0) >= gameIds.length;
        break;
      }
    }
    if (isEarned) {
      const isNew = await awardAchievement(childId, achievement.id);
      if (isNew) {
        newlyEarned.push(achievement);
        if (achievement.pointsReward) {
          await addPointsToChild(childId, achievement.pointsReward);
        }
      }
    }
  }
  return newlyEarned;
}

// ─── Admin Stats (FIXED: accurate level calculation) ─────────────────────────
export async function getAdminStats() {
  const db = await getDb();
  if (!db) return null;
  const totalChildren = await db.select({ count: sql<number>`count(*)` }).from(children);
  const totalStories = await db.select({ count: sql<number>`count(*)` }).from(stories);
  const totalActivities = await db.select({ count: sql<number>`count(*)` }).from(activities);
  const totalGames = await db.select({ count: sql<number>`count(*)` }).from(educationalGames);
  const completedReadings = await db
    .select({ count: sql<number>`count(*)` })
    .from(childStoryProgress)
    .where(eq(childStoryProgress.isCompleted, true));
  return {
    totalChildren: Number(totalChildren[0]?.count ?? 0),
    totalStories: Number(totalStories[0]?.count ?? 0),
    totalActivities: Number(totalActivities[0]?.count ?? 0),
    totalGames: Number(totalGames[0]?.count ?? 0),
    completedReadings: Number(completedReadings[0]?.count ?? 0),
  };
}

export async function getChildDetailedStats(childId: number) {
  const db = await getDb();
  if (!db) return null;
  const child = await getChildById(childId);
  if (!child) return null;
  const progress = await getChildAllProgress(childId);
  const activityResults = await getChildActivityResults(childId);
  const earnedAchievements = await getChildAchievements(childId);
  const completedStories = progress.filter((p) => p.isCompleted).length;
  const completedActivities = activityResults.filter((r) => r.isCompleted).length;
  // جلب المشتريات من المتجر
  const inventory = await getChildInventory(childId);
  // جلب الألعاب المفتوحة
  const unlockedGames = await db.select({
    gameId: childUnlockedGames.gameId,
    unlockedAt: childUnlockedGames.unlockedAt,
    gameTitle: educationalGames.title,
    gameEmoji: educationalGames.emoji,
  }).from(childUnlockedGames)
    .innerJoin(educationalGames, eq(childUnlockedGames.gameId, educationalGames.id))
    .where(eq(childUnlockedGames.childId, childId));
  // جلب المغامرات المفتوحة
  const unlockedAdventures = await db.select({
    adventureId: childUnlockedAdventures.adventureId,
    unlockedAt: childUnlockedAdventures.unlockedAt,
    adventureTitle: storyAdventures.title,
    adventureEmoji: storyAdventures.emoji,
  }).from(childUnlockedAdventures)
    .innerJoin(storyAdventures, eq(childUnlockedAdventures.adventureId, storyAdventures.id))
    .where(eq(childUnlockedAdventures.childId, childId));
  return {
    child,
    completedStories,
    completedActivities,
    totalAchievements: earnedAchievements.length,
    achievements: earnedAchievements,
    recentProgress: progress.slice(0, 5),
    inventory,
    unlockedGames,
    unlockedAdventures,
  };
}

//// ─── Leaderboard ─────────────────────────────────────────────────────
/**
 * جلب أعلى الأطفال نقاطاً.
 * - إذا كان الطفل من داخل الروضة (isKindergartenStudent=true) يتم الفلترة حسب فصله فقط.
 * - إذا كان من خارج الروضة يظهر جميع الأطفال.
 */
export async function getTopChildren(
  limit = 5,
  opts?: { isKindergarten?: boolean; classroom?: string | null }
) {
  const db = await getDb();
  if (!db) return [];

  const conditions: any[] = [];

  // إذا كان من داخل الروضة ولديه فصل محدد → فلتر حسب الفصل
  if (opts?.isKindergarten && opts?.classroom) {
    conditions.push(
      eq(children.isKindergartenStudent, true),
      eq(children.classroom, opts.classroom as any)
    );
  }
  // إذا كان من داخل الروضة بدون فصل → فلتر داخل الروضة فقط
  else if (opts?.isKindergarten && !opts?.classroom) {
    conditions.push(eq(children.isKindergartenStudent, true));
  }
  // إذا كان من خارج الروضة → لا فلترة (يظهر الجميع)

  const query = db
    .select({
      id: children.id,
      name: children.name,
      avatarEmoji: children.avatarEmoji,
      totalPoints: children.totalPoints,
      level: children.level,
      classroom: children.classroom,
      isKindergartenStudent: children.isKindergartenStudent,
    })
    .from(children);

  if (conditions.length > 0) {
    return query.where(and(...conditions)).orderBy(desc(children.totalPoints)).limit(limit);
  }
  return query.orderBy(desc(children.totalPoints)).limit(limit);
}

// ─── Site Reviews ───────────────────────────────────────────────────────────
export async function createReview(data: InsertSiteReview) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(siteReviews).values(data);
  return true;
}

export async function getApprovedReviews() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(siteReviews)
    .where(and(eq(siteReviews.isApproved, true), eq(siteReviews.isDeleted, false)))
    .orderBy(siteReviews.createdAt);
}

export async function getAllReviewsAdmin() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(siteReviews)
    .where(eq(siteReviews.isDeleted, false))
    .orderBy(siteReviews.createdAt);
}

export async function approveReview(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(siteReviews).set({ isApproved: true }).where(eq(siteReviews.id, id));
}

export async function deleteReview(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(siteReviews).set({ isDeleted: true }).where(eq(siteReviews.id, id));
}

// ─── Educational Games ────────────────────────────────────────────────────────
export async function getAllEducationalGames(level?: "easy" | "medium" | "hard") {
  const db = await getDb();
  if (!db) return [];
  if (level) {
    return db.select().from(educationalGames)
      .where(and(eq(educationalGames.level, level), eq(educationalGames.isPublished, true)))
      .orderBy(educationalGames.orderIndex, educationalGames.id);
  }
  return db.select().from(educationalGames)
    .where(eq(educationalGames.isPublished, true))
    .orderBy(educationalGames.level, educationalGames.orderIndex);
}

export async function getEducationalGameById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(educationalGames).where(eq(educationalGames.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createEducationalGame(data: {
  title: string;
  description?: string;
  type: string;
  level: "easy" | "medium" | "hard";
  ageGroup?: string;
  emoji?: string;
  pointsReward?: number;
  gameData: any;
  orderIndex?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(educationalGames).values(data as any);
  const result = await db.select().from(educationalGames).orderBy(desc(educationalGames.id)).limit(1);
  return result[0];
}

export async function updateEducationalGame(id: number, data: Partial<{
  title: string;
  description: string;
  type: string;
  level: "easy" | "medium" | "hard";
  emoji: string;
  pointsReward: number;
  gameData: any;
  isPublished: boolean;
  orderIndex: number;
}>) {
  const db = await getDb();
  if (!db) return;
  await db.update(educationalGames).set(data as any).where(eq(educationalGames.id, id));
}

export async function deleteEducationalGame(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(childGameProgress).where(eq(childGameProgress.gameId, id));
  await db.delete(educationalGames).where(eq(educationalGames.id, id));
}

export async function getAllEducationalGamesAdmin() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(educationalGames)
    .orderBy(educationalGames.level, educationalGames.orderIndex);
}

export async function saveGameProgress(data: {
  childId: number;
  gameId: number;
  score: number;
  maxScore: number;
  isCompleted: boolean;
  pointsEarned: number;
}) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(childGameProgress)
    .where(and(eq(childGameProgress.childId, data.childId), eq(childGameProgress.gameId, data.gameId)))
    .limit(1);
  if (existing.length > 0) {
    await db.update(childGameProgress)
      .set({
        score: data.score,
        maxScore: data.maxScore,
        isCompleted: data.isCompleted,
        pointsEarned: data.pointsEarned,
        completedAt: data.isCompleted ? new Date() : existing[0].completedAt,
        attempts: (existing[0].attempts ?? 1) + 1,
      })
      .where(eq(childGameProgress.id, existing[0].id));
  } else {
    await db.insert(childGameProgress).values({
      ...data,
      completedAt: data.isCompleted ? new Date() : undefined,
    });
  }
  // Award points if completed
  if (data.isCompleted && data.pointsEarned > 0) {
    await addPointsToChild(data.childId, data.pointsEarned);
  }
}

export async function getChildGameProgressList(childId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(childGameProgress).where(eq(childGameProgress.childId, childId));
}

// ─── Story Adventures ─────────────────────────────────────────────────────────
export async function getAllAdventures(level?: string) {
  const db = await getDb();
  if (!db) return [];
  if (level) {
    return db.select().from(storyAdventures)
      .where(and(eq(storyAdventures.isPublished, true), eq(storyAdventures.level, level as "easy" | "medium" | "hard")))
      .orderBy(storyAdventures.orderIndex, storyAdventures.id);
  }
  return db.select().from(storyAdventures)
    .where(eq(storyAdventures.isPublished, true))
    .orderBy(storyAdventures.orderIndex, storyAdventures.id);
}

export async function getAdventureById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(storyAdventures).where(eq(storyAdventures.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getChildAdventureProgressList(childId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(childAdventureProgress).where(eq(childAdventureProgress.childId, childId));
}

export async function saveAdventureProgress(data: {
  childId: number;
  adventureId: number;
  isCompleted: boolean;
  endingKey: string;
  pointsEarned: number;
  choices: string[];
}) {
  const db = await getDb();
  if (!db) return { pointsEarned: 0, isNewEnding: false };
  const existing = await db.select().from(childAdventureProgress)
    .where(and(eq(childAdventureProgress.childId, data.childId), eq(childAdventureProgress.adventureId, data.adventureId)))
    .limit(1);

  if (existing.length > 0) {
    const prev = existing[0];
    const prevEndings: string[] = (prev.endingsDiscovered as string[]) ?? [];
    const newEndings = prevEndings.includes(data.endingKey) ? prevEndings : [...prevEndings, data.endingKey];
    const bonusPoints = !prevEndings.includes(data.endingKey) ? 20 : 5; // new ending +20, replay +5
    const totalPoints = (prev.pointsEarned ?? 0) + bonusPoints;
    await db.update(childAdventureProgress)
      .set({
        isCompleted: true,
        endingsDiscovered: newEndings,
        pointsEarned: totalPoints,
        attempts: (prev.attempts ?? 1) + 1,
        lastChoices: data.choices,
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(childAdventureProgress.id, prev.id));
    await addPointsToChild(data.childId, bonusPoints);
    return { pointsEarned: bonusPoints, isNewEnding: !prevEndings.includes(data.endingKey) };
  } else {
    const pts = data.pointsEarned;
    await db.insert(childAdventureProgress).values({
      childId: data.childId,
      adventureId: data.adventureId,
      isCompleted: data.isCompleted,
      endingsDiscovered: [data.endingKey],
      pointsEarned: pts,
      attempts: 1,
      lastChoices: data.choices,
      completedAt: data.isCompleted ? new Date() : undefined,
    });
    if (data.isCompleted && pts > 0) {
      await addPointsToChild(data.childId, pts);
    }
    return { pointsEarned: pts, isNewEnding: true };
  }
}

// ─── Daily Challenges ──────────────────────────────────────────────────────────
// يختار قصة/لعبة/مغامرة يومية حسب مستوى الطفل مع تنويع يومي
export async function getTodayChallenge(childLevel: number = 1) {
  const db = await getDb();
  if (!db) return null;
  const { dailyChallenges, stories, educationalGames, storyAdventures } = await import("../drizzle/schema.js");
  const today = new Date().toISOString().slice(0, 10);
  // مفتاح فريد لكل مستوى في نفس اليوم
  const levelKey = `${today}-L${childLevel}`;
  const [row] = await db.select().from(dailyChallenges).where(eq(dailyChallenges.dateKey, levelKey));
  if (row) return row;
  // تحديد مستوى المحتوى حسب مستوى الطفل (قيم enum: easy/medium/hard)
  const gameLevel: 'easy' | 'medium' | 'hard' = childLevel <= 3 ? 'easy' : childLevel <= 6 ? 'medium' : 'hard';
  const adventureLevel: 'easy' | 'medium' | 'hard' = gameLevel;
  // مستوى القصص (easy/medium/hard - نفس قيم enum جدول stories)
  const storyDifficulty: 'easy' | 'medium' | 'hard' = gameLevel;
  // اختيار قصة من المستوى المناسب
  const allStories = await db.select({ id: stories.id }).from(stories)
    .where(eq(stories.difficulty, storyDifficulty));
  // اختيار لعبة من المستوى المناسب
  const allGames = await db.select({ id: educationalGames.id }).from(educationalGames)
    .where(eq(educationalGames.level, gameLevel));
  // اختيار مغامرة من المستوى المناسب
  const allAdventures = await db.select({ id: storyAdventures.id }).from(storyAdventures)
    .where(and(eq(storyAdventures.level, adventureLevel), eq(storyAdventures.isPublished, true)));
  // استخدام تاريخ اليوم كبذرة للاختيار العشوائي المتسق
  const dayNum = parseInt(today.replace(/-/g, ''), 10);
  const pickItem = (arr: { id: number }[]) => arr.length > 0 ? arr[dayNum % arr.length].id : null;
  const storyId = pickItem(allStories);
  const gameId = pickItem(allGames);
  const adventureId = pickItem(allAdventures);
  // إنشاء تحدي اليوم للمستوى
  await db.insert(dailyChallenges).values({
    dateKey: levelKey,
    readStoryId: storyId,
    playGameId: gameId,
    playAdventureId: adventureId,
    bonusPoints: 50 + (childLevel * 5), // نقاط إضافية للمستويات الأعلى
  });
  const [created] = await db.select().from(dailyChallenges).where(eq(dailyChallenges.dateKey, levelKey));
  return created;
}

export async function getChildDailyChallengeProgress(childId: number) {
  const db = await getDb();
  if (!db) return null;
  const { childDailyChallengeProgress } = await import("../drizzle/schema.js");
  const today = new Date().toISOString().slice(0, 10);
  const [row] = await db.select().from(childDailyChallengeProgress)
    .where(and(eq(childDailyChallengeProgress.childId, childId), eq(childDailyChallengeProgress.dateKey, today)));
  return row ?? null;
}

export async function markChallengeTask(childId: number, task: "readStory" | "playGame" | "playAdventure") {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const { childDailyChallengeProgress, dailyChallenges } = await import("../drizzle/schema.js");
  const today = new Date().toISOString().slice(0, 10);

  // Ensure progress row exists
  let [progress] = await db.select().from(childDailyChallengeProgress)
    .where(and(eq(childDailyChallengeProgress.childId, childId), eq(childDailyChallengeProgress.dateKey, today)));

  if (!progress) {
    await db.insert(childDailyChallengeProgress).values({ childId, dateKey: today });
    [progress] = await db.select().from(childDailyChallengeProgress)
      .where(and(eq(childDailyChallengeProgress.childId, childId), eq(childDailyChallengeProgress.dateKey, today)));
  }

  const updateData: Record<string, boolean | Date> = {};
  if (task === "readStory" && !progress.readStoryDone) updateData.readStoryDone = true;
  if (task === "playGame" && !progress.playGameDone) updateData.playGameDone = true;
  if (task === "playAdventure" && !progress.playAdventureDone) updateData.playAdventureDone = true;

  if (Object.keys(updateData).length > 0) {
    await db.update(childDailyChallengeProgress).set(updateData)
      .where(and(eq(childDailyChallengeProgress.childId, childId), eq(childDailyChallengeProgress.dateKey, today)));
  }

  // Re-fetch updated progress
  const [updated] = await db.select().from(childDailyChallengeProgress)
    .where(and(eq(childDailyChallengeProgress.childId, childId), eq(childDailyChallengeProgress.dateKey, today)));

  // Check if all done and bonus not yet awarded
  if (updated.readStoryDone && updated.playGameDone && updated.playAdventureDone && !updated.bonusAwarded) {
    const [challenge] = await db.select().from(dailyChallenges).where(eq(dailyChallenges.dateKey, today));
    const bonus = challenge?.bonusPoints ?? 50;
    await addPointsToChild(childId, bonus);
    await db.update(childDailyChallengeProgress)
      .set({ bonusAwarded: true, completedAt: new Date() })
      .where(and(eq(childDailyChallengeProgress.childId, childId), eq(childDailyChallengeProgress.dateKey, today)));
    return { allDone: true, bonusAwarded: bonus };
  }

  return { allDone: false, bonusAwarded: 0 };
}

// ─── Leaderboard ───────────────────────────────────────────────────────────────
export async function getLeaderboard(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  const { children } = await import("../drizzle/schema.js");
  return db.select({
    id: children.id,
    name: children.name,
    avatarEmoji: children.avatarEmoji,
    totalPoints: children.totalPoints,
    level: children.level,
    readingStreak: children.readingStreak,
  }).from(children).orderBy(desc(children.totalPoints)).limit(limit);
}

// ─── Shop ──────────────────────────────────────────────────────────────────────
export async function getShopItems(type?: string) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(shopItems).where(eq(shopItems.isEnabled, true));
  return query.orderBy(shopItems.levelRequired, shopItems.sortOrder);
}

export async function getAllShopItems() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(shopItems).orderBy(shopItems.type, shopItems.levelRequired);
}

export async function upsertShopItem(data: {
  id?: number; type: string; name: string; description?: string;
  icon?: string; value: string; levelRequired: number; pointsCost: number;
  isEnabled: boolean; sortOrder?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (data.id) {
    await db.update(shopItems).set({ ...data } as any).where(eq(shopItems.id, data.id));
    return data.id;
  } else {
    const [result] = await db.insert(shopItems).values({ ...data } as any);
    return (result as any).insertId;
  }
}

export async function deleteShopItem(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(shopItems).where(eq(shopItems.id, id));
}

export async function getChildInventory(childId: number) {
  const db = await getDb();
  if (!db) return [];
  // childInventory and shopItems imported at top
  return db.select({
    id: childInventory.id,
    shopItemId: childInventory.shopItemId,
    acquiredVia: childInventory.acquiredVia,
    isEquipped: childInventory.isEquipped,
    acquiredAt: childInventory.acquiredAt,
    itemType: shopItems.type,
    itemName: shopItems.name,
    itemIcon: shopItems.icon,
    itemValue: shopItems.value,
  }).from(childInventory)
    .innerJoin(shopItems, eq(childInventory.shopItemId, shopItems.id))
    .where(eq(childInventory.childId, childId));
}

export async function purchaseShopItem(childId: number, shopItemId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const { shopItems, childInventory, children } = await import("../drizzle/schema.js");
  const [item] = await db.select().from(shopItems).where(eq(shopItems.id, shopItemId));
  if (!item) throw new Error("Item not found");

  const [child] = await db.select().from(children).where(eq(children.id, childId));
  if (!child) throw new Error("Child not found");

  if (child.level < item.levelRequired) throw new Error("Level too low");
  if (child.totalPoints < item.pointsCost) throw new Error("Not enough points");

  // Check already owned
  const [owned] = await db.select().from(childInventory)
    .where(and(eq(childInventory.childId, childId), eq(childInventory.shopItemId, shopItemId)));
  if (owned) throw new Error("Already owned");

  // Deduct points if cost > 0
  if (item.pointsCost > 0) {
    await db.update(children).set({ totalPoints: child.totalPoints - item.pointsCost }).where(eq(children.id, childId));
  }

  await db.insert(childInventory).values({ childId, shopItemId, acquiredVia: "purchase" });
  return { success: true };
}

export async function grantLevelReward(childId: number, level: number, shopItemId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const { childInventory, childLevelRewards } = await import("../drizzle/schema.js");

  // Check already granted this level
  const [existing] = await db.select().from(childLevelRewards)
    .where(and(eq(childLevelRewards.childId, childId), eq(childLevelRewards.level, level)));
  if (existing) return { alreadyGranted: true };

  await db.insert(childInventory).values({ childId, shopItemId, acquiredVia: "level_reward" });
  await db.insert(childLevelRewards).values({ childId, level, shopItemId });
  return { success: true };
}

export async function equipShopItem(childId: number, shopItemId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // childInventory and shopItems imported at top
  const [item] = await db.select().from(shopItems).where(eq(shopItems.id, shopItemId));
  if (!item) throw new Error("Item not found");

  // Unequip all items of same type
  const allOwned = await db.select({ id: childInventory.id, shopItemId: childInventory.shopItemId })
    .from(childInventory).where(eq(childInventory.childId, childId));

  for (const owned of allOwned) {
    const [ownedItem] = await db.select({ type: shopItems.type }).from(shopItems).where(eq(shopItems.id, owned.shopItemId));
    if (ownedItem?.type === item.type) {
      await db.update(childInventory).set({ isEquipped: false }).where(eq(childInventory.id, owned.id));
    }
  }

  // Equip selected
  await db.update(childInventory).set({ isEquipped: true })
    .where(and(eq(childInventory.childId, childId), eq(childInventory.shopItemId, shopItemId)));

  // If avatar, update child avatarEmoji
  if (item.type === "avatar") {
    const { children } = await import("../drizzle/schema.js");
    await db.update(children).set({ avatarEmoji: item.value }).where(eq(children.id, childId));
  }

  return { success: true };
}

export async function adminAdjustChild(childId: number, data: { points?: number; level?: number }) {
  const db = await getDb();
  if (!db) return;
  const { children } = await import("../drizzle/schema.js");
  const updateData: Record<string, number> = {};
  if (data.points !== undefined) updateData.totalPoints = data.points;
  if (data.level !== undefined) updateData.level = data.level;
  await db.update(children).set(updateData).where(eq(children.id, childId));
}

// ─── Locked Games ───────────────────────────────────────────────────────────────────────────────────────
export async function getLockedGames() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(educationalGames)
    .where(and(eq(educationalGames.isLocked, true), eq(educationalGames.isPublished, true)))
    .orderBy(educationalGames.level, educationalGames.lockCost);
}
export async function getChildUnlockedGameIds(childId: number): Promise<number[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ gameId: childUnlockedGames.gameId })
    .from(childUnlockedGames)
    .where(eq(childUnlockedGames.childId, childId));
  return rows.map((r) => r.gameId);
}
export async function unlockGameWithPoints(childId: number, gameId: number): Promise<{ success: boolean; message: string }> {
  const db = await getDb();
  if (!db) return { success: false, message: "خطأ في قاعدة البيانات" };
  // التحقق من اللعبة
  const [game] = await db.select().from(educationalGames).where(eq(educationalGames.id, gameId)).limit(1);
  if (!game) return { success: false, message: "اللعبة غير موجودة" };
  if (!game.isLocked) return { success: false, message: "اللعبة ليست مقفلة" };
  // التحقق من عدم الفتح مسبقاً
  const alreadyUnlocked = await db.select().from(childUnlockedGames)
    .where(and(eq(childUnlockedGames.childId, childId), eq(childUnlockedGames.gameId, gameId)))
    .limit(1);
  if (alreadyUnlocked.length > 0) return { success: false, message: "اللعبة مفتوحة بالفعل" };
  // التحقق من النقاط
  const [child] = await db.select().from(children).where(eq(children.id, childId)).limit(1);
  if (!child) return { success: false, message: "الطفل غير موجود" };
  if (child.totalPoints < game.lockCost) return { success: false, message: `تحتاج إلى ${game.lockCost} نقطة لفتح هذه اللعبة` };
  // خصم النقاط وأضف للمفتوحة
  await db.update(children).set({ totalPoints: child.totalPoints - game.lockCost }).where(eq(children.id, childId));
  await db.insert(childUnlockedGames).values({ childId, gameId });
  return { success: true, message: `تم فتح اللعبة بنجاح! تم خصم ${game.lockCost} نقطة` };
}
export async function seedShopItems() {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select({ id: shopItems.id }).from(shopItems).limit(1);
  if (existing.length > 0) return;
  await db.insert(shopItems).values([
    // Avatars
    { type: "avatar", name: "نجمة ذهبية", icon: "⭐", value: "⭐", levelRequired: 3, pointsCost: 0, sortOrder: 1 },
    { type: "avatar", name: "بريق متألق", icon: "✨", value: "✨", levelRequired: 5, pointsCost: 0, sortOrder: 2 },
    { type: "avatar", name: "تاج ملكي", icon: "👑", value: "👑", levelRequired: 8, pointsCost: 0, sortOrder: 3 },
    { type: "avatar", name: "أسد شجاع", icon: "🦁", value: "🦁", levelRequired: 4, pointsCost: 50, sortOrder: 4 },
    { type: "avatar", name: "فراشة جميلة", icon: "🦋", value: "🦋", levelRequired: 3, pointsCost: 30, sortOrder: 5 },
    { type: "avatar", name: "صاروخ فضائي", icon: "🚀", value: "🚀", levelRequired: 6, pointsCost: 80, sortOrder: 6 },
    // Themes
    { type: "theme", name: "سماء الليل", icon: "🌙", value: "from-indigo-900 to-purple-900", levelRequired: 2, pointsCost: 20, sortOrder: 1 },
    { type: "theme", name: "غروب الشمس", icon: "🌅", value: "from-orange-400 to-pink-500", levelRequired: 3, pointsCost: 30, sortOrder: 2 },
    { type: "theme", name: "غابة خضراء", icon: "🌿", value: "from-green-500 to-emerald-700", levelRequired: 4, pointsCost: 40, sortOrder: 3 },
    { type: "theme", name: "بحر أزرق", icon: "🌊", value: "from-blue-400 to-cyan-600", levelRequired: 5, pointsCost: 50, sortOrder: 4 },
    { type: "theme", name: "كون بنفسجي", icon: "🔮", value: "from-purple-500 to-violet-800", levelRequired: 7, pointsCost: 70, sortOrder: 5 },
    // Adventure unlocks (levels 1-10)
    { type: "adventure_unlock", name: "مغامرة المستوى 2", icon: "🧩", value: "level_2", levelRequired: 2, pointsCost: 0, sortOrder: 1 },
    { type: "adventure_unlock", name: "مغامرة المستوى 3", icon: "🧩", value: "level_3", levelRequired: 3, pointsCost: 0, sortOrder: 2 },
    { type: "adventure_unlock", name: "مغامرة المستوى 4", icon: "🧩", value: "level_4", levelRequired: 4, pointsCost: 0, sortOrder: 3 },
    { type: "adventure_unlock", name: "مغامرة المستوى 5", icon: "🧩", value: "level_5", levelRequired: 5, pointsCost: 0, sortOrder: 4 },
  ] as any[]);
}

// ─── Locked Adventures ────────────────────────────────────────────────────────
export async function getLockedAdventures() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: storyAdventures.id,
    title: storyAdventures.title,
    emoji: storyAdventures.emoji,
    level: storyAdventures.level,
    lockCost: (storyAdventures as any).lockCost,
  }).from(storyAdventures)
    .where(and(eq((storyAdventures as any).isLocked, true), eq(storyAdventures.isPublished, true)))
    .orderBy(storyAdventures.level, (storyAdventures as any).lockCost);
}
export async function getChildUnlockedAdventureIds(childId: number): Promise<number[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ adventureId: childUnlockedAdventures.adventureId })
    .from(childUnlockedAdventures)
    .where(eq(childUnlockedAdventures.childId, childId));
  return rows.map((r) => r.adventureId);
}
export async function unlockAdventureWithPoints(childId: number, adventureId: number): Promise<{ success: boolean; message: string }> {
  const db = await getDb();
  if (!db) return { success: false, message: "خطأ في قاعدة البيانات" };
  const [adv] = await db.select().from(storyAdventures).where(eq(storyAdventures.id, adventureId)).limit(1);
  if (!adv) return { success: false, message: "المغامرة غير موجودة" };
  if (!(adv as any).isLocked) return { success: false, message: "المغامرة ليست مقفلة" };
  const alreadyUnlocked = await db.select().from(childUnlockedAdventures)
    .where(and(eq(childUnlockedAdventures.childId, childId), eq(childUnlockedAdventures.adventureId, adventureId)))
    .limit(1);
  if (alreadyUnlocked.length > 0) return { success: false, message: "المغامرة مفتوحة بالفعل" };
  const [child] = await db.select().from(children).where(eq(children.id, childId)).limit(1);
  if (!child) return { success: false, message: "الطفل غير موجود" };
  const cost = (adv as any).lockCost ?? 0;
  if (child.totalPoints < cost) return { success: false, message: `تحتاج إلى ${cost} نقطة لفتح هذه المغامرة` };
  await db.update(children).set({ totalPoints: child.totalPoints - cost }).where(eq(children.id, childId));
  await db.insert(childUnlockedAdventures).values({ childId, adventureId });
  return { success: true, message: `تم فتح المغامرة بنجاح! تم خصم ${cost} نقطة` };
}

// ─── Admin Accounts (Multi-admin) ────────────────────────────────────────────
export async function getAllAdminAccounts() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: adminAccounts.id,
    email: adminAccounts.email,
    name: adminAccounts.name,
    addedBy: adminAccounts.addedBy,
    isActive: adminAccounts.isActive,
    createdAt: adminAccounts.createdAt,
  }).from(adminAccounts).orderBy(adminAccounts.createdAt);
}

export async function addAdminAccount(email: string, name: string, password: string, addedBy: string) {
  const db = await getDb();
  if (!db) throw new Error("DB error");
  const hashedPassword = await hashPassword(password);
  await db.insert(adminAccounts).values({ email, name, password: hashedPassword, addedBy });
}

export async function removeAdminAccount(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB error");
  await db.delete(adminAccounts).where(eq(adminAccounts.id, id));
}

export async function validateAdminLogin(email: string, password: string) {
  const db = await getDb();
  if (!db) return null;
  const [admin] = await db.select().from(adminAccounts)
    .where(and(eq(adminAccounts.email, email), eq(adminAccounts.isActive, true)))
    .limit(1);
  if (!admin) return null;
  const isValid = await comparePassword(password, admin.password);
  if (!isValid) return null;
  return { email: admin.email, name: admin.name };
}

// ─── Schools & Classrooms ─────────────────────────────────────────────────────
export async function createSchool(data: { name: string; email: string; adminEmail: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB error");
  await db.insert(schools).values(data);
  const [school] = await db.select().from(schools).where(eq(schools.email, data.email)).limit(1);
  return school;
}
export async function getAllSchools() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schools).orderBy(desc(schools.createdAt));
}
export async function getSchoolById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const [school] = await db.select().from(schools).where(eq(schools.id, id)).limit(1);
  return school ?? null;
}
export async function getSchoolByAdminEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const [school] = await db.select().from(schools).where(eq(schools.adminEmail, email)).limit(1);
  return school ?? null;
}
export async function deleteSchool(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB error");
  await db.delete(schoolClassrooms).where(eq(schoolClassrooms.schoolId, id));
  await db.delete(schools).where(eq(schools.id, id));
}
export async function addSchoolClassroom(schoolId: number, name: string) {
  const db = await getDb();
  if (!db) throw new Error("DB error");
  await db.insert(schoolClassrooms).values({ schoolId, name });
}
export async function getSchoolClassrooms(schoolId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schoolClassrooms).where(eq(schoolClassrooms.schoolId, schoolId));
}
export async function deleteSchoolClassroom(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB error");
  await db.delete(schoolClassrooms).where(eq(schoolClassrooms.id, id));
}
export async function getSchoolStats(schoolId: number) {
  const db = await getDb();
  if (!db) return null;
  // Get all children in this school
  const schoolChildren = await db.select().from(children)
    .where(eq(children.schoolId, schoolId));
  const childIds = schoolChildren.map((c: any) => c.id);
  if (childIds.length === 0) return {
    children: [], students: [], totalChildren: 0, avgPoints: 0, topChildren: [],
    classrooms: [], classroomStats: [], gameProgress: []
  };
  // Get story progress counts per child
  const storyProgressRows = await db.select().from(childStoryProgress)
    .where(sql`childId IN (${sql.join(childIds.map((id: number) => sql`${id}`), sql`, `)})`);
  // Get game progress for these children
  const gameProgress = await db.select().from(childGameProgress)
    .where(sql`childId IN (${sql.join(childIds.map((id: number) => sql`${id}`), sql`, `)})`);
  const totalPoints = schoolChildren.reduce((sum: number, c: any) => sum + (c.totalPoints || 0), 0);
  const avgPoints = schoolChildren.length > 0 ? Math.round(totalPoints / schoolChildren.length) : 0;
  const topChildren = [...schoolChildren]
    .sort((a: any, b: any) => (b.totalPoints || 0) - (a.totalPoints || 0))
    .slice(0, 10);
  // Build enriched students array
  const students = schoolChildren.map((c: any) => ({
    ...c,
    storiesRead: storyProgressRows.filter((sp: any) => sp.childId === c.id && sp.isCompleted).length,
    gamesPlayed: gameProgress.filter((gp: any) => gp.childId === c.id).length,
  }));
  // Build per-classroom stats
  const classroomNames: string[] = Array.from(
    new Set(schoolChildren.map((c: any) => c.classroom).filter(Boolean))
  ) as string[];
  const classroomStats = classroomNames.map((name: string) => {
    const cls = students.filter((s: any) => s.classroom === name);
    const clsPoints = cls.reduce((sum: number, s: any) => sum + (s.totalPoints || 0), 0);
    const clsAvg = cls.length > 0 ? Math.round(clsPoints / cls.length) : 0;
    const topStudent = [...cls].sort((a: any, b: any) => (b.totalPoints || 0) - (a.totalPoints || 0))[0];
    return {
      name,
      count: cls.length,
      totalPoints: clsPoints,
      avgPoints: clsAvg,
      storiesRead: cls.reduce((sum: number, s: any) => sum + (s.storiesRead || 0), 0),
      gamesPlayed: cls.reduce((sum: number, s: any) => sum + (s.gamesPlayed || 0), 0),
      topStudent: topStudent ? { name: topStudent.name, points: topStudent.totalPoints, avatarEmoji: topStudent.avatarEmoji, avatarUrl: topStudent.avatarUrl } : null,
      students: cls,
    };
  });
  // Legacy classrooms field for backward compat
  const classrooms = classroomStats.map((c: any) => ({ name: c.name, count: c.count }));
  return {
    children: schoolChildren,
    students,
    totalChildren: schoolChildren.length,
    avgPoints,
    topChildren,
    gameProgress,
    classrooms,
    classroomStats,
  };
}
export async function getAllSchoolsStats() {
  const db = await getDb();
  if (!db) return [];
  const allSchools = await db.select().from(schools);
  const results = [];
  for (const school of allSchools) {
    const stats = await getSchoolStats(school.id);
    results.push({ school, stats });
  }
  return results;
}
export async function validateAdminLoginWithRole(email: string, password: string) {
  const db = await getDb();
  if (!db) return null;
  const [admin] = await db.select().from(adminAccounts)
    .where(and(eq(adminAccounts.email, email), eq(adminAccounts.isActive, true)))
    .limit(1);
  if (!admin) return null;
  const isValid = await comparePassword(password, admin.password);
  if (!isValid) return null;
  const role = admin.role ?? 'school_admin';
  const schoolId = admin.schoolId ?? null;
  let school = null;
  if (schoolId) {
    school = await getSchoolById(schoolId);
  }
  return { email: admin.email, name: admin.name, role, schoolId, school };
}

// ─── Admin: Get Today's Challenge with Content Names ──────────────────────────
export async function getTodayChallengeAdmin() {
  const db = await getDb();
  if (!db) return [];
  const { dailyChallenges, stories, educationalGames, storyAdventures } = await import("../drizzle/schema.js");
  const today = new Date().toISOString().slice(0, 10);
  const rows = await db.select().from(dailyChallenges)
    .where(sql`${dailyChallenges.dateKey} LIKE ${today + '%'}`)
    .orderBy(dailyChallenges.dateKey);
  if (!rows.length) return [];
  const allStories = await db.select({ id: stories.id, title: stories.title, isPublished: stories.isPublished }).from(stories);
  const allGames = await db.select({ id: educationalGames.id, title: educationalGames.title, isLocked: educationalGames.isLocked, isPublished: educationalGames.isPublished }).from(educationalGames);
  const allAdventures = await db.select({ id: storyAdventures.id, title: storyAdventures.title, isLocked: storyAdventures.isLocked, isPublished: storyAdventures.isPublished }).from(storyAdventures);
  return rows.map(row => {
    const story = row.readStoryId ? allStories.find(s => s.id === row.readStoryId) : null;
    const game = row.playGameId ? allGames.find(g => g.id === row.playGameId) : null;
    const adventure = row.playAdventureId ? allAdventures.find(a => a.id === row.playAdventureId) : null;
    return {
      ...row,
      storyTitle: story?.title ?? null,
      storyLocked: story ? !story.isPublished : false,
      gameTitle: game?.title ?? null,
      gameLocked: game?.isLocked ?? false,
      adventureTitle: adventure?.title ?? null,
      adventureLocked: adventure?.isLocked ?? false,
    };
  });
}
// ─── Admin: Get Shop Items with Purchase Count ────────────────────────────────
export async function getAllShopItemsWithPurchaseCount() {
  const db = await getDb();
  if (!db) return [];
  const { shopItems, childInventory } = await import("../drizzle/schema.js");
  const items = await db.select().from(shopItems).orderBy(shopItems.type, shopItems.levelRequired);
  const purchaseCounts = await db
    .select({
      shopItemId: childInventory.shopItemId,
      count: sql`COUNT(*)`,
    })
    .from(childInventory)
    .where(eq(childInventory.acquiredVia, 'purchase'))
    .groupBy(childInventory.shopItemId);
  const countMap = Object.fromEntries(purchaseCounts.map((r: any) => [r.shopItemId, Number(r.count)]));
  return items.map(item => ({ ...item, purchaseCount: countMap[item.id] ?? 0 }));
}
