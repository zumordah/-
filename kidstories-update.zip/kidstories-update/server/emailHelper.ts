/**
 * Email Helper - Resend Integration
 * لإرسال الإيميلات عبر Resend (resend.com)
 * RESEND_API_KEY مُضاف كـ secret في المشروع
 */

const RESEND_API_KEY = process.env.RESEND_API_KEY;
// استخدام عنوان Resend الافتراضي مؤقتاً حتى يتم التحقق من الدومين الخاص
// لتفعيل الدومين الخاص: https://resend.com/domains → أضف kidstories-92plgnvs.manus.space
const FROM_EMAIL = "onboarding@resend.dev";
const FROM_NAME = "عالم القصص التعليمي";
const SITE_URL = "https://kidstories-92plgnvs.manus.space";

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  if (!RESEND_API_KEY) {
    console.log("[Email] RESEND_API_KEY not set - email not sent to:", options.to);
    console.log("[Email] Subject:", options.subject);
    return false;
  }

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: `${FROM_NAME} <${FROM_EMAIL}>`,
        to: [options.to],
        subject: options.subject,
        html: options.html,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[Email] Send failed:", error);
      // إذا كان الخطأ متعلق بعدم التحقق من الدومين
      if (error.includes('verify a domain') || error.includes('validation_error')) {
        console.warn('[Email] تنبيه: لم يتم التحقق من الدومين في Resend. الإيميل لم يُرسل إلى:', options.to);
      }
      return false;
    }

    console.log("[Email] Sent successfully to:", options.to);
    return true;
  } catch (err) {
    console.error("[Email] Error:", err);
    return false;
  }
}

/**
 * تذييل إلغاء الاشتراك المشترك لجميع القوالب
 */
function buildUnsubscribeFooter(unsubscribeToken: string): string {
  const unsubscribeUrl = `${SITE_URL}/unsubscribe?token=${unsubscribeToken}`;
  return `
    <div style="background:#f8f8f8; padding:20px; text-align:center; border-top:1px solid #eee; margin-top:30px;">
      <p style="color:#999; font-size:12px; margin:0 0 8px;">
        أنت تتلقى هذا البريد لأنك مشترك في تحديثات <strong>عالم القصص التعليمي</strong>
      </p>
      <p style="margin:0;">
        <a href="${unsubscribeUrl}" 
           style="color:#e74c3c; font-size:12px; text-decoration:underline;">
          إلغاء الاشتراك من رسائل البريد الإلكتروني
        </a>
        &nbsp;|&nbsp;
        <a href="${SITE_URL}" style="color:#6c63ff; font-size:12px; text-decoration:none;">
          زيارة الموقع
        </a>
      </p>
      <p style="color:#ccc; font-size:11px; margin:8px 0 0;">
        © 2026 عالم القصص التعليمي — تصميم: زمرده عبد العزيز السماعيل
      </p>
    </div>
  `;
}

/**
 * قالب تأكيد الاشتراك عند تسجيل طفل جديد
 */
export async function sendWelcomeSubscriptionEmail(
  email: string,
  childName: string,
  unsubscribeToken: string
): Promise<boolean> {
  const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { box-sizing: border-box; }
    body { font-family: 'Arial', sans-serif; background: #f0f4ff; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 8px 30px rgba(108,99,255,0.15); }
    .header { background: linear-gradient(135deg, #6c63ff 0%, #a855f7 50%, #ec4899 100%); padding: 40px 30px; text-align: center; color: white; position: relative; }
    .header::after { content: ''; position: absolute; bottom: -20px; left: 0; right: 0; height: 40px; background: white; border-radius: 50% 50% 0 0; }
    .header-emoji { font-size: 60px; display: block; margin-bottom: 15px; }
    .header h1 { margin: 0; font-size: 26px; font-weight: bold; }
    .header p { margin: 8px 0 0; opacity: 0.9; font-size: 15px; }
    .body { padding: 40px 30px 20px; }
    .greeting { font-size: 22px; color: #333; font-weight: bold; margin-bottom: 15px; }
    .message { color: #555; font-size: 15px; line-height: 1.8; margin-bottom: 25px; }
    .features { background: linear-gradient(135deg, #f8f4ff, #fff0fb); border-radius: 16px; padding: 25px; margin: 20px 0; }
    .features h3 { color: #6c63ff; font-size: 17px; margin: 0 0 15px; }
    .feature-item { display: flex; align-items: center; gap: 12px; margin: 12px 0; }
    .feature-emoji { font-size: 24px; flex-shrink: 0; }
    .feature-text { color: #444; font-size: 14px; }
    .cta-btn { display: block; background: linear-gradient(135deg, #6c63ff, #a855f7); color: white; text-decoration: none; padding: 16px 40px; border-radius: 50px; text-align: center; font-size: 17px; font-weight: bold; margin: 25px auto; max-width: 280px; box-shadow: 0 4px 15px rgba(108,99,255,0.4); }
    .tip-box { background: #fffbeb; border: 2px solid #fbbf24; border-radius: 12px; padding: 15px 20px; margin: 20px 0; }
    .tip-box p { margin: 0; color: #92400e; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <span class="header-emoji">📚✨</span>
      <h1>مرحباً في عالم القصص!</h1>
      <p>منصتك التعليمية المفضلة للأطفال</p>
    </div>
    <div class="body">
      <p class="greeting">أهلاً وسهلاً ${childName}! 🎉</p>
      <p class="message">
        يسعدنا انضمامك إلى <strong>عالم القصص التعليمي</strong> — المنصة التفاعلية التي تجمع بين المتعة والتعلم في رحلة لا تُنسى!
        <br><br>
        حسابك جاهز الآن، ويمكنك البدء فوراً في استكشاف عالم مليء بالقصص والألعاب والمغامرات.
      </p>

      <div class="features">
        <h3>🌟 ما ينتظرك في المنصة:</h3>
        <div class="feature-item">
          <span class="feature-emoji">📖</span>
          <span class="feature-text"><strong>25+ قصة تفاعلية</strong> بأصوات احترافية لكل صفحة</span>
        </div>
        <div class="feature-item">
          <span class="feature-emoji">🎮</span>
          <span class="feature-text"><strong>50+ لعبة تعليمية</strong> في اللغة والرياضيات والعلوم</span>
        </div>
        <div class="feature-item">
          <span class="feature-emoji">🗺️</span>
          <span class="feature-text"><strong>مغامرات تفاعلية</strong> تتخذ فيها قراراتك وتشكّل النهاية</span>
        </div>
        <div class="feature-item">
          <span class="feature-emoji">🏆</span>
          <span class="feature-text"><strong>نقاط وشارات وجوائز</strong> تكافئك على كل إنجاز</span>
        </div>
        <div class="feature-item">
          <span class="feature-emoji">🎯</span>
          <span class="feature-text"><strong>تحديات يومية</strong> تجعل التعلم ممتعاً كل يوم</span>
        </div>
      </div>

      <a href="${SITE_URL}" class="cta-btn">
        🚀 ابدأ رحلتك الآن!
      </a>

      <div class="tip-box">
        <p>💡 <strong>نصيحة:</strong> ابدأ بقراءة قصة من مكتبتنا، ثم العب الألعاب المرتبطة بها لتكسب نقاطاً مضاعفة!</p>
      </div>
    </div>
    ${buildUnsubscribeFooter(unsubscribeToken)}
  </div>
</body>
</html>
  `;

  return sendEmail({
    to: email,
    subject: `🎉 مرحباً ${childName}! حسابك في عالم القصص جاهز`,
    html,
  });
}

/**
 * إرسال بيانات تسجيل الدخول لمدير مدرسة جديد
 */
export async function sendSchoolAdminWelcomeEmail(
  email: string,
  schoolName: string,
  password: string,
  unsubscribeToken?: string
): Promise<boolean> {
  const footer = unsubscribeToken
    ? buildUnsubscribeFooter(unsubscribeToken)
    : `<div style="background:#f8f8f8;padding:20px;text-align:center;color:#999;font-size:12px;">© 2026 عالم القصص التعليمي</div>`;

  const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Arial', sans-serif; background: #f0f4ff; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
    .header { background: linear-gradient(135deg, #6c63ff, #a855f7); padding: 30px; text-align: center; color: white; }
    .header h1 { margin: 0; font-size: 24px; }
    .header p { margin: 8px 0 0; opacity: 0.9; }
    .body { padding: 30px; }
    .body h2 { color: #333; font-size: 20px; }
    .info-box { background: #f8f4ff; border: 2px solid #6c63ff; border-radius: 12px; padding: 20px; margin: 20px 0; }
    .info-row { display: flex; justify-content: space-between; margin: 10px 0; }
    .label { color: #666; font-weight: bold; }
    .value { color: #6c63ff; font-weight: bold; font-size: 16px; }
    .btn { display: block; background: linear-gradient(135deg, #6c63ff, #a855f7); color: white; text-decoration: none; padding: 14px 30px; border-radius: 10px; text-align: center; font-size: 16px; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>📚 عالم القصص التعليمي</h1>
      <p>مرحباً بك في منصتنا التعليمية</p>
    </div>
    <div class="body">
      <h2>مرحباً بمدرسة ${schoolName} 🎉</h2>
      <p>تم إنشاء حسابك بنجاح كمدير لمدرسة <strong>${schoolName}</strong> في منصة عالم القصص التعليمي.</p>
      <p>يمكنك الآن تتبع تقدم طلابك ومشاهدة إحصائياتهم التفصيلية.</p>
      
      <div class="info-box">
        <p style="margin: 0 0 15px; font-weight: bold; color: #333;">بيانات تسجيل الدخول:</p>
        <div class="info-row">
          <span class="label">البريد الإلكتروني:</span>
          <span class="value">${email}</span>
        </div>
        <div class="info-row">
          <span class="label">كلمة المرور:</span>
          <span class="value">${password}</span>
        </div>
        <div class="info-row">
          <span class="label">اسم المدرسة:</span>
          <span class="value">${schoolName}</span>
        </div>
      </div>
      
      <a href="${SITE_URL}" class="btn">
        🚀 الدخول إلى لوحة التحكم
      </a>
      
      <p style="color: #999; font-size: 13px;">يُرجى تغيير كلمة المرور بعد أول تسجيل دخول للحفاظ على أمان حسابك.</p>
    </div>
    ${footer}
  </div>
</body>
</html>
  `;

  return sendEmail({
    to: email,
    subject: `🎉 مرحباً بمدرسة ${schoolName} في عالم القصص التعليمي`,
    html,
  });
}

/**
 * إرسال التقرير الأسبوعي لمدير المدرسة
 */
export async function sendWeeklyReportEmail(
  email: string,
  schoolName: string,
  stats: {
    totalStudents: number;
    activeStudents: number;
    avgScore: number;
    totalBadges: number;
    topGames: Array<{ name: string; plays: number }>;
    topStudents: Array<{ name: string; score: number }>;
    weekStart: string;
    weekEnd: string;
  },
  unsubscribeToken?: string,
  customNote?: string
): Promise<boolean> {
  const topGamesHtml = stats.topGames
    .slice(0, 5)
    .map((g, i) => `<tr><td style="padding:10px;border-bottom:1px solid #eee;">${i + 1}</td><td style="padding:10px;border-bottom:1px solid #eee;">${g.name}</td><td style="padding:10px;border-bottom:1px solid #eee;text-align:center;">${g.plays} مرة</td></tr>`)
    .join("");

  const topStudentsHtml = stats.topStudents
    .slice(0, 5)
    .map((s, i) => `<tr><td style="padding:10px;border-bottom:1px solid #eee;">${i + 1}</td><td style="padding:10px;border-bottom:1px solid #eee;">${s.name}</td><td style="padding:10px;border-bottom:1px solid #eee;text-align:center;font-weight:bold;color:#6c63ff;">${s.score} نقطة</td></tr>`)
    .join("");

  const footer = unsubscribeToken
    ? buildUnsubscribeFooter(unsubscribeToken)
    : `<div style="background:#f8f8f8;padding:20px;text-align:center;color:#999;font-size:12px;">© 2026 عالم القصص التعليمي</div>`;

  const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <style>
    * { box-sizing: border-box; }
    body { font-family: 'Arial', sans-serif; background: #f0f4ff; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 8px 30px rgba(108,99,255,0.15); }
    .header { background: linear-gradient(135deg, #6c63ff, #a855f7); padding: 35px 30px; text-align: center; color: white; }
    .header h1 { margin: 0; font-size: 24px; }
    .header .school { font-size: 18px; margin: 8px 0 0; font-weight: bold; }
    .header .dates { font-size: 13px; opacity: 0.85; margin: 5px 0 0; }
    .body { padding: 30px; }
    .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
    .stat-card { background: linear-gradient(135deg, #f8f4ff, #fff0fb); border-radius: 14px; padding: 18px; text-align: center; border: 1px solid #e9d5ff; }
    .stat-number { font-size: 32px; font-weight: bold; color: #6c63ff; }
    .stat-label { color: #666; font-size: 13px; margin-top: 6px; }
    .section-title { font-size: 16px; font-weight: bold; color: #333; margin: 25px 0 12px; display: flex; align-items: center; gap: 8px; }
    table { width: 100%; border-collapse: collapse; border-radius: 10px; overflow: hidden; }
    thead tr { background: linear-gradient(135deg, #6c63ff, #a855f7); color: white; }
    thead th { padding: 12px; text-align: right; font-size: 14px; }
    tbody tr:nth-child(even) { background: #f8f4ff; }
    .no-data { text-align: center; color: #999; padding: 20px; font-size: 14px; }
    .cta-btn { display: block; background: linear-gradient(135deg, #6c63ff, #a855f7); color: white; text-decoration: none; padding: 14px 30px; border-radius: 50px; text-align: center; font-size: 15px; font-weight: bold; margin: 25px auto; max-width: 260px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>📊 التقرير الأسبوعي</h1>
      <p class="school">🏫 ${schoolName}</p>
      <p class="dates">📅 ${stats.weekStart} — ${stats.weekEnd}</p>
    </div>
    <div class="body">

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-number">${stats.totalStudents}</div>
          <div class="stat-label">👥 إجمالي الطلاب</div>
        </div>
        <div class="stat-card">
          <div class="stat-number">${stats.activeStudents}</div>
          <div class="stat-label">⚡ طلاب نشطون هذا الأسبوع</div>
        </div>
        <div class="stat-card">
          <div class="stat-number">${stats.avgScore}</div>
          <div class="stat-label">⭐ متوسط النقاط</div>
        </div>
        <div class="stat-card">
          <div class="stat-number">${stats.totalBadges}</div>
          <div class="stat-label">🏅 شارات مكتسبة</div>
        </div>
      </div>

      <p class="section-title">🎮 أكثر الألعاب لعباً هذا الأسبوع</p>
      <table>
        <thead><tr><th>#</th><th>اسم اللعبة</th><th>عدد المرات</th></tr></thead>
        <tbody>
          ${topGamesHtml || `<tr><td colspan="3" class="no-data">لا توجد بيانات ألعاب هذا الأسبوع</td></tr>`}
        </tbody>
      </table>

      <p class="section-title">🏆 أفضل الطلاب هذا الأسبوع</p>
      <table>
        <thead><tr><th>#</th><th>اسم الطالب</th><th>النقاط</th></tr></thead>
        <tbody>
          ${topStudentsHtml || `<tr><td colspan="3" class="no-data">لا توجد بيانات طلاب هذا الأسبوع</td></tr>`}
        </tbody>
      </table>

      ${customNote ? `
      <div style="background:#fffbeb;border:2px solid #fbbf24;border-radius:14px;padding:20px 24px;margin:20px 0;direction:rtl;">
        <p style="margin:0 0 8px;font-weight:bold;color:#92400e;font-size:15px;">📝 ملاحظة من الإدارة:</p>
        <p style="margin:0;color:#78350f;font-size:14px;line-height:1.8;white-space:pre-wrap;">${customNote}</p>
      </div>` : ''}
      <a href="${SITE_URL}" class="cta-btn">
        📈 عرض التقرير الكامل
      </a>
    </div>
    ${footer}
  </div>
</body>
</html>
  `;

  return sendEmail({
    to: email,
    subject: `📊 التقرير الأسبوعي — ${schoolName} (${stats.weekStart})`,
    html,
  });
}
