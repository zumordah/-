import { getDb } from "./db";
import { eq, and } from "drizzle-orm";
import { childDrawings, drawingLikes } from "../drizzle/schema";

export async function submitDrawing(childId: number, childName: string, schoolName: string | undefined, storyId: number, storyTitle: string, imageUrl: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(childDrawings).values({
    childId,
    childName,
    schoolName,
    storyId,
    storyTitle,
    imageUrl,
    status: "pending",
  });
  return result;
}

export async function getFeaturedDrawings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(childDrawings).where(and(
    eq(childDrawings.status, "approved"),
    eq(childDrawings.isFeatured, true)
  )).limit(3);
}

export async function getAllApprovedDrawings(storyId?: number, schoolName?: string) {
  const db = await getDb();
  if (!db) return [];
  let query: any = db.select().from(childDrawings).where(eq(childDrawings.status, "approved"));
  if (storyId) query = query.where(eq(childDrawings.storyId, storyId));
  if (schoolName) query = query.where(eq(childDrawings.schoolName, schoolName));
  return query.orderBy(childDrawings.createdAt);
}

export async function getChildDrawings(childId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(childDrawings).where(eq(childDrawings.childId, childId));
}

export async function getAdminDrawings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(childDrawings).orderBy(childDrawings.createdAt);
}

export async function approveDrawing(drawingId: number, rating: number, note?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(childDrawings).set({
    status: "approved",
    rating,
    adminNote: note,
    reviewedAt: new Date(),
  }).where(eq(childDrawings.id, drawingId));
}

export async function rejectDrawing(drawingId: number, note?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(childDrawings).set({
    status: "rejected",
    adminNote: note,
    reviewedAt: new Date(),
  }).where(eq(childDrawings.id, drawingId));
}

export async function setFeatured(drawingId: number, isFeatured: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(childDrawings).set({ isFeatured }).where(eq(childDrawings.id, drawingId));
}

export async function likeDrawing(drawingId: number, childId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(drawingLikes).where(
    and(eq(drawingLikes.drawingId, drawingId), eq(drawingLikes.childId, childId))
  );
  if (existing.length > 0) return false;
  
  await db.insert(drawingLikes).values({ drawingId, childId });
  await db.update(childDrawings).set({
    likesCount: (childDrawings.likesCount || 0) + 1
  }).where(eq(childDrawings.id, drawingId));
  return true;
}
