import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user data for authenticated users", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeDefined();
    expect(result?.email).toBe("admin@example.com");
    expect(result?.role).toBe("admin");
  });
});

describe("stories.list", () => {
  it("returns stories list from database", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.stories.list({});
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("games.list", () => {
  it("returns games list from database", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.games.list({});
    expect(Array.isArray(result)).toBe(true);
    // Each game should have required fields
    if (result.length > 0) {
      const game = result[0];
      expect(game).toHaveProperty("id");
      expect(game).toHaveProperty("title");
      expect(game).toHaveProperty("level");
      expect(game).toHaveProperty("type");
    }
  });
});

describe("admin access control", () => {
  it("rejects non-admin users from admin endpoints", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("rejects unauthenticated users from admin endpoints", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("allows admin users to access admin endpoints", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.stats();
    expect(result).toBeDefined();
    expect(result).toHaveProperty("totalChildren");
    expect(result).toHaveProperty("totalStories");
    expect(result).toHaveProperty("totalActivities");
  });
});

describe("admin.levelStats", () => {
  it("returns real level distribution data", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.levelStats();
    expect(result).toBeDefined();
    expect(result).toHaveProperty("totalChildren");
    expect(result).toHaveProperty("completedEasy");
    expect(result).toHaveProperty("completedMedium");
    expect(result).toHaveProperty("completedHard");
    expect(result).toHaveProperty("levelDistribution");
    expect(result.levelDistribution).toHaveProperty("beginner");
    expect(result.levelDistribution).toHaveProperty("intermediate");
    expect(result.levelDistribution).toHaveProperty("advanced");
    expect(result.levelDistribution).toHaveProperty("expert");
  });
});

describe("admin.allGames", () => {
  it("returns all games for admin management", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.allGames();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("children.register", () => {
  it("creates a new child account", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.children.register({
      name: "طفل اختبار",
      email: `test-${Date.now()}@example.com`,
      ageGroup: "4-6",
      isKindergartenStudent: false,
    });
    expect(result).toBeDefined();
    expect(result).toHaveProperty("child");
    expect(result.child).toHaveProperty("id");
    expect(result.child).toHaveProperty("name");
    expect(result.child.name).toBe("طفل اختبار");
    expect(result.isNew).toBe(true);
  });
});

describe("reviews.list", () => {
  it("returns approved reviews list", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.reviews.list();
    expect(Array.isArray(result)).toBe(true);
  });
});
