import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { SignJWT, jwtVerify } from "jose";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, adminProcedure, router } from "./_core/trpc";
import {
  addPointsToChild,
  awardAchievement,
  checkAndAwardAchievements,
  createChild,
  createStory,
  createStoryPage,
  deleteChild,
  deleteStory,
  getActivitiesByStory,
  getActivityById,
  getActivityQuestions,
  getAdminStats,
  getAllActivities,
  getAllAchievements,
  getAllChildren,
  getAllStories,
  getChildAchievements,
  getChildActivityResults,
  getChildAllProgress,
  getChildByEmail,
  getChildById,
  getChildDetailedStats,
  getChildStoryProgress,
  getStoryById,
  getStoryPages,
  saveActivityResult,
  updateChildActivity,
  upsertStoryProgress,
  getTopChildren,
  createReview,
  getApprovedReviews,
  getAllReviewsAdmin,
  approveReview,
  deleteReview,
  getAllEducationalGames,
  getAllEducationalGamesAdmin,
  getEducationalGameById,
  createEducationalGame,
  updateEducationalGame,
  deleteEducationalGame,
  saveGameProgress,
  getChildGameProgressList,
  getAllAdventures,
  getAdventureById,
  getChildAdventureProgressList,
  saveAdventureProgress,
  getTodayChallenge,
  getChildDailyChallengeProgress,
  markChallengeTask,
  getTodayChallengeAdmin,
  getAllShopItemsWithPurchaseCount,
  getLeaderboard,
  getShopItems,
  getAllShopItems,
  upsertShopItem,
  deleteShopItem,
  getChildInventory,
  purchaseShopItem,
  grantLevelReward,
  equipShopItem,
  adminAdjustChild,
  getDb,
  getLockedGames,
  getChildUnlockedGameIds,
  unlockGameWithPoints,
  getLockedAdventures,
  getChildUnlockedAdventureIds,
  unlockAdventureWithPoints,
  getAllAdminAccounts,
  addAdminAccount,
  removeAdminAccount,
  validateAdminLogin,
  validateAdminLoginWithRole,
  createSchool,
  getAllSchools,
  getSchoolById,
  getSchoolByAdminEmail,
  deleteSchool,
  addSchoolClassroom,
  getSchoolClassrooms,
  deleteSchoolClassroom,
  getSchoolStats,
  getAllSchoolsStats,
} from "./db";
import { achievements, activities, activityQuestions, stories, storyPages, educationalGames, interactiveGameProgress, children, storyAdventures, childAdventureProgress, siteReviews, childStoryProgress, childGameProgress, childCompanion, childOwnedCharacters, childColorTheme, childVoiceRecordings, emailSubscriptions, recordingReactions } from "../drizzle/schema";
import { sendWeeklyReportEmail, sendSchoolAdminWelcomeEmail, sendWelcomeSubscriptionEmail } from "./emailHelper";
import { runWeeklyReports, buildWeeklyReportText } from "./weeklyReportJob";
import { eq, desc, sql, and, inArray } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";
import { submitDrawing, getFeaturedDrawings, getAllApprovedDrawings, getChildDrawings, getAdminDrawings, approveDrawing, rejectDrawing, setFeatured, likeDrawing } from "./drawingsDb";
export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Children ──────────────────────────────────────────────────────────────
  children: router({
    register: publicProcedure
      .input(
        z.object({
          name: z.string().min(2).max(100),
          email: z.string().email(),
          ageGroup: z.enum(["4-6", "6-8", "8-10"]),
          avatarEmoji: z.string().optional(),
          isKindergartenStudent: z.boolean().optional(),
          classroom: z.string().optional(),
          schoolId: z.number().optional(),
          referralSource: z.enum(["الأهل", "الأصدقاء", "العمل", "مواقع التواصل"]).optional(),
          gender: z.enum(["boy", "girl"]).optional(),
          password: z.string().min(6).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const crypto = await import("crypto");
        const existing = await getChildByEmail(input.email);
        if (existing) {
          // التحقق من كلمة المرور إن كان الحساب يستخدمها
          if (input.password && (existing as any).password) {
            const hashed = crypto.createHash("sha256").update(input.password).digest("hex");
            if (hashed !== (existing as any).password) {
              throw new TRPCError({ code: "UNAUTHORIZED", message: "كلمة المرور غير صحيحة" });
            }
          }
          await updateChildActivity(existing.id);
          return { child: existing, isNew: false };
        }
        // تشفير كلمة المرور قبل الحفظ
        const hashedPassword = input.password
          ? crypto.createHash("sha256").update(input.password).digest("hex")
          : null;
        const child = await createChild({ ...input, password: hashedPassword ?? undefined } as any);
        if (!child) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // تفعيل الشخصية الافتراضية حسب الجنس
        const defaultCharId = input.gender === "girl" ? "lajen" : "sami";
        const db = await getDb();
        if (db) {
          await db.insert(childCompanion).values({
            childId: child.id,
            characterId: defaultCharId,
          }).onDuplicateKeyUpdate({ set: { characterId: defaultCharId } });
          // إضافة الشخصية الافتراضية لقائمة المملوكة
          await db.insert(childOwnedCharacters).values({
            childId: child.id,
            characterId: defaultCharId,
            acquiredVia: "level_reward",
          }).onDuplicateKeyUpdate({ set: { characterId: defaultCharId } });
        }
        await seedDefaultAchievements();
        // إرسال إيميل تأكيد الاشتراك وتسجيل الاشتراك في قاعدة البيانات
        try {
          const db = await getDb();
          if (db) {
            const crypto = await import("crypto");
            const token = crypto.randomBytes(32).toString("hex");
            await db.insert(emailSubscriptions).values({
              email: input.email,
              childId: child.id,
              childName: child.name,
              token,
              isSubscribed: true,
            }).onDuplicateKeyUpdate({ set: { childId: child.id, childName: child.name } });
            // إرسال إيميل الترحيب (غير متزامن - لا يوقف التسجيل)
            sendWelcomeSubscriptionEmail(input.email, child.name, token).catch(() => {});
          }
        } catch (e) {
          console.error("[Register] Email subscription error:", e);
        }
        return { child, isNew: true };
      }),

    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string().optional() }))
      .mutation(async ({ input }) => {
        const child = await getChildByEmail(input.email);
        if (!child) throw new TRPCError({ code: "NOT_FOUND", message: "لم يتم العثور على حسابك. هل أنت مسجّل؟" });
        // التحقق من كلمة المرور إن كان الحساب يستخدمها
        if ((child as any).password) {
          if (!input.password) {
            throw new TRPCError({ code: "UNAUTHORIZED", message: "يرجى إدخال كلمة المرور" });
          }
          const crypto = await import("crypto");
          const hashed = crypto.createHash("sha256").update(input.password).digest("hex");
          if (hashed !== (child as any).password) {
            throw new TRPCError({ code: "UNAUTHORIZED", message: "كلمة المرور غير صحيحة" });
          }
        }
        await updateChildActivity(child.id);
        return child;
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const child = await getChildById(input.id);
        if (!child) throw new TRPCError({ code: "NOT_FOUND" });
        return child;
      }),

    uploadAvatar: publicProcedure
      .input(z.object({
        childId: z.number(),
        base64: z.string(),
        contentType: z.string().default("image/jpeg"),
      }))
      .mutation(async ({ input }) => {
        const { storagePut } = await import("./storage.js");
        const { generateImage } = await import("./_core/imageGeneration.js");
        const base64Clean = input.base64.replace(/^data:[^;]+;base64,/, "");
        const buffer = Buffer.from(base64Clean, "base64");
        // رفع الصورة الأصلية أولاً
        const origKey = `avatars/orig-${input.childId}-${Date.now()}.jpg`;
        const { url: origUrl } = await storagePut(origKey, buffer, input.contentType);
        // قص الخلفية باستخدام generateImage
        let finalUrl = origUrl;
        try {
          const result = await generateImage({
            prompt: "Remove the background completely. Keep only the person or face. Make the background pure white. Portrait photo crop, centered face.",
            originalImages: [{ url: origUrl, mimeType: "image/jpeg" }],
          });
          if (result?.url) finalUrl = result.url;
        } catch (e) {
          console.error("[uploadAvatar] Background removal failed, using original:", e);
        }
        // تحديث avatarUrl في قاعدة البيانات
        const db = await getDb();
        if (db) {
          await db.update(children).set({ avatarUrl: finalUrl }).where(eq(children.id, input.childId));
        }
        return { url: finalUrl };
      }),

    getDashboard: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const child = await getChildById(input.childId);
        if (!child) throw new TRPCError({ code: "NOT_FOUND" });
        const progress = await getChildAllProgress(input.childId);
        const activityResults = await getChildActivityResults(input.childId);
        const earnedAchievements = await getChildAchievements(input.childId);
        const gameProgress = await getChildGameProgressList(input.childId);
        const completedStories = progress.filter((p) => p.isCompleted).length;
        const completedActivities = activityResults.filter((r) => r.isCompleted).length;
        const completedGames = gameProgress.filter((g) => g.isCompleted).length;
        const allAchievements = await getAllAchievements();
        
        // Calculate story level progress (easy/medium/hard)
        const allStories = await getAllStories();
        const easyStories = allStories.filter((s: any) => s.difficulty === 'easy');
        const mediumStories = allStories.filter((s: any) => s.difficulty === 'medium');
        const hardStories = allStories.filter((s: any) => s.difficulty === 'hard');
        const progressMap: Record<number, boolean> = {};
        progress.forEach((p: any) => { if (p.isCompleted) progressMap[p.storyId] = true; });
        const completedEasyCount = easyStories.filter((s: any) => progressMap[s.id]).length;
        const completedMediumCount = mediumStories.filter((s: any) => progressMap[s.id]).length;
        const completedHardCount = hardStories.filter((s: any) => progressMap[s.id]).length;
        const mediumUnlocked = easyStories.length === 0 || completedEasyCount >= easyStories.length;
        const hardUnlocked = mediumStories.length === 0 || completedMediumCount >= mediumStories.length;
        // current story level: easy → medium → hard
        const currentStoryLevel = hardUnlocked && hardStories.length > 0 ? 'hard' : mediumUnlocked && mediumStories.length > 0 ? 'medium' : 'easy';

        // Calculate actual level based on real progress
        const totalCompleted = completedStories + completedActivities + completedGames;
        const pointsForNextLevel = ((child.level) * 100) - child.totalPoints;
        
        return {
          child,
          completedStories,
          completedActivities,
          completedGames,
          earnedAchievements,
          allAchievements,
          recentProgress: progress.slice(0, 5),
          pointsForNextLevel: Math.max(0, pointsForNextLevel),
          totalCompleted,
          currentStoryLevel,
          completedEasy: completedEasyCount,
          completedMedium: completedMediumCount,
          completedHard: completedHardCount,
          totalEasy: easyStories.length,
          totalMedium: mediumStories.length,
          totalHard: hardStories.length,
        };
      }),
  }),

  // ─── Stories ───────────────────────────────────────────────────────────────
  stories: router({
    list: publicProcedure
      .input(z.object({ ageGroup: z.string().optional(), difficulty: z.enum(["easy", "medium", "hard"]).optional() }))
      .query(async ({ input }) => {
        const allStories = await getAllStories(input.ageGroup);
        if (input.difficulty) {
          return allStories.filter((s: any) => s.difficulty === input.difficulty);
        }
        return allStories;
      }),

    byLevel: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const allStories = await getAllStories();
        const progress = await getChildAllProgress(input.childId);
        const completedIds = new Set(progress.filter((p: any) => p.isCompleted).map((p: any) => p.storyId));
        const easyStories = allStories.filter((s: any) => s.difficulty === "easy");
        const mediumStories = allStories.filter((s: any) => s.difficulty === "medium");
        const hardStories = allStories.filter((s: any) => s.difficulty === "hard");
        const easyCompleted = easyStories.filter((s: any) => completedIds.has(s.id)).length;
        const mediumCompleted = mediumStories.filter((s: any) => completedIds.has(s.id)).length;
        const hardCompleted = hardStories.filter((s: any) => completedIds.has(s.id)).length;
        const easyUnlocked = true;
        const mediumUnlocked = easyStories.length > 0 && easyCompleted >= easyStories.length;
        const hardUnlocked = mediumStories.length > 0 && mediumCompleted >= mediumStories.length;
        return {
          easy: { stories: easyStories, completed: easyCompleted, total: easyStories.length, unlocked: easyUnlocked },
          medium: { stories: mediumStories, completed: mediumCompleted, total: mediumStories.length, unlocked: mediumUnlocked },
          hard: { stories: hardStories, completed: hardCompleted, total: hardStories.length, unlocked: hardUnlocked },
        };
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const story = await getStoryById(input.id);
        if (!story) throw new TRPCError({ code: "NOT_FOUND" });
        const pages = await getStoryPages(input.id);
        return { story, pages };
      }),

    getProgress: publicProcedure
      .input(z.object({ childId: z.number(), storyId: z.number() }))
      .query(async ({ input }) => {
        return getChildStoryProgress(input.childId, input.storyId);
      }),

    getAllProgress: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildAllProgress(input.childId);
      }),

    updateProgress: publicProcedure
      .input(
        z.object({
          childId: z.number(),
          storyId: z.number(),
          currentPage: z.number(),
          isCompleted: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const story = await getStoryById(input.storyId);
        if (!story) throw new TRPCError({ code: "NOT_FOUND" });
        const isCompleted = input.isCompleted ?? false;
        let pointsEarned = 0;
        if (isCompleted) {
          pointsEarned = story.pointsReward;
          await addPointsToChild(input.childId, pointsEarned);
        }
        await upsertStoryProgress({
          childId: input.childId,
          storyId: input.storyId,
          currentPage: input.currentPage,
          isCompleted,
          pointsEarned,
        });
        await updateChildActivity(input.childId);
        const newAchievements = await checkAndAwardAchievements(input.childId);
        return { success: true, pointsEarned, newAchievements };
      }),

    create: adminProcedure
      .input(
        z.object({
          title: z.string().min(2),
          description: z.string().optional(),
          coverImage: z.string().optional(),
          ageGroup: z.enum(["4-6", "6-8", "8-10", "all"]),
          audioUrl: z.string().optional(),
          difficulty: z.enum(["easy", "medium", "hard"]).optional(),
          pointsReward: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return createStory(input);
      }),

    addPage: adminProcedure
      .input(
        z.object({
          storyId: z.number(),
          pageNumber: z.number(),
          text: z.string(),
          imageUrl: z.string().optional(),
          audioUrl: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await createStoryPage(input);
        return { success: true };
      }),

    updatePage: adminProcedure
      .input(z.object({
        id: z.number(),
        text: z.string().optional(),
        imageUrl: z.string().optional(),
        audioUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        const { id, ...updates } = input;
        await db.update(storyPages).set(updates).where(eq(storyPages.id, id));
        return { success: true };
      }),
    deletePage: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        await db.delete(storyPages).where(eq(storyPages.id, input.id));
        return { success: true };
      }),
     delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteStory(input.id);
        return { success: true };
      }),
    generateWithAI: adminProcedure
      .input(z.object({
        topic: z.string().min(2),
        ageGroup: z.enum(["4-6", "6-8", "8-10", "all"]),
        difficulty: z.enum(["easy", "medium", "hard"]),
        pagesCount: z.number().min(3).max(10).default(5),
      }))
      .mutation(async ({ input }) => {
        const difficultyLabel = { easy: "مبتدئ (3-5 سنوات)", medium: "متوسط (5-7 سنوات)", hard: "متقدم (7-10 سنوات)" }[input.difficulty];
        const response = await invokeLLM({
          messages: [
            { role: "system", content: `أنت كاتب قصص أطفال سعودي متخصص. اكتب قصصاً تعليمية جميلة باللغة العربية الفصحى البسيطة للأطفال. القصص يجب أن تحمل قيماً إسلامية وسعودية وتكون مناسبة للمستوى الدراسي.` },
            { role: "user", content: `اكتب قصة للأطفال عن موضوع: "${input.topic}" للمستوى ${difficultyLabel}.
القصة يجب أن تكون من ${input.pagesCount} صفحات.
استجب بـ JSON فقط بهذا الهيكل:
{
  "title": "عنوان القصة",
  "description": "وصف مختصر جذاب للقصة (جملة واحدة)",
  "emoji": "إيموجي مناسب",
  "pages": [
    { "text": "نص الصفحة الأولى (2-3 جمل مناسبة للعمر)", "imageDescription": "وصف الصورة المقترحة" },
    ...
  ]
}` }
          ],
          response_format: { type: "json_schema", json_schema: { name: "story_data", strict: true, schema: { type: "object", properties: { title: { type: "string" }, description: { type: "string" }, emoji: { type: "string" }, pages: { type: "array", items: { type: "object", properties: { text: { type: "string" }, imageDescription: { type: "string" } }, required: ["text", "imageDescription"], additionalProperties: false } } }, required: ["title", "description", "emoji", "pages"], additionalProperties: false } } }
        });
        const content = response.choices[0].message.content;
        const storyData = JSON.parse(typeof content === "string" ? content : JSON.stringify(content));
        return {
          title: storyData.title,
          description: storyData.description,
          emoji: storyData.emoji,
          pages: storyData.pages,
        };
      }),
  }),
  // ─── Activities ────────────────────────────────────────────────────────────
  activities: router({
    listByStory: publicProcedure
      .input(z.object({ storyId: z.number() }))
      .query(async ({ input }) => {
        return getActivitiesByStory(input.storyId);
      }),

    listAll: publicProcedure
      .input(z.object({ ageGroup: z.string().optional() }))
      .query(async ({ input }) => {
        return getAllActivities(input.ageGroup);
      }),

    getWithQuestions: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const activity = await getActivityById(input.id);
        if (!activity) throw new TRPCError({ code: "NOT_FOUND" });
        const questions = await getActivityQuestions(input.id);
        const story = await getStoryById(activity.storyId);
        return { activity, questions, story };
      }),

    submitResult: publicProcedure
      .input(
        z.object({
          childId: z.number(),
          activityId: z.number(),
          score: z.number(),
          maxScore: z.number(),
          isCompleted: z.boolean(),
        })
      )
      .mutation(async ({ input }) => {
        const activity = await getActivityById(input.activityId);
        if (!activity) throw new TRPCError({ code: "NOT_FOUND" });
        const percentage = input.maxScore > 0 ? (input.score / input.maxScore) * 100 : 0;
        const pointsEarned = input.isCompleted ? Math.round((percentage / 100) * activity.pointsReward) : 0;
        await saveActivityResult({ ...input, pointsEarned });
        if (pointsEarned > 0) await addPointsToChild(input.childId, pointsEarned);
        await updateChildActivity(input.childId);
        const newAchievements = await checkAndAwardAchievements(input.childId);
        return { success: true, pointsEarned, newAchievements };
      }),

    getChildResults: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildActivityResults(input.childId);
      }),

    create: adminProcedure
      .input(
        z.object({
          storyId: z.number(),
          title: z.string(),
          type: z.enum(["quiz", "matching", "puzzle"]),
          description: z.string().optional(),
          pointsReward: z.number().optional(),
          ageGroup: z.enum(["4-6", "6-8", "8-10", "all"]).optional(),
          questions: z.array(
            z.object({
              questionText: z.string(),
              questionType: z.enum(["multiple_choice", "matching", "puzzle"]),
              options: z.any().optional(),
              correctAnswer: z.string(),
              explanation: z.string().optional(),
              orderIndex: z.number().optional(),
            })
          ),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.insert(activities).values({
          storyId: input.storyId,
          title: input.title,
          type: input.type,
          description: input.description,
          pointsReward: input.pointsReward ?? 20,
          ageGroup: input.ageGroup ?? "all",
        });
        const allActs = await db.select().from(activities).where(eq(activities.storyId, input.storyId));
        const created = allActs[allActs.length - 1];
        if (created && input.questions.length > 0) {
          for (const q of input.questions) {
            await db.insert(activityQuestions).values({
              activityId: created.id,
              questionText: q.questionText,
              questionType: q.questionType,
              options: q.options,
              correctAnswer: q.correctAnswer,
              explanation: q.explanation,
              orderIndex: q.orderIndex ?? 0,
            });
          }
        }
        return { success: true, activityId: created?.id };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.delete(activityQuestions).where(eq(activityQuestions.activityId, input.id));
        await db.delete(activities).where(eq(activities.id, input.id));
        return { success: true };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        type: z.enum(["quiz", "matching", "puzzle"]).optional(),
        pointsReward: z.number().optional(),
        ageGroup: z.enum(["4-6", "6-8", "8-10", "all"]).optional(),
        isPublished: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { id, ...updates } = input;
        await db.update(activities).set(updates as any).where(eq(activities.id, id));
        return { success: true };
      }),

    allAdmin: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(activities).orderBy(desc(activities.id));
    }),
    // ── Question CRUD ──
    addQuestion: adminProcedure
      .input(z.object({
        activityId: z.number(),
        questionText: z.string(),
        questionType: z.enum(['multiple_choice', 'matching', 'puzzle']),
        options: z.any().optional(),
        correctAnswer: z.string(),
        explanation: z.string().optional(),
        orderIndex: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        await db.insert(activityQuestions).values({
          activityId: input.activityId,
          questionText: input.questionText,
          questionType: input.questionType,
          options: input.options,
          correctAnswer: input.correctAnswer,
          explanation: input.explanation,
          orderIndex: input.orderIndex ?? 0,
        });
        return { success: true };
      }),
    updateQuestion: adminProcedure
      .input(z.object({
        id: z.number(),
        questionText: z.string().optional(),
        options: z.any().optional(),
        correctAnswer: z.string().optional(),
        explanation: z.string().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        const { id, ...updates } = input;
        await db.update(activityQuestions).set(updates as any).where(eq(activityQuestions.id, id));
        return { success: true };
      }),
    deleteQuestion: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        await db.delete(activityQuestions).where(eq(activityQuestions.id, input.id));
        return { success: true };
      }),
  }),
  // ─── Achievementss ──────────────────────────────────────────────────────────
  achievements: router({
    list: publicProcedure.query(async () => {
      return getAllAchievements();
    }),
    getChildAchievements: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildAchievements(input.childId);
      }),
  }),

  // ─── Admin ─────────────────────────────────────────────────────────────────
  admin: router({
     login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input }) => {
        const admin = await validateAdminLoginWithRole(input.email.toLowerCase().trim(), input.password);
        if (!admin) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "بيانات الدخول غير صحيحة" });
        }
        // إصدار Admin JWT token
        const secret = new TextEncoder().encode(process.env.JWT_SECRET ?? 'fallback_secret');
        const adminToken = await new SignJWT({ adminEmail: admin.email, adminRole: admin.role ?? 'school_admin', adminName: admin.name })
          .setProtectedHeader({ alg: 'HS256' })
          .setExpirationTime('30d')
          .sign(secret);
        return { success: true, role: admin.role ?? 'school_admin', name: admin.name, email: admin.email, schoolId: admin.schoolId, school: admin.school, adminToken };
      }),
    checkAdminEmail: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .mutation(async ({ input }) => {
        const admin = await validateAdminLogin(input.email.toLowerCase().trim(), "__check_only__");
        // We just check if the email exists in admin_accounts
        const db = await getDb();
        if (!db) return { isAdmin: false };
        const { adminAccounts: adminAccountsTable } = await import("../drizzle/schema");
        const [found] = await db.select().from(adminAccountsTable)
          .where(and(eq(adminAccountsTable.email, input.email.toLowerCase().trim()), eq(adminAccountsTable.isActive, true)))
          .limit(1);
        return { isAdmin: !!found };
      }),
    // ─── Multi-admin management ─────────────────────────────────────────────
    listAdmins: adminProcedure.query(async () => {
      return getAllAdminAccounts();
    }),
    addAdmin: adminProcedure
      .input(z.object({ email: z.string().email(), name: z.string().min(2), password: z.string().min(6), addedBy: z.string() }))
      .mutation(async ({ input }) => {
        await addAdminAccount(input.email.toLowerCase().trim(), input.name, input.password, input.addedBy);
        return { success: true };
      }),
    removeAdmin: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await removeAdminAccount(input.id);
        return { success: true };
      }),

    // تغيير كلمة المرور من لوحة التحكم (يستخدم publicProcedure لأن الأدمن يسجل دخوله عبر localStorage وليس OAuth)
    changePassword: publicProcedure
      .input(z.object({
        email: z.string().email(),
        currentPassword: z.string().min(1),
        newPassword: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { adminAccounts: adminAccountsTable } = await import("../drizzle/schema");
        // جلب بيانات الأدمن
        const [admin] = await db.select().from(adminAccountsTable)
          .where(and(eq(adminAccountsTable.email, input.email.toLowerCase().trim()), eq(adminAccountsTable.isActive, true)))
          .limit(1);
        if (!admin) throw new TRPCError({ code: "NOT_FOUND", message: "لم يتم العثور على الحساب" });
        // التحقق من كلمة المرور الحالية (تدعم النص العادي وbcrypt)
        const storedPwd = (admin as any).password as string;
        const { default: bcrypt } = await import("bcrypt");
        let isCurrentValid: boolean;
        if (storedPwd.startsWith("$2b$") || storedPwd.startsWith("$2a$")) {
          isCurrentValid = await bcrypt.compare(input.currentPassword, storedPwd);
        } else {
          isCurrentValid = input.currentPassword === storedPwd;
        }
        if (!isCurrentValid) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "كلمة المرور الحالية غير صحيحة" });
        }
        // تشفير كلمة المرور الجديدة وتخزينها
        const hashedNewPwd = await bcrypt.hash(input.newPassword, 10);
        const safeEmail = input.email.toLowerCase().trim().replace(/'/g, "''");
        const safePwd = hashedNewPwd.replace(/'/g, "''");
        await db.execute(
          `UPDATE admin_accounts SET password = '${safePwd}' WHERE email = '${safeEmail}' AND isActive = 1`
        );
        return { success: true, message: "تم تغيير كلمة المرور بنجاح" };
      }),

    stats: adminProcedure.query(async () => {
      return getAdminStats();
    }),

    children: adminProcedure.query(async () => {
      return getAllChildren();
    }),

    childDetail: adminProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildDetailedStats(input.childId);
      }),

    deleteChild: adminProcedure
      .input(z.object({ childId: z.number() }))
      .mutation(async ({ input }) => {
        await deleteChild(input.childId);
        return { success: true };
      }),

    bulkDeleteChildren: adminProcedure
      .input(z.object({ childIds: z.array(z.number()).min(1) }))
      .mutation(async ({ input }) => {
        for (const id of input.childIds) {
          await deleteChild(id);
        }
        return { success: true, deleted: input.childIds.length };
      }),

    bulkTransferChildren: adminProcedure
      .input(z.object({
        childIds: z.array(z.number()).min(1),
        schoolId: z.number().nullable().optional(),
        classroom: z.string().nullable().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const updates: Record<string, any> = {};
        if (input.schoolId !== undefined) updates.schoolId = input.schoolId;
        if (input.classroom !== undefined) updates.classroom = input.classroom;
        if (Object.keys(updates).length === 0) return { success: true, transferred: 0 };
        for (const id of input.childIds) {
          await db.update(children).set(updates).where(eq(children.id, id));
        }
        return { success: true, transferred: input.childIds.length };
      }),

    updateChild: adminProcedure
      .input(z.object({
        childId: z.number(),
        name: z.string().min(2).optional(),
        email: z.string().email().optional(),
        ageGroup: z.enum(["4-6", "6-8", "8-10"]).optional(),
        gender: z.enum(["boy", "girl"]).optional(),
        totalPoints: z.number().min(0).optional(),
        level: z.number().min(1).optional(),
        isKindergartenStudent: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { childId, ...updates } = input;
        if (Object.keys(updates).length === 0) return { success: true };
        await db.update(children).set(updates as any).where(eq(children.id, childId));
        return { success: true };
      }),

    resetChildPoints: adminProcedure
      .input(z.object({ childId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(children).set({ totalPoints: 0, level: 1 }).where(eq(children.id, input.childId));
        return { success: true };
      }),

    allStories: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(stories);
    }),

    deleteStory: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteStory(input.id);
        return { success: true };
      }),

    updateStory: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        coverImage: z.string().optional(),
        ageGroup: z.enum(["4-6", "6-8", "8-10", "all"]).optional(),
        difficulty: z.enum(["easy", "medium", "hard"]).optional(),
        pointsReward: z.number().optional(),
        isPublished: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { id, ...updates } = input;
        await db.update(stories).set(updates).where(eq(stories.id, id));
        return { success: true };
      }),

    // FIXED: Accurate level stats based on actual progress
    levelStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return null;
      const mysql = await import('mysql2/promise');
      const conn = await mysql.default.createConnection(process.env.DATABASE_URL!);

      try {
        // Count children per actual level based on completed stories
        const [childrenWithProgress] = await conn.query(`
          SELECT c.id, c.name, c.totalPoints, c.level,
            COALESCE(SUM(CASE WHEN s.difficulty = 'easy' AND sp.isCompleted = 1 THEN 1 ELSE 0 END), 0) as easyDone,
            COALESCE(SUM(CASE WHEN s.difficulty = 'medium' AND sp.isCompleted = 1 THEN 1 ELSE 0 END), 0) as mediumDone,
            COALESCE(SUM(CASE WHEN s.difficulty = 'hard' AND sp.isCompleted = 1 THEN 1 ELSE 0 END), 0) as hardDone,
            COALESCE(COUNT(CASE WHEN sp.isCompleted = 1 THEN 1 END), 0) as totalDone
          FROM children c
          LEFT JOIN child_story_progress sp ON c.id = sp.childId
          LEFT JOIN stories s ON sp.storyId = s.id
          GROUP BY c.id, c.name, c.totalPoints, c.level
          ORDER BY totalDone DESC, c.totalPoints DESC
        `) as any;

        // Story counts per difficulty
        const [storyCounts] = await conn.query(`
          SELECT difficulty, COUNT(*) as count
          FROM stories WHERE isPublished = 1
          GROUP BY difficulty
        `) as any;

        const storyCountMap: Record<string, number> = {};
        (storyCounts as any[]).forEach((r: any) => { storyCountMap[r.difficulty] = r.count; });

        const easyTotal = storyCountMap['easy'] || 0;
        const mediumTotal = storyCountMap['medium'] || 0;
        const hardTotal = storyCountMap['hard'] || 0;

        // Calculate actual levels based on completed stories
        let beginnerCount = 0; // Haven't completed easy level
        let intermediateCount = 0; // Completed easy, working on medium
        let advancedCount = 0; // Completed medium, working on hard
        let expertCount = 0; // Completed all levels

        for (const child of childrenWithProgress as any[]) {
          const easyDone = Number(child.easyDone);
          const mediumDone = Number(child.mediumDone);
          const hardDone = Number(child.hardDone);

          if (easyTotal > 0 && easyDone >= easyTotal && mediumTotal > 0 && mediumDone >= mediumTotal && hardTotal > 0 && hardDone >= hardTotal) {
            expertCount++;
          } else if (easyTotal > 0 && easyDone >= easyTotal && mediumTotal > 0 && mediumDone >= mediumTotal) {
            advancedCount++;
          } else if (easyTotal > 0 && easyDone >= easyTotal) {
            intermediateCount++;
          } else {
            beginnerCount++;
          }
        }

        const [[totalChildrenRow]] = await conn.query('SELECT COUNT(*) as count FROM children') as any;

        // Count children who completed each level
        let completedEasyCount = 0;
        let completedMediumCount = 0;
        let completedHardCount = 0;

        for (const child of childrenWithProgress as any[]) {
          const easyDone = Number(child.easyDone);
          const mediumDone = Number(child.mediumDone);
          const hardDone = Number(child.hardDone);
          if (easyTotal > 0 && easyDone >= easyTotal) completedEasyCount++;
          if (mediumTotal > 0 && mediumDone >= mediumTotal) completedMediumCount++;
          if (hardTotal > 0 && hardDone >= hardTotal) completedHardCount++;
        }

        return {
          totalChildren: totalChildrenRow.count,
          storyCounts: storyCountMap,
          completedEasy: completedEasyCount,
          completedMedium: completedMediumCount,
          completedHard: completedHardCount,
          levelDistribution: {
            beginner: beginnerCount,
            intermediate: intermediateCount,
            advanced: advancedCount,
            expert: expertCount,
          },
          topProgressChildren: (childrenWithProgress as any[]).slice(0, 10),
        };
      } finally {
        await conn.end();
      }
    }),

    // Segmented stats: kindergarten vs outside
    segmentedStats: adminProcedure.query(async () => {
      const mysql = await import('mysql2/promise');
      const conn = await mysql.default.createConnection(process.env.DATABASE_URL!);

      try {
        const getStatsForGroup = async (filter: string) => {
          const [[totalRow]] = await conn.query(`SELECT COUNT(*) as count FROM children ${filter}`) as any;

          const [topChildren] = await conn.query(`
            SELECT c.name, c.totalPoints, c.level, c.storyLevel, c.classroom, c.isKindergartenStudent,
              COALESCE(COUNT(CASE WHEN sp.isCompleted = 1 THEN 1 END), 0) as totalDone,
              (SELECT COUNT(*) FROM child_voice_recordings vr WHERE vr.childId = c.id AND vr.isDeleted = 0) as recordingCount
            FROM children c
            LEFT JOIN child_story_progress sp ON c.id = sp.childId
            ${filter}
            GROUP BY c.id, c.name, c.totalPoints, c.level, c.storyLevel, c.classroom, c.isKindergartenStudent
            ORDER BY c.totalPoints DESC, totalDone DESC
            LIMIT 10
          `) as any;

          const [[cEasy]] = await conn.query(`
            SELECT COUNT(*) as count FROM (
              SELECT c.id FROM children c ${filter}
              AND (SELECT COUNT(*) FROM child_story_progress sp JOIN stories s ON sp.storyId = s.id
                WHERE sp.childId = c.id AND s.difficulty = 'easy' AND sp.isCompleted = 1
              ) >= (SELECT COUNT(*) FROM stories WHERE difficulty = 'easy' AND isPublished = 1)
              AND (SELECT COUNT(*) FROM stories WHERE difficulty = 'easy' AND isPublished = 1) > 0
            ) t
          `) as any;

          const [[cMedium]] = await conn.query(`
            SELECT COUNT(*) as count FROM (
              SELECT c.id FROM children c ${filter}
              AND (SELECT COUNT(*) FROM child_story_progress sp JOIN stories s ON sp.storyId = s.id
                WHERE sp.childId = c.id AND s.difficulty = 'medium' AND sp.isCompleted = 1
              ) >= (SELECT COUNT(*) FROM stories WHERE difficulty = 'medium' AND isPublished = 1)
              AND (SELECT COUNT(*) FROM stories WHERE difficulty = 'medium' AND isPublished = 1) > 0
            ) t
          `) as any;

          const [[cHard]] = await conn.query(`
            SELECT COUNT(*) as count FROM (
              SELECT c.id FROM children c ${filter}
              AND (SELECT COUNT(*) FROM child_story_progress sp JOIN stories s ON sp.storyId = s.id
                WHERE sp.childId = c.id AND s.difficulty = 'hard' AND sp.isCompleted = 1
              ) >= (SELECT COUNT(*) FROM stories WHERE difficulty = 'hard' AND isPublished = 1)
              AND (SELECT COUNT(*) FROM stories WHERE difficulty = 'hard' AND isPublished = 1) > 0
            ) t
          `) as any;

          const [classroomDist] = await conn.query(`
            SELECT classroom, COUNT(*) as count FROM children ${filter} AND classroom IS NOT NULL GROUP BY classroom
          `) as any;

          const [referralDist] = await conn.query(`
            SELECT referralSource, COUNT(*) as count FROM children ${filter} AND referralSource IS NOT NULL GROUP BY referralSource
          `) as any;

          return {
            total: totalRow.count,
            completedEasy: cEasy.count,
            completedMedium: cMedium.count,
            completedHard: cHard.count,
            topChildren,
            classroomDist,
            referralDist,
          };
        };

        const kindergartenStats = await getStatsForGroup('WHERE isKindergartenStudent = 1');
        const outsideStats = await getStatsForGroup('WHERE isKindergartenStudent = 0 OR isKindergartenStudent IS NULL');
        const allStats = await getStatsForGroup('WHERE 1=1');

        return { kindergartenStats, outsideStats, allStats };
      } finally {
        await conn.end();
      }
    }),

    // Advanced stats for overview tab
    advancedStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return null;
      const mysql = await import('mysql2/promise');
      const conn = await mysql.default.createConnection(process.env.DATABASE_URL!);
      try {
        const [topChildren] = await conn.query(`
          SELECT name, totalPoints, level FROM children ORDER BY totalPoints DESC LIMIT 5
        `) as any;
        const [recentActivity] = await conn.query(`
          SELECT c.name, sp.updatedAt FROM child_story_progress sp
          JOIN children c ON sp.childId = c.id
          ORDER BY sp.updatedAt DESC LIMIT 10
        `) as any;
        return { topChildren, recentActivity };
      } finally {
        await conn.end();
      }
    }),

    // Reviews management
    allReviews: adminProcedure.query(async () => {
      return getAllReviewsAdmin();
    }),

    approveReview: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await approveReview(input.id);
        return { success: true };
      }),

    deleteReview: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteReview(input.id);
        return { success: true };
      }),

    // ─── Admin: Game Management (NEW) ────────────────────────────────────────
    allGames: adminProcedure.query(async () => {
      return getAllEducationalGamesAdmin();
    }),

    createGame: adminProcedure
      .input(z.object({
        title: z.string().min(2),
        description: z.string().optional(),
        type: z.string(),
        level: z.enum(["easy", "medium", "hard"]),
        ageGroup: z.string().optional(),
        emoji: z.string().optional(),
        pointsReward: z.number().optional(),
        gameData: z.any(),
        orderIndex: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const game = await createEducationalGame(input);
        return { success: true, game };
      }),

    updateGame: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        type: z.string().optional(),
        level: z.enum(["easy", "medium", "hard"]).optional(),
        emoji: z.string().optional(),
        pointsReward: z.number().optional(),
        gameData: z.any().optional(),
        isPublished: z.boolean().optional(),
        orderIndex: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await updateEducationalGame(id, data);
        return { success: true };
      }),

    deleteGame: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteEducationalGame(input.id);
        return { success: true };
      }),

    seedSampleData: adminProcedure.mutation(async () => {
      await seedDefaultAchievements();
      await seedSampleStories();
      return { success: true };
    }),
    // ─── Adventures Admin ────────────────────────────────────────────────────────
    allAdventures: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(storyAdventures).orderBy(storyAdventures.orderIndex, storyAdventures.id);
    }),
    createAdventure: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        emoji: z.string().default("🌟"),
        level: z.enum(["easy", "medium", "hard"]),
        ageGroup: z.enum(["4-6", "6-8", "8-10", "all"]).default("all"),
        pointsReward: z.number().default(50),
        totalEndings: z.number().default(2),
        adventureData: z.any(),
        isPublished: z.boolean().default(true),
        orderIndex: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB error" });
        await db.insert(storyAdventures).values({
          title: input.title,
          description: input.description,
          emoji: input.emoji,
          level: input.level,
          ageGroup: input.ageGroup,
          pointsReward: input.pointsReward,
          totalEndings: input.totalEndings,
          adventureData: input.adventureData ?? {},
          isPublished: input.isPublished,
          orderIndex: input.orderIndex,
        });
        return { success: true };
      }),
    updateAdventure: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        description: z.string().optional(),
        emoji: z.string().optional(),
        level: z.enum(["easy", "medium", "hard"]).optional(),
        pointsReward: z.number().optional(),
        isPublished: z.boolean().optional(),
        orderIndex: z.number().optional(),
        totalEndings: z.number().optional(),
        adventureData: z.any().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB error" });
        const { id, ...rest } = input;
        await db.update(storyAdventures).set(rest).where(eq(storyAdventures.id, id));
        return { success: true };
      }),
    deleteAdventure: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB error" });
        await db.delete(childAdventureProgress).where(eq(childAdventureProgress.adventureId, input.id));
        await db.delete(storyAdventures).where(eq(storyAdventures.id, input.id));
        return { success: true };
      }),
    // ─── Interactive Games Admin ──────────────────────────────────────────────────
    interactiveLabStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { totalPlays: 0, completedGames: 0, byCategory: [] };
      const rows = await db.select().from(interactiveGameProgress);
      const totalPlays = rows.reduce((s, r) => s + r.attempts, 0);
      const completedGames = rows.filter(r => r.isCompleted).length;
      const byCategory = ["memory", "sorting", "sequencing", "build_logic"].map(cat => ({
        category: cat,
        plays: rows.filter(r => r.category === cat).reduce((s, r) => s + r.attempts, 0),
        completed: rows.filter(r => r.category === cat && r.isCompleted).length,
      }));
      return { totalPlays, completedGames, byCategory };
    }),
    deleteInteractiveProgress: adminProcedure
      .input(z.object({ childId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB error" });
        await db.delete(interactiveGameProgress).where(eq(interactiveGameProgress.childId, input.childId));
        return { success: true };
      }),
    // ─── Comprehensive Stats ──────────────────────────────────────────────────────
    comprehensiveStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return null;
      const [allChildren, allStories, allGames, allAdventures, allActivities, allReviews, allProgress, allGameProgress, allAdventureProgress, allInteractiveProgress] = await Promise.all([
        db.select().from(children),
        db.select().from(stories),
        db.select().from(educationalGames),
        db.select().from(storyAdventures),
        db.select().from(activities),
        db.select().from(siteReviews),
        db.select().from(childStoryProgress),
        db.select().from(childGameProgress),
        db.select().from(childAdventureProgress),
        db.select().from(interactiveGameProgress),
      ]);
      // Children stats
      const totalChildren = allChildren.length;
      const kindergartenChildren = allChildren.filter(c => c.isKindergartenStudent).length;
      const outsideChildren = totalChildren - kindergartenChildren;
      const classroomBreakdown = ["مرح", "نجوم", "غيوم", "ألوان"].map(cls => ({
        name: cls,
        count: allChildren.filter(c => c.classroom === cls).length,
      }));
      const levelBreakdown = [1,2,3,4,5,6,7,8,9,10].map(lvl => ({
        level: lvl,
        count: allChildren.filter(c => c.level === lvl).length,
      }));
      const topChildren = [...allChildren].sort((a, b) => b.totalPoints - a.totalPoints).slice(0, 10).map(c => ({
        name: c.name, points: c.totalPoints, level: c.level, classroom: c.classroom,
      }));
      // Content stats
      const totalStories = allStories.length;
      const totalGames = allGames.length;
      const totalAdventures = allAdventures.length;
      const totalActivities = allActivities.length;
      // Engagement stats
      const totalStoryReads = allProgress.filter(p => p.isCompleted).length;
      const totalGamePlays = allGameProgress.reduce((s, r) => s + (r.attempts ?? 0), 0);
      const totalAdventurePlays = allAdventureProgress.length;
      const totalInteractivePlays = allInteractiveProgress.reduce((s, r) => s + r.attempts, 0);
      const totalPoints = allChildren.reduce((s, c) => s + c.totalPoints, 0);
      const avgPoints = totalChildren > 0 ? Math.round(totalPoints / totalChildren) : 0;
      // Reviews stats
      const totalReviews = allReviews.length;
      const avgRating = totalReviews > 0 ? (allReviews.reduce((s, r) => s + r.rating, 0) / totalReviews).toFixed(1) : "0";
      // Most read stories
      const storyReadCounts = allStories.map(s => ({
        title: s.title,
        reads: allProgress.filter(p => p.storyId === s.id && p.isCompleted).length,
      })).sort((a, b) => b.reads - a.reads).slice(0, 5);
      // Interactive games by category
      const interactiveByCategory = ["memory", "sorting", "sequencing", "build_logic"].map(cat => ({
        category: cat,
        plays: allInteractiveProgress.filter(r => r.category === cat).reduce((s, r) => s + r.attempts, 0),
        completed: allInteractiveProgress.filter(r => r.category === cat && r.isCompleted).length,
      }));
      return {
        generatedAt: new Date().toISOString(),
        children: { total: totalChildren, kindergarten: kindergartenChildren, outside: outsideChildren, classroomBreakdown, levelBreakdown, topChildren },
        content: { stories: totalStories, games: totalGames, adventures: totalAdventures, activities: totalActivities },
        engagement: { storyReads: totalStoryReads, gamePlays: totalGamePlays, adventurePlays: totalAdventurePlays, interactivePlays: totalInteractivePlays },
        points: { total: totalPoints, average: avgPoints },
        reviews: { total: totalReviews, avgRating },
        storyReadCounts,
        interactiveByCategory,
      };
    }),
  }),
  // ─── Leaderboard ────────────────────────────────────────────────────────────────────
  leaderboard: router({
    top5: publicProcedure
      .input(z.object({
        isKindergarten: z.boolean().optional(),
        classroom: z.string().nullable().optional(),
      }).optional())
      .query(async ({ input }) => {
        return getTopChildren(5, {
          isKindergarten: input?.isKindergarten,
          classroom: input?.classroom,
        });
      }),
    getTop: publicProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return getLeaderboard(input.limit ?? 20);
      }),
  }),

  // ─── Reviews ───────────────────────────────────────────────────────────────
  reviews: router({
    list: publicProcedure.query(async () => {
      return getApprovedReviews();
    }),

    submit: publicProcedure
      .input(z.object({
        name: z.string().min(2).max(100),
        review: z.string().min(5).max(1000),
        rating: z.number().min(1).max(5).default(5),
      }))
      .mutation(async ({ input }) => {
        await createReview({
          name: input.name,
          review: input.review,
          rating: input.rating,
          isApproved: false,
          isDeleted: false,
        });
        return { success: true };
      }),
  }),

  // ─── Educational Games ───────────────────────────────────────────────────────
  games: router({
    list: publicProcedure
      .input(z.object({ level: z.enum(["easy", "medium", "hard"]).optional() }))
      .query(async ({ input }) => {
        return getAllEducationalGames(input.level);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const game = await getEducationalGameById(input.id);
        if (!game) throw new TRPCError({ code: "NOT_FOUND", message: "اللعبة غير موجودة" });
        return game;
      }),

    saveProgress: publicProcedure
      .input(z.object({
        childId: z.number(),
        gameId: z.number(),
        score: z.number(),
        maxScore: z.number(),
        isCompleted: z.boolean(),
        pointsEarned: z.number(),
      }))
      .mutation(async ({ input }) => {
        await saveGameProgress(input);
        const newAchievements = await checkAndAwardAchievements(input.childId);
        return { success: true, newAchievements };
      }),

    myProgress: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildGameProgressList(input.childId);
      }),
    getLockedGames: publicProcedure
      .query(async () => {
        return getLockedGames();
      }),
    getUnlockedGameIds: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildUnlockedGameIds(input.childId);
      }),
    unlockGame: publicProcedure
      .input(z.object({ childId: z.number(), gameId: z.number() }))
      .mutation(async ({ input }) => {
        return unlockGameWithPoints(input.childId, input.gameId);
      }),
    uploadImage: adminProcedure
      .input(z.object({
        base64: z.string(),
        filename: z.string().optional(),
        contentType: z.string().default("image/jpeg"),
      }))
      .mutation(async ({ input }) => {
        const { storagePut } = await import("./storage.js");
        const base64Data = input.base64.replace(/^data:[^;]+;base64,/, "");
        const buffer = Buffer.from(base64Data, "base64");
        const ext = input.contentType.split("/")[1] ?? "jpg";
        const filename = input.filename ?? `game-img-${Date.now()}.${ext}`;
        const key = `game-images/${Date.now()}-${filename}`;
        const { url } = await storagePut(key, buffer, input.contentType);
        return { url };
      }),
  }),

  // ─── Daily Challenges ──────────────────────────────────────────────────────
  challenges: router({
    getToday: publicProcedure
      .input(z.object({ childLevel: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getTodayChallenge(input?.childLevel ?? 1);
      }),
    getAdminDetails: adminProcedure.query(async () => {
      return getTodayChallengeAdmin();
    }),
    getProgress: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildDailyChallengeProgress(input.childId);
      }),
    markTask: publicProcedure
      .input(z.object({ childId: z.number(), task: z.enum(["readStory", "playGame", "playAdventure"]) }))
      .mutation(async ({ input }) => {
         return markChallengeTask(input.childId, input.task);
      }),
  }),

  // ─── Shopp ────────────────────────────────────────────────────────────────────
  shop: router({
    getItems: publicProcedure.query(async () => {
      return getShopItems();
    }),
    getAllAdmin: adminProcedure.query(async () => {
      return getAllShopItems();
    }),
    getAllAdminWithCount: adminProcedure.query(async () => {
      return getAllShopItemsWithPurchaseCount();
    }),
    upsert: adminProcedure
      .input(z.object({
        id: z.number().optional(),
        type: z.enum(["avatar", "theme", "adventure_unlock"]),
        name: z.string(),
        description: z.string().optional(),
        icon: z.string().optional(),
        value: z.string(),
        levelRequired: z.number(),
        pointsCost: z.number(),
        isEnabled: z.boolean(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return upsertShopItem(input);
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return deleteShopItem(input.id);
      }),
    getInventory: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildInventory(input.childId);
      }),
    purchase: publicProcedure
      .input(z.object({ childId: z.number(), shopItemId: z.number() }))
      .mutation(async ({ input }) => {
        return purchaseShopItem(input.childId, input.shopItemId);
      }),
    grantLevelReward: publicProcedure
      .input(z.object({ childId: z.number(), level: z.number(), shopItemId: z.number() }))
      .mutation(async ({ input }) => {
        return grantLevelReward(input.childId, input.level, input.shopItemId);
      }),
    equip: publicProcedure
      .input(z.object({ childId: z.number(), shopItemId: z.number() }))
      .mutation(async ({ input }) => {
        return equipShopItem(input.childId, input.shopItemId);
      }),
    adminAdjustChild: adminProcedure
      .input(z.object({ childId: z.number(), points: z.number().optional(), level: z.number().optional() }))
      .mutation(async ({ input }) => {
        return adminAdjustChild(input.childId, { points: input.points, level: input.level });
      }),
  }),

  interactiveLab: router({
    getProgress: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const rows = await db.select().from(interactiveGameProgress)
          .where(eq(interactiveGameProgress.childId, input.childId));
        return rows;
      }),
    saveProgress: publicProcedure
      .input(z.object({
        childId: z.number(),
        gameId: z.string(),
        category: z.enum(["memory", "sorting", "sequencing", "build_logic", "logic_puzzle", "coloring"]),
        score: z.number(),
        isCompleted: z.boolean(),
        pointsEarned: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB error" });
        // Check if record exists
        const existing = await db.select().from(interactiveGameProgress)
          .where(
            and(
              eq(interactiveGameProgress.childId, input.childId),
              eq(interactiveGameProgress.gameId, input.gameId)
            )
          );
        if (existing.length > 0) {
          await db.update(interactiveGameProgress)
            .set({
              score: Math.max(existing[0].score, input.score),
              isCompleted: existing[0].isCompleted || input.isCompleted,
              pointsEarned: Math.max(existing[0].pointsEarned, input.pointsEarned),
              attempts: existing[0].attempts + 1,
              completedAt: input.isCompleted ? new Date() : existing[0].completedAt,
            })
            .where(
              and(
                eq(interactiveGameProgress.childId, input.childId),
                eq(interactiveGameProgress.gameId, input.gameId)
              )
            );
        } else {
          await db.insert(interactiveGameProgress).values({
            childId: input.childId,
            gameId: input.gameId,
            category: input.category,
            score: input.score,
            isCompleted: input.isCompleted,
            pointsEarned: input.pointsEarned,
            attempts: 1,
            completedAt: input.isCompleted ? new Date() : undefined,
          });
        }
        // Award points to child
        if (input.pointsEarned > 0 && input.childId > 0) {
          const childRows = await db.select().from(children).where(eq(children.id, input.childId));
          if (childRows.length > 0) {
            const newPoints = childRows[0].totalPoints + input.pointsEarned;
            const newLevel = Math.min(10, Math.floor(newPoints / 100) + 1);
            await db.update(children)
              .set({ totalPoints: newPoints, level: newLevel })
              .where(eq(children.id, input.childId));
          }
          await checkAndAwardAchievements(input.childId);
        }
        return { success: true, pointsEarned: input.pointsEarned };
      }),
  }),

  // ─── Voice Recordings ──────────────────────────────────────────────────────────────
  recordings: router({
    // جلب تسجيلات طفل معين
    getMyRecordings: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(childVoiceRecordings)
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            eq(childVoiceRecordings.isDeleted, false)
          ))
          .orderBy(desc(childVoiceRecordings.createdAt));
      }),

    // حفظ تسجيل جديد (URL من S3) - إذا كان pageNumber موجوداً يستبدل التسجيل القديم
    saveRecording: publicProcedure
      .input(z.object({
        childId: z.number(),
        title: z.string().min(1).max(200),
        audioUrl: z.string().url(),
        audioKey: z.string(),
        durationSeconds: z.number().optional(),
        storyId: z.number().optional(),
        pageNumber: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // إذا كان لدينا storyId + pageNumber نستبدل التسجيل القديم بدلاً من إضافة جديد
        if (input.storyId && input.pageNumber !== undefined) {
          const existing = await db.select().from(childVoiceRecordings)
            .where(and(
              eq(childVoiceRecordings.childId, input.childId),
              eq(childVoiceRecordings.storyId, input.storyId),
              eq(childVoiceRecordings.pageNumber, input.pageNumber),
              eq(childVoiceRecordings.isDeleted, false)
            ));
          if (existing.length > 0) {
            // تحديث التسجيل الموجود
            await db.update(childVoiceRecordings)
              .set({
                audioUrl: input.audioUrl,
                audioKey: input.audioKey,
                durationSeconds: input.durationSeconds ?? 0,
                isApproved: false,
              })
              .where(eq(childVoiceRecordings.id, existing[0].id));
            return { success: true, id: existing[0].id, replaced: true };
          }
        }
        const result = await db.insert(childVoiceRecordings).values({
          childId: input.childId,
          title: input.title,
          audioUrl: input.audioUrl,
          audioKey: input.audioKey,
          durationSeconds: input.durationSeconds ?? 0,
          storyId: input.storyId,
          pageNumber: input.pageNumber,
          isApproved: false,
          isDeleted: false,
        });
        return { success: true, id: result[0].insertId, replaced: false };
      }),
    // جلب التسجيلات مجمّعة حسب القصة مع اسم القصة
    getMyRecordingsGrouped: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const recs = await db.select().from(childVoiceRecordings)
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            eq(childVoiceRecordings.isDeleted, false)
          ))
          .orderBy(desc(childVoiceRecordings.createdAt));
        // جلب أسماء القصص
        const storyIdsSet = new Set(recs.filter(r => r.storyId).map(r => r.storyId as number));
        const storyIds = Array.from(storyIdsSet);
        let storyNames: Record<number, string> = {};
        if (storyIds.length > 0) {
          const storiesList = await db.select({ id: stories.id, title: stories.title })
            .from(stories)
            .where(sql`${stories.id} IN (${sql.join(storyIds.map(id => sql`${id}`), sql`, `)})`);
          storyNames = Object.fromEntries(storiesList.map((s: { id: number; title: string }) => [s.id, s.title]));
        }
        // تجميع حسب القصة
        const grouped: Record<string, { storyId: number | null; storyTitle: string; recordings: typeof recs }> = {};
        for (const rec of recs) {
          const key = rec.storyId ? String(rec.storyId) : 'other';
          if (!grouped[key]) {
            grouped[key] = {
              storyId: rec.storyId ?? null,
              storyTitle: rec.storyId ? (storyNames[rec.storyId] ?? 'قصة غير معروفة') : 'تسجيلات أخرى',
              recordings: [],
            };
          }
          grouped[key].recordings.push(rec);
        }
        return Object.values(grouped);
      }),
    // جلب تسجيل صفحة محددة
    getPageRecording: publicProcedure
      .input(z.object({ childId: z.number(), storyId: z.number(), pageNumber: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const rows = await db.select().from(childVoiceRecordings)
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            eq(childVoiceRecordings.storyId, input.storyId),
            eq(childVoiceRecordings.pageNumber, input.pageNumber),
            eq(childVoiceRecordings.isDeleted, false)
          ))
          .limit(1);
        return rows[0] ?? null;
      }),

    // حذف تسجيل (soft delete)
    deleteRecording: publicProcedure
      .input(z.object({ id: z.number(), childId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(childVoiceRecordings)
          .set({ isDeleted: true })
          .where(and(
            eq(childVoiceRecordings.id, input.id),
            eq(childVoiceRecordings.childId, input.childId)
          ));
        return { success: true };
      }),

    // تقييم تسجيل من الأدمن (1-5 نجوم)
    rateRecording: adminProcedure
      .input(z.object({
        id: z.number(),
        rating: z.number().min(1).max(5),
        ratingComment: z.string().max(300).optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(childVoiceRecordings)
          .set({ rating: input.rating, ratingComment: input.ratingComment ?? null })
          .where(eq(childVoiceRecordings.id, input.id));
        return { success: true };
      }),
    // إدارة الأدمن: جلب جميع التسجيلات
    getAllAdmin: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const rows = await db
        .select({
          id: childVoiceRecordings.id,
          childId: childVoiceRecordings.childId,
          childName: children.name,
          title: childVoiceRecordings.title,
          audioUrl: childVoiceRecordings.audioUrl,
          isApproved: childVoiceRecordings.isApproved,
          isDeleted: childVoiceRecordings.isDeleted,
          rating: childVoiceRecordings.rating,
          ratingComment: childVoiceRecordings.ratingComment,
          createdAt: childVoiceRecordings.createdAt,
          updatedAt: childVoiceRecordings.updatedAt,
          storyId: childVoiceRecordings.storyId,
          pageNumber: childVoiceRecordings.pageNumber,
        })
        .from(childVoiceRecordings)
        .leftJoin(children, eq(childVoiceRecordings.childId, children.id))
        .where(eq(childVoiceRecordings.isDeleted, false))
        .orderBy(desc(childVoiceRecordings.createdAt));
      return rows;
    }),

    // الأدمن: اعتماد تسجيل
    approveRecording: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(childVoiceRecordings)
          .set({ isApproved: true })
          .where(eq(childVoiceRecordings.id, input.id));
        return { success: true };
      }),

    // الأدمن: حذف تسجيل
    adminDelete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(childVoiceRecordings)
          .set({ isDeleted: true })
          .where(eq(childVoiceRecordings.id, input.id));
        return { success: true };
      }),

    // جلب التسجيلات المقيّمة حديثاً ولم يرها الطفل بعد
    getNewRatings: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(childVoiceRecordings)
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            eq(childVoiceRecordings.isDeleted, false),
            sql`${childVoiceRecordings.rating} IS NOT NULL`,
            sql`${childVoiceRecordings.ratingSeenAt} IS NULL`
          ))
          .orderBy(desc(childVoiceRecordings.updatedAt));
      }),

    // تعليم التقييمات كمشاهدة
    markRatingsSeen: publicProcedure
      .input(z.object({ childId: z.number(), ids: z.array(z.number()) }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        if (input.ids.length === 0) return { success: true };
        await db.update(childVoiceRecordings)
          .set({ ratingSeenAt: new Date() })
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            sql`${childVoiceRecordings.id} IN (${sql.join(input.ids.map(id => sql`${id}`), sql`, `)})`
          ));
        return { success: true };
      }),

    // الأدمن: جلب تسجيلات طفل محدد
    getChildRecordings: adminProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const recs = await db.select().from(childVoiceRecordings)
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            eq(childVoiceRecordings.isDeleted, false)
          ))
          .orderBy(desc(childVoiceRecordings.createdAt));
        // جلب أسماء القصص
        const storyIds = Array.from(new Set(recs.filter(r => r.storyId).map(r => r.storyId as number)));
        let storyNames: Record<number, string> = {};
        if (storyIds.length > 0) {
          const storiesList = await db.select({ id: stories.id, title: stories.title })
            .from(stories)
            .where(sql`${stories.id} IN (${sql.join(storyIds.map(id => sql`${id}`), sql`, `)})`);
          storyNames = Object.fromEntries(storiesList.map((s: { id: number; title: string }) => [s.id, s.title]));
        }
        // جلب ردود الفعل لكل تسجيل
        const recIds = recs.map(r => r.id);
        let reactionsMap: Record<number, Array<{ id: number; emoji: string; label: string; createdAt: Date }>> = {};
        if (recIds.length > 0) {
          const allReactions = await db.select().from(recordingReactions)
            .where(sql`${recordingReactions.recordingId} IN (${sql.join(recIds.map(id => sql`${id}`), sql`, `)})`);
          allReactions.forEach((rx: any) => {
            if (!reactionsMap[rx.recordingId]) reactionsMap[rx.recordingId] = [];
            reactionsMap[rx.recordingId].push({ id: rx.id, emoji: rx.emoji, label: rx.label, createdAt: rx.createdAt });
          });
        }
        return recs.map(r => ({ ...r, storyTitle: r.storyId ? (storyNames[r.storyId] ?? 'قصة غير معروفة') : null, reactions: reactionsMap[r.id] ?? [] }));
      }),

    // الأدمن: إضافة رد فعل (رمز تعبيري) على تسجيل
    addReaction: adminProcedure
      .input(z.object({
        recordingId: z.number(),
        emoji: z.string().max(10),
        label: z.string().max(100),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.insert(recordingReactions).values({
          recordingId: input.recordingId,
          emoji: input.emoji,
          label: input.label,
          seenByChild: false,
        });
        return { success: true };
      }),

    // الأدمن: حذف رد فعل
    deleteReaction: adminProcedure
      .input(z.object({ reactionId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.delete(recordingReactions).where(eq(recordingReactions.id, input.reactionId));
        return { success: true };
      }),

    // الطفل: جلب ردود الفعل على تسجيلاته (غير المشاهدة)
    getMyReactions: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        // جلب تسجيلات هذا الطفل مع storyId وpageNumber
        const recs = await db.select({
          id: childVoiceRecordings.id,
          title: childVoiceRecordings.title,
          storyId: childVoiceRecordings.storyId,
          pageNumber: childVoiceRecordings.pageNumber,
        })
          .from(childVoiceRecordings)
          .where(and(
            eq(childVoiceRecordings.childId, input.childId),
            eq(childVoiceRecordings.isDeleted, false)
          ));
        if (recs.length === 0) return [];
        const recIds = recs.map(r => r.id);
        const recMap = Object.fromEntries(recs.map(r => [r.id, r]));
        // جلب أسماء القصص المرتبطة
        const storyIdsSet = new Set(recs.map(r => r.storyId).filter(Boolean) as number[]);
        const storyIds = Array.from(storyIdsSet);
        let storyNames: Record<number, string> = {};
        if (storyIds.length > 0) {
          const storyRows = await db.select({ id: stories.id, title: stories.title })
            .from(stories)
            .where(sql`${stories.id} IN (${sql.join(storyIds.map(id => sql`${id}`), sql`, `)})`);
          storyNames = Object.fromEntries(storyRows.map(s => [s.id, s.title]));
        }
        const reactions = await db.select().from(recordingReactions)
          .where(sql`${recordingReactions.recordingId} IN (${sql.join(recIds.map(id => sql`${id}`), sql`, `)})`)
          .orderBy(sql`${recordingReactions.createdAt} DESC`);
        return reactions.map((rx: any) => ({
          ...rx,
          recordingTitle: recMap[rx.recordingId]?.title ?? '',
          storyId: recMap[rx.recordingId]?.storyId ?? null,
          pageNumber: recMap[rx.recordingId]?.pageNumber ?? null,
          storyTitle: recMap[rx.recordingId]?.storyId ? (storyNames[recMap[rx.recordingId]!.storyId!] ?? '') : '',
        }));
      }),

    // الطفل: تعليم ردود الفعل كمشاهدة
    markReactionsSeen: publicProcedure
      .input(z.object({ reactionIds: z.array(z.number()) }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        if (input.reactionIds.length === 0) return { success: true };
        await db.update(recordingReactions)
          .set({ seenByChild: true })
          .where(sql`${recordingReactions.id} IN (${sql.join(input.reactionIds.map(id => sql`${id}`), sql`, `)})`);
        return { success: true };
      }),

    // مدير المدرسة: جلب تسجيلات طلاب مدرسته
    getSchoolRecordings: adminProcedure
      .input(z.object({ schoolId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        // جلب أطفال المدرسة
        const schoolChildren = await db.select({ id: children.id, name: children.name, classroom: children.classroom })
          .from(children)
          .where(eq(children.schoolId, input.schoolId));
        if (schoolChildren.length === 0) return [];
        const childIds = schoolChildren.map(c => c.id);
        const childMap = Object.fromEntries(schoolChildren.map(c => [c.id, c]));
        // جلب التسجيلات
        const recs = await db.select().from(childVoiceRecordings)
          .where(and(
            sql`${childVoiceRecordings.childId} IN (${sql.join(childIds.map(id => sql`${id}`), sql`, `)})`,
            eq(childVoiceRecordings.isDeleted, false)
          ))
          .orderBy(desc(childVoiceRecordings.createdAt));
        // جلب أسماء القصص
        const storyIds = Array.from(new Set(recs.filter(r => r.storyId).map(r => r.storyId as number)));
        let storyNames: Record<number, string> = {};
        if (storyIds.length > 0) {
          const storiesList = await db.select({ id: stories.id, title: stories.title })
            .from(stories)
            .where(sql`${stories.id} IN (${sql.join(storyIds.map(id => sql`${id}`), sql`, `)})`);
          storyNames = Object.fromEntries(storiesList.map((s: { id: number; title: string }) => [s.id, s.title]));
        }
        // جلب ردود الفعل
        const recIds = recs.map(r => r.id);
        let reactionsMap: Record<number, Array<{ id: number; emoji: string; label: string; createdAt: Date }>> = {};
        if (recIds.length > 0) {
          const allReactions = await db.select().from(recordingReactions)
            .where(sql`${recordingReactions.recordingId} IN (${sql.join(recIds.map(id => sql`${id}`), sql`, `)})`);
          allReactions.forEach((rx: any) => {
            if (!reactionsMap[rx.recordingId]) reactionsMap[rx.recordingId] = [];
            reactionsMap[rx.recordingId].push({ id: rx.id, emoji: rx.emoji, label: rx.label, createdAt: rx.createdAt });
          });
        }
        return recs.map(r => ({
          ...r,
          childName: childMap[r.childId]?.name ?? 'طفل',
          storyTitle: r.storyId ? (storyNames[r.storyId] ?? 'قصة غير معروفة') : null,
          reactions: reactionsMap[r.id] ?? []
        }));
      }),

    // مدير المدرسة: إضافة رد فعل على تسجيل
    schoolAddReaction: adminProcedure
      .input(z.object({
        recordingId: z.number(),
        emoji: z.string().max(10),
        label: z.string().max(100),
        schoolId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // التحقق أن التسجيل ينتمي لطفل في المدرسة
        const [rec] = await db.select({ childId: childVoiceRecordings.childId })
          .from(childVoiceRecordings)
          .where(eq(childVoiceRecordings.id, input.recordingId));
        if (!rec) throw new TRPCError({ code: "NOT_FOUND" });
        const [child] = await db.select({ schoolId: children.schoolId })
          .from(children)
          .where(eq(children.id, rec.childId));
        if (!child || child.schoolId !== input.schoolId) throw new TRPCError({ code: "FORBIDDEN" });
        await db.insert(recordingReactions).values({
          recordingId: input.recordingId,
          emoji: input.emoji,
          label: input.label,
          seenByChild: false,
        });
        return { success: true };
      }),

    // مدير المدرسة: حذف رد فعل
    schoolDeleteReaction: adminProcedure
      .input(z.object({ reactionId: z.number(), schoolId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.delete(recordingReactions).where(eq(recordingReactions.id, input.reactionId));
        return { success: true };
      }),
  }),

  // ─── Companion Characters ──────────────────────────────────────────────────
  companion: router({
    // جلب الشخصية المرافقة الحالية للطفل
    getMyCompanion: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const rows = await db.select().from(childCompanion)
          .where(eq(childCompanion.childId, input.childId));
        return rows[0] ?? null;
      }),

    // جلب الشخصيات المملوكة للطفل
    getOwnedCharacters: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const rows = await db.select().from(childOwnedCharacters)
          .where(eq(childOwnedCharacters.childId, input.childId));
        return rows.map(r => r.characterId);
      }),

    // شراء شخصية جديدة
    purchaseCharacter: publicProcedure
      .input(z.object({
        childId: z.number(),
        characterId: z.string(),
        pointsCost: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // التحقق من النقاط
        const childRows = await db.select().from(children).where(eq(children.id, input.childId));
        if (childRows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "الطفل غير موجود" });
        const child = childRows[0];
        if (child.totalPoints < input.pointsCost) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "نقاط غير كافية" });
        }
        // التحقق من عدم الشراء مسبقاً
        const existing = await db.select().from(childOwnedCharacters)
          .where(and(eq(childOwnedCharacters.childId, input.childId), eq(childOwnedCharacters.characterId, input.characterId)));
        if (existing.length > 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "الشخصية مملوكة مسبقاً" });
        }
        // خصم النقاط
        await db.update(children)
          .set({ totalPoints: child.totalPoints - input.pointsCost })
          .where(eq(children.id, input.childId));
        // إضافة الشخصية للمخزون
        await db.insert(childOwnedCharacters).values({
          childId: input.childId,
          characterId: input.characterId,
          acquiredVia: "purchase",
        });
        return { success: true, remainingPoints: child.totalPoints - input.pointsCost };
      }),

    // تجهيز شخصية (تعيينها كمرافق)
    equipCharacter: publicProcedure
      .input(z.object({
        childId: z.number(),
        characterId: z.string(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // upsert
        const existing = await db.select().from(childCompanion)
          .where(eq(childCompanion.childId, input.childId));
        if (existing.length > 0) {
          await db.update(childCompanion)
            .set({ characterId: input.characterId })
            .where(eq(childCompanion.childId, input.childId));
        } else {
          await db.insert(childCompanion).values({
            childId: input.childId,
            characterId: input.characterId,
          });
        }
        return { success: true };
      }),
  }),

  // ─── Color Themes ────────────────────────────────────────────────────────────
  colorTheme: router({
    getMyTheme: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { themeId: 'default' };
        const rows = await db.select().from(childColorTheme)
          .where(eq(childColorTheme.childId, input.childId));
        return rows[0] ?? { themeId: 'default' };
      }),

    setTheme: publicProcedure
      .input(z.object({
        childId: z.number(),
        themeId: z.string(),
        pointsCost: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // إذا كان هناك تكلفة، خصم النقاط
        if (input.pointsCost && input.pointsCost > 0) {
          const childRows = await db.select().from(children).where(eq(children.id, input.childId));
          if (childRows.length === 0) throw new TRPCError({ code: "NOT_FOUND" });
          const child = childRows[0];
          if (child.totalPoints < input.pointsCost) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "نقاط غير كافية" });
          }
          await db.update(children)
            .set({ totalPoints: child.totalPoints - input.pointsCost })
            .where(eq(children.id, input.childId));
        }
        // upsert theme
        const existing = await db.select().from(childColorTheme)
          .where(eq(childColorTheme.childId, input.childId));
        if (existing.length > 0) {
          await db.update(childColorTheme)
            .set({ themeId: input.themeId })
            .where(eq(childColorTheme.childId, input.childId));
        } else {
          await db.insert(childColorTheme).values({
            childId: input.childId,
            themeId: input.themeId,
          });
        }
        return { success: true };
      }),
  }),

  adventures: router({
    list: publicProcedure
      .input(z.object({ level: z.string().optional() }))
      .query(async ({ input }) => {
        return getAllAdventures(input.level);
      }),
    getLockedAdventures: publicProcedure.query(async () => {
      return getLockedAdventures();
    }),
    getUnlockedAdventureIds: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildUnlockedAdventureIds(input.childId);
      }),
    unlockAdventure: publicProcedure
      .input(z.object({ childId: z.number(), adventureId: z.number() }))
      .mutation(async ({ input }) => {
        return unlockAdventureWithPoints(input.childId, input.adventureId);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const adv = await getAdventureById(input.id);
        if (!adv) throw new TRPCError({ code: "NOT_FOUND", message: "المغامرة غير موجودة" });
        return adv;
      }),

    getChildProgress: publicProcedure
      .input(z.object({ childId: z.number() }))
      .query(async ({ input }) => {
        return getChildAdventureProgressList(input.childId);
      }),

    complete: publicProcedure
      .input(z.object({
        childId: z.number(),
        adventureId: z.number(),
        endingKey: z.string(),
        pointsEarned: z.number(),
        choices: z.array(z.string()),
      }))
      .mutation(async ({ input }) => {
        const result = await saveAdventureProgress({
          ...input,
          isCompleted: true,
        });
        if (input.childId > 0) {
          await checkAndAwardAchievements(input.childId);
        }
        return result ?? { pointsEarned: 0, isNewEnding: false };
      }),
  }),

  // ─── Schools (Multi-Tenant) ────────────────────────────────────────────────
  schools: router({
    // Founder only: list all schools
    list: adminProcedure.query(async () => {
      return getAllSchools();
    }),
    // Founder only: create school
    create: adminProcedure
      .input(z.object({
        name: z.string().min(2),
        email: z.string().email(),
        adminEmail: z.string().email(),
        adminName: z.string().min(2),
        adminPassword: z.string().min(6),
      }))
      .mutation(async ({ input }) => {
        const school = await createSchool({ name: input.name, email: input.email, adminEmail: input.adminEmail });
        // Create admin account for this school
        await addAdminAccount(input.adminEmail.toLowerCase().trim(), input.adminName, input.adminPassword, 'founder');
        // Update admin account with schoolId and role
        const db = await getDb();
        if (db && school) {
          const { adminAccounts: adminAccountsTable } = await import('../drizzle/schema');
          await db.execute(
            `UPDATE admin_accounts SET schoolId = ${school.id}, role = 'school_admin' WHERE email = '${input.adminEmail.toLowerCase().trim()}'`
          );
        }
        return { success: true, school };
      }),
    // Founder only: delete school
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteSchool(input.id);
        return { success: true };
      }),
    // Add classroom to school
    addClassroom: adminProcedure
      .input(z.object({ schoolId: z.number(), name: z.string().min(1) }))
      .mutation(async ({ input }) => {
        await addSchoolClassroom(input.schoolId, input.name);
        return { success: true };
      }),
    // Get classrooms for a school (public - needed for registration)
    getClassrooms: publicProcedure
      .input(z.object({ schoolId: z.number() }))
      .query(async ({ input }) => {
        return getSchoolClassrooms(input.schoolId);
      }),
    // Delete classroom
    deleteClassroom: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteSchoolClassroom(input.id);
        return { success: true };
      }),
    // Get stats for a specific school (school admin or founder)
    getStats: publicProcedure
      .input(z.object({ schoolId: z.number() }))
      .query(async ({ input }) => {
        return getSchoolStats(input.schoolId);
      }),

    // School admin: bulk delete children in their school
    bulkDeleteChildren: adminProcedure
      .input(z.object({
        childIds: z.array(z.number()).min(1),
        schoolId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // Verify all children belong to this school
        for (const id of input.childIds) {
          const child = await db.select().from(children).where(eq(children.id, id)).then(r => r[0]);
          if (child && child.schoolId === input.schoolId) {
            await deleteChild(id);
          }
        }
        return { success: true, deleted: input.childIds.length };
      }),

    // School admin: bulk transfer children between classrooms in their school
    bulkTransferClassroom: adminProcedure
      .input(z.object({
        childIds: z.array(z.number()).min(1),
        schoolId: z.number(),
        classroom: z.string(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        for (const id of input.childIds) {
          const child = await db.select().from(children).where(eq(children.id, id)).then(r => r[0]);
          if (child && child.schoolId === input.schoolId) {
            await db.update(children).set({ classroom: input.classroom as any }).where(eq(children.id, id));
          }
        }
        return { success: true, transferred: input.childIds.length };
      }),

    // Founder only: get all schools stats
    getAllStats: adminProcedure.query(async () => {
      return getAllSchoolsStats();
    }),
    // Public: list schools for registration dropdown
    listPublic: publicProcedure.query(async () => {
      const allSchools = await getAllSchools();
      return allSchools.filter((s: any) => s.isActive);
    }),
    // Send weekly report to a school admin (founder only)
    sendWeeklyReport: adminProcedure
      .input(z.object({ schoolId: z.number(), customNote: z.string().optional() }))
      .mutation(async ({ input }) => {
        const school = await getSchoolById(input.schoolId);
        if (!school) throw new TRPCError({ code: "NOT_FOUND", message: "المدرسة غير موجودة" });
        const stats = await getSchoolStats(input.schoolId);
        if (!stats) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // Build stats object for email
        const now = new Date();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - 7);
        const emailStats = {
          totalStudents: stats.totalChildren,
          activeStudents: stats.children.filter((c: any) => (c.totalPoints ?? 0) > 0).length,
          avgScore: stats.avgPoints,
          totalBadges: 0,
          topGames: [],
          topStudents: stats.topChildren.map((c: any) => ({ name: c.name, score: c.totalPoints ?? 0 })),
          weekStart: weekStart.toLocaleDateString("ar-SA"),
          weekEnd: now.toLocaleDateString("ar-SA"),
        };
        const adminEmail = (school as any).email;
        const sent = await sendWeeklyReportEmail(adminEmail, (school as any).name, emailStats, undefined, input.customNote);
        return { success: sent, message: sent ? "تم إرسال التقرير بنجاح" : "لم يتم الإرسال - يجب التحقق من الدومين في Resend أولاً عبر resend.com/domains" };
      }),
    // Send weekly reports to ALL schools (founder only)
    sendAllWeeklyReports: adminProcedure.mutation(async () => {
      const allSchools = await getAllSchools();
      let sent = 0;
      let failed = 0;
      for (const school of allSchools) {
        const stats = await getSchoolStats((school as any).id);
        if (!stats) { failed++; continue; }
        const now = new Date();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - 7);
        const emailStats = {
          totalStudents: stats.totalChildren,
          activeStudents: stats.children.filter((c: any) => (c.totalPoints ?? 0) > 0).length,
          avgScore: stats.avgPoints,
          totalBadges: 0,
          topGames: [],
          topStudents: stats.topChildren.map((c: any) => ({ name: c.name, score: c.totalPoints ?? 0 })),
          weekStart: weekStart.toLocaleDateString("ar-SA"),
          weekEnd: now.toLocaleDateString("ar-SA"),
        };
        const ok = await sendWeeklyReportEmail((school as any).email, (school as any).name, emailStats);
        if (ok) sent++; else failed++;
      }
      return { sent, failed, total: allSchools.length };
    }),

    // بيانات نمو المستخدمين مع دعم فلتر التاريخ
    userGrowthStats: adminProcedure
      .input(z.object({
        fromDate: z.string().optional(), // YYYY-MM-DD
        toDate: z.string().optional(),   // YYYY-MM-DD
      }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { weekly: [], monthly: [], byAgeGroup: [], byGender: [] };

        const now = new Date();
        // تحويل Date إلى صيغة MySQL DATETIME
        const toSqlDate = (d: Date) => d.toISOString().slice(0, 19).replace('T', ' ');

        // تحديد نطاق التاريخ المخصص أو الافتراضي
        const rangeStart = input?.fromDate ? new Date(input.fromDate + "T00:00:00") : null;
        const rangeEnd   = input?.toDate   ? new Date(input.toDate   + "T23:59:59") : null;
        const useCustomRange = rangeStart && rangeEnd;

        // بيانات آخر 12 أسبوع (أو ضمن النطاق المخصص)
        const weeklyRows: Array<{ week: string; count: number }> = [];
        if (useCustomRange) {
          const msPerWeek = 7 * 24 * 60 * 60 * 1000;
          const totalMs = rangeEnd!.getTime() - rangeStart!.getTime();
          const numWeeks = Math.max(1, Math.min(52, Math.ceil(totalMs / msPerWeek)));
          for (let i = 0; i < numWeeks; i++) {
            const wStart = new Date(rangeStart!.getTime() + i * msPerWeek);
            const wEnd   = new Date(Math.min(wStart.getTime() + msPerWeek - 1, rangeEnd!.getTime()));
            const [row] = await db.execute(
              `SELECT COUNT(*) as count FROM children WHERE createdAt >= '${toSqlDate(wStart)}' AND createdAt <= '${toSqlDate(wEnd)}'`
            ) as any[];
            const label = wStart.toLocaleDateString("ar-SA", { month: "short", day: "numeric" });
            weeklyRows.push({ week: label, count: Number((row as any)?.count ?? 0) });
          }
        } else {
          for (let i = 11; i >= 0; i--) {
            const weekStart = new Date(now);
            weekStart.setDate(now.getDate() - i * 7 - 6);
            weekStart.setHours(0, 0, 0, 0);
            const weekEnd = new Date(now);
            weekEnd.setDate(now.getDate() - i * 7);
            weekEnd.setHours(23, 59, 59, 999);
            const [row] = await db.execute(
              `SELECT COUNT(*) as count FROM children WHERE createdAt >= '${toSqlDate(weekStart)}' AND createdAt <= '${toSqlDate(weekEnd)}'`
            ) as any[];
            const label = weekStart.toLocaleDateString("ar-SA", { month: "short", day: "numeric" });
            weeklyRows.push({ week: label, count: Number((row as any)?.count ?? 0) });
          }
        }

        // بيانات آخر 12 شهر (أو ضمن النطاق المخصص)
        const monthlyRows: Array<{ month: string; count: number }> = [];
        if (useCustomRange) {
          const startYear  = rangeStart!.getFullYear();
          const startMonth = rangeStart!.getMonth();
          const endYear    = rangeEnd!.getFullYear();
          const endMonth   = rangeEnd!.getMonth();
          const totalMonths = (endYear - startYear) * 12 + (endMonth - startMonth) + 1;
          for (let i = 0; i < totalMonths; i++) {
            const d = new Date(startYear, startMonth + i, 1);
            const start = new Date(Math.max(d.getTime(), rangeStart!.getTime()));
            const end   = new Date(Math.min(new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999).getTime(), rangeEnd!.getTime()));
            const [row] = await db.execute(
              `SELECT COUNT(*) as count FROM children WHERE createdAt >= '${toSqlDate(start)}' AND createdAt <= '${toSqlDate(end)}'`
            ) as any[];
            const label = d.toLocaleDateString("ar-SA", { year: "numeric", month: "short" });
            monthlyRows.push({ month: label, count: Number((row as any)?.count ?? 0) });
          }
        } else {
          for (let i = 11; i >= 0; i--) {
            const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const start = d;
            const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999);
            const [row] = await db.execute(
              `SELECT COUNT(*) as count FROM children WHERE createdAt >= '${toSqlDate(start)}' AND createdAt <= '${toSqlDate(end)}'`
            ) as any[];
            const label = d.toLocaleDateString("ar-SA", { year: "numeric", month: "short" });
            monthlyRows.push({ month: label, count: Number((row as any)?.count ?? 0) });
          }
        }

        // توزيع الفئات العمرية (ضمن النطاق إن وُجد)
        const ageFilter = useCustomRange
          ? `WHERE createdAt >= '${toSqlDate(rangeStart!)}' AND createdAt <= '${toSqlDate(rangeEnd!)}'`
          : "";
        const ageRows = await db.execute(
          `SELECT ageGroup, COUNT(*) as count FROM children ${ageFilter} GROUP BY ageGroup`
        ) as any[];
        const byAgeGroup = (Array.isArray(ageRows) ? ageRows : []).map((r: any) => ({
          name: `${r.ageGroup} سنة`,
          value: Number(r.count ?? 0),
        }));

        // توزيع الجنس
        const genderRows = await db.execute(
          `SELECT gender, COUNT(*) as count FROM children ${ageFilter} GROUP BY gender`
        ) as any[];
        const byGender = (Array.isArray(genderRows) ? genderRows : []).map((r: any) => ({
          name: r.gender === "boy" ? "أولاد" : "بنات",
          value: Number(r.count ?? 0),
        }));

        // إجمالي عدد المتعلمين
        const [totalRow] = await db.execute(`SELECT COUNT(*) as count FROM children`) as any[];
        const totalCount = Number((totalRow as any)?.count ?? 0);

        return { weekly: weeklyRows, monthly: monthlyRows, byAgeGroup, byGender, totalCount };
      }),

    // نمو الطلاب حسب المدرسة شهرياً
    schoolGrowthStats: adminProcedure
      .input(z.object({
        fromDate: z.string().optional(),
        toDate: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { schools: [], months: [], data: [] };

        const now = new Date();
        const rangeStart = input?.fromDate ? new Date(input.fromDate + "T00:00:00") : null;
        const rangeEnd   = input?.toDate   ? new Date(input.toDate   + "T23:59:59") : null;
        const useCustomRange = rangeStart && rangeEnd;

        // جلب قائمة المدارس
        const allSchools = await getAllSchools();
        if (!allSchools || allSchools.length === 0) return { schools: [], months: [], data: [] };

        // تحديد الأشهر
        const months: string[] = [];
        const monthKeys: Array<{ label: string; start: number; end: number }> = [];
        if (useCustomRange) {
          const startYear  = rangeStart!.getFullYear();
          const startMonth = rangeStart!.getMonth();
          const endYear    = rangeEnd!.getFullYear();
          const endMonth   = rangeEnd!.getMonth();
          const totalMonths = (endYear - startYear) * 12 + (endMonth - startMonth) + 1;
          for (let i = 0; i < totalMonths; i++) {
            const d = new Date(startYear, startMonth + i, 1);
            const start = Math.max(d.getTime(), rangeStart!.getTime());
            const end   = Math.min(new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999).getTime(), rangeEnd!.getTime());
            const label = d.toLocaleDateString("ar-SA", { year: "numeric", month: "short" });
            months.push(label);
            monthKeys.push({ label, start, end });
          }
        } else {
          for (let i = 11; i >= 0; i--) {
            const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const start = d.getTime();
            const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999).getTime();
            const label = d.toLocaleDateString("ar-SA", { year: "numeric", month: "short" });
            months.push(label);
            monthKeys.push({ label, start, end });
          }
        }

        // لكل مدرسة، جلب عدد الطلاب الجدد لكل شهر
        const toSqlDateSchool = (d: Date) => d.toISOString().slice(0, 19).replace('T', ' ');
        const schoolNames = allSchools.map((s: any) => s.name as string);
        const data: Array<Record<string, string | number>> = monthKeys.map(mk => {
          const row: Record<string, string | number> = { month: mk.label };
          schoolNames.forEach((name: string) => { row[name] = 0; });
          return row;
        });

        for (const school of allSchools) {
          for (let mi = 0; mi < monthKeys.length; mi++) {
            const { start, end } = monthKeys[mi];
            const startDate = new Date(start);
            const endDate = new Date(end);
            const [row] = await db.execute(
              `SELECT COUNT(*) as count FROM children WHERE schoolId = ${(school as any).id} AND createdAt >= '${toSqlDateSchool(startDate)}' AND createdAt <= '${toSqlDateSchool(endDate)}'`
            ) as any[];
            data[mi][(school as any).name] = Number((row as any)?.count ?? 0);
          }
        }

        return { schools: schoolNames, months, data };
      }),
    // طلب تسجيل مدرسة جديدة (عام - بدون تسجيل دخول)
    requestRegistration: publicProcedure
      .input(z.object({
        schoolName: z.string().min(2),
        adminName: z.string().min(2),
        adminEmail: z.string().email(),
        password: z.string().min(6),
        phone: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { schoolRegistrations: regTable } = await import("../drizzle/schema.js");
        const existing = await db.select().from(regTable)
          .where(eq(regTable.adminEmail, input.adminEmail.toLowerCase().trim()))
          .limit(1);
        if (existing.length > 0 && existing[0].status !== 'rejected') {
          throw new TRPCError({ code: "CONFLICT", message: "يوجد طلب تسجيل مسبق بهذا البريد الإلكتروني" });
        }
        const bcrypt = await import("bcrypt");
        const passwordHash = await bcrypt.hash(input.password, 10);
        if (existing.length > 0) {
          await db.update(regTable).set({
            schoolName: input.schoolName.trim(),
            adminName: input.adminName.trim(),
            passwordHash,
            phone: input.phone?.trim() ?? null,
            notes: input.notes?.trim() ?? null,
            status: "pending",
            reviewedAt: null,
            rejectionReason: null,
          }).where(eq(regTable.adminEmail, input.adminEmail.toLowerCase().trim()));
        } else {
          await db.insert(regTable).values({
            schoolName: input.schoolName.trim(),
            adminName: input.adminName.trim(),
            adminEmail: input.adminEmail.toLowerCase().trim(),
            passwordHash,
            phone: input.phone?.trim() ?? null,
            notes: input.notes?.trim() ?? null,
            status: "pending",
          });
        }
        return { success: true, message: "تم إرسال طلب التسجيل بنجاح! سيتم مراجعته وإشعارك بالقبول أو الرفض" };
      }),
    // قائمة طلبات التسجيل (للأدمن فقط)
    listRegistrations: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const { schoolRegistrations: regTable } = await import("../drizzle/schema.js");
      return db.select().from(regTable).orderBy(desc(regTable.createdAt));
    }),
    // موافقة على طلب تسجيل (للأدمن فقط)
    approveRegistration: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { schoolRegistrations: regTable, adminAccounts: adminAccountsTable, schools: schoolsTable } = await import("../drizzle/schema.js");
        const [reg] = await db.select().from(regTable).where(eq(regTable.id, input.id)).limit(1);
        if (!reg) throw new TRPCError({ code: "NOT_FOUND", message: "الطلب غير موجود" });
        // إنشاء المدرسة أو جلبها إذا كانت موجودة بالفعل
        let school: any = null;
        try {
          school = await createSchool({ name: reg.schoolName, email: reg.adminEmail, adminEmail: reg.adminEmail });
        } catch (_e: any) {
          // إذا كانت المدرسة موجودة بالفعل (UNIQUE constraint) نجلبها
          const [existing] = await db.select().from(schoolsTable).where(eq(schoolsTable.email, reg.adminEmail)).limit(1);
          school = existing ?? null;
        }
        // إنشاء أو تحديث حساب الأدمن
        const existingAdmin = await db.select().from(adminAccountsTable)
          .where(eq(adminAccountsTable.email, reg.adminEmail)).limit(1);
        if (existingAdmin.length === 0) {
          await db.insert(adminAccountsTable).values({
            email: reg.adminEmail,
            name: reg.adminName,
            password: reg.passwordHash,
            role: "school_admin",
            schoolId: school?.id ?? null,
            isActive: true,
          });
        } else {
          await db.update(adminAccountsTable)
            .set({ schoolId: school?.id ?? null, role: "school_admin", isActive: true, password: reg.passwordHash })
            .where(eq(adminAccountsTable.email, reg.adminEmail));
        }
        // تحديث الطلب إلى approved
        await db.update(regTable)
          .set({ status: "approved", reviewedAt: new Date() })
          .where(eq(regTable.id, input.id));
        return { success: true, schoolId: school?.id };
      }),
    // رفض طلب تسجيل (للأدمن فقط)
    rejectRegistration: adminProcedure
      .input(z.object({ id: z.number(), reason: z.string().optional() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { schoolRegistrations: regTable } = await import("../drizzle/schema.js");
        await db.update(regTable)
          .set({ status: "rejected", rejectionReason: input.reason ?? null, reviewedAt: new Date() })
          .where(eq(regTable.id, input.id));
        return { success: true };
      }),
  }),


  // ─── Email Subscriptions ────────────────────────────────────────────────────────────────────────────────────
  email: router({
    // إلغاء الاشتراك عبر رابط التذييل
    unsubscribe: publicProcedure
      .input(z.object({ token: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [sub] = await db.select().from(emailSubscriptions).where(eq(emailSubscriptions.token, input.token)).limit(1);
        if (!sub) throw new TRPCError({ code: "NOT_FOUND", message: "لم يتم العثور على هذا الاشتراك" });
        if (!sub.isSubscribed) return { success: true, alreadyUnsubscribed: true };
        await db.update(emailSubscriptions)
          .set({ isSubscribed: false, unsubscribedAt: new Date() })
          .where(eq(emailSubscriptions.token, input.token));
        return { success: true, alreadyUnsubscribed: false, email: sub.email };
      }),

    // إعادة الاشتراك
    resubscribe: publicProcedure
      .input(z.object({ token: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(emailSubscriptions)
          .set({ isSubscribed: true, unsubscribedAt: null })
          .where(eq(emailSubscriptions.token, input.token));
        return { success: true };
      }),

    // التحقق من حالة الاشتراك عبر التوكن
    checkStatus: publicProcedure
      .input(z.object({ token: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [sub] = await db.select().from(emailSubscriptions).where(eq(emailSubscriptions.token, input.token)).limit(1);
        if (!sub) throw new TRPCError({ code: "NOT_FOUND" });
        return { isSubscribed: sub.isSubscribed, email: sub.email, childName: sub.childName };
      }),

    // لوحة الأدمن: قائمة جميع المشتركين
    listAll: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(emailSubscriptions).orderBy(desc(emailSubscriptions.subscribedAt));
    }),

    // إحصائيات المشتركين: نمو شهري + توزيع الحالات
    subscriberStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { monthly: [], statusDist: [], total: 0, activeCount: 0, unsubCount: 0 };
      const all = await db.select().from(emailSubscriptions).orderBy(emailSubscriptions.subscribedAt);
      const total = all.length;
      const activeCount = all.filter(s => s.isSubscribed).length;
      const unsubCount = total - activeCount;

      // نمو شهري (آخر 12 شهر)
      const monthMap: Record<string, { month: string; subscribed: number; unsubscribed: number }> = {};
      const now = new Date();
      for (let i = 11; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        const label = d.toLocaleDateString('ar-SA', { month: 'short', year: '2-digit' });
        monthMap[key] = { month: label, subscribed: 0, unsubscribed: 0 };
      }
      for (const s of all) {
        if (s.subscribedAt) {
          const d = new Date(s.subscribedAt);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
          if (monthMap[key]) monthMap[key].subscribed++;
        }
        if (s.unsubscribedAt) {
          const d = new Date(s.unsubscribedAt);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
          if (monthMap[key]) monthMap[key].unsubscribed++;
        }
      }
      const monthly = Object.values(monthMap);

      // توزيع الحالات
      const statusDist = [
        { name: 'نشط', value: activeCount, fill: '#10b981' },
        { name: 'ملغى', value: unsubCount, fill: '#ef4444' },
      ];

      return { monthly, statusDist, total, activeCount, unsubCount };
    }),

    // إحصائيات مشتركي مدرسة محددة
    schoolSubscriberStats: adminProcedure
      .input(z.object({ schoolId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { monthly: [], statusDist: [], total: 0, activeCount: 0, unsubCount: 0 };
        // جلب أطفال المدرسة للحصول على إيميلاتهم
        const schoolChildren = await db.select({ id: children.id, email: children.email })
          .from(children)
          .where(eq(children.schoolId, input.schoolId));
        const emails = schoolChildren.map(c => c.email).filter(Boolean) as string[];
        if (emails.length === 0) return { monthly: [], statusDist: [], total: 0, activeCount: 0, unsubCount: 0 };
        const all = await db.select().from(emailSubscriptions)
          .where(inArray(emailSubscriptions.email, emails))
          .orderBy(emailSubscriptions.subscribedAt);
        const total = all.length;
        const activeCount = all.filter(s => s.isSubscribed).length;
        const unsubCount = total - activeCount;
        const monthMap: Record<string, { month: string; subscribed: number; unsubscribed: number }> = {};
        const now = new Date();
        for (let i = 11; i >= 0; i--) {
          const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
          const label = d.toLocaleDateString('ar-SA', { month: 'short', year: '2-digit' });
          monthMap[key] = { month: label, subscribed: 0, unsubscribed: 0 };
        }
        for (const s of all) {
          if (s.subscribedAt) {
            const d = new Date(s.subscribedAt);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (monthMap[key]) monthMap[key].subscribed++;
          }
          if (s.unsubscribedAt) {
            const d = new Date(s.unsubscribedAt);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (monthMap[key]) monthMap[key].unsubscribed++;
          }
        }
        const monthly = Object.values(monthMap);
        const statusDist = [
          { name: 'نشط', value: activeCount, fill: '#10b981' },
          { name: 'ملغى', value: unsubCount, fill: '#ef4444' },
        ];
        return { monthly, statusDist, total, activeCount, unsubCount };
      }),

    // تشغيل التقارير يدوياً من لوحة الأدمن
    runWeeklyReports: adminProcedure.mutation(async () => {
      return runWeeklyReports();
    }),

    // عرض نص التقرير الأسبوعي لمدرسة محددة
    previewReport: adminProcedure
      .input(z.object({ schoolId: z.number() }))
      .query(async ({ input }) => {
        const school = await getSchoolById(input.schoolId);
        if (!school) throw new TRPCError({ code: "NOT_FOUND" });
        const stats = await getSchoolStats(input.schoolId);
        if (!stats) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const now = new Date();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - 7);
        const emailStats = {
          totalStudents: stats.totalChildren,
          activeStudents: stats.children.filter((c: any) => (c.totalPoints ?? 0) > 0).length,
          avgScore: stats.avgPoints,
          totalBadges: 0,
          topGames: [],
          topStudents: stats.topChildren.map((c: any) => ({ name: c.name, score: c.totalPoints ?? 0 })),
          weekStart: weekStart.toLocaleDateString("ar-SA"),
          weekEnd: now.toLocaleDateString("ar-SA"),
        };
        const text = buildWeeklyReportText((school as any).name, emailStats);
        return { text, school: (school as any).name, stats: emailStats };
      }),
  }),
});
export type AppRouter = typeof appRouter;

// ─── Seed Helpers ─────────────────────────────────────────────────────────────
async function seedDefaultAchievements() {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(achievements).limit(1);
  if (existing.length > 0) return;

  const defaultAchievements = [
    { key: "first_story", title: "أول قصة!", description: "قرأت قصتك الأولى", emoji: "📖", condition: "first_story", conditionValue: 1, pointsReward: 20 },
    { key: "stories_3", title: "قارئ نشيط", description: "قرأت 3 قصص", emoji: "🌟", condition: "stories_read", conditionValue: 3, pointsReward: 30 },
    { key: "stories_5", title: "محب القراءة", description: "قرأت 5 قصص", emoji: "🏆", condition: "stories_read", conditionValue: 5, pointsReward: 50 },
    { key: "first_activity", title: "أول نشاط!", description: "أكملت نشاطك الأول", emoji: "🎯", condition: "first_activity", conditionValue: 1, pointsReward: 20 },
    { key: "activities_3", title: "متحدي الألعاب", description: "أكملت 3 أنشطة", emoji: "🎮", condition: "activities_completed", conditionValue: 3, pointsReward: 30 },
    { key: "points_50", title: "جامع النقاط", description: "جمعت 50 نقطة", emoji: "💎", condition: "total_points", conditionValue: 50, pointsReward: 10 },
    { key: "points_100", title: "بطل النقاط", description: "جمعت 100 نقطة", emoji: "👑", condition: "total_points", conditionValue: 100, pointsReward: 25 },
    { key: "level_2", title: "ارتقيت!", description: "وصلت للمستوى الثاني", emoji: "⬆️", condition: "level_reached", conditionValue: 2, pointsReward: 15 },
  ];

  for (const ach of defaultAchievements) {
    await db.insert(achievements).values(ach).onDuplicateKeyUpdate({ set: { title: ach.title } });
  }
}

async function seedSampleStories() {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(stories).limit(1);
  if (existing.length > 0) return;

  // Story 1 - Easy
  await db.insert(stories).values({
    title: "ليلى والفراشة الملونة",
    description: "قصة جميلة عن ليلى الصغيرة التي تكتشف فراشة ملونة سحرية في حديقتها",
    coverImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
    ageGroup: "4-6",
    totalPages: 4,
    difficulty: "easy",
    pointsReward: 15,
  });
  const allStories1 = await db.select().from(stories);
  const s1 = allStories1[allStories1.length - 1];
  if (s1) {
    const pages1 = [
      { storyId: s1.id, pageNumber: 1, text: "في يوم مشمس وجميل، كانت ليلى الصغيرة تلعب في حديقة منزلها الواسعة. كانت تحب الزهور الملونة والفراشات التي تطير بينها.", imageUrl: "https://images.unsplash.com/photo-1490750967868-88df5691cc7d?w=600&h=400&fit=crop" },
      { storyId: s1.id, pageNumber: 2, text: "فجأة، رأت ليلى فراشة جميلة لم ترَ مثلها من قبل! كانت أجنحتها تلمع بألوان قوس قزح.", imageUrl: "https://images.unsplash.com/photo-1444927714506-8492d94b4e3d?w=600&h=400&fit=crop" },
      { storyId: s1.id, pageNumber: 3, text: "همست الفراشة لليلى: 'أنا فراشة السعادة! أطير إلى كل طفل يحب الطبيعة ويعتني بها.'", imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop" },
      { storyId: s1.id, pageNumber: 4, text: "من ذلك اليوم، أصبحت ليلى تسقي الزهور كل صباح وتحمي الحشرات الصغيرة. النهاية", imageUrl: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=600&h=400&fit=crop" },
    ];
    for (const page of pages1) await db.insert(storyPages).values(page);

    await db.insert(activities).values({
      storyId: s1.id, title: "أسئلة عن ليلى والفراشة", type: "quiz",
      description: "اختبر فهمك لقصة ليلى والفراشة الملونة", pointsReward: 25, ageGroup: "4-6",
    });
    const act1 = (await db.select().from(activities).where(eq(activities.storyId, s1.id)))[0];
    if (act1) {
      await db.insert(activityQuestions).values([
        { activityId: act1.id, questionText: "أين كانت ليلى تلعب؟", questionType: "multiple_choice", options: JSON.stringify(["في الحديقة", "في المدرسة", "في البيت", "في الشارع"]), correctAnswer: "0", explanation: "كانت ليلى تلعب في حديقة منزلها", orderIndex: 0 },
        { activityId: act1.id, questionText: "ما لون أجنحة الفراشة؟", questionType: "multiple_choice", options: JSON.stringify(["أحمر فقط", "أزرق فقط", "ألوان قوس قزح", "أصفر فقط"]), correctAnswer: "2", explanation: "كانت أجنحة الفراشة تلمع بألوان قوس قزح", orderIndex: 1 },
      ]);
    }
  }

  // Story 2 - Medium
  await db.insert(stories).values({
    title: "الأسد الصغير الشجاع",
    description: "قصة عن شبل أسد يكتشف الشجاعة بداخله",
    coverImage: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=400&h=300&fit=crop",
    ageGroup: "6-8", totalPages: 4, difficulty: "medium", pointsReward: 20,
  });
  const allStories2 = await db.select().from(stories);
  const s2 = allStories2[allStories2.length - 1];
  if (s2) {
    const pages2 = [
      { storyId: s2.id, pageNumber: 1, text: "في غابة خضراء جميلة، عاش شبل أسد اسمه سامي. كان سامي يخاف من كل شيء.", imageUrl: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=600&h=400&fit=crop" },
      { storyId: s2.id, pageNumber: 2, text: "ذات يوم، سمع سامي صوت بكاء. وجد أرنباً صغيراً عالقاً في شجرة عالية.", imageUrl: "https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=600&h=400&fit=crop" },
      { storyId: s2.id, pageNumber: 3, text: "تذكر سامي كلام أمه: 'الشجاعة ليست غياب الخوف، بل هي المضي قدماً رغم الخوف.'", imageUrl: "https://images.unsplash.com/photo-1474511320723-9a56873867b5?w=600&h=400&fit=crop" },
      { storyId: s2.id, pageNumber: 4, text: "أنقذ سامي الأرنب وأدرك أن الشجاعة الحقيقية تولد حين نساعد الآخرين. النهاية", imageUrl: "https://images.unsplash.com/photo-1551969014-7d2c4cddf0b6?w=600&h=400&fit=crop" },
    ];
    for (const page of pages2) await db.insert(storyPages).values(page);
  }

  // Story 3 - Hard
  await db.insert(stories).values({
    title: "رحلة النجوم",
    description: "مغامرة فضائية رائعة مع طفلة تسافر بين النجوم",
    coverImage: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=400&h=300&fit=crop",
    ageGroup: "8-10", totalPages: 4, difficulty: "hard", pointsReward: 25,
  });
  const allStories3 = await db.select().from(stories);
  const s3 = allStories3[allStories3.length - 1];
  if (s3) {
    const pages3 = [
      { storyId: s3.id, pageNumber: 1, text: "كانت نورا طفلة تعشق النجوم. كل ليلة تجلس على شرفتها وتحدق في السماء.", imageUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=600&h=400&fit=crop" },
      { storyId: s3.id, pageNumber: 2, text: "فجأة، ظهرت مركبة فضائية صغيرة أمام نورا! قبلت نورا مهمة إيجاد النجمة المفقودة.", imageUrl: "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=600&h=400&fit=crop" },
      { storyId: s3.id, pageNumber: 3, text: "سافرت نورا بين المجرات وتعلمت أن كل نجمة لها اسم وقصة.", imageUrl: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=600&h=400&fit=crop" },
      { storyId: s3.id, pageNumber: 4, text: "عادت نورا وقالت لأمها: 'الكون واسع جداً، لكن كل نجمة فيه مهمة، تماماً كل واحد منا.' النهاية", imageUrl: "https://images.unsplash.com/photo-1464802686167-b939a6910659?w=600&h=400&fit=crop" },
    ];
    for (const page of pages3) await db.insert(storyPages).values(page);
  }
}


// ─── Drawings Router ───────────────────────────────────────────────────────
appRouter.drawings = router({
  submit: publicProcedure
    .input(z.object({ storyId: z.number(), imageUrl: z.string() }))
    .mutation(async ({ input }) => {
      return getFeaturedDrawings();
    }),

  getFeatured: publicProcedure.query(() => getFeaturedDrawings()),

  getAll: publicProcedure
    .input(z.object({ storyId: z.number().optional(), schoolName: z.string().optional() }).optional())
    .query(({ input }) => getAllApprovedDrawings(input?.storyId, input?.schoolName)),

  getMyDrawings: publicProcedure.query(async () => {
    return [];
  }),

  like: publicProcedure
    .input(z.object({ drawingId: z.number() }))
    .mutation(async ({ input }) => {
      return true;
    }),

  adminGetAll: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    return getAdminDrawings();
  }),

  adminReview: protectedProcedure
    .input(z.object({ drawingId: z.number(), approved: z.boolean(), rating: z.number().min(1).max(5).optional(), note: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      if (input.approved) {
        return approveDrawing(input.drawingId, input.rating || 0, input.note);
      } else {
        return rejectDrawing(input.drawingId, input.note);
      }
    }),

  adminSetFeatured: protectedProcedure
    .input(z.object({ drawingId: z.number(), isFeatured: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      return setFeatured(input.drawingId, input.isFeatured);
    }),
});
