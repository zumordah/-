/**
 * Weekly Report Cron Job
 * يُرسل تقارير أسبوعية لجميع مديري المدارس كل إثنين الساعة 8 صباحاً
 *
 * الجدولة: 0 8 * * 1  (كل إثنين الساعة 8:00 صباحاً)
 *
 * الاستخدام: يُستدعى من server/index.ts عند بدء الخادم
 */

import { getAllSchools, getSchoolStats, getDb } from "./db";
import { sendWeeklyReportEmail } from "./emailHelper";
import { emailSubscriptions } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// ─── نص التقرير النصي (للعرض في لوحة الأدمن) ──────────────────────────────
export function buildWeeklyReportText(
  schoolName: string,
  stats: {
    totalStudents: number;
    activeStudents: number;
    avgScore: number;
    totalBadges: number;
    topStudents: Array<{ name: string; score: number }>;
    topGames: Array<{ name: string; plays: number }>;
    weekStart: string;
    weekEnd: string;
  }
): string {
  const topStudentsList = stats.topStudents.length > 0
    ? stats.topStudents.slice(0, 5).map((s, i) => `  ${i + 1}. ${s.name} — ${s.score} نقطة`).join("\n")
    : "  لا توجد بيانات";

  const topGamesList = stats.topGames.length > 0
    ? stats.topGames.slice(0, 5).map((g, i) => `  ${i + 1}. ${g.name} — ${g.plays} مرة`).join("\n")
    : "  لا توجد بيانات";

  return `
══════════════════════════════════════════
📊 التقرير الأسبوعي — ${schoolName}
📅 الفترة: ${stats.weekStart} — ${stats.weekEnd}
══════════════════════════════════════════

📌 الملخص العام:
  • إجمالي الطلاب المسجلين: ${stats.totalStudents} طالب
  • الطلاب النشطون هذا الأسبوع: ${stats.activeStudents} طالب
  • متوسط النقاط: ${stats.avgScore} نقطة
  • الشارات المكتسبة: ${stats.totalBadges} شارة

🏆 أفضل الطلاب هذا الأسبوع:
${topStudentsList}

🎮 أكثر الألعاب لعباً:
${topGamesList}

══════════════════════════════════════════
✉️ تم الإرسال تلقائياً بواسطة منصة عالم القصص التعليمي
══════════════════════════════════════════
  `.trim();
}

// ─── تشغيل التقارير لجميع المدارس ──────────────────────────────────────────
export async function runWeeklyReports(): Promise<{
  sent: number;
  failed: number;
  total: number;
  log: string[];
}> {
  const log: string[] = [];
  let sent = 0;
  let failed = 0;

  try {
    const allSchools = await getAllSchools();
    log.push(`[${new Date().toISOString()}] بدء إرسال التقارير الأسبوعية — ${allSchools.length} مدرسة`);

    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - 7);

    for (const school of allSchools) {
      const s = school as any;
      try {
        const stats = await getSchoolStats(s.id);
        if (!stats) {
          log.push(`  ✗ ${s.name}: فشل في جلب الإحصائيات`);
          failed++;
          continue;
        }

        const emailStats = {
          totalStudents: stats.totalChildren,
          activeStudents: stats.children.filter((c: any) => (c.totalPoints ?? 0) > 0).length,
          avgScore: stats.avgPoints,
          totalBadges: 0,
          topGames: [],
          topStudents: stats.topChildren.map((c: any) => ({ name: c.name, score: c.totalPoints ?? 0 })),
          weekStart: weekStart.toLocaleDateString("ar-SA"),
          weekEnd: now.toLocaleDateString("ar-SA"),
        };

        // جلب unsubscribe token لمدير المدرسة إن وُجد
        let unsubToken: string | undefined;
        try {
          const db = await getDb();
          if (db) {
            const [sub] = await db.select()
              .from(emailSubscriptions)
              .where(eq(emailSubscriptions.email, s.email))
              .limit(1);
            if (sub) {
              if (!sub.isSubscribed) {
                log.push(`  ⏭ ${s.name}: ألغى الاشتراك — تم تخطيه`);
                continue;
              }
              unsubToken = sub.token;
            }
          }
        } catch (_) {}

        const ok = await sendWeeklyReportEmail(s.email, s.name, emailStats, unsubToken);
        if (ok) {
          sent++;
          log.push(`  ✓ ${s.name} → ${s.email}`);
        } else {
          failed++;
          log.push(`  ✗ ${s.name}: فشل الإرسال`);
        }
      } catch (err) {
        failed++;
        log.push(`  ✗ ${s.name}: خطأ — ${String(err)}`);
      }
    }

    log.push(`[${new Date().toISOString()}] انتهى الإرسال — نجح: ${sent}, فشل: ${failed}`);
  } catch (err) {
    log.push(`[${new Date().toISOString()}] خطأ عام: ${String(err)}`);
  }

  return { sent, failed, total: sent + failed, log };
}

// ─── Cron Scheduler (كل إثنين الساعة 8 صباحاً) ─────────────────────────────
let cronTimer: ReturnType<typeof setTimeout> | null = null;

function getNextMondayAt8AM(): Date {
  const now = new Date();
  const next = new Date(now);
  // الإثنين = 1
  const daysUntilMonday = (1 - now.getDay() + 7) % 7 || 7;
  next.setDate(now.getDate() + daysUntilMonday);
  next.setHours(8, 0, 0, 0);
  return next;
}

export function startWeeklyReportCron(): void {
  const scheduleNext = () => {
    const nextRun = getNextMondayAt8AM();
    const delay = nextRun.getTime() - Date.now();
    console.log(`[WeeklyReport] المهمة التالية: ${nextRun.toLocaleString("ar-SA")} (بعد ${Math.round(delay / 1000 / 60 / 60)} ساعة)`);

    cronTimer = setTimeout(async () => {
      console.log("[WeeklyReport] بدء الإرسال التلقائي...");
      const result = await runWeeklyReports();
      console.log(`[WeeklyReport] انتهى — نجح: ${result.sent}, فشل: ${result.failed}`);
      result.log.forEach((line) => console.log(line));
      // جدولة الأسبوع القادم
      scheduleNext();
    }, delay);
  };

  scheduleNext();
}

export function stopWeeklyReportCron(): void {
  if (cronTimer) {
    clearTimeout(cronTimer);
    cronTimer = null;
    console.log("[WeeklyReport] تم إيقاف المهمة");
  }
}
