import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import { jwtVerify } from "jose";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    // التحقق من Manus OAuth user role
    if (ctx.user && ctx.user.role === 'admin') {
      return next({ ctx: { ...ctx, user: ctx.user } });
    }

    // التحقق من Admin JWT token في header
    const adminToken = ctx.req.headers['x-admin-token'] as string | undefined;
    if (adminToken) {
      try {
        const secret = new TextEncoder().encode(process.env.JWT_SECRET ?? 'fallback_secret');
        const { payload } = await jwtVerify(adminToken, secret, { algorithms: ['HS256'] });
        const adminRole = payload['adminRole'] as string;
        if (adminRole === 'founder' || adminRole === 'admin' || adminRole === 'school_admin') {
          // إنشاء user افتراضي للأدمن
          const fakeAdminUser = {
            id: 0,
            openId: payload['adminEmail'] as string,
            name: (payload['adminName'] as string) ?? 'الأدمن',
            email: payload['adminEmail'] as string,
            role: 'admin' as const,
            createdAt: new Date(),
            lastSignedIn: new Date(),
            loginMethod: null,
          };
          return next({ ctx: { ...ctx, user: fakeAdminUser } });
        }
      } catch (e) {
        // token غير صالح - نكمل للخطأ
      }
    }

    throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  }),
);
