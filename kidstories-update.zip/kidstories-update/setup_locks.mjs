import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. قفل ~40% من الألعاب التعليمية ───────────────────────────────────────
// الاستراتيجية: قفل آخر 40% من كل مستوى (الأصعب ضمن المستوى)
// easy: 24 لعبة → قفل 10 (آخر 10)
// medium: 17 لعبة → قفل 7 (آخر 7)
// hard: 18 لعبة → قفل 7 (آخر 7)

// إلغاء القفل عن الجميع أولاً
await conn.execute('UPDATE educational_games SET isLocked = 0, lockCost = 0');
console.log('✅ تم إلغاء قفل جميع الألعاب');

// قفل آخر 10 ألعاب سهلة
const easyLockedIds = [30029, 30038, 30030, 30031, 30032, 60009, 60010, 60001, 60003, 60004];
for (const id of easyLockedIds) {
  await conn.execute('UPDATE educational_games SET isLocked = 1, lockCost = 40 WHERE id = ?', [id]);
}
console.log('✅ تم قفل 10 ألعاب مبتدئ');

// قفل 7 ألعاب متوسطة
const mediumLockedIds = [30040, 60011, 60012, 60005, 30039, 30036, 30035];
for (const id of mediumLockedIds) {
  await conn.execute('UPDATE educational_games SET isLocked = 1, lockCost = 60 WHERE id = ?', [id]);
}
console.log('✅ تم قفل 7 ألعاب متوسطة');

// قفل 7 ألعاب متقدمة
const hardLockedIds = [30047, 30048, 60007, 60008, 60013, 60014, 30043];
for (const id of hardLockedIds) {
  await conn.execute('UPDATE educational_games SET isLocked = 1, lockCost = 80 WHERE id = ?', [id]);
}
console.log('✅ تم قفل 7 ألعاب متقدمة');

// ─── 2. قفل ~40% من المغامرات (10 من 25) ────────────────────────────────────
// إلغاء القفل عن الجميع أولاً
await conn.execute('UPDATE story_adventures SET isPublished = 1');

// جلب المغامرات مرتبة
const [adventures] = await conn.execute('SELECT id, title, level FROM story_adventures ORDER BY level, id');
console.log('المغامرات:', adventures.map(a => `${a.id}:${a.level}:${a.title}`).join('\n'));

// قفل آخر 40% من كل مستوى (easy: 5 → قفل 2, medium: 5 → قفل 2, hard: 5 → قفل 2 + bonus)
// نستخدم عمود isPublished = false للقفل (المغامرات غير المنشورة = مقفلة)
const easyAdvs = adventures.filter(a => a.level === 'easy');
const mediumAdvs = adventures.filter(a => a.level === 'medium');
const hardAdvs = adventures.filter(a => a.level === 'hard');

// قفل آخر 2 من كل مستوى
const lockedAdvIds = [
  ...easyAdvs.slice(-2).map(a => a.id),
  ...mediumAdvs.slice(-2).map(a => a.id),
  ...hardAdvs.slice(-3).map(a => a.id),  // 3 من المتقدم
];
console.log('IDs المغامرات المقفلة:', lockedAdvIds);

// نضيف عمود isLocked للمغامرات إذا لم يكن موجوداً
const [advCols] = await conn.execute('SHOW COLUMNS FROM story_adventures');
const advColNames = advCols.map(c => c.Field);
if (!advColNames.includes('isLocked')) {
  await conn.execute('ALTER TABLE story_adventures ADD COLUMN isLocked TINYINT(1) NOT NULL DEFAULT 0');
  await conn.execute('ALTER TABLE story_adventures ADD COLUMN lockCost INT NOT NULL DEFAULT 0');
  console.log('✅ تم إضافة عمودي isLocked وlockCost للمغامرات');
}

// إلغاء القفل عن الجميع
await conn.execute('UPDATE story_adventures SET isLocked = 0, lockCost = 0');

// قفل المحددة
for (const id of lockedAdvIds) {
  await conn.execute('UPDATE story_adventures SET isLocked = 1, lockCost = 70 WHERE id = ?', [id]);
}
console.log(`✅ تم قفل ${lockedAdvIds.length} مغامرة`);

// ─── 3. إضافة عناصر المتجر للألعاب والمغامرات المقفلة ────────────────────────
// حذف العناصر القديمة من نوع game_unlock وadventure_game_unlock
await conn.execute('DELETE FROM shop_items WHERE type IN ("game_unlock", "adventure_game_unlock", "game_pack")');

// إضافة حزم فتح الألعاب
const gamePacks = [
  { type: 'game_pack', name: 'حزمة ألعاب المبتدئ', description: 'افتح 10 ألعاب إضافية في المستوى المبتدئ', icon: '🎮', value: 'easy_games', levelRequired: 1, pointsCost: 150, sortOrder: 10 },
  { type: 'game_pack', name: 'حزمة ألعاب المتوسط', description: 'افتح 7 ألعاب إضافية في المستوى المتوسط', icon: '🕹️', value: 'medium_games', levelRequired: 3, pointsCost: 200, sortOrder: 11 },
  { type: 'game_pack', name: 'حزمة ألعاب المتقدم', description: 'افتح 7 ألعاب إضافية في المستوى المتقدم', icon: '🏆', value: 'hard_games', levelRequired: 6, pointsCost: 250, sortOrder: 12 },
  { type: 'adventure_pack', name: 'حزمة مغامرات المبتدئ', description: 'افتح مغامرتين إضافيتين في المستوى المبتدئ', icon: '⚔️', value: 'easy_adventures', levelRequired: 1, pointsCost: 100, sortOrder: 13 },
  { type: 'adventure_pack', name: 'حزمة مغامرات المتوسط', description: 'افتح مغامرتين إضافيتين في المستوى المتوسط', icon: '🗡️', value: 'medium_adventures', levelRequired: 3, pointsCost: 150, sortOrder: 14 },
  { type: 'adventure_pack', name: 'حزمة مغامرات المتقدم', description: 'افتح 3 مغامرات إضافية في المستوى المتقدم', icon: '🌟', value: 'hard_adventures', levelRequired: 6, pointsCost: 200, sortOrder: 15 },
];

for (const pack of gamePacks) {
  await conn.execute(
    'INSERT INTO shop_items (type, name, description, icon, value, levelRequired, pointsCost, isEnabled, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)',
    [pack.type, pack.name, pack.description, pack.icon, pack.value, pack.levelRequired, pack.pointsCost, pack.sortOrder]
  );
}
console.log('✅ تم إضافة 6 حزم فتح في المتجر');

// ─── 4. تحقق نهائي ───────────────────────────────────────────────────────────
const [lockedGames] = await conn.execute('SELECT COUNT(*) as cnt FROM educational_games WHERE isLocked = 1');
const [totalGames] = await conn.execute('SELECT COUNT(*) as cnt FROM educational_games');
const [lockedAdvs] = await conn.execute('SELECT COUNT(*) as cnt FROM story_adventures WHERE isLocked = 1');
const [totalAdvs] = await conn.execute('SELECT COUNT(*) as cnt FROM story_adventures');

console.log(`\n📊 ملخص القفل:`);
console.log(`ألعاب تعليمية: ${lockedGames[0].cnt}/${totalGames[0].cnt} مقفلة (${Math.round(lockedGames[0].cnt/totalGames[0].cnt*100)}%)`);
console.log(`مغامرات: ${lockedAdvs[0].cnt}/${totalAdvs[0].cnt} مقفلة (${Math.round(lockedAdvs[0].cnt/totalAdvs[0].cnt*100)}%)`);

await conn.end();
