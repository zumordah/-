import { useCallback, useRef } from "react";

/**
 * Hook for adventure sound effects using Web Audio API (no external files needed)
 */
export function useAdventureSound() {
  const audioCtxRef = useRef<AudioContext | null>(null);

  const getCtx = useCallback((): AudioContext | null => {
    if (typeof window === "undefined") return null;
    if (!audioCtxRef.current) {
      try {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      } catch {
        return null;
      }
    }
    // Resume if suspended (browser autoplay policy)
    if (audioCtxRef.current.state === "suspended") {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  }, []);

  /** Play a sequence of notes */
  const playNotes = useCallback(
    (notes: { freq: number; duration: number; delay: number; type?: OscillatorType; gain?: number }[]) => {
      const ctx = getCtx();
      if (!ctx) return;

      notes.forEach(({ freq, duration, delay, type = "sine", gain = 0.3 }) => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);

        osc.type = type;
        osc.frequency.setValueAtTime(freq, ctx.currentTime + delay);

        gainNode.gain.setValueAtTime(0, ctx.currentTime + delay);
        gainNode.gain.linearRampToValueAtTime(gain, ctx.currentTime + delay + 0.02);
        gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + duration);

        osc.start(ctx.currentTime + delay);
        osc.stop(ctx.currentTime + delay + duration + 0.05);
      });
    },
    [getCtx]
  );

  /** 🟢 Safe choice - calm ascending tone */
  const playSafeChoice = useCallback(() => {
    playNotes([
      { freq: 523, duration: 0.15, delay: 0, type: "sine", gain: 0.25 },
      { freq: 659, duration: 0.15, delay: 0.12, type: "sine", gain: 0.25 },
    ]);
  }, [playNotes]);

  /** 🟡 Adventure choice - exciting rising tones */
  const playAdventureChoice = useCallback(() => {
    playNotes([
      { freq: 440, duration: 0.1, delay: 0, type: "triangle", gain: 0.3 },
      { freq: 554, duration: 0.1, delay: 0.08, type: "triangle", gain: 0.3 },
      { freq: 659, duration: 0.15, delay: 0.16, type: "triangle", gain: 0.35 },
    ]);
  }, [playNotes]);

  /** 🔴 Learning choice - thoughtful tone */
  const playLearningChoice = useCallback(() => {
    playNotes([
      { freq: 392, duration: 0.2, delay: 0, type: "sine", gain: 0.2 },
      { freq: 349, duration: 0.25, delay: 0.18, type: "sine", gain: 0.2 },
    ]);
  }, [playNotes]);

  /** ✨ Points earned - sparkle sound */
  const playPointsEarned = useCallback((points: number) => {
    const baseFreq = points >= 20 ? 880 : points >= 10 ? 660 : 523;
    playNotes([
      { freq: baseFreq, duration: 0.08, delay: 0, type: "triangle", gain: 0.2 },
      { freq: baseFreq * 1.25, duration: 0.08, delay: 0.07, type: "triangle", gain: 0.2 },
      { freq: baseFreq * 1.5, duration: 0.12, delay: 0.14, type: "triangle", gain: 0.25 },
    ]);
  }, [playNotes]);

  /** 🌟 Good ending - happy fanfare */
  const playGoodEnding = useCallback(() => {
    playNotes([
      { freq: 523, duration: 0.15, delay: 0, type: "triangle", gain: 0.3 },
      { freq: 659, duration: 0.15, delay: 0.15, type: "triangle", gain: 0.3 },
      { freq: 784, duration: 0.15, delay: 0.3, type: "triangle", gain: 0.3 },
      { freq: 1047, duration: 0.4, delay: 0.45, type: "triangle", gain: 0.35 },
    ]);
  }, [playNotes]);

  /** 🏆 Great ending - triumphant fanfare */
  const playGreatEnding = useCallback(() => {
    playNotes([
      { freq: 523, duration: 0.12, delay: 0, type: "square", gain: 0.2 },
      { freq: 659, duration: 0.12, delay: 0.1, type: "square", gain: 0.2 },
      { freq: 784, duration: 0.12, delay: 0.2, type: "square", gain: 0.2 },
      { freq: 1047, duration: 0.12, delay: 0.3, type: "square", gain: 0.25 },
      { freq: 1319, duration: 0.5, delay: 0.42, type: "triangle", gain: 0.3 },
      // harmony
      { freq: 659, duration: 0.5, delay: 0.42, type: "sine", gain: 0.15 },
    ]);
  }, [playNotes]);

  /** 📚 Learning ending - reflective melody */
  const playLearningEnding = useCallback(() => {
    playNotes([
      { freq: 440, duration: 0.2, delay: 0, type: "sine", gain: 0.25 },
      { freq: 494, duration: 0.2, delay: 0.2, type: "sine", gain: 0.25 },
      { freq: 523, duration: 0.3, delay: 0.4, type: "sine", gain: 0.3 },
    ]);
  }, [playNotes]);

  /** 🎉 New ending discovered - special celebration */
  const playNewEndingDiscovered = useCallback(() => {
    // Ascending arpeggio + sparkle
    playNotes([
      { freq: 523, duration: 0.1, delay: 0, type: "triangle", gain: 0.3 },
      { freq: 659, duration: 0.1, delay: 0.08, type: "triangle", gain: 0.3 },
      { freq: 784, duration: 0.1, delay: 0.16, type: "triangle", gain: 0.3 },
      { freq: 1047, duration: 0.1, delay: 0.24, type: "triangle", gain: 0.35 },
      { freq: 1319, duration: 0.1, delay: 0.32, type: "triangle", gain: 0.35 },
      { freq: 1568, duration: 0.4, delay: 0.4, type: "triangle", gain: 0.4 },
      // sparkle notes
      { freq: 2093, duration: 0.08, delay: 0.5, type: "sine", gain: 0.2 },
      { freq: 1760, duration: 0.08, delay: 0.6, type: "sine", gain: 0.2 },
      { freq: 2093, duration: 0.12, delay: 0.7, type: "sine", gain: 0.2 },
    ]);
  }, [playNotes]);

  /** 🔄 Replay - short reset sound */
  const playReplay = useCallback(() => {
    playNotes([
      { freq: 784, duration: 0.1, delay: 0, type: "sine", gain: 0.2 },
      { freq: 659, duration: 0.1, delay: 0.1, type: "sine", gain: 0.2 },
      { freq: 523, duration: 0.15, delay: 0.2, type: "sine", gain: 0.2 },
    ]);
  }, [playNotes]);

  return {
    playSafeChoice,
    playAdventureChoice,
    playLearningChoice,
    playPointsEarned,
    playGoodEnding,
    playGreatEnding,
    playLearningEnding,
    playNewEndingDiscovered,
    playReplay,
  };
}
