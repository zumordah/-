import { useMemo } from "react";
import { trpc } from "@/lib/trpc";

// الإطارات: CSS classes لكل قيمة
export const FRAME_STYLES: Record<string, string> = {
  "frame-star": "ring-4 ring-yellow-400 ring-offset-2",
  "frame-moon": "ring-4 ring-indigo-400 ring-offset-2",
  "frame-rainbow": "ring-4 ring-pink-400 ring-offset-2",
  "frame-gold": "ring-4 ring-amber-500 ring-offset-2 shadow-lg shadow-amber-200",
  "frame-space": "ring-4 ring-purple-600 ring-offset-2 shadow-lg shadow-purple-300",
};

export const DEFAULT_THEME = "from-violet-600 to-purple-700";

/**
 * Hook لجلب مظهر الطفل المخصص (إطار + ثيم) من المتجر
 */
export function useChildAppearance(childId: number | undefined) {
  const { data: items = [] } = trpc.shop.getItems.useQuery(undefined, {
    enabled: !!childId,
    staleTime: 60_000,
  });

  const { data: inventory = [] } = trpc.shop.getInventory.useQuery(
    { childId: childId ?? 0 },
    { enabled: !!childId, staleTime: 30_000 }
  );

  const appearance = useMemo(() => {
    const equippedIds = new Set(inventory.filter((i) => i.isEquipped).map((i) => i.shopItemId));

    const equippedFrame = inventory.find(
      (i) => i.isEquipped && items.find((it) => it.id === i.shopItemId && it.type === "avatar_frame")
    );
    const equippedTheme = inventory.find(
      (i) => i.isEquipped && items.find((it) => it.id === i.shopItemId && it.type === "theme")
    );
    const equippedAvatarItem = inventory.find(
      (i) => i.isEquipped && items.find((it) => it.id === i.shopItemId && it.type === "avatar")
    );

    const frameItem = equippedFrame ? items.find((it) => it.id === equippedFrame.shopItemId) : null;
    const themeItem = equippedTheme ? items.find((it) => it.id === equippedTheme.shopItemId) : null;
    const avatarItem = equippedAvatarItem ? items.find((it) => it.id === equippedAvatarItem.shopItemId) : null;

    return {
      frameClass: frameItem ? (FRAME_STYLES[frameItem.value] ?? "") : "",
      themeGradient: themeItem ? themeItem.value : DEFAULT_THEME,
      avatarOverride: avatarItem ? avatarItem.icon : null,
      hasCustomization: !!(frameItem || themeItem || avatarItem),
      equippedIds,
    };
  }, [inventory, items]);

  return appearance;
}
