import { useState, useCallback, useRef } from "react";

/**
 * Hook for Arabic Text-to-Speech
 * يستخدم /api/tts (Microsoft Edge Neural TTS - ZariyahNeural) كمصدر أساسي
 * مع fallback لـ Web Speech API في حالة الفشل
 */
export function useArabicTTS() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // ─── إيقاف أي صوت جارٍ ───────────────────────────────────────────────────
  const stopAll = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      audioRef.current = null;
    }
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setSpeakingId(null);
  }, []);

  // ─── Fallback: Web Speech API ─────────────────────────────────────────────
  const speakFallback = useCallback((text: string, id: string) => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ar-SA";
    utterance.rate = 0.85;
    utterance.pitch = 1.05;
    utterance.volume = 1;
    const voices = window.speechSynthesis.getVoices();
    const arabicVoice =
      voices.find((v) => v.lang === "ar-SA" && v.localService) ||
      voices.find((v) => v.lang === "ar-SA") ||
      voices.find((v) => v.lang.startsWith("ar")) ||
      null;
    if (arabicVoice) utterance.voice = arabicVoice;
    utterance.onstart = () => { setIsSpeaking(true); setSpeakingId(id); };
    utterance.onend = () => { setIsSpeaking(false); setSpeakingId(null); };
    utterance.onerror = () => { setIsSpeaking(false); setSpeakingId(null); };
    window.speechSynthesis.speak(utterance);
  }, []);

  /**
   * speak(audioUrl?, text, id) أو speak(text, id) - الطريقة القديمة
   *
   * - إذا كان audioUrl موجوداً: يُشغّل الملف مباشرةً
   * - إذا كان النص فقط: يستدعي /api/tts (ZariyahNeural) ثم يُشغّله
   * - في حالة الفشل: يستخدم Web Speech API كـ fallback
   */
  const speak = useCallback((
    audioUrlOrText: string | undefined,
    textOrId: string,
    id?: string
  ) => {
    let audioUrl: string | undefined;
    let text: string;
    let speakId: string;

    if (id !== undefined) {
      // speak(audioUrl?, text, id)
      audioUrl = audioUrlOrText;
      text = textOrId;
      speakId = id;
    } else {
      // speak(text, id) - الطريقة القديمة
      audioUrl = undefined;
      text = audioUrlOrText || textOrId;
      speakId = textOrId;
    }

    // إذا كان نفس الصوت يُشغَّل، أوقفه
    if (speakingId === speakId && isSpeaking) {
      stopAll();
      return;
    }

    // أوقف أي صوت جارٍ
    stopAll();

    // إذا كان هناك رابط صوت مباشر (ملف MP3 مرفوع)، شغّله
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      audio.onplay = () => { setIsSpeaking(true); setSpeakingId(speakId); };
      audio.onended = () => { setIsSpeaking(false); setSpeakingId(null); audioRef.current = null; };
      audio.onerror = () => {
        audioRef.current = null;
        speakFallback(text, speakId);
      };
      audio.play().catch(() => speakFallback(text, speakId));
      return;
    }

    // استدعاء /api/tts لتوليد الصوت ديناميكياً (ZariyahNeural)
    if (!text || text.trim().length === 0) return;

    const ttsUrl = `/api/tts?text=${encodeURIComponent(text.slice(0, 600))}`;
    const audio = new Audio(ttsUrl);
    audioRef.current = audio;

    // نضع حالة "جاري التحميل" فوراً
    setIsSpeaking(true);
    setSpeakingId(speakId);

    audio.onplay = () => { setIsSpeaking(true); setSpeakingId(speakId); };
    audio.onended = () => { setIsSpeaking(false); setSpeakingId(null); audioRef.current = null; };
    audio.onerror = () => {
      // Fallback لـ Web Speech API
      audioRef.current = null;
      speakFallback(text, speakId);
    };

    audio.play().catch(() => {
      audioRef.current = null;
      speakFallback(text, speakId);
    });
  }, [speakingId, isSpeaking, stopAll, speakFallback]);

  const stop = useCallback(() => {
    stopAll();
  }, [stopAll]);

  const isSupported = true; // دائماً مدعوم (TTS server أو Web Speech)

  return { speak, stop, isSpeaking, speakingId, isSupported };
}
