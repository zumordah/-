import { useCallback } from "react";

// يرسل event للشخصية المرافقة - فقط عند اكتمال اللعبة
function dispatchCompanionEvent(type: 'celebration' | 'encouragement' | 'activity') {
  window.dispatchEvent(new CustomEvent('companion-trigger', { detail: { type } }));
}

export function useEncouragementVoice() {
  // أثناء اللعبة: لا تُطلق الشخصية المرافقة (فقط تأثير بصري يتولاه الـ UI)
  const encourageCorrect = useCallback(() => {
    // لا شيء - التأثير البصري يكفي (اللون الأخضر في الـ UI)
  }, []);

  const encourageWrong = useCallback(() => {
    // لا شيء - التأثير البصري يكفي (الاهتزاز في الـ UI)
  }, []);

  const encourageAdventure = useCallback(() => {
    dispatchCompanionEvent('activity');
  }, []);

  // فقط هذه تُطلق الشخصية المرافقة - عند النتيجة النهائية
  const encourageCompletion = useCallback(() => {
    dispatchCompanionEvent('celebration');
  }, []);

  const encourageRandom = useCallback(() => {
    // لا شيء أثناء اللعبة
  }, []);

  const speak = useCallback((_text: string) => {}, []);

  const stop = useCallback(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }, []);

  return {
    encourageRandom,
    encourageCorrect,
    encourageWrong,
    encourageAdventure,
    encourageCompletion,
    speak,
    stop,
  };
}
