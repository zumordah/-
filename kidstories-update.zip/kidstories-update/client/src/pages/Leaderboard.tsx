import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { Trophy, Star, ArrowRight, Crown, Medal, Award, Flame } from "lucide-react";

const RANK_STYLES = [
  { bg: "bg-gradient-to-r from-yellow-400 to-amber-500", text: "text-white", icon: Crown, iconColor: "text-yellow-100", border: "border-yellow-300" },
  { bg: "bg-gradient-to-r from-slate-400 to-slate-500", text: "text-white", icon: Medal, iconColor: "text-slate-100", border: "border-slate-300" },
  { bg: "bg-gradient-to-r from-orange-400 to-amber-600", text: "text-white", icon: Award, iconColor: "text-orange-100", border: "border-orange-300" },
];

function getLevelTitle(level: number) {
  if (level >= 10) return "أسطورة";
  if (level >= 8) return "بطل";
  if (level >= 6) return "متميز";
  if (level >= 4) return "متقدم";
  if (level >= 2) return "متوسط";
  return "مبتدئ";
}

export default function Leaderboard() {
  const [, navigate] = useLocation();
  const { child } = useChild();

  const { data: leaders = [], isLoading } = trpc.leaderboard.getTop.useQuery({ limit: 20 });

  const myRank = child ? leaders.findIndex((l) => l.id === child.id) + 1 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-20" dir="rtl">
      <div className="max-w-md mx-auto px-4 pt-6 space-y-5">

        {/* Header */}
        <div className="flex items-center justify-between">
          <button onClick={() => navigate("/home")} className="flex items-center gap-1 text-indigo-600 text-sm font-medium">
            <ArrowRight className="w-4 h-4" /> الرئيسية
          </button>
          <div className="flex items-center gap-2 bg-white rounded-full px-3 py-1.5 shadow-sm border border-indigo-100">
            <Trophy className="w-4 h-4 text-indigo-500" />
            <span className="text-xs font-bold text-indigo-700">لوحة الشرف</span>
          </div>
        </div>

        {/* Hero banner */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-3xl p-5 text-white shadow-lg text-center">
          <Trophy className="w-10 h-10 mx-auto mb-2 text-yellow-300" />
          <h1 className="text-xl font-bold">أبطال القراءة</h1>
          <p className="text-white/70 text-sm mt-1">أفضل الأطفال في النقاط والإنجازات</p>
          {myRank > 0 && (
            <div className="mt-3 inline-block bg-white/20 rounded-full px-4 py-1.5 text-sm font-bold">
              ترتيبك: #{myRank}
            </div>
          )}
        </div>

        {/* Top 3 podium */}
        {!isLoading && leaders.length >= 3 && (
          <div className="flex items-end justify-center gap-3 px-2 pt-2">
            {/* 2nd */}
            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center bg-gradient-to-br from-purple-400 to-pink-400 text-2xl mx-auto">
                {(leaders[1] as any)?.avatarUrl ? (
                  <img src={(leaders[1] as any).avatarUrl} alt={leaders[1].name} className="w-full h-full object-cover" />
                ) : leaders[1].avatarEmoji}
              </div>
              <div className="text-xs font-bold text-gray-600 text-center truncate w-full text-center">{leaders[1].name}</div>
              <div className="w-full bg-gradient-to-t from-slate-400 to-slate-300 rounded-t-xl py-4 flex flex-col items-center shadow-md">
                <Medal className="w-5 h-5 text-white mb-1" />
                <span className="text-white font-bold text-sm">2</span>
                <span className="text-white/80 text-xs">{leaders[1].totalPoints} نقطة</span>
              </div>
            </div>
            {/* 1st */}
            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-full overflow-hidden flex items-center justify-center bg-gradient-to-br from-yellow-400 to-orange-400 text-3xl mx-auto">
                {(leaders[0] as any)?.avatarUrl ? (
                  <img src={(leaders[0] as any).avatarUrl} alt={leaders[0].name} className="w-full h-full object-cover" />
                ) : leaders[0].avatarEmoji}
              </div>
              <div className="text-xs font-bold text-gray-700 text-center truncate w-full text-center">{leaders[0].name}</div>
              <div className="w-full bg-gradient-to-t from-yellow-500 to-yellow-400 rounded-t-xl py-6 flex flex-col items-center shadow-lg">
                <Crown className="w-6 h-6 text-white mb-1" />
                <span className="text-white font-bold text-lg">1</span>
                <span className="text-white/80 text-xs">{leaders[0].totalPoints} نقطة</span>
              </div>
            </div>
            {/* 3rd */}
            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center bg-gradient-to-br from-orange-400 to-amber-400 text-2xl mx-auto">
                {(leaders[2] as any)?.avatarUrl ? (
                  <img src={(leaders[2] as any).avatarUrl} alt={leaders[2].name} className="w-full h-full object-cover" />
                ) : leaders[2].avatarEmoji}
              </div>
              <div className="text-xs font-bold text-gray-600 text-center truncate w-full text-center">{leaders[2].name}</div>
              <div className="w-full bg-gradient-to-t from-orange-500 to-orange-400 rounded-t-xl py-3 flex flex-col items-center shadow-md">
                <Award className="w-5 h-5 text-white mb-1" />
                <span className="text-white font-bold text-sm">3</span>
                <span className="text-white/80 text-xs">{leaders[2].totalPoints} نقطة</span>
              </div>
            </div>
          </div>
        )}

        {/* Full list */}
        <div className="space-y-2">
          <h2 className="font-bold text-gray-700 text-sm">القائمة الكاملة</h2>
          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-14 bg-gray-100 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : leaders.length === 0 ? (
            <div className="text-center py-10 text-gray-400">
              <Trophy className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p>لا يوجد لاعبون بعد</p>
            </div>
          ) : (
            leaders.map((leader, idx) => {
              const isMe = child?.id === leader.id;
              const rankStyle = idx < 3 ? RANK_STYLES[idx] : null;
              return (
                <div
                  key={leader.id}
                  className={`flex items-center gap-3 p-3 rounded-2xl border-2 transition-all ${
                    isMe
                      ? "bg-indigo-50 border-indigo-300 shadow-md"
                      : rankStyle
                      ? `${rankStyle.bg} ${rankStyle.border}`
                      : "bg-white border-gray-100"
                  }`}
                >
                  {/* Rank */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                    rankStyle ? "bg-white/30 text-white" : isMe ? "bg-indigo-200 text-indigo-700" : "bg-gray-100 text-gray-500"
                  }`}>
                    {idx + 1}
                  </div>

                  {/* Avatar */}
                  <div className="w-9 h-9 rounded-full overflow-hidden flex items-center justify-center bg-gradient-to-br from-purple-400 to-pink-400 text-xl flex-shrink-0">
                    {(leader as any)?.avatarUrl ? (
                      <img src={(leader as any).avatarUrl} alt={leader.name} className="w-full h-full object-cover" />
                    ) : leader.avatarEmoji}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className={`font-bold text-sm truncate ${rankStyle ? "text-white" : isMe ? "text-indigo-700" : "text-gray-700"}`}>
                      {leader.name} {isMe && <span className="text-xs">(أنت)</span>}
                    </div>
                    <div className={`text-xs flex items-center gap-2 ${rankStyle ? "text-white/70" : "text-gray-400"}`}>
                      <span>المستوى {leader.level} • {getLevelTitle(leader.level)}</span>
                      {(leader.readingStreak ?? 0) > 0 && (
                        <span className="flex items-center gap-0.5">
                          <Flame className="w-3 h-3 text-orange-400" />
                          {leader.readingStreak}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Points */}
                  <div className={`flex items-center gap-1 font-bold text-sm flex-shrink-0 ${rankStyle ? "text-white" : isMe ? "text-indigo-600" : "text-gray-600"}`}>
                    <Star className={`w-4 h-4 ${rankStyle ? "fill-white" : "fill-yellow-400 text-yellow-400"}`} />
                    {leader.totalPoints}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* CTA */}
        <button
          onClick={() => navigate("/challenges")}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all active:scale-[0.98]"
        >
          <Flame className="w-5 h-5" />
          أكمل تحدي اليوم لكسب نقاط
        </button>
      </div>
    </div>
  );
}
