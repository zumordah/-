import { useState } from 'react';
import { useChild } from '@/contexts/ChildContext';
import { trpc } from '@/lib/trpc';
import { CHARACTERS, CompanionCharacter } from '@/data/charactersData';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

export default function CharacterShop() {
  const { child, setChild } = useChild();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const { data: companionData, refetch: refetchCompanion } = trpc.companion.getMyCompanion.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const { data: ownedIds = [], refetch: refetchOwned } = trpc.companion.getOwnedCharacters.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const { data: childData, refetch: refetchChild } = trpc.children.getById.useQuery(
    { id: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const purchaseMutation = trpc.companion.purchaseCharacter.useMutation({
    onSuccess: (data) => {
      toast.success('تم شراء الشخصية بنجاح! 🎉');
      refetchOwned();
      refetchChild();
      if (child && setChild) {
        setChild({ ...child, totalPoints: data.remainingPoints });
      }
    },
    onError: (err) => {
      toast.error(err.message || 'حدث خطأ أثناء الشراء');
    },
  });

  const equipMutation = trpc.companion.equipCharacter.useMutation({
    onSuccess: () => {
      toast.success('تم تعيين الشخصية المرافقة! 🌟');
      refetchCompanion();
      utils.companion.getMyCompanion.invalidate();
    },
    onError: (err) => {
      toast.error(err.message || 'حدث خطأ');
    },
  });

  const currentPoints = childData?.totalPoints ?? child?.totalPoints ?? 0;
  const currentLevel = childData?.level ?? child?.level ?? 1;
  const equippedCharacterId = companionData?.characterId ?? 'sami';

  // الشخصية المجانية حسب الجنس: البنت → لجين، الولد → سامي
  const childGender = childData?.gender ?? child?.gender ?? 'boy';
  const freeCharId = childGender === 'girl' ? 'lajen' : 'sami';

  const isOwned = (charId: string) => charId === freeCharId || ownedIds.includes(charId);
  const isEquipped = (charId: string) => charId === equippedCharacterId;

  const handlePurchase = (char: CompanionCharacter) => {
    if (!child?.id) return;
    if (currentPoints < char.pointsCost) {
      toast.error(`تحتاج ${char.pointsCost} نقطة لشراء هذه الشخصية. لديك ${currentPoints} نقطة فقط.`);
      return;
    }
    purchaseMutation.mutate({
      childId: child.id,
      characterId: char.id,
      pointsCost: char.pointsCost,
    });
  };

  const handleEquip = (char: CompanionCharacter) => {
    if (!child?.id) return;
    equipMutation.mutate({
      childId: child.id,
      characterId: char.id,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 p-4" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate('/shop')}
          className="p-2 rounded-full bg-white shadow text-purple-600 hover:bg-purple-50"
        >
          ←
        </button>
        <div>
          <h1 className="text-2xl font-bold text-purple-800">🧸 متجر الشخصيات</h1>
          <p className="text-sm text-gray-500">اختر رفيقك المفضل في كل رحلة!</p>
        </div>
        <div className="mr-auto bg-yellow-100 px-3 py-1 rounded-full">
          <span className="text-yellow-700 font-bold">⭐ {currentPoints} نقطة</span>
        </div>
      </div>

      {/* الشخصية المرافقة الحالية */}
      <div className="bg-white rounded-2xl shadow-md p-4 mb-6 flex items-center gap-4">
        <img
          src={CHARACTERS.find(c => c.id === equippedCharacterId)?.imageUrl}
          alt="الشخصية الحالية"
          className="w-16 h-16 object-contain"
        />
        <div>
          <p className="text-sm text-gray-500">رفيقك الحالي</p>
          <p className="text-lg font-bold text-purple-700">
            {CHARACTERS.find(c => c.id === equippedCharacterId)?.name}
          </p>
          <p className="text-xs text-gray-400">
            {CHARACTERS.find(c => c.id === equippedCharacterId)?.personality}
          </p>
        </div>
      </div>

      {/* قائمة الشخصيات */}
      <div className="grid grid-cols-2 gap-4">
        {CHARACTERS.map((char) => {
          const owned = isOwned(char.id);
          const equipped = isEquipped(char.id);
          const canAfford = currentPoints >= char.pointsCost;
          const levelOk = currentLevel >= char.levelRequired;

          return (
            <div
              key={char.id}
              className={`bg-white rounded-2xl shadow-md overflow-hidden border-2 transition-all ${
                equipped ? 'border-purple-500 shadow-purple-200' : 'border-transparent'
              }`}
            >
              {/* صورة الشخصية */}
              <div
                className="relative flex items-center justify-center p-4 h-32"
                style={{ backgroundColor: `${char.color}15` }}
              >
                <img
                  src={char.imageUrl}
                  alt={char.name}
                  className={`w-20 h-20 object-contain ${!owned && !levelOk ? 'opacity-50 grayscale' : ''}`}
                />
                {equipped && (
                  <div className="absolute top-2 right-2 bg-purple-500 text-white text-xs px-2 py-0.5 rounded-full">
                    مرافقك ✓
                  </div>
                )}
                {!owned && !levelOk && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-t-2xl">
                    <span className="text-white text-xs font-bold bg-black/50 px-2 py-1 rounded">
                      🔒 مستوى {char.levelRequired}
                    </span>
                  </div>
                )}
              </div>

              {/* معلومات الشخصية */}
              <div className="p-3">
                <h3 className="font-bold text-gray-800 text-sm">{char.name}</h3>
                <p className="text-xs text-gray-500 mb-2">{char.personality}</p>

                {/* زر الإجراء */}
                {char.id === freeCharId ? (
                  // الشخصية المجانية حسب الجنس
                  equipped ? (
                    <div className="text-center text-xs text-purple-600 font-bold py-1">✓ مرافقك الحالي</div>
                  ) : (
                    <button
                      onClick={() => handleEquip(char)}
                      className="w-full py-1.5 rounded-xl text-xs font-bold text-white"
                      style={{ backgroundColor: char.color }}
                    >
                      اختر كمرافق
                    </button>
                  )
                ) : owned ? (
                  equipped ? (
                    <div className="text-center text-xs text-purple-600 font-bold py-1">✓ مرافقك الحالي</div>
                  ) : (
                    <button
                      onClick={() => handleEquip(char)}
                      className="w-full py-1.5 rounded-xl text-xs font-bold text-white"
                      style={{ backgroundColor: char.color }}
                    >
                      اختر كمرافق
                    </button>
                  )
                ) : !levelOk ? (
                  <div className="text-center text-xs text-gray-400 py-1">
                    🔒 يتطلب مستوى {char.levelRequired}
                  </div>
                ) : (
                  <button
                    onClick={() => handlePurchase(char)}
                    disabled={!canAfford || purchaseMutation.isPending}
                    className={`w-full py-1.5 rounded-xl text-xs font-bold text-white transition-opacity ${
                      !canAfford ? 'opacity-50' : 'hover:opacity-90'
                    }`}
                    style={{ backgroundColor: canAfford ? char.color : '#9CA3AF' }}
                  >
                    {canAfford ? `⭐ ${char.pointsCost} نقطة` : `تحتاج ${char.pointsCost} نقطة`}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
