import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { CheckCircle, Circle, Star, Trophy, BookOpen, Gamepad2, Swords, ArrowRight, Gift, Flame } from "lucide-react";

// ─── Confetti burst on completion ────────────────────────────────────────────
const CONFETTI_CSS = `
@keyframes confettiFall {
  0%   { transform: translateY(-20px) rotate(0deg); opacity: 1; }
  100% { transform: translateY(110vh) rotate(720deg); opacity: 0; }
}
.confetti-piece {
  position: fixed;
  width: 10px;
  height: 10px;
  border-radius: 2px;
  animation: confettiFall linear forwards;
  pointer-events: none;
  z-index: 9999;
}
@keyframes popIn {
  0%   { transform: scale(0.5); opacity: 0; }
  70%  { transform: scale(1.1); }
  100% { transform: scale(1); opacity: 1; }
}
@keyframes slideUp {
  from { transform: translateY(20px); opacity: 0; }
  to   { transform: translateY(0); opacity: 1; }
}
`;

const COLORS = ["#f59e0b", "#10b981", "#6366f1", "#ec4899", "#f97316", "#14b8a6"];

function MiniConfetti({ active }: { active: boolean }) {
  if (!active) return null;
  const pieces = Array.from({ length: 30 }).map((_, i) => ({
    left: `${Math.random() * 100}%`,
    color: COLORS[i % COLORS.length],
    duration: `${0.8 + Math.random() * 1.2}s`,
    delay: `${Math.random() * 0.4}s`,
    size: `${6 + Math.random() * 8}px`,
  }));
  return (
    <>
      {pieces.map((p, i) => (
        <div
          key={i}
          className="confetti-piece"
          style={{ left: p.left, top: "-10px", background: p.color, width: p.size, height: p.size, animationDuration: p.duration, animationDelay: p.delay }}
        />
      ))}
    </>
  );
}

// ─── Avatar evolution helper ──────────────────────────────────────────────────
function getAvatarStage(level: number) {
  if (level >= 8) return "👑";
  if (level >= 5) return "✨";
  if (level >= 3) return "⭐";
  return "";
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function DailyChallenges() {
  const [, navigate] = useLocation();
  const { child } = useChild();
  const [showConfetti, setShowConfetti] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);

  const { data: challenge } = trpc.challenges.getToday.useQuery(
    { childLevel: child?.level ?? 1 },
    { enabled: !!child }
  );
  // جلب تفاصيل القصة/اللعبة/المغامرة المحددة لليوم
  const { data: todayStory } = trpc.stories.getById.useQuery(
    { id: challenge?.readStoryId ?? 0 },
    { enabled: !!challenge?.readStoryId }
  );
  const { data: todayAdventure } = trpc.adventures.getById.useQuery(
    { id: challenge?.playAdventureId ?? 0 },
    { enabled: !!challenge?.playAdventureId }
  );
  const { data: progress, refetch: refetchProgress } = trpc.challenges.getProgress.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: childData, refetch: refetchChild } = trpc.children.getById.useQuery(
    { id: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const markTask = trpc.challenges.markTask.useMutation({
    onSuccess: async (result) => {
      await refetchProgress();
      await refetchChild();
      if (result.allDone && result.bonusAwarded > 0) {
        setShowConfetti(true);
        setJustCompleted(true);
        setTimeout(() => setShowConfetti(false), 3000);
      }
    },
  });

  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = CONFETTI_CSS;
    document.head.appendChild(style);
    return () => { document.head.removeChild(style); };
  }, []);

  const levelLabel = (child?.level ?? 1) <= 3 ? 'مبتدئ' : (child?.level ?? 1) <= 6 ? 'متوسط' : 'متقدم';
  const tasks = [
    {
      key: "readStory" as const,
      label: "اقرأ قصة",
      desc: todayStory ? `قصة اليوم: «${todayStory.story.title}»` : `اقرأ قصة من مستوى ${levelLabel}`,
      icon: BookOpen,
      color: "text-blue-600",
      bg: "bg-blue-50",
      border: "border-blue-200",
      done: progress?.readStoryDone ?? false,
      link: challenge?.readStoryId ? `/story/${challenge.readStoryId}?from=daily-challenge` : "/home",
    },
    {
      key: "playGame" as const,
      label: "العب لعبة",
      desc: `العب أي لعبة تعليمية من مستوى ${levelLabel}`,
      icon: Gamepad2,
      color: "text-purple-600",
      bg: "bg-purple-50",
      border: "border-purple-200",
      done: progress?.playGameDone ?? false,
      link: challenge?.playGameId ? `/game/${challenge.playGameId}?from=daily-challenge` : "/activities/games?from=daily-challenge",
    },
    {
      key: "playAdventure" as const,
      label: "أكمل مغامرة",
      desc: todayAdventure ? `مغامرة اليوم: «${todayAdventure.title}»` : `أكمل مغامرة من مستوى ${levelLabel}`,
      icon: Swords,
      color: "text-orange-600",
      bg: "bg-orange-50",
      border: "border-orange-200",
      done: progress?.playAdventureDone ?? false,
      link: challenge?.playAdventureId ? `/adventure/${challenge.playAdventureId}?from=daily-challenge` : "/adventures?from=daily-challenge",
    },
  ];

  const completedCount = tasks.filter((t) => t.done).length;
  const allDone = completedCount === 3;
  const bonusPoints = challenge?.bonusPoints ?? 50;

  const level = childData?.level ?? child?.level ?? 1;
  const totalPoints = childData?.totalPoints ?? child?.totalPoints ?? 0;
  const avatarStage = getAvatarStage(level);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 pb-20" dir="rtl">
      <MiniConfetti active={showConfetti} />

      <div className="px-4 pt-6 space-y-5 max-w-md mx-auto">

        {/* Header */}
        <div className="flex items-center justify-between">
          <button onClick={() => navigate("/home")} className="flex items-center gap-1 text-orange-600 text-sm font-medium">
            <ArrowRight className="w-4 h-4" /> الرئيسية
          </button>
          <div className="flex items-center gap-2 bg-white rounded-full px-3 py-1.5 shadow-sm border border-orange-100">
            <Flame className="w-4 h-4 text-orange-500" />
            <span className="text-xs font-bold text-orange-700">تحدي اليوم</span>
          </div>
        </div>

        {/* Child info card */}
        {child && (
          <div
            className="bg-gradient-to-r from-amber-400 to-orange-500 rounded-3xl p-5 text-white shadow-lg"
            style={{ animation: "popIn 0.5s ease both" }}
          >
            <div className="flex items-center gap-3">
              <div className="text-4xl">{child.avatarEmoji}{avatarStage}</div>
              <div>
                <p className="font-bold text-lg">{child.name}</p>
                <div className="flex items-center gap-3 text-white/80 text-sm">
                  <span>المستوى {level}</span>
                  <span className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-white" /> {totalPoints} نقطة
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Progress bar */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-orange-100" style={{ animation: "slideUp 0.4s ease 0.1s both" }}>
          <div className="flex items-center justify-between mb-3">
            <span className="font-bold text-gray-700">تقدم التحدي</span>
            <span className="text-sm font-bold text-orange-600">{completedCount}/3</span>
          </div>
          <div className="h-3 bg-orange-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-700"
              style={{ width: `${(completedCount / 3) * 100}%` }}
            />
          </div>
          {allDone && (
            <div className="mt-3 flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl p-2.5">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span className="text-green-700 font-bold text-sm">
                {progress?.bonusAwarded ? `✅ تم استلام المكافأة! +${bonusPoints} نقطة` : `🎉 أكملت التحدي! +${bonusPoints} نقطة مكافأة`}
              </span>
            </div>
          )}
        </div>

        {/* Tasks */}
        <div className="space-y-3" style={{ animation: "slideUp 0.4s ease 0.2s both" }}>
          <h2 className="font-bold text-gray-700 text-sm">مهام اليوم</h2>
          {tasks.map((task, idx) => {
            const Icon = task.icon;
            return (
              <div
                key={task.key}
                className={`${task.bg} border-2 ${task.done ? "border-green-300" : task.border} rounded-2xl p-4 transition-all`}
                style={{ animation: `slideUp 0.4s ease ${0.1 + idx * 0.08}s both` }}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${task.done ? "bg-green-100" : "bg-white"} shadow-sm flex-shrink-0`}>
                    {task.done ? (
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    ) : (
                      <Icon className={`w-5 h-5 ${task.color}`} />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className={`font-bold text-sm ${task.done ? "text-green-700 line-through opacity-70" : "text-gray-700"}`}>
                      {task.label}
                    </p>
                    <p className="text-xs text-gray-500">{task.desc}</p>
                  </div>
                  {!task.done && (
                    <button
                      onClick={() => navigate(task.link)}
                      className={`text-xs font-bold px-3 py-1.5 rounded-lg bg-white border ${task.border} ${task.color}`}
                    >
                      ابدأ
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Reward card */}
        <div
          className={`rounded-2xl p-4 border-2 ${allDone ? "bg-yellow-50 border-yellow-300" : "bg-gray-50 border-gray-200"}`}
          style={{ animation: "slideUp 0.4s ease 0.4s both" }}
        >
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${allDone ? "bg-yellow-100" : "bg-gray-100"}`}>
              <Gift className={`w-5 h-5 ${allDone ? "text-yellow-600" : "text-gray-400"}`} />
            </div>
            <div>
              <p className={`font-bold text-sm ${allDone ? "text-yellow-700" : "text-gray-500"}`}>
                مكافأة إتمام التحدي
              </p>
              <p className={`text-xs ${allDone ? "text-yellow-600" : "text-gray-400"}`}>
                +{bonusPoints} نقطة إضافية عند إتمام المهام الثلاث
              </p>
            </div>
            {allDone && (
              <div className="mr-auto">
                <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" />
              </div>
            )}
          </div>
        </div>

        {/* Leaderboard teaser */}
        <button
          onClick={() => navigate("/leaderboard")}
          className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all active:scale-[0.98]"
          style={{ animation: "slideUp 0.4s ease 0.5s both" }}
        >
          <Trophy className="w-5 h-5" />
          لوحة الشرف — من الأفضل؟
        </button>
      </div>
    </div>
  );
}
