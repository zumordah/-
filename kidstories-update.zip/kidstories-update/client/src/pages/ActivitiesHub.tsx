import { useLocation } from "wouter";
import { useChild } from "@/contexts/ChildContext";
import { BookOpen, Gamepad2, Star, Trophy, Map, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

export default function ActivitiesHub() {
  const [, navigate] = useLocation();
  const { child } = useChild();

  const { data: stories } = trpc.stories.list.useQuery({});
  const { data: games } = trpc.games.list.useQuery({});
  const { data: adventures } = trpc.adventures.list.useQuery({});

  const storiesCount = stories?.length ?? 0;
  const gamesCount = games?.length ?? 50;
  const adventuresCount = adventures?.length ?? 15;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-4 pb-20" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate("/home")} className="flex-shrink-0">
          <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-purple-800">مركز الأنشطة 🎯</h1>
          <p className="text-sm text-purple-500">اختر نوع النشاط الذي تريده</p>
        </div>
      </div>

      {/* Points Banner */}
      {child && (
        <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl p-4 mb-6 shadow-md flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-white" />
            <span className="text-white font-bold text-lg">{child.totalPoints} نقطة</span>
          </div>
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-white fill-white" />
            <span className="text-white font-semibold">مستوى {child.level}</span>
          </div>
        </div>
      )}

      {/* Three Main Sections */}
      <div className="space-y-5">

        {/* Section 1: Story Activities */}
        <button
          onClick={() => navigate("/activities/stories")}
          className="w-full bg-white rounded-3xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden active:scale-[0.98]"
        >
          <div className="bg-gradient-to-r from-purple-500 to-indigo-600 p-6 flex items-center gap-4">
            <div className="bg-white/20 rounded-2xl p-3">
              <BookOpen className="w-10 h-10 text-white" />
            </div>
            <div className="text-right flex-1">
              <h2 className="text-xl font-bold text-white">أنشطة القصص 📚</h2>
              <p className="text-purple-100 text-sm mt-1">أسئلة وتحديات لكل قصة قرأتها</p>
            </div>
            <div className="bg-white/20 rounded-xl px-3 py-1 text-center min-w-[52px]">
              <span className="text-white font-bold text-lg">{storiesCount > 0 ? storiesCount : "—"}</span>
              <p className="text-purple-100 text-xs">قصة</p>
            </div>
          </div>
          <div className="p-4 flex gap-3 flex-wrap">
            {["مبتدئ 🟢", "متوسط 🟡", "متقدم 🔴"].map((lvl) => (
              <span key={lvl} className="bg-purple-50 text-purple-700 text-xs font-semibold px-3 py-1 rounded-full border border-purple-200">
                {lvl}
              </span>
            ))}
            <span className="bg-yellow-50 text-yellow-700 text-xs font-semibold px-3 py-1 rounded-full border border-yellow-200 mr-auto">
              🏆 حتى 35 نقطة للنشاط
            </span>
          </div>
        </button>

        {/* Section 2: Educational Games */}
        <button
          onClick={() => navigate("/activities/games")}
          className="w-full bg-white rounded-3xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden active:scale-[0.98]"
        >
          <div className="bg-gradient-to-r from-green-500 to-teal-600 p-6 flex items-center gap-4">
            <div className="bg-white/20 rounded-2xl p-3">
              <Gamepad2 className="w-10 h-10 text-white" />
            </div>
            <div className="text-right flex-1">
              <h2 className="text-xl font-bold text-white">ألعاب تعليمية 🎮</h2>
              <p className="text-green-100 text-sm mt-1">حروف وأرقام وكلمات وتصنيف وتطابق</p>
            </div>
            <div className="bg-white/20 rounded-xl px-3 py-1 text-center min-w-[52px]">
              <span className="text-white font-bold text-lg">{gamesCount}</span>
              <p className="text-green-100 text-xs">لعبة</p>
            </div>
          </div>
          <div className="p-4 flex gap-3 flex-wrap">
            {["حروف عربية 🔤", "أرقام 🔢", "تصنيف 📦", "تطابق 🎯", "كلمات ✏️"].map((tag) => (
              <span key={tag} className="bg-green-50 text-green-700 text-xs font-semibold px-3 py-1 rounded-full border border-green-200">
                {tag}
              </span>
            ))}
          </div>
          <div className="px-4 pb-4">
            <div className="flex gap-2 flex-wrap">
              {["مبتدئ 🟢", "متوسط 🟡", "متقدم 🔴"].map((lvl) => (
                <span key={lvl} className="bg-teal-50 text-teal-700 text-xs font-semibold px-3 py-1 rounded-full border border-teal-200">
                  {lvl}
                </span>
              ))}
              <span className="bg-yellow-50 text-yellow-700 text-xs font-semibold px-3 py-1 rounded-full border border-yellow-200 mr-auto">
                ⚡ حتى 25 نقطة للعبة
              </span>
            </div>
          </div>
        </button>

        {/* Section 3: Story Adventures */}
        <button
          onClick={() => navigate("/adventures")}
          className="w-full bg-white rounded-3xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden active:scale-[0.98]"
        >
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-6 flex items-center gap-4">
            <div className="bg-white/20 rounded-2xl p-3">
              <Map className="w-10 h-10 text-white" />
            </div>
            <div className="text-right flex-1">
              <h2 className="text-xl font-bold text-white">مغامرات القصة 🧩</h2>
              <p className="text-indigo-100 text-sm mt-1">قرر مصير القصة باختياراتك!</p>
            </div>
            <div className="bg-white/20 rounded-xl px-3 py-1 text-center min-w-[52px]">
              <span className="text-white font-bold text-lg">{adventuresCount}</span>
              <p className="text-indigo-100 text-xs">مغامرة</p>
            </div>
          </div>
          <div className="p-4 flex gap-3 flex-wrap">
            {["مبتدئ 🟢", "متوسط 🟡", "متقدم 🔴"].map((lvl) => (
              <span key={lvl} className="bg-indigo-50 text-indigo-700 text-xs font-semibold px-3 py-1 rounded-full border border-indigo-200">
                {lvl}
              </span>
            ))}
            <span className="bg-yellow-50 text-yellow-700 text-xs font-semibold px-3 py-1 rounded-full border border-yellow-200 mr-auto">
              🏆 حتى 70 نقطة للمغامرة
            </span>
          </div>
        </button>

        {/* Section 4: Interactive Lab */}
        <button
          onClick={() => navigate("/interactive-lab")}
          className="w-full bg-white rounded-3xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden active:scale-[0.98]"
        >
          <div className="bg-gradient-to-r from-pink-500 to-rose-600 p-6 flex items-center gap-4">
            <div className="bg-white/20 rounded-2xl p-3 text-4xl">🧠</div>
            <div className="text-right flex-1">
              <h2 className="text-xl font-bold text-white">الألعاب التفاعلية 🧩</h2>
              <p className="text-pink-100 text-sm mt-1">سحب وإفلات وترتيب ومطابقة بطريقة ممتعة!</p>
            </div>
            <div className="bg-white/20 rounded-xl px-3 py-1 text-center min-w-[52px]">
              <span className="text-white font-bold text-lg">16</span>
              <p className="text-pink-100 text-xs">لعبة</p>
            </div>
          </div>
          <div className="p-4 flex gap-3 flex-wrap">
            {["ذاكرة 🧠", "تصنيف 📦", "ترتيب 🔢", "منطق 🧩"].map((tag) => (
              <span key={tag} className="bg-pink-50 text-pink-700 text-xs font-semibold px-3 py-1 rounded-full border border-pink-200">
                {tag}
              </span>
            ))}
            <span className="bg-yellow-50 text-yellow-700 text-xs font-semibold px-3 py-1 rounded-full border border-yellow-200 mr-auto">
              ⭐ 10 نقاط لكل لعبة
            </span>
          </div>
        </button>

      </div>

      {/* Motivation Banner */}
      <div className="mt-6 bg-gradient-to-r from-pink-400 to-rose-500 rounded-2xl p-4 text-center shadow-md">
        <Zap className="w-6 h-6 text-white mx-auto mb-1" />
        <p className="text-white font-bold">كل نشاط تكمله يجلب لك نقاطاً جديدة! 🌟</p>
        <p className="text-pink-100 text-sm mt-1">اجمع النقاط وارتقِ في لوحة المتصدرين</p>
      </div>
    </div>
  );
}
