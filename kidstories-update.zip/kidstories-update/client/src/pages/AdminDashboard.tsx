import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { CHARACTERS } from '@/data/charactersData';
import WeeklyReportPreview from '@/components/WeeklyReportPreview';
import UsersManagementTab from '@/components/UsersManagementTab';
import ChangePasswordModal from '@/components/ChangePasswordModal';
import UserGrowthCharts from '@/components/UserGrowthCharts';
import EmailSubscribersTab from '@/components/EmailSubscribersTab';
import SchoolRegistrationsTab from '@/components/SchoolRegistrationsTab';
import { memoryGames, sortingGames, sequencingGames, buildLogicGames, logicPuzzleGames, coloringGames } from '@/lib/interactiveGamesData';
import {
  Users, BookOpen, Gamepad2, Trophy, Star, Plus, Trash2, Eye,
  BarChart3, Search, ArrowRight, Crown, Zap, Clock, LogOut, MessageSquare, CheckCircle, Edit, Pencil, Save, X, FileDown
} from "lucide-react";

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, loading, logout } = useAuth();

  // قراءة جلسة الأدمن مباشرة في useState (lazy initializer) لتجنب flash
  const [localAdminSession, setLocalAdminSession] = useState<{ email: string; name: string; role: string; loginTime: number } | null>(() => {
    try {
      const stored = localStorage.getItem("adminSession");
      if (stored) {
        const session = JSON.parse(stored);
        const ONE_WEEK = 7 * 24 * 60 * 60 * 1000;
        const ONE_MONTH = 30 * 24 * 60 * 60 * 1000;
        const duration = session.rememberMe ? ONE_MONTH : ONE_WEEK;
        if ((session.role === "admin" || session.role === "founder") && Date.now() - session.loginTime < duration) {
          return session;
        } else {
          localStorage.removeItem("adminSession");
        }
      }
    } catch {}
    return null;
  });

  const [showChangePassword, setShowChangePassword] = useState(false);
  const [needsRelogin, setNeedsRelogin] = useState(() => {
    try {
      const stored = localStorage.getItem("adminSession");
      if (stored) {
        const session = JSON.parse(stored);
        if ((session.role === "admin" || session.role === "founder") && !session.adminToken) {
          return true;
        }
      }
    } catch {}
    return false;
  });

  // جميع useState hooks الأخرى
  const [activeTab, setActiveTab] = useState<"overview" | "children" | "stories" | "activities" | "reviews" | "levels" | "segmented" | "games" | "challenges" | "shop" | "adventures" | "interactive" | "stats" | "recordings" | "characters" | "admins" | "schools" | "compare_schools" | "weekly_reports" | "users_management" | "user_growth" | "email_subscribers" | "school_registrations">("overview");
  const [segmentedFilter, setSegmentedFilter] = useState<"all" | "kindergarten" | "outside">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedChild, setSelectedChild] = useState<number | null>(null);
  // التحديد الجماعي للمتعلمين
  const [selectedChildIds, setSelectedChildIds] = useState<Set<number>>(new Set());
  const [showBulkTransferDialog, setShowBulkTransferDialog] = useState(false);
  const [bulkTransferSchoolId, setBulkTransferSchoolId] = useState<string>("");
  const [bulkTransferClassroom, setBulkTransferClassroom] = useState<string>("");
  const [bulkTransferClassrooms, setBulkTransferClassrooms] = useState<string[]>([]);
  const [showAddStory, setShowAddStory] = useState(false);
  const [showAddActivity, setShowAddActivity] = useState(false);
  const [editingStory, setEditingStory] = useState<any | null>(null);
  const [editingStoryPages, setEditingStoryPages] = useState(false);
  const [storyPagesData, setStoryPagesData] = useState<any[]>([]);
  const [editingPageId, setEditingPageId] = useState<number | null>(null);
  const [editingPageText, setEditingPageText] = useState("");
  const [editingPageImage, setEditingPageImage] = useState("");
  const [newPageImageUrl, setNewPageImageUrl] = useState("");
  const [editingActivity, setEditingActivity] = useState<any | null>(null);
  const [activityQuestionsData, setActivityQuestionsData] = useState<any[]>([]);
  const [editingQuestionId, setEditingQuestionId] = useState<number | null>(null);
  const [editingQuestionForm, setEditingQuestionForm] = useState<{ questionText: string; options: string[]; correctAnswer: string; explanation: string } | null>(null);
  const [newQuestionForm, setNewQuestionForm] = useState({ questionText: "", options: ["", "", "", ""], correctAnswer: "0", explanation: "" });
  const [storyForm, setStoryForm] = useState({
    title: "", description: "", coverImage: "", ageGroup: "all" as any,
    difficulty: "easy" as any, pointsReward: 15,
  });
  const [storyPages, setStoryPages] = useState([{ text: "", imageUrl: "" }]);
  const [showAIGenerator, setShowAIGenerator] = useState(false);
  const [storyPdfLoading, setStoryPdfLoading] = useState<number | null>(null);
  const [aiTopic, setAiTopic] = useState("");
  const [aiPagesCount, setAiPagesCount] = useState(5);
  const [aiDifficulty, setAiDifficulty] = useState<"easy"|"medium"|"hard">("easy");
  const [aiAgeGroup, setAiAgeGroup] = useState<"4-6"|"6-8"|"8-10"|"all">("4-6");
  const [activityForm, setActivityForm] = useState({
    storyId: 0, title: "", type: "quiz" as any, description: "",
    pointsReward: 25, ageGroup: "all" as any,
  });
  const [questions, setQuestions] = useState([{
    questionText: "", questionType: "multiple_choice" as any,
    options: ["", "", "", ""], correctAnswer: "0", explanation: "",
  }]);

  // لا حاجة لـ useEffect لقراءة localStorage - تم في useState lazy initializer

  // الأدمن إما عبر Manus OAuth أو عبر جلسة محلية
  const isAdminAccess = (isAuthenticated && user?.role === "admin") || localAdminSession?.role === "admin" || localAdminSession?.role === "founder";

  const handleAdminLogout = () => {
    localStorage.removeItem("adminSession");
    setLocalAdminSession(null);
    if (isAuthenticated) logout();
    navigate("/");
  };

  // جميع trpc hooks بعد كل useState/useEffect (Rules of Hooks)
  const { data: stats } = trpc.admin.stats.useQuery(undefined, { enabled: isAdminAccess });
  const { data: advancedStats } = trpc.admin.advancedStats.useQuery(undefined, { enabled: isAdminAccess && activeTab === "overview" });
  const { data: levelStats } = trpc.admin.levelStats.useQuery(undefined, { enabled: isAdminAccess && activeTab === "levels" });
  const { data: segmentedStats } = trpc.admin.segmentedStats.useQuery(undefined, { enabled: isAdminAccess && activeTab === "segmented" });
  const { data: children } = trpc.admin.children.useQuery(undefined, { enabled: isAdminAccess });
  const { data: stories } = trpc.stories.list.useQuery({}, { enabled: isAdminAccess });
  const { data: adminStories } = trpc.admin.allStories.useQuery(undefined, { enabled: isAdminAccess && activeTab === "stories" });
  const { data: childDetail } = trpc.admin.childDetail.useQuery(
    { childId: selectedChild! },
    { enabled: selectedChild !== null && isAdminAccess }
  );
  const createStoryMutation = trpc.stories.create.useMutation();
  const updatePageMutation = trpc.stories.updatePage.useMutation({ onSuccess: () => { toast.success("تم تحديث الصفحة ✅"); setEditingPageId(null); } });
  const deletePageMutation = trpc.stories.deletePage.useMutation({ onSuccess: () => { toast.success("تم حذف الصفحة"); } });
  const addPageToStoryMutation = trpc.stories.addPage.useMutation({ onSuccess: () => { toast.success("تمت إضافة الصفحة ✅"); } });
  const addQuestionMutation = trpc.activities.addQuestion.useMutation({ onSuccess: () => { toast.success("تمت إضافة السؤال ✅"); setNewQuestionForm({ questionText: "", options: ["", "", "", ""], correctAnswer: "0", explanation: "" }); } });
  const updateQuestionMutation = trpc.activities.updateQuestion.useMutation({ onSuccess: () => { toast.success("تم تحديث السؤال ✅"); setEditingQuestionId(null); } });
  const deleteQuestionMutation = trpc.activities.deleteQuestion.useMutation({ onSuccess: () => { toast.success("تم حذف السؤال"); } });
  const getActivityWithQuestions = trpc.activities.getWithQuestions.useQuery(
    { id: editingActivity?.id ?? 0 },
    { enabled: !!editingActivity, onSuccess: (data: any) => setActivityQuestionsData(data.questions || []) } as any
  );
  const generateStoryMutation = trpc.stories.generateWithAI.useMutation();
  const addPageMutation = trpc.stories.addPage.useMutation();
  const deleteStoryMutation = trpc.stories.delete.useMutation();
  const updateStoryMutation = trpc.admin.updateStory.useMutation();
  const createActivityMutation = trpc.activities.create.useMutation();
  const deleteActivityMutation = trpc.activities.delete.useMutation();
  const updateActivityMutation = trpc.activities.update.useMutation();
  const { data: allActivities, refetch: refetchActivities } = trpc.activities.allAdmin.useQuery(undefined, { enabled: isAdminAccess && activeTab === "activities" });
  const deleteChildMutation = trpc.admin.deleteChild.useMutation();
  const bulkDeleteChildrenMutation = trpc.admin.bulkDeleteChildren.useMutation();
  const bulkTransferChildrenMutation = trpc.admin.bulkTransferChildren.useMutation();
  const { data: allSchoolsList = [] } = trpc.schools.list.useQuery(undefined, { enabled: isAdminAccess });
  const deleteStoryMutation2 = trpc.admin.deleteStory.useMutation();
  const seedMutation = trpc.admin.seedSampleData.useMutation();
  const utils = trpc.useUtils();
  const { data: allReviews, refetch: refetchReviews } = trpc.admin.allReviews.useQuery(
    undefined,
    { enabled: isAdminAccess && activeTab === "reviews" }
  );
  const approveReviewMutation = trpc.admin.approveReview.useMutation();
  const deleteReviewMutation = trpc.admin.deleteReview.useMutation();
  const { data: allRecordings = [], refetch: refetchRecordings } = trpc.recordings.getAllAdmin.useQuery(
    undefined,
    { enabled: isAdminAccess && activeTab === "recordings" }
  );
  const rateRecordingMutation = trpc.recordings.rateRecording.useMutation({
    onSuccess: () => { toast.success('تم حفظ التقييم ⭐'); refetchRecordings(); },
    onError: () => toast.error('حدث خطأ'),
  });
  const [ratingInputs, setRatingInputs] = useState<Record<string, { rating: number; comment: string }>>({}); 
  const [recFilter, setRecFilter] = useState<'all' | 'unrated' | string>('all'); // 'all' | 'unrated' | childId
  const [selectedChildForRec, setSelectedChildForRec] = useState<number | null>(null);
  const { data: childRecordings = [], refetch: refetchChildRec } = trpc.recordings.getChildRecordings.useQuery(
    { childId: selectedChildForRec! },
    { enabled: isAdminAccess && selectedChildForRec !== null }
  );
  const approveRecordingMutation = trpc.recordings.approveRecording.useMutation({
    onSuccess: () => { refetchRecordings(); toast.success("تم الاعتماد"); },
  });
  const deleteRecordingMutation = trpc.recordings.adminDelete.useMutation({
    onSuccess: () => { refetchRecordings(); toast.success("تم الحذف"); },
  });
  const addReactionMutation = trpc.recordings.addReaction.useMutation({
    onSuccess: () => { refetchRecordings(); refetchChildRec(); toast.success("تم إرسال رد الفعل 🎉"); },
    onError: () => toast.error('حدث خطأ'),
  });
  const deleteReactionMutation = trpc.recordings.deleteReaction.useMutation({
    onSuccess: () => { refetchRecordings(); refetchChildRec(); },
    onError: () => toast.error('حدث خطأ'),
  });

  // بعد جميع hooks: early returns
  if (needsRelogin && localAdminSession) {
    return (
      <div className="min-h-screen bg-kids-gradient flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl">
          <div className="text-6xl mb-4">🔄</div>
          <h2 className="text-2xl font-bold text-foreground mb-2">يرجى تجديد تسجيل الدخول</h2>
          <p className="text-muted-foreground mb-6">تم تحديث نظام الأمان. يرجى تسجيل الدخول مرة واحدة لتفعيل الصلاحيات الجديدة.</p>
          <Button
            onClick={() => { localStorage.removeItem("adminSession"); navigate("/login"); }}
            className="w-full h-12 rounded-2xl font-bold"
          >
            تسجيل الدخول مجدداً
          </Button>
        </div>
      </div>
    );
  }

  if (loading && !localAdminSession) {
    return (
      <div className="min-h-screen bg-kids-gradient flex items-center justify-center">
        <div className="text-6xl animate-float">⏳</div>
      </div>
    );
  }

  if (!isAdminAccess) {
    return (
      <div className="min-h-screen bg-kids-gradient flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl">
          <div className="text-6xl mb-4">🔐</div>
          <h2 className="text-2xl font-bold text-foreground mb-2">لوحة تحكم المدير</h2>
          <p className="text-muted-foreground mb-6">هذه الصفحة للمدير فقط. سجلي دخولك بإيميل المدير من صفحة تسجيل الدخول</p>
          <Button
            onClick={() => navigate("/login")}
            className="w-full h-12 rounded-2xl font-bold"
          >
            تسجيل الدخول
          </Button>
        </div>
      </div>
    );
  }

  const filteredChildren = (children || []).filter((c) =>
    c.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleGenerateStory = async () => {
    if (!aiTopic.trim()) { toast.error("أدخل موضوع القصة"); return; }
    try {
      toast.info("جارٍ توليد القصة... قد يستغرق 10-20 ثانية ⚙️");
      const result = await generateStoryMutation.mutateAsync({
        topic: aiTopic,
        ageGroup: aiAgeGroup,
        difficulty: aiDifficulty,
        pagesCount: aiPagesCount,
      });
      setStoryForm(prev => ({
        ...prev,
        title: result.title,
        description: result.description,
        ageGroup: aiAgeGroup,
        difficulty: aiDifficulty,
      }));
      setStoryPages(result.pages.map((p: any) => ({ text: p.text, imageUrl: p.imageDescription ? `[صورة مقترحة: ${p.imageDescription}]` : "" })));
      setShowAIGenerator(false);
      toast.success("تم توليد القصة! راجع المحتوى واحفظ 🎉");
    } catch (e: any) {
      toast.error(e.message || "حدث خطأ في توليد القصة");
    }
  };

  const handleCreateStory = async () => {
    if (!storyForm.title) { toast.error("أدخل عنوان القصة"); return; }
    try {
      const story = await createStoryMutation.mutateAsync({ ...storyForm, pointsReward: Number(storyForm.pointsReward) });
      if (story) {
        for (let i = 0; i < storyPages.length; i++) {
          if (storyPages[i].text) {
            await addPageMutation.mutateAsync({
              storyId: story.id,
              pageNumber: i + 1,
              text: storyPages[i].text,
              imageUrl: storyPages[i].imageUrl || undefined,
            });
          }
        }
      }
      toast.success("تم إنشاء القصة بنجاح! 🎉");
      setShowAddStory(false);
      setStoryForm({ title: "", description: "", coverImage: "", ageGroup: "all", difficulty: "easy", pointsReward: 15 });
      setStoryPages([{ text: "", imageUrl: "" }]);
      utils.stories.list.invalidate();
    } catch (e: any) {
      toast.error(e.message || "حدث خطأ");
    }
  };

  const handleCreateActivity = async () => {
    if (!activityForm.title || !activityForm.storyId) { toast.error("أدخل عنوان النشاط واختر القصة"); return; }
    const validQuestions = questions.filter((q) => q.questionText.trim());
    if (validQuestions.length === 0) { toast.error("أضف سؤالاً واحداً على الأقل"); return; }
    try {
      await createActivityMutation.mutateAsync({
        ...activityForm,
        storyId: Number(activityForm.storyId),
        pointsReward: Number(activityForm.pointsReward),
        questions: validQuestions.map((q) => ({
          ...q,
          options: q.options.filter(Boolean),
        })),
      });
      toast.success("تم إنشاء النشاط بنجاح! 🎉");
      setShowAddActivity(false);
      utils.activities.listAll.invalidate();
    } catch (e: any) {
      toast.error(e.message || "حدث خطأ");
    }
  };

  const handleSeedData = async () => {
    try {
      await seedMutation.mutateAsync();
      toast.success("تم إضافة البيانات التجريبية بنجاح!");
      utils.stories.list.invalidate();
      utils.admin.stats.invalidate();
    } catch (e: any) {
      toast.error(e.message || "حدث خطأ");
    }
  };

  const handleApproveReview = async (id: number) => {
    try {
      await approveReviewMutation.mutateAsync({ id });
      toast.success("تم الموافقة على التقييم ✅");
      refetchReviews();
    } catch { toast.error("حدث خطأ"); }
  };

  const handleDeleteReview = async (id: number) => {
    try {
      await deleteReviewMutation.mutateAsync({ id });
      toast.success("تم حذف التقييم");
      refetchReviews();
    } catch { toast.error("حدث خطأ"); }
  };

  const handleDeleteStory2 = async (id: number) => {
    if (!confirm('هل تريد حذف هذه القصة نهائياً؟')) return;
    try {
      await deleteStoryMutation2.mutateAsync({ id });
      toast.success('تم حذف القصة');
      utils.admin.allStories.invalidate();
      utils.stories.list.invalidate();
    } catch { toast.error('حدث خطأ'); }
  };

  const handleUpdateStory = async () => {
    if (!editingStory) return;
    try {
      await updateStoryMutation.mutateAsync({
        id: editingStory.id,
        title: editingStory.title,
        description: editingStory.description,
        coverImage: editingStory.coverImage,
        ageGroup: editingStory.ageGroup,
        difficulty: editingStory.difficulty,
        pointsReward: Number(editingStory.pointsReward),
        isPublished: editingStory.isPublished,
      });
      toast.success('تم تحديث القصة ✅');
      setEditingStory(null);
      utils.admin.allStories.invalidate();
      utils.stories.list.invalidate();
    } catch (e: any) { toast.error(e.message || 'حدث خطأ'); }
  };

  const handleToggleStoryPublish = async (story: any) => {
    try {
      await updateStoryMutation.mutateAsync({ id: story.id, isPublished: !story.isPublished });
      toast.success(story.isPublished ? 'تم إخفاء القصة' : 'تم نشر القصة ✅');
      utils.admin.allStories.invalidate();
      utils.stories.list.invalidate();
    } catch { toast.error('حدث خطأ'); }
  };

  const handleDownloadStoryPDF = async (story: any) => {
    setStoryPdfLoading(story.id);
    try {
      // جلب صفحات القصة
      const result = await (trpc as any).stories.get.query({ id: story.id });
      const pages: any[] = result?.pages ?? [];

      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = doc.internal.pageSize.getWidth();
      const pageH = doc.internal.pageSize.getHeight();
      const margin = 15;

      // صفحة الغلاف
      doc.setFillColor(99, 102, 241);
      doc.rect(0, 0, pageW, pageH, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.text(story.title || "قصة", pageW / 2, pageH / 2 - 10, { align: "center" });
      doc.setFontSize(12);
      if (story.description) {
        const descLines = doc.splitTextToSize(story.description, pageW - margin * 2);
        doc.text(descLines, pageW / 2, pageH / 2 + 10, { align: "center" });
      }
      doc.setFontSize(10);
      doc.text(`عدد الصفحات: ${pages.length}`, pageW / 2, pageH - 20, { align: "center" });

      // صفحات القصة
      for (let i = 0; i < pages.length; i++) {
        const pg = pages[i];
        doc.addPage();
        doc.setFillColor(255, 255, 255);
        doc.rect(0, 0, pageW, pageH, "F");

        // رقم الصفحة
        doc.setFontSize(9);
        doc.setTextColor(150, 150, 150);
        doc.text(`صفحة ${i + 1} / ${pages.length}`, pageW - margin, margin - 5, { align: "right" });

        // الصورة (إن وجدت)
        let textStartY = margin + 5;
        if (pg.imageUrl) {
          try {
            const imgH = 80;
            const imgW = pageW - margin * 2;
            doc.addImage(pg.imageUrl, "JPEG", margin, margin, imgW, imgH);
            textStartY = margin + imgH + 8;
          } catch {
            // تجاهل خطأ تحميل الصورة
          }
        }

        // نص الصفحة
        if (pg.text) {
          doc.setFontSize(14);
          doc.setTextColor(30, 30, 30);
          const lines = doc.splitTextToSize(pg.text, pageW - margin * 2);
          doc.text(lines, margin, textStartY + 5);
        }
      }

      const safeName = (story.title || "قصة").replace(/[^\u0600-\u06FF\w]/g, "_");
      doc.save(`قصة_${safeName}.pdf`);
      toast.success("✅ تم تحميل PDF القصة");
    } catch (e) {
      toast.error("حدث خطأ أثناء تحميل PDF");
    } finally {
      setStoryPdfLoading(null);
    }
  };

  const handleDeleteActivity = async (id: number) => {
    if (!confirm('هل تريد حذف هذا النشاط نهائياً؟')) return;
    try {
      await deleteActivityMutation.mutateAsync({ id });
      toast.success('تم حذف النشاط');
      refetchActivities();
    } catch { toast.error('حدث خطأ'); }
  };

  const tabGroups = [
    {
      label: "الرئيسية",
      emoji: "🏠",
      tabs: [
        { id: "overview", label: "نظرة عامة", icon: BarChart3 },
        { id: "children", label: "المتعلمون", icon: Users },
      ]
    },
    {
      label: "المحتوى",
      emoji: "📚",
      tabs: [
        { id: "stories", label: "القصص", icon: BookOpen },
        { id: "activities", label: "الأنشطة", icon: Gamepad2 },
        { id: "games", label: "الألعاب", icon: Gamepad2 },
        { id: "interactive", label: "التفاعلية", icon: Zap },
        { id: "adventures", label: "المغامرات", icon: Star },
        { id: "challenges", label: "التحديات", icon: BarChart3 },
        { id: "shop", label: "المتجر", icon: BarChart3 },
      ]
    },
    {
      label: "الإحصائيات",
      emoji: "📊",
      tabs: [
        { id: "stats", label: "إحصائيات شاملة", icon: BarChart3 },
        { id: "levels", label: "المستويات", icon: BarChart3 },
        { id: "segmented", label: "مقسّمة", icon: Users },
        { id: "user_growth", label: "النمو", icon: BarChart3 },
        { id: "compare_schools", label: "مقارنة المدارس", icon: BarChart3 },
      ]
    },
    {
      label: "الإدارة",
      emoji: "⚙️",
      tabs: [
        { id: "school_registrations", label: "طلبات التسجيل", icon: Users },
        { id: "schools", label: "المدارس", icon: Users },
        { id: "admins", label: "المديرون", icon: Users },
        { id: "users_management", label: "المستخدمون", icon: Users },
        { id: "characters", label: "الشخصيات", icon: Star },
        { id: "recordings", label: "التسجيلات", icon: Star },
        { id: "reviews", label: "التقييمات", icon: MessageSquare },
        { id: "email_subscribers", label: "المشتركون", icon: Users },
        { id: "weekly_reports", label: "التقارير", icon: BarChart3 },
      ]
    },
  ];
  const tabs = tabGroups.flatMap(g => g.tabs);

  return (
    <div className="min-h-screen bg-kids-gradient">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm border-b border-border/50 sticky top-0 z-50">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png" alt="قصة وفكرة" className="w-12 h-12 object-contain" style={{ background: 'transparent' }} />
            <div>
              <p className="font-bold text-foreground text-sm">لوحة تحكم المدير</p>
              <p className="text-xs text-muted-foreground">{user?.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => window.open('/home', '_blank', 'noopener,noreferrer')} className="text-xs gap-1 rounded-xl">
              <ArrowRight className="h-4 w-4" />
              الموقع
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowChangePassword(true)} className="text-xs gap-1 rounded-xl">
              🔐 كلمة المرور
            </Button>
            <Button variant="ghost" size="sm" onClick={handleAdminLogout} className="text-xs text-destructive rounded-xl">
              <LogOut className="h-4 w-4" />
              خروج
            </Button>
          </div>
        </div>
      </header>

      {/* Modal تغيير كلمة المرور */}
      {showChangePassword && <ChangePasswordModal onClose={() => setShowChangePassword(false)} />}
      {/* Dialog النقل الجماعي */}
      {showBulkTransferDialog && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-xl font-bold mb-4">🏫 نقل {selectedChildIds.size} متعلم</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-bold mb-1 block">المدرسة (اختياري)</Label>
                <Select value={bulkTransferSchoolId} onValueChange={async (val) => {
                  setBulkTransferSchoolId(val);
                  setBulkTransferClassroom("");
                  if (val) {
                    // جلب الفصول للمدرسة المختارة
                    try {
                      const res = await fetch(`/api/trpc/schools.getClassrooms?input=${encodeURIComponent(JSON.stringify({ json: { schoolId: Number(val) } }))}`, {
                        headers: { 'x-admin-token': JSON.parse(localStorage.getItem('adminSession') || '{}').adminToken || '' }
                      });
                      const data = await res.json();
                      setBulkTransferClassrooms((data?.result?.data?.json || []).map((c: any) => c.name));
                    } catch { setBulkTransferClassrooms([]); }
                  } else {
                    setBulkTransferClassrooms([]);
                  }
                }}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="اختر مدرسة (أو اترك فارغًا للإبقاء في نفس المدرسة)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">بدون تغيير المدرسة</SelectItem>
                    {allSchoolsList.map((s: any) => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-bold mb-1 block">الفصل (اختياري)</Label>
                {bulkTransferClassrooms.length > 0 ? (
                  <Select value={bulkTransferClassroom} onValueChange={setBulkTransferClassroom}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="اختر فصل" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون تغيير الفصل</SelectItem>
                      {bulkTransferClassrooms.map((cls) => (
                        <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input value={bulkTransferClassroom} onChange={(e) => setBulkTransferClassroom(e.target.value)}
                    placeholder="اكتب اسم الفصل (مثل: فصل أ)" className="rounded-xl" />
                )}
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <Button className="flex-1 rounded-xl" onClick={async () => {
                const schoolId = bulkTransferSchoolId && bulkTransferSchoolId !== 'none' ? Number(bulkTransferSchoolId) : undefined;
                const classroom = bulkTransferClassroom && bulkTransferClassroom !== 'none' ? bulkTransferClassroom : undefined;
                if (!schoolId && !classroom) { toast.error('يرجى اختيار مدرسة أو فصل على الأقل'); return; }
                await bulkTransferChildrenMutation.mutateAsync({
                  childIds: Array.from(selectedChildIds),
                  schoolId: schoolId ?? null,
                  classroom: classroom ?? null,
                });
                setShowBulkTransferDialog(false);
                setSelectedChildIds(new Set());
                setBulkTransferSchoolId("");
                setBulkTransferClassroom("");
                utils.admin.children.invalidate();
                toast.success(`تم نقل ${selectedChildIds.size} متعلم بنجاح ✅`);
              }}>تأكيد النقل</Button>
              <Button variant="outline" className="rounded-xl" onClick={() => setShowBulkTransferDialog(false)}>إلغاء</Button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs - مجمّعة في مجموعات */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-border/30 sticky top-[73px] z-40">
        <div className="container">
          <div className="flex flex-col gap-0">
            {tabGroups.map((group) => (
              <div key={group.label} className="flex items-center gap-1 border-b border-border/10 last:border-b-0 py-1">
                <span className="text-xs font-bold text-muted-foreground/70 whitespace-nowrap px-2 min-w-[80px] text-right">
                  {group.emoji} {group.label}
                </span>
                <div className="flex gap-1 overflow-x-auto flex-1">
                  {group.tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                        activeTab === tab.id
                          ? "bg-primary text-white shadow-md"
                          : "text-muted-foreground hover:bg-muted"
                      }`}
                    >
                      <tab.icon className="h-3.5 w-3.5" />
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <main className="container py-6">
        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: "إجمالي المتعلمين", value: stats?.totalChildren ?? 0, emoji: "👥", color: "bg-card-gradient-purple" },
                { label: "القصص المنشورة", value: stats?.totalStories ?? 0, emoji: "📚", color: "bg-card-gradient-blue" },
                { label: "الأنشطة المتاحة", value: stats?.totalActivities ?? 0, emoji: "🎮", color: "bg-card-gradient-green" },
                { label: "قراءات مكتملة", value: stats?.completedReadings ?? 0, emoji: "✅", color: "bg-card-gradient-orange" },
              ].map((stat) => (
                <div key={stat.label} className={`${stat.color} rounded-3xl p-5 text-white`}>
                  <div className="text-3xl mb-2">{stat.emoji}</div>
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <div className="text-white/80 text-xs mt-1">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-3xl p-5 shadow-sm">
              <h3 className="font-bold text-foreground text-lg mb-4">إجراءات سريعة</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <Button onClick={() => setActiveTab("stories")} variant="outline" className="h-12 rounded-2xl gap-2 border-2">
                  <Plus className="h-4 w-4" />
                  إضافة قصة
                </Button>
                <Button onClick={() => setActiveTab("activities")} variant="outline" className="h-12 rounded-2xl gap-2 border-2">
                  <Plus className="h-4 w-4" />
                  إضافة نشاط
                </Button>
                <Button
                  onClick={handleSeedData}
                  disabled={seedMutation.isPending}
                  variant="outline"
                  className="h-12 rounded-2xl gap-2 border-2 border-green-300 text-green-700 hover:bg-green-50"
                >
                  <Zap className="h-4 w-4" />
                  {seedMutation.isPending ? "جارٍ..." : "بيانات تجريبية"}
                </Button>
              </div>
            </div>

            {/* Top Learners */}
            {advancedStats && advancedStats.topChildren && advancedStats.topChildren.length > 0 && (
              <div className="bg-white rounded-3xl p-5 shadow-sm">
                <h3 className="font-bold text-foreground text-lg mb-4 flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  أعلى المتعلمين نقاطاً
                </h3>
                <div className="space-y-2">
                  {advancedStats.topChildren.map((child: any, i: number) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-muted/30 rounded-2xl">
                      <div className="text-xl font-bold text-primary w-6 text-center">{i + 1}</div>
                      <div className="flex-1">
                        <p className="font-bold text-sm">{child.name}</p>
                        <p className="text-xs text-muted-foreground">مستوى {child.level}</p>
                      </div>
                      <div className="font-bold text-primary text-sm">{child.totalPoints} نقطة</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Activity */}
            {advancedStats && advancedStats.recentActivity && advancedStats.recentActivity.length > 0 && (
              <div className="bg-white rounded-3xl p-5 shadow-sm">
                <h3 className="font-bold text-foreground text-lg mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-500" />
                  آخر النشاطات
                </h3>
                <div className="space-y-2">
                  {advancedStats.recentActivity.map((a: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-muted/30 rounded-2xl">
                      <span className="font-medium text-sm">{a.name}</span>
                      <span className="text-xs text-muted-foreground">{new Date(a.updatedAt).toLocaleDateString('ar-SA')}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Children Tab */}
        {activeTab === "children" && (
          <div className="space-y-4">
            {/* شريط الإجراءات الجماعية */}
            {selectedChildIds.size > 0 && (
              <div className="bg-primary/10 border-2 border-primary/30 rounded-2xl p-3 flex flex-wrap items-center gap-2">
                <span className="font-bold text-primary text-sm">تم تحديد {selectedChildIds.size} متعلم</span>
                <div className="flex gap-2 mr-auto flex-wrap">
                  <Button size="sm" variant="outline" className="rounded-xl gap-1 text-xs" onClick={async () => {
                    const ids = Array.from(selectedChildIds);
                    const selected = (children || []).filter(c => ids.includes(c.id));
                    // طباعة PDF
                    const { jsPDF } = await import('jspdf');
                    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
                    doc.setFont('helvetica');
                    doc.setFontSize(18);
                    doc.text('Student List', 105, 20, { align: 'center' });
                    doc.setFontSize(11);
                    let y = 35;
                    selected.forEach((c, i) => {
                      doc.text(`${i + 1}. ${c.name} | ${c.email} | Level: ${c.level} | Points: ${c.totalPoints}`, 15, y);
                      y += 8;
                      if (y > 270) { doc.addPage(); y = 20; }
                    });
                    doc.save(`students-${Date.now()}.pdf`);
                  }}>
                    🖨️ طباعة PDF
                  </Button>
                  <Button size="sm" variant="outline" className="rounded-xl gap-1 text-xs text-blue-600 border-blue-300" onClick={async () => {
                    const schoolId = bulkTransferSchoolId ? Number(bulkTransferSchoolId) : undefined;
                    if (!schoolId && !bulkTransferClassroom) {
                      setShowBulkTransferDialog(true);
                      return;
                    }
                    setShowBulkTransferDialog(true);
                  }}>
                    🏫 نقل لمدرسة/فصل
                  </Button>
                  <Button size="sm" variant="outline" className="rounded-xl gap-1 text-xs text-destructive border-destructive/30" onClick={async () => {
                    if (!confirm(`هل تريد حذف ${selectedChildIds.size} متعلم نهائياً؟`)) return;
                    await bulkDeleteChildrenMutation.mutateAsync({ childIds: Array.from(selectedChildIds) });
                    setSelectedChildIds(new Set());
                    utils.admin.children.invalidate();
                    toast.success(`تم حذف ${selectedChildIds.size} متعلم بنجاح`);
                  }}>
                    🗑️ حذف المحددين
                  </Button>
                  <Button size="sm" variant="ghost" className="rounded-xl text-xs" onClick={() => setSelectedChildIds(new Set())}>
                    × إلغاء
                  </Button>
                </div>
              </div>
            )}
            <div className="flex items-center gap-3">
              <input type="checkbox" className="w-4 h-4 rounded cursor-pointer"
                checked={filteredChildren.length > 0 && filteredChildren.every(c => selectedChildIds.has(c.id))}
                onChange={(e) => {
                  if (e.target.checked) setSelectedChildIds(new Set(filteredChildren.map(c => c.id)));
                  else setSelectedChildIds(new Set());
                }}
                title="تحديد الكل"
              />
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث باسم الطفل أو البريد..."
                  className="pr-10 rounded-2xl border-2"
                />
              </div>
            </div>

            {filteredChildren.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-3">👥</div>
                <p className="text-muted-foreground">لا يوجد متعلمون مسجلون بعد</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {filteredChildren.map((child) => (
                  <div key={child.id} className={`bg-white rounded-3xl p-5 shadow-sm border-2 transition-all ${selectedChildIds.has(child.id) ? 'border-primary bg-primary/5' : 'border-transparent'}`}>
                    <div className="flex items-start gap-3 mb-4">
                      <input type="checkbox" className="w-4 h-4 rounded cursor-pointer mt-1 flex-shrink-0"
                        checked={selectedChildIds.has(child.id)}
                        onChange={(e) => {
                          const next = new Set(selectedChildIds);
                          if (e.target.checked) next.add(child.id); else next.delete(child.id);
                          setSelectedChildIds(next);
                        }}
                      />
                      <div className="text-4xl">{child.avatarEmoji}</div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-foreground truncate">{child.name}</h3>
                        <p className="text-xs text-muted-foreground truncate">{child.email}</p>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                          {child.ageGroup} سنوات
                        </span>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="text-center bg-muted/30 rounded-xl p-2">
                        <div className="text-lg font-bold text-primary">{child.level}</div>
                        <div className="text-xs text-muted-foreground">المستوى</div>
                      </div>
                      <div className="text-center bg-muted/30 rounded-xl p-2">
                        <div className="text-lg font-bold text-yellow-500">{child.totalPoints}</div>
                        <div className="text-xs text-muted-foreground">نقطة</div>
                      </div>
                      <div className="text-center bg-muted/30 rounded-xl p-2">
                        <div className="text-lg font-bold text-green-500">
                          {child.lastActiveAt ? new Date(child.lastActiveAt).toLocaleDateString("ar-SA", { month: "short", day: "numeric" }) : "-"}
                        </div>
                        <div className="text-xs text-muted-foreground">آخر نشاط</div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 rounded-xl gap-1 border-2"
                        onClick={() => setSelectedChild(selectedChild === child.id ? null : child.id)}
                      >
                        <Eye className="h-3 w-3" />
                        التفاصيل
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-xl border-2 border-destructive/30 text-destructive hover:bg-destructive/5"
                        onClick={async () => {
                          if (confirm(`هل تريد حذف حساب ${child.name}؟`)) {
                            await deleteChildMutation.mutateAsync({ childId: child.id });
                            utils.admin.children.invalidate();
                            toast.success("تم حذف الحساب");
                          }
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>

                    {/* Child Detail Expansion */}
                    {selectedChild === child.id && childDetail && (
                      <div className="mt-4 pt-4 border-t border-border space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="bg-blue-50 rounded-xl p-2 text-center">
                            <div className="font-bold text-blue-700">{childDetail.completedStories}</div>
                            <div className="text-xs text-blue-600">قصة مقروءة</div>
                          </div>
                          <div className="bg-green-50 rounded-xl p-2 text-center">
                            <div className="font-bold text-green-700">{childDetail.completedActivities}</div>
                            <div className="text-xs text-green-600">نشاط مكتمل</div>
                          </div>
                        </div>
                        {childDetail.achievements.length > 0 && (
                          <div>
                            <p className="text-xs font-bold text-muted-foreground mb-2">الإنجازات المحققة:</p>
                            <div className="flex flex-wrap gap-1">
                              {childDetail.achievements.map((ach) => (
                                <span key={ach.id} className="text-lg" title={ach.title}>{ach.emoji}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {/* الألعاب المفتوحة */}
                        {(childDetail as any).unlockedGames?.length > 0 && (
                          <div>
                            <p className="text-xs font-bold text-muted-foreground mb-2">🎮 ألعاب مفتوحة ({(childDetail as any).unlockedGames.length}):</p>
                            <div className="flex flex-wrap gap-1">
                              {(childDetail as any).unlockedGames.map((g: any) => (
                                <span key={g.gameId} className="bg-green-50 border border-green-200 text-green-700 text-xs px-2 py-1 rounded-full">
                                  {g.gameEmoji ?? '🎮'} {g.gameTitle}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        {/* المغامرات المفتوحة */}
                        {(childDetail as any).unlockedAdventures?.length > 0 && (
                          <div>
                            <p className="text-xs font-bold text-muted-foreground mb-2">⚔️ مغامرات مفتوحة ({(childDetail as any).unlockedAdventures.length}):</p>
                            <div className="flex flex-wrap gap-1">
                              {(childDetail as any).unlockedAdventures.map((a: any) => (
                                <span key={a.adventureId} className="bg-purple-50 border border-purple-200 text-purple-700 text-xs px-2 py-1 rounded-full">
                                  {a.adventureEmoji ?? '🌟'} {a.adventureTitle}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        {/* مشتريات المتجر */}
                        {(childDetail as any).inventory?.length > 0 && (
                          <div>
                            <p className="text-xs font-bold text-muted-foreground mb-2">🛒 مشتريات المتجر ({(childDetail as any).inventory.length}):</p>
                            <div className="flex flex-wrap gap-1">
                              {(childDetail as any).inventory.map((item: any) => (
                                <span key={item.id} className="bg-amber-50 border border-amber-200 text-amber-700 text-xs px-2 py-1 rounded-full">
                                  {item.itemIcon ?? '🎁'} {item.itemName}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        {(childDetail as any).unlockedGames?.length === 0 && (childDetail as any).unlockedAdventures?.length === 0 && (childDetail as any).inventory?.length === 0 && (
                          <p className="text-xs text-muted-foreground text-center py-2">لم يفتح أي عنصر بعد</p>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Stories Tab */}
        {activeTab === "stories" && (
          <div className="space-y-4">
            <Button onClick={() => setShowAddStory(true)} className="gap-2 rounded-2xl h-12 font-bold">
              <Plus className="h-5 w-5" />
              إضافة قصة جديدة
            </Button>

            <div className="mb-2 text-sm text-muted-foreground">إجمالي القصص: {(adminStories || stories || []).length}</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {(adminStories || stories || []).map((story: any) => (
                <div key={story.id} className="bg-white rounded-3xl overflow-hidden shadow-sm border border-border/20">
                  <div className="relative h-36 overflow-hidden">
                    <img
                      src={story.coverImage || "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=200&fit=crop"}
                      alt={story.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                    <span className="absolute bottom-2 right-2 text-xs text-white bg-black/40 px-2 py-0.5 rounded-full">
                      {story.ageGroup} سنوات
                    </span>
                    <span className="absolute top-2 left-2 text-xs text-white bg-primary/80 px-2 py-0.5 rounded-full">
                      #{story.id}
                    </span>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-foreground text-sm mb-1 line-clamp-1">{story.title}</h3>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{story.description}</p>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs text-muted-foreground">{story.totalPages} صفحة</span>
                      <div className="flex items-center gap-1">
                        <Zap className="h-3 w-3 text-yellow-500" />
                        <span className="text-xs font-bold text-yellow-600">{story.pointsReward} نقطة</span>
                      </div>
                    </div>
                    <div className="flex gap-2 mb-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 rounded-xl border-2 gap-1 text-xs text-blue-600 border-blue-200 hover:bg-blue-50"
                        onClick={() => window.open(`/story/${story.id}`, '_blank')}
                      >
                        <Eye className="h-3 w-3" />
                        معاينة
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 rounded-xl border-2 gap-1 text-xs"
                        onClick={() => setEditingStory({ ...story })}
                      >
                        <Edit className="h-3 w-3" />
                        تعديل
                      </Button>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className={`flex-1 rounded-xl border-2 text-xs ${story.isPublished ? 'text-orange-600 border-orange-200' : 'text-green-600 border-green-200'}`}
                        onClick={() => handleToggleStoryPublish(story)}
                      >
                        {story.isPublished ? 'إخفاء' : 'نشر'}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-xl border-2 border-red-200 text-red-600 hover:bg-red-50 px-2"
                        onClick={() => handleDownloadStoryPDF(story)}
                        disabled={storyPdfLoading === story.id}
                        title="تحميل PDF"
                      >
                        {storyPdfLoading === story.id
                          ? <div className="w-3 h-3 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
                          : <FileDown className="h-3 w-3" />
                        }
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-xl border-2 border-destructive/30 text-destructive hover:bg-destructive/5 px-2"
                        onClick={() => handleDeleteStory2(story.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Edit Story Modal */}
            {editingStory && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
                <div className="bg-white rounded-3xl p-6 w-full max-w-lg my-4 shadow-2xl">
                  <div className="flex items-center justify-between mb-5">
                    <h3 className="text-xl font-bold text-foreground">تعديل القصة ✏️</h3>
                    <Button variant="ghost" size="sm" onClick={() => setEditingStory(null)}><X className="h-4 w-4" /></Button>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-bold mb-1 block">عنوان القصة</Label>
                      <Input value={editingStory.title} onChange={(e) => setEditingStory({ ...editingStory, title: e.target.value })} className="rounded-xl border-2" />
                    </div>
                    <div>
                      <Label className="text-sm font-bold mb-1 block">الوصف</Label>
                      <Input value={editingStory.description || ''} onChange={(e) => setEditingStory({ ...editingStory, description: e.target.value })} className="rounded-xl border-2" />
                    </div>
                    <div>
                      <Label className="text-sm font-bold mb-1 block">رابط صورة الغلاف</Label>
                      <Input value={editingStory.coverImage || ''} onChange={(e) => setEditingStory({ ...editingStory, coverImage: e.target.value })} className="rounded-xl border-2" dir="ltr" placeholder="https://..." />
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <Label className="text-sm font-bold mb-1 block">الفئة العمرية</Label>
                        <Select value={editingStory.ageGroup} onValueChange={(v) => setEditingStory({ ...editingStory, ageGroup: v })}>
                          <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">الكل</SelectItem>
                            <SelectItem value="4-6">٤-٦</SelectItem>
                            <SelectItem value="6-8">٦-٨</SelectItem>
                            <SelectItem value="8-10">٨-١٠</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-bold mb-1 block">الصعوبة</Label>
                        <Select value={editingStory.difficulty} onValueChange={(v) => setEditingStory({ ...editingStory, difficulty: v })}>
                          <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="easy">مبتدئ</SelectItem>
                            <SelectItem value="medium">متوسط</SelectItem>
                            <SelectItem value="hard">متقدم</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-bold mb-1 block">النقاط</Label>
                        <Input type="number" value={editingStory.pointsReward} onChange={(e) => setEditingStory({ ...editingStory, pointsReward: Number(e.target.value) })} className="rounded-xl border-2" />
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-xl">
                      <input type="checkbox" id="storyPublished" checked={!!editingStory.isPublished} onChange={(e) => setEditingStory({ ...editingStory, isPublished: e.target.checked })} className="w-4 h-4" />
                      <Label htmlFor="storyPublished" className="text-sm font-bold cursor-pointer">منشور (ظاهر للأطفال)</Label>
                    </div>
                  </div>
                  {/* زر تعديل الصفحات */}
                  <div className="mt-4 border-t border-border/30 pt-4">
                    <Button
                      variant="outline"
                      className="w-full rounded-2xl h-11 border-2 border-blue-200 text-blue-700 hover:bg-blue-50 gap-2 font-bold"
                      onClick={async () => {
                        setEditingStoryPages(true);
                        let adminToken = '';
                        try {
                          const stored = localStorage.getItem('adminSession');
                          if (stored) { const s = JSON.parse(stored); adminToken = s.adminToken || ''; }
                        } catch {}
                        const res = await fetch(`/api/trpc/stories.getById?batch=1&input=${encodeURIComponent(JSON.stringify({ '0': { json: { id: editingStory.id } } }))}`, {
                          headers: adminToken ? { 'x-admin-token': adminToken } : {}
                        });
                        const json = await res.json();
                        // batch format: [{result: {data: {json: {...}}}}]
                        const storyData = Array.isArray(json) ? json[0]?.result?.data?.json : json?.result?.data;
                        setStoryPagesData(storyData?.pages || []);
                      }}
                    >
                      📄 تعديل صفحات القصة ({editingStory.totalPages || 0} صفحة)
                    </Button>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <Button onClick={handleUpdateStory} disabled={updateStoryMutation.isPending} className="flex-1 rounded-2xl h-12 font-bold gap-2">
                      <Save className="h-4 w-4" />
                      {updateStoryMutation.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                    </Button>
                    <Button variant="outline" onClick={() => setEditingStory(null)} className="rounded-2xl h-12 border-2">إلغاء</Button>
                  </div>
                </div>
              </div>
            )}

            {/* Story Pages Editor Modal */}
            {editingStoryPages && editingStory && (
              <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-start justify-center z-[60] p-4 overflow-y-auto">
                <div className="bg-white rounded-3xl p-6 w-full max-w-2xl my-4 shadow-2xl">
                  <div className="flex items-center justify-between mb-5">
                    <h3 className="text-xl font-bold text-foreground">📄 صفحات قصة: {editingStory.title}</h3>
                    <Button variant="ghost" size="sm" onClick={() => setEditingStoryPages(false)}><X className="h-4 w-4" /></Button>
                  </div>
                  <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                    {storyPagesData.map((page: any, idx: number) => (
                      <div key={page.id} className="border-2 border-border/30 rounded-2xl p-4 bg-muted/20">
                        <div className="flex items-center justify-between mb-3">
                          <span className="font-bold text-sm text-primary">الصفحة {idx + 1}</span>
                          <div className="flex gap-2">
                            {editingPageId === page.id ? (
                              <>
                                <Button size="sm" className="rounded-xl text-xs gap-1" onClick={() => {
                                  updatePageMutation.mutate({ id: page.id, text: editingPageText, imageUrl: editingPageImage || undefined });
                                  setStoryPagesData(prev => prev.map(p => p.id === page.id ? { ...p, text: editingPageText, imageUrl: editingPageImage } : p));
                                }}>
                                  <Save className="h-3 w-3" /> حفظ
                                </Button>
                                <Button size="sm" variant="outline" className="rounded-xl text-xs" onClick={() => setEditingPageId(null)}>إلغاء</Button>
                              </>
                            ) : (
                              <>
                                <Button size="sm" variant="outline" className="rounded-xl text-xs gap-1" onClick={() => {
                                  setEditingPageId(page.id);
                                  setEditingPageText(page.text || '');
                                  setEditingPageImage(page.imageUrl || '');
                                }}>
                                  <Edit className="h-3 w-3" /> تعديل
                                </Button>
                                <Button size="sm" variant="outline" className="rounded-xl text-xs border-destructive/30 text-destructive hover:bg-destructive/5 px-2" onClick={() => {
                                  if (confirm('حذف هذه الصفحة؟')) {
                                    deletePageMutation.mutate({ id: page.id });
                                    setStoryPagesData(prev => prev.filter(p => p.id !== page.id));
                                  }
                                }}><Trash2 className="h-3 w-3" /></Button>
                              </>
                            )}
                          </div>
                        </div>
                        {editingPageId === page.id ? (
                          <div className="space-y-3">
                            <div>
                              <Label className="text-xs font-bold mb-1 block">نص الصفحة</Label>
                              <textarea
                                className="w-full h-28 p-3 border-2 rounded-xl text-sm resize-y bg-white focus:ring-2 focus:ring-primary/30 focus:border-primary"
                                value={editingPageText}
                                onChange={e => setEditingPageText(e.target.value)}
                              />
                            </div>
                            <div>
                              <Label className="text-xs font-bold mb-1 block">صورة الصفحة</Label>
                              <div className="space-y-2">
                                <Input value={editingPageImage} onChange={e => setEditingPageImage(e.target.value)} className="rounded-xl border-2 text-sm" dir="ltr" placeholder="https://... أو ارفع صورة أدناه" />
                                <div className="flex items-center gap-2">
                                  <label className="flex-1 cursor-pointer">
                                    <div className="border-2 border-dashed border-blue-300 rounded-xl p-3 text-center text-xs text-blue-600 hover:bg-blue-50 transition-colors">
                                      📁 رفع صورة من الجهاز
                                    </div>
                                    <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      if (!file) return;
                                      let adminToken = '';
                                      try { const s = localStorage.getItem('adminSession'); if (s) adminToken = JSON.parse(s).adminToken || ''; } catch {}
                                      const fd = new FormData();
                                      fd.append('image', file);
                                      const res = await fetch('/api/upload-image', { method: 'POST', headers: adminToken ? { 'x-admin-token': adminToken } : {}, body: fd });
                                      const data = await res.json();
                                      if (data.url) { setEditingPageImage(data.url); toast.success('تم رفع الصورة ✅'); }
                                      else toast.error(data.error || 'فشل رفع الصورة');
                                    }} />
                                  </label>
                                  {editingPageImage && (
                                    <button type="button" className="text-xs text-red-500 hover:text-red-700 px-2 py-1 border border-red-200 rounded-lg" onClick={() => setEditingPageImage('')}>حذف الصورة</button>
                                  )}
                                </div>
                                {editingPageImage && <img src={editingPageImage} alt="" className="h-24 w-full object-cover rounded-xl border" />}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <p className="text-sm text-foreground leading-relaxed">{page.text}</p>
                            {page.imageUrl && <img src={page.imageUrl} alt="" className="mt-2 h-20 w-full object-cover rounded-xl" />}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  {/* إضافة صفحة جديدة */}
                  <div className="mt-4 border-t border-border/30 pt-4">
                    <h4 className="font-bold text-sm mb-3 text-green-700">➕ إضافة صفحة جديدة</h4>
                    <div className="space-y-3">
                      <textarea
                        id="newPageText"
                        className="w-full h-24 p-3 border-2 rounded-xl text-sm resize-y bg-white focus:ring-2 focus:ring-green-300"
                        placeholder="نص الصفحة الجديدة..."
                      />
                      <div className="space-y-2">
                        <Input value={newPageImageUrl} onChange={e => setNewPageImageUrl(e.target.value)} className="rounded-xl border-2 text-sm" dir="ltr" placeholder="رابط صورة (URL) - اختياري" />
                        <label className="cursor-pointer block">
                          <div className="border-2 border-dashed border-green-300 rounded-xl p-3 text-center text-xs text-green-700 hover:bg-green-50 transition-colors">
                            📁 رفع صورة من الجهاز
                          </div>
                          <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            let adminToken = '';
                            try { const s = localStorage.getItem('adminSession'); if (s) adminToken = JSON.parse(s).adminToken || ''; } catch {}
                            const fd = new FormData();
                            fd.append('image', file);
                            const res = await fetch('/api/upload-image', { method: 'POST', headers: adminToken ? { 'x-admin-token': adminToken } : {}, body: fd });
                            const data = await res.json();
                            if (data.url) { setNewPageImageUrl(data.url); toast.success('تم رفع الصورة ✅'); }
                            else toast.error(data.error || 'فشل رفع الصورة');
                          }} />
                        </label>
                        {newPageImageUrl && <img src={newPageImageUrl} alt="" className="h-20 w-full object-cover rounded-xl border" />}
                      </div>
                      <Button
                        className="w-full rounded-2xl h-10 bg-green-600 hover:bg-green-700 text-sm font-bold"
                        onClick={() => {
                          const text = (document.getElementById('newPageText') as HTMLTextAreaElement)?.value;
                          if (!text?.trim()) { toast.error('أدخل نص الصفحة'); return; }
                          addPageToStoryMutation.mutate({ storyId: editingStory.id, text, pageNumber: storyPagesData.length + 1, imageUrl: newPageImageUrl || undefined }, {
                            onSuccess: () => {
                              (document.getElementById('newPageText') as HTMLTextAreaElement).value = '';
                              setNewPageImageUrl('');
                            }
                          });
                        }}
                      >➕ إضافة الصفحة</Button>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-3 rounded-2xl border-2" onClick={() => setEditingStoryPages(false)}>إغلاق</Button>
                </div>
              </div>
            )}
            {/* Add Story Modal */}
            {showAddStory && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
                <div className="bg-white rounded-3xl p-6 w-full max-w-lg my-4 shadow-2xl">
                  <h3 className="text-xl font-bold text-foreground mb-5">إضافة قصة جديدة 📖</h3>

                  {/* زر توليد بالذكاء الاصطناعي */}
                  <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-2xl p-4 mb-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-bold text-purple-800 text-sm">✨ توليد قصة بالذكاء الاصطناعي</h4>
                        <p className="text-xs text-purple-600">اكتب موضوعاً وسيولد الذكاء الاصطناعي قصة كاملة</p>
                      </div>
                      <button onClick={() => setShowAIGenerator(!showAIGenerator)} className="text-xs bg-purple-600 text-white px-3 py-1.5 rounded-xl hover:bg-purple-700 transition-colors font-bold">
                        {showAIGenerator ? "إخفاء" : "توليد بالذكاء"}
                      </button>
                    </div>
                    {showAIGenerator && (
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs font-bold mb-1 block text-purple-700">موضوع القصة *</Label>
                          <Input value={aiTopic} onChange={(e) => setAiTopic(e.target.value)} className="rounded-xl border-2 border-purple-200 text-sm" placeholder="مثال: الصدق والأمانة, يوم الوطن, الصبر والمثابرة..." />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label className="text-xs font-bold mb-1 block text-purple-700">المستوى</Label>
                            <Select value={aiDifficulty} onValueChange={(v) => setAiDifficulty(v as any)}>
                              <SelectTrigger className="rounded-xl border-2 border-purple-200 text-xs h-9"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="easy">مبتدئ</SelectItem>
                                <SelectItem value="medium">متوسط</SelectItem>
                                <SelectItem value="hard">متقدم</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-xs font-bold mb-1 block text-purple-700">العمر</Label>
                            <Select value={aiAgeGroup} onValueChange={(v) => setAiAgeGroup(v as any)}>
                              <SelectTrigger className="rounded-xl border-2 border-purple-200 text-xs h-9"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="4-6">٤-٦ سنوات</SelectItem>
                                <SelectItem value="6-8">٦-٨ سنوات</SelectItem>
                                <SelectItem value="8-10">٨-١٠ سنوات</SelectItem>
                                <SelectItem value="all">الكل</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-xs font-bold mb-1 block text-purple-700">عدد الصفحات</Label>
                            <Input type="number" min={3} max={10} value={aiPagesCount} onChange={(e) => setAiPagesCount(Number(e.target.value))} className="rounded-xl border-2 border-purple-200 text-xs h-9" />
                          </div>
                        </div>
                        <Button onClick={handleGenerateStory} disabled={generateStoryMutation.isPending} className="w-full rounded-xl h-10 bg-purple-600 hover:bg-purple-700 text-sm font-bold">
                          {generateStoryMutation.isPending ? "جارٍ التوليد... ⚙️" : "✨ ولّد القصة"}
                        </Button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-bold mb-1 block">عنوان القصة *</Label>
                      <Input value={storyForm.title} onChange={(e) => setStoryForm({ ...storyForm, title: e.target.value })} className="rounded-xl border-2" placeholder="عنوان القصة" />
                    </div>
                    <div>
                      <Label className="text-sm font-bold mb-1 block">الوصف</Label>
                      <Input value={storyForm.description} onChange={(e) => setStoryForm({ ...storyForm, description: e.target.value })} className="rounded-xl border-2" placeholder="وصف مختصر للقصة" />
                    </div>
                    <div>
                      <Label className="text-sm font-bold mb-1 block">رابط صورة الغلاف</Label>
                      <Input value={storyForm.coverImage} onChange={(e) => setStoryForm({ ...storyForm, coverImage: e.target.value })} className="rounded-xl border-2" placeholder="https://..." dir="ltr" />
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <Label className="text-sm font-bold mb-1 block">الفئة العمرية</Label>
                        <Select value={storyForm.ageGroup} onValueChange={(v) => setStoryForm({ ...storyForm, ageGroup: v as any })}>
                          <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">الكل</SelectItem>
                            <SelectItem value="4-6">٤-٦ سنوات</SelectItem>
                            <SelectItem value="6-8">٦-٨ سنوات</SelectItem>
                            <SelectItem value="8-10">٨-١٠ سنوات</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-bold mb-1 block">الصعوبة</Label>
                        <Select value={storyForm.difficulty} onValueChange={(v) => setStoryForm({ ...storyForm, difficulty: v as any })}>
                          <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="easy">مبتدئ</SelectItem>
                            <SelectItem value="medium">متوسط</SelectItem>
                            <SelectItem value="hard">متقدم</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-bold mb-1 block">النقاط</Label>
                        <Input type="number" value={storyForm.pointsReward} onChange={(e) => setStoryForm({ ...storyForm, pointsReward: Number(e.target.value) })} className="rounded-xl border-2" />
                      </div>
                    </div>

                    {/* Story Pages */}
                    <div>
                      <Label className="text-sm font-bold mb-2 block">صفحات القصة</Label>
                      {storyPages.map((page, idx) => (
                        <div key={idx} className="bg-muted/30 rounded-2xl p-3 mb-2">
                          <p className="text-xs font-bold text-muted-foreground mb-2">صفحة {idx + 1}</p>
                          <textarea
                            value={page.text}
                            onChange={(e) => {
                              const newPages = [...storyPages];
                              newPages[idx].text = e.target.value;
                              setStoryPages(newPages);
                            }}
                            className="w-full border-2 border-border rounded-xl p-2 text-sm resize-none focus:border-primary outline-none"
                            rows={3}
                            placeholder="نص الصفحة..."
                          />
                          <Input
                            value={page.imageUrl}
                            onChange={(e) => {
                              const newPages = [...storyPages];
                              newPages[idx].imageUrl = e.target.value;
                              setStoryPages(newPages);
                            }}
                            className="mt-2 rounded-xl border-2 text-xs"
                            placeholder="رابط صورة الصفحة (اختياري)"
                            dir="ltr"
                          />
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setStoryPages([...storyPages, { text: "", imageUrl: "" }])}
                        className="rounded-xl border-2 gap-1"
                      >
                        <Plus className="h-3 w-3" />
                        إضافة صفحة
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-3 mt-6">
                    <Button onClick={handleCreateStory} disabled={createStoryMutation.isPending} className="flex-1 rounded-2xl h-12 font-bold">
                      {createStoryMutation.isPending ? "جارٍ الحفظ..." : "حفظ القصة"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddStory(false)} className="rounded-2xl h-12 border-2">
                      إلغاء
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Activities Tab */}
        {activeTab === "activities" && (
          <div className="space-y-4">
            <Button onClick={() => setShowAddActivity(true)} className="gap-2 rounded-2xl h-12 font-bold bg-secondary hover:bg-secondary/90">
              <Plus className="h-5 w-5" />
              إضافة نشاط جديد
            </Button>

            {/* Activities List */}
            {!showAddActivity && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-base font-bold text-foreground">قائمة الأنشطة</h3>
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">{(allActivities || []).length} نشاط</span>
                </div>
                {(!allActivities || allActivities.length === 0) ? (
                  <div className="text-center py-10 bg-white/60 rounded-3xl">
                    <div className="text-4xl mb-2">&#127918;</div>
                    <p className="text-muted-foreground">لا توجد أنشطة بعد</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {(allActivities || []).map((act: any) => (
                      <div key={act.id} className="bg-white rounded-2xl p-4 shadow-sm border border-border/30">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-bold text-sm text-foreground">{act.title}</span>
                              <span className="text-xs bg-secondary/20 text-secondary-foreground px-2 py-0.5 rounded-full">
                                {act.type === 'quiz' ? 'اختبار' : act.type === 'matching' ? 'مطابقة' : 'لغز'}
                              </span>
                              <span className={`text-xs px-2 py-0.5 rounded-full ${act.isPublished ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                                {act.isPublished ? 'منشور' : 'مخفي'}
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground">{act.description}</p>
                            <div className="flex gap-2 mt-1">
                              <span className="text-xs text-muted-foreground">الفئة: {act.ageGroup}</span>
                              <span className="text-xs text-yellow-600">⚡ {act.pointsReward} نقطة</span>
                            </div>
                          </div>
                          <div className="flex gap-2 flex-shrink-0">
                            <Button
                              size="sm"
                              variant="outline"
                              className="rounded-xl border-2 text-xs gap-1 border-purple-200 text-purple-700 hover:bg-purple-50"
                              onClick={() => setEditingActivity(act)}
                            >
                              ❓ الأسئلة
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="rounded-xl border-2 text-xs gap-1"
                              onClick={() => updateActivityMutation.mutate({ id: act.id, isPublished: !act.isPublished }, {
                                onSuccess: () => { toast.success(act.isPublished ? 'تم إخفاء النشاط' : 'تم نشر النشاط ✅'); refetchActivities(); },
                                onError: (e: any) => toast.error(e.message),
                              })}
                            >
                              {act.isPublished ? 'إخفاء' : 'نشر'}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="rounded-xl border-2 border-destructive/30 text-destructive hover:bg-destructive/5 px-2"
                              onClick={() => handleDeleteActivity(act.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Activity Questions Manager Modal */}
            {editingActivity && (
              <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
                <div className="bg-white rounded-3xl p-6 w-full max-w-2xl my-4 shadow-2xl">
                  <div className="flex items-center justify-between mb-5">
                    <h3 className="text-xl font-bold text-foreground">❓ أسئلة: {editingActivity.title}</h3>
                    <Button variant="ghost" size="sm" onClick={() => setEditingActivity(null)}><X className="h-4 w-4" /></Button>
                  </div>
                  {/* قائمة الأسئلة */}
                  <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1 mb-4">
                    {activityQuestionsData.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground text-sm">لا توجد أسئلة بعد</div>
                    ) : activityQuestionsData.map((q: any, idx: number) => (
                      <div key={q.id} className="border-2 border-border/30 rounded-2xl p-4 bg-muted/20">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1">
                            {editingQuestionId === q.id && editingQuestionForm ? (
                              <div className="space-y-2">
                                <textarea
                                  className="w-full h-20 p-2 border-2 rounded-xl text-sm resize-none"
                                  value={editingQuestionForm.questionText}
                                  onChange={e => setEditingQuestionForm(prev => prev ? { ...prev, questionText: e.target.value } : prev)}
                                  placeholder="نص السؤال..."
                                />
                                <div className="grid grid-cols-2 gap-2">
                                  {[0,1,2,3].map(i => (
                                    <Input key={i}
                                      value={editingQuestionForm.options[i] ?? ''}
                                      onChange={e => {
                                        const opts = [...editingQuestionForm.options];
                                        opts[i] = e.target.value;
                                        setEditingQuestionForm(prev => prev ? { ...prev, options: opts } : prev);
                                      }}
                                      placeholder={`خيار ${i+1}`}
                                      className="rounded-xl border-2 text-xs"
                                    />
                                  ))}
                                </div>
                                <div className="flex gap-2">
                                  <select
                                    className="flex-1 border-2 rounded-xl p-2 text-sm"
                                    value={editingQuestionForm.correctAnswer}
                                    onChange={e => setEditingQuestionForm(prev => prev ? { ...prev, correctAnswer: e.target.value } : prev)}
                                  >
                                    <option value="0">الخيار 1 (صحيح)</option>
                                    <option value="1">الخيار 2 (صحيح)</option>
                                    <option value="2">الخيار 3 (صحيح)</option>
                                    <option value="3">الخيار 4 (صحيح)</option>
                                  </select>
                                  <Button size="sm" className="rounded-xl text-xs" onClick={() => {
                                    if (!editingQuestionForm) return;
                                    updateQuestionMutation.mutate({ id: q.id, questionText: editingQuestionForm.questionText, options: editingQuestionForm.options, correctAnswer: editingQuestionForm.correctAnswer });
                                    setActivityQuestionsData(prev => prev.map(x => x.id === q.id ? { ...x, ...editingQuestionForm } : x));
                                  }} disabled={updateQuestionMutation.isPending}><Save className="h-3 w-3" /> حفظ</Button>
                                  <Button size="sm" variant="outline" className="rounded-xl text-xs" onClick={() => { setEditingQuestionId(null); setEditingQuestionForm(null); }}>إلغاء</Button>
                                </div>
                              </div>
                            ) : (
                              <div>
                                <p className="text-sm font-bold text-foreground mb-1">س{idx+1}: {q.questionText}</p>
                                {Array.isArray(q.options) && (
                                  <div className="grid grid-cols-2 gap-1 mt-1">
                                    {q.options.map((opt: string, i: number) => (
                                      <span key={i} className={`text-xs px-2 py-1 rounded-lg ${String(i) === String(q.correctAnswer) ? 'bg-green-100 text-green-700 font-bold' : 'bg-muted text-muted-foreground'}`}>{opt}</span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                          {editingQuestionId !== q.id && (
                            <div className="flex gap-1 flex-shrink-0">
                              <Button size="sm" variant="outline" className="rounded-xl text-xs px-2" onClick={() => {
                                setEditingQuestionId(q.id);
                                setEditingQuestionForm({
                                  questionText: q.questionText || '',
                                  options: Array.isArray(q.options) ? [...q.options] : ['', '', '', ''],
                                  correctAnswer: String(q.correctAnswer ?? '0'),
                                  explanation: q.explanation || '',
                                });
                              }}><Edit className="h-3 w-3" /></Button>
                              <Button size="sm" variant="outline" className="rounded-xl text-xs px-2 border-destructive/30 text-destructive" onClick={() => {
                                if (confirm('حذف هذا السؤال؟')) {
                                  deleteQuestionMutation.mutate({ id: q.id });
                                  setActivityQuestionsData(prev => prev.filter(x => x.id !== q.id));
                                }
                              }}><Trash2 className="h-3 w-3" /></Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  {/* إضافة سؤال جديد */}
                  <div className="border-t border-border/30 pt-4">
                    <h4 className="font-bold text-sm mb-3 text-green-700">➕ إضافة سؤال جديد</h4>
                    <div className="space-y-3">
                      <textarea
                        className="w-full h-20 p-3 border-2 rounded-xl text-sm resize-none"
                        placeholder="نص السؤال..."
                        value={newQuestionForm.questionText}
                        onChange={e => setNewQuestionForm(prev => ({ ...prev, questionText: e.target.value }))}
                      />
                      <div className="grid grid-cols-2 gap-2">
                        {newQuestionForm.options.map((opt, i) => (
                          <Input key={i} value={opt} onChange={e => { const o = [...newQuestionForm.options]; o[i] = e.target.value; setNewQuestionForm(prev => ({ ...prev, options: o })); }} placeholder={`خيار ${i+1}`} className="rounded-xl border-2 text-xs" />
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <select
                          className="flex-1 border-2 rounded-xl p-2 text-sm"
                          value={newQuestionForm.correctAnswer}
                          onChange={e => setNewQuestionForm(prev => ({ ...prev, correctAnswer: e.target.value }))}
                        >
                          <option value="0">الخيار 1 (صحيح)</option>
                          <option value="1">الخيار 2 (صحيح)</option>
                          <option value="2">الخيار 3 (صحيح)</option>
                          <option value="3">الخيار 4 (صحيح)</option>
                        </select>
                        <Button
                          className="rounded-2xl bg-green-600 hover:bg-green-700 text-sm font-bold px-4"
                          disabled={!newQuestionForm.questionText.trim() || addQuestionMutation.isPending}
                          onClick={() => {
                            addQuestionMutation.mutate({
                              activityId: editingActivity.id,
                              questionText: newQuestionForm.questionText,
                              questionType: 'multiple_choice',
                              options: newQuestionForm.options,
                              correctAnswer: newQuestionForm.correctAnswer,
                              orderIndex: activityQuestionsData.length,
                            }, { onSuccess: (_, vars) => {
                              setActivityQuestionsData(prev => [...prev, { id: Date.now(), ...vars }]);
                            }});
                          }}
                        >➕ إضافة</Button>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-3 rounded-2xl border-2" onClick={() => setEditingActivity(null)}>إغلاق</Button>
                </div>
              </div>
            )}
            {/* Add Activity Modal */}
            {showAddActivity && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
                <div className="bg-white rounded-3xl p-6 w-full max-w-lg my-4 shadow-2xl">
                  <h3 className="text-xl font-bold text-foreground mb-5">إضافة نشاط جديد 🎮</h3>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-bold mb-1 block">اختر القصة *</Label>
                      <Select value={String(activityForm.storyId)} onValueChange={(v) => setActivityForm({ ...activityForm, storyId: Number(v) })}>
                        <SelectTrigger className="rounded-xl border-2"><SelectValue placeholder="اختر قصة" /></SelectTrigger>
                        <SelectContent>
                          {(stories || []).map((s) => (
                            <SelectItem key={s.id} value={String(s.id)}>{s.title}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-sm font-bold mb-1 block">عنوان النشاط *</Label>
                      <Input value={activityForm.title} onChange={(e) => setActivityForm({ ...activityForm, title: e.target.value })} className="rounded-xl border-2" placeholder="عنوان النشاط" />
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <Label className="text-sm font-bold mb-1 block">النوع</Label>
                        <Select value={activityForm.type} onValueChange={(v) => setActivityForm({ ...activityForm, type: v as any })}>
                          <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="quiz">اختبار</SelectItem>
                            <SelectItem value="matching">مطابقة</SelectItem>
                            <SelectItem value="puzzle">لغز</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-bold mb-1 block">الفئة العمرية</Label>
                        <Select value={activityForm.ageGroup} onValueChange={(v) => setActivityForm({ ...activityForm, ageGroup: v as any })}>
                          <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">الكل</SelectItem>
                            <SelectItem value="4-6">٤-٦</SelectItem>
                            <SelectItem value="6-8">٦-٨</SelectItem>
                            <SelectItem value="8-10">٨-١٠</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-bold mb-1 block">النقاط</Label>
                        <Input type="number" value={activityForm.pointsReward} onChange={(e) => setActivityForm({ ...activityForm, pointsReward: Number(e.target.value) })} className="rounded-xl border-2" />
                      </div>
                    </div>

                    {/* Questions */}
                    <div>
                      <Label className="text-sm font-bold mb-2 block">الأسئلة</Label>
                      {questions.map((q, qi) => (
                        <div key={qi} className="bg-muted/30 rounded-2xl p-3 mb-3">
                          <p className="text-xs font-bold text-muted-foreground mb-2">سؤال {qi + 1}</p>
                          <Input
                            value={q.questionText}
                            onChange={(e) => {
                              const newQ = [...questions];
                              newQ[qi].questionText = e.target.value;
                              setQuestions(newQ);
                            }}
                            className="rounded-xl border-2 mb-2"
                            placeholder="نص السؤال"
                          />
                          <div className="space-y-1 mb-2">
                            {q.options.map((opt, oi) => (
                              <div key={oi} className="flex gap-2 items-center">
                                <button
                                  onClick={() => {
                                    const newQ = [...questions];
                                    newQ[qi].correctAnswer = String(oi);
                                    setQuestions(newQ);
                                  }}
                                  className={`w-6 h-6 rounded-full border-2 flex-shrink-0 ${q.correctAnswer === String(oi) ? "bg-green-500 border-green-500" : "border-border"}`}
                                />
                                <Input
                                  value={opt}
                                  onChange={(e) => {
                                    const newQ = [...questions];
                                    newQ[qi].options[oi] = e.target.value;
                                    setQuestions(newQ);
                                  }}
                                  className="rounded-xl border-2 h-8 text-xs"
                                  placeholder={`خيار ${oi + 1}`}
                                />
                              </div>
                            ))}
                          </div>
                          <Input
                            value={q.explanation}
                            onChange={(e) => {
                              const newQ = [...questions];
                              newQ[qi].explanation = e.target.value;
                              setQuestions(newQ);
                            }}
                            className="rounded-xl border-2 text-xs"
                            placeholder="شرح الإجابة الصحيحة (اختياري)"
                          />
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setQuestions([...questions, { questionText: "", questionType: "multiple_choice", options: ["", "", "", ""], correctAnswer: "0", explanation: "" }])}
                        className="rounded-xl border-2 gap-1"
                      >
                        <Plus className="h-3 w-3" />
                        إضافة سؤال
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-3 mt-6">
                    <Button onClick={handleCreateActivity} disabled={createActivityMutation.isPending} className="flex-1 rounded-2xl h-12 font-bold bg-secondary hover:bg-secondary/90">
                      {createActivityMutation.isPending ? "جارٍ الحفظ..." : "حفظ النشاط"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddActivity(false)} className="rounded-2xl h-12 border-2">
                      إلغاء
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
         {/* Reviews Tab */}
        {activeTab === "reviews" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-bold text-foreground">إدارة تقييمات الموقع</h2>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                {allReviews?.length ?? 0} تقييم
              </span>
            </div>

            {!allReviews || allReviews.length === 0 ? (
              <div className="text-center py-16 bg-white/60 rounded-3xl">
                <div className="text-5xl mb-3">💬</div>
                <p className="text-muted-foreground">لا توجد تقييمات حتى الآن</p>
              </div>
            ) : (
              <div className="space-y-3">
                {allReviews.map((r) => (
                  <div key={r.id} className={`bg-white rounded-2xl p-4 shadow-sm border-2 ${
                    r.isApproved ? "border-green-200" : "border-yellow-200"
                  }`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-sm text-foreground">{r.name}</span>
                          <div className="flex">
                            {Array.from({ length: r.rating }).map((_, i) => (
                              <Star key={i} className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                            ))}
                          </div>
                          {r.isApproved ? (
                            <span className="text-xs text-green-600 font-bold bg-green-50 px-2 py-0.5 rounded-full">✅ منشور</span>
                          ) : (
                            <span className="text-xs text-yellow-600 font-bold bg-yellow-50 px-2 py-0.5 rounded-full">⏳ بانتظار</span>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">{r.review}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(r.createdAt).toLocaleDateString("ar-SA")}
                        </p>
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        {!r.isApproved && (
                          <Button
                            size="sm"
                            onClick={() => handleApproveReview(r.id)}
                            className="rounded-xl h-8 text-xs bg-green-500 hover:bg-green-600 gap-1"
                          >
                            <CheckCircle className="h-3 w-3" />
                            نشر
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteReview(r.id)}
                          className="rounded-xl h-8 text-xs gap-1"
                        >
                          <Trash2 className="h-3 w-3" />
                          حذف
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {/* تبويب إحصائيات المستويات */}
        {/* تبويب الإحصائيات المقسّمة */}
        {activeTab === "segmented" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <span className="text-2xl">📊</span> إحصائيات مقسّمة حسب المجموعة
            </h2>

            {/* أزرار التصفية */}
            <div className="flex gap-3 flex-wrap">
              {[
                { key: "all", label: "🌍 جميع الأطفال", color: "bg-blue-500" },
                { key: "kindergarten", label: "🌸 روضة السعادة", color: "bg-pink-500" },
                { key: "outside", label: "🏠 خارج الروضة", color: "bg-purple-500" },
              ].map((btn) => (
                <button
                  key={btn.key}
                  onClick={() => setSegmentedFilter(btn.key as any)}
                  className={`px-5 py-2.5 rounded-2xl font-bold text-sm transition-all shadow-sm ${
                    segmentedFilter === btn.key
                      ? `${btn.color} text-white scale-105 shadow-md`
                      : "bg-white/80 text-foreground border border-border/50 hover:bg-white"
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            {!segmentedStats ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (() => {
              const data = segmentedFilter === "kindergarten"
                ? segmentedStats.kindergartenStats
                : segmentedFilter === "outside"
                ? segmentedStats.outsideStats
                : segmentedStats.allStats;

              const groupLabel = segmentedFilter === "kindergarten"
                ? "🌸 روضة السعادة"
                : segmentedFilter === "outside"
                ? "🏠 خارج الروضة"
                : "🌍 جميع الأطفال";

              return (
                <>
                  {/* بطاقة الملخص */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm text-center">
                      <div className="text-3xl font-bold text-blue-600">{data.total}</div>
                      <div className="text-xs text-muted-foreground mt-1">إجمالي الأطفال</div>
                    </div>
                    <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm text-center">
                      <div className="text-3xl font-bold text-green-600">{data.completedEasy}</div>
                      <div className="text-xs text-muted-foreground mt-1">أكملوا مستوى المبتدئ 🟢</div>
                    </div>
                    <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm text-center">
                      <div className="text-3xl font-bold text-yellow-600">{data.completedMedium}</div>
                      <div className="text-xs text-muted-foreground mt-1">أكملوا المستوى المتوسط 🟡</div>
                    </div>
                    <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm text-center">
                      <div className="text-3xl font-bold text-red-600">{data.completedHard}</div>
                      <div className="text-xs text-muted-foreground mt-1">أكملوا مستوى المتقدم 🔴</div>
                    </div>
                  </div>

                  {/* شريط التقدم لكل مستوى */}
                  <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                    <h3 className="font-bold text-foreground mb-4">{groupLabel} — نسب إكمال المستويات</h3>
                    <div className="space-y-4">
                      {[
                        { label: "مستوى المبتدئ 🟢", count: data.completedEasy, color: "bg-green-500" },
                        { label: "مستوى المتوسط 🟡", count: data.completedMedium, color: "bg-yellow-500" },
                        { label: "مستوى المتقدم 🔴", count: data.completedHard, color: "bg-red-500" },
                      ].map((lvl) => {
                        const pct = data.total > 0 ? Math.round((lvl.count / data.total) * 100) : 0;
                        return (
                          <div key={lvl.label}>
                            <div className="flex justify-between text-sm mb-1">
                              <span className="text-muted-foreground">{lvl.label}</span>
                              <span className="font-bold">{lvl.count} / {data.total} ({pct}%)</span>
                            </div>
                            <div className="h-3 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full ${lvl.color} rounded-full transition-all duration-700`}
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* توزيع الفصول (روضة السعادة فقط) */}
                  {segmentedFilter === "kindergarten" && (data.classroomDist as any[]).length > 0 && (
                    <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                      <h3 className="font-bold text-foreground mb-4">🏫 توزيع الأطفال على الفصول</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {(data.classroomDist as any[]).map((c: any) => (
                          <div key={c.classroom} className="bg-pink-50 rounded-2xl p-4 text-center border border-pink-200">
                            <div className="text-2xl font-bold text-pink-600">{c.count}</div>
                            <div className="text-xs text-pink-700 mt-1 font-medium">{c.classroom}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* توزيع مصدر المعرفة (خارج الروضة فقط) */}
                  {segmentedFilter === "outside" && (data.referralDist as any[]).length > 0 && (
                    <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                      <h3 className="font-bold text-foreground mb-4">💬 كيف عرفوا عنّا؟</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {(data.referralDist as any[]).map((r: any) => (
                          <div key={r.referralSource} className="bg-purple-50 rounded-2xl p-4 text-center border border-purple-200">
                            <div className="text-2xl font-bold text-purple-600">{r.count}</div>
                            <div className="text-xs text-purple-700 mt-1 font-medium">{r.referralSource}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* جدول أكثر الأطفال تقدماً في المجموعة */}
                  <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                    <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
                      <span>🏅</span> أكثر الأطفال تقدماً — {groupLabel}
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-border/50">
                            <th className="text-right py-2 px-3 text-muted-foreground font-medium">المتعلم</th>
                            {segmentedFilter === "kindergarten" && (
                              <th className="text-center py-2 px-3 text-pink-600 font-medium">الفصل</th>
                            )}
                            <th className="text-center py-2 px-3 text-purple-600 font-medium">🎯 المستوى</th>
                            <th className="text-center py-2 px-3 text-blue-600 font-medium">📚 مستوى القصص</th>
                            <th className="text-center py-2 px-3 text-amber-600 font-medium">⭐ النقاط</th>
                            <th className="text-center py-2 px-3 text-green-600 font-medium">📖 القصص المكتملة</th>
                            <th className="text-center py-2 px-3 text-rose-600 font-medium">🎤 تسجيلات</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(data.topChildren as any[]).map((child: any, i: number) => (
                            <tr key={i} className="border-b border-border/20 hover:bg-muted/30 transition-colors">
                              <td className="py-2 px-3 font-medium text-foreground">
                                <span className="inline-flex items-center gap-1">
                                  {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`}
                                  {child.name}
                                  {child.isKindergartenStudent ? (
                                    <span className="text-xs bg-pink-100 text-pink-600 px-1.5 py-0.5 rounded-full">🌸 روضة</span>
                                  ) : null}
                                </span>
                              </td>
                              {segmentedFilter === "kindergarten" && (
                                <td className="text-center py-2 px-3">
                                  <span className="bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full text-xs">{child.classroom || "—"}</span>
                                </td>
                              )}
                              <td className="text-center py-2 px-3">
                                <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full text-xs font-bold">Lv.{child.level ?? 1}</span>
                              </td>
                              <td className="text-center py-2 px-3">
                                {child.storyLevel === 'easy' ? (
                                  <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full text-xs font-bold">🟢 سهل</span>
                                ) : child.storyLevel === 'medium' ? (
                                  <span className="bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full text-xs font-bold">🟡 متوسط</span>
                                ) : child.storyLevel === 'hard' ? (
                                  <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-full text-xs font-bold">🔴 متقدم</span>
                                ) : (
                                  <span className="bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full text-xs">—</span>
                                )}
                              </td>
                              <td className="text-center py-2 px-3">
                                <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-xs font-bold">{child.totalPoints ?? 0}</span>
                              </td>
                              <td className="text-center py-2 px-3">
                                <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full text-xs font-bold">{child.totalDone ?? 0}</span>
                              </td>
                              <td className="text-center py-2 px-3">
                                {(child.recordingCount ?? 0) > 0 ? (
                                  <span className="bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full text-xs font-bold">🎤 {child.recordingCount}</span>
                                ) : (
                                  <span className="text-muted-foreground text-xs">—</span>
                                )}
                              </td>
                            </tr>
                          ))}
                          {(data.topChildren as any[]).length === 0 && (
                            <tr>
                              <td colSpan={segmentedFilter === "kindergarten" ? 7 : 6} className="text-center py-8 text-muted-foreground">لا يوجد بيانات لهذه المجموعة بعد</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        )}

        {activeTab === "levels" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <span className="text-2xl">🏆</span> إحصائيات انتقال المستويات
            </h2>

            {!levelStats ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (
              <>
                {/* بطاقات المستويات الثلاث */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    {
                      level: "مبتدئ", emoji: "🟢", color: "from-green-400 to-emerald-500",
                      completed: levelStats.completedEasy,
                      stories: levelStats.storyCounts?.easy ?? 0,
                      label: "المستوى الأول",
                    },
                    {
                      level: "متوسط", emoji: "🟡", color: "from-yellow-400 to-orange-500",
                      completed: levelStats.completedMedium,
                      stories: levelStats.storyCounts?.medium ?? 0,
                      label: "المستوى الثاني",
                    },
                    {
                      level: "متقدم", emoji: "🔴", color: "from-red-400 to-rose-500",
                      completed: levelStats.completedHard,
                      stories: levelStats.storyCounts?.hard ?? 0,
                      label: "المستوى الثالث",
                    },
                  ].map((lvl) => {
                    const pct = levelStats.totalChildren > 0
                      ? Math.round((lvl.completed / levelStats.totalChildren) * 100) : 0;
                    return (
                      <div key={lvl.level} className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                        <div className="flex items-center gap-3 mb-4">
                          <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${lvl.color} flex items-center justify-center text-2xl shadow`}>
                            {lvl.emoji}
                          </div>
                          <div>
                            <h3 className="font-bold text-foreground">{lvl.label} - {lvl.level}</h3>
                            <p className="text-xs text-muted-foreground">{lvl.stories} قصة في هذا المستوى</p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">أكملوا المستوى كاملاً</span>
                            <span className="font-bold text-foreground">{lvl.completed} / {levelStats.totalChildren}</span>
                          </div>
                          <div className="h-3 bg-muted rounded-full overflow-hidden">
                            <div
                              className={`h-full bg-gradient-to-r ${lvl.color} rounded-full transition-all duration-700`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <p className="text-xs text-muted-foreground text-left">{pct}% من المتعلمين</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* مسار الانتقال البصري */}
                <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                  <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
                    <span>🔄</span> مسار انتقال المتعلمين بين المستويات
                  </h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    {[
                      { label: `الكل (${levelStats.totalChildren})`, color: "bg-gray-200 text-gray-700" },
                      { label: "→", color: "" },
                      { label: `أكمل مبتدئ (${levelStats.completedEasy})`, color: "bg-green-100 text-green-700" },
                      { label: "→", color: "" },
                      { label: `أكمل متوسط (${levelStats.completedMedium})`, color: "bg-yellow-100 text-yellow-700" },
                      { label: "→", color: "" },
                      { label: `أكمل متقدم (${levelStats.completedHard})`, color: "bg-red-100 text-red-700" },
                    ].map((item, i) => (
                      item.label === "→"
                        ? <span key={i} className="text-2xl text-muted-foreground font-bold">→</span>
                        : <span key={i} className={`px-3 py-1.5 rounded-full text-sm font-bold ${item.color}`}>{item.label}</span>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    معدل الانتقال من المبتدئ إلى المتوسط:{" "}
                    <strong>{levelStats.totalChildren > 0 ? Math.round((levelStats.completedEasy / levelStats.totalChildren) * 100) : 0}%</strong>
                    {" · "}معدل الانتقال من المتوسط إلى المتقدم:{" "}
                    <strong>{levelStats.completedEasy > 0 ? Math.round((levelStats.completedMedium / levelStats.completedEasy) * 100) : 0}%</strong>
                  </p>
                </div>

                {/* جدول أكثر المتعلمين تقدماً */}
                <div className="bg-white/80 rounded-3xl p-5 border border-border/50 shadow-sm">
                  <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
                    <span>🏅</span> أكثر المتعلمين تقدماً
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border/50">
                          <th className="text-right py-2 px-3 text-muted-foreground font-medium">المتعلم</th>
                          <th className="text-center py-2 px-3 text-green-600 font-medium">🟢 مبتدئ</th>
                          <th className="text-center py-2 px-3 text-yellow-600 font-medium">🟡 متوسط</th>
                          <th className="text-center py-2 px-3 text-red-600 font-medium">🔴 متقدم</th>
                          <th className="text-center py-2 px-3 text-primary font-medium">الإجمالي</th>
                          <th className="text-center py-2 px-3 text-muted-foreground font-medium">النقاط</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(levelStats.topProgressChildren as any[] || []).map((child: any, i: number) => (
                          <tr key={i} className="border-b border-border/20 hover:bg-muted/30 transition-colors">
                            <td className="py-2 px-3 font-medium text-foreground">
                              <span className="inline-flex items-center gap-1">
                                {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`}
                                {child.name}
                              </span>
                            </td>
                            <td className="text-center py-2 px-3">
                              <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full text-xs font-bold">{child.easyDone}</span>
                            </td>
                            <td className="text-center py-2 px-3">
                              <span className="bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full text-xs font-bold">{child.mediumDone}</span>
                            </td>
                            <td className="text-center py-2 px-3">
                              <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-full text-xs font-bold">{child.hardDone}</span>
                            </td>
                            <td className="text-center py-2 px-3">
                              <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full text-xs font-bold">{child.totalDone}</span>
                            </td>
                            <td className="text-center py-2 px-3 text-muted-foreground text-xs">{child.totalPoints}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
        {/* Games Tab */}
        {activeTab === "games" && (
          <GamesManagementTab />
        )}
        {/* Challenges Tab */}
        {activeTab === "challenges" && (
          <ChallengesAdminTab />
        )}
        {/* Shop Tab */}
        {activeTab === "shop" && (
          <ShopAdminTab />
        )}
        {/* Adventures Tab */}
        {activeTab === "adventures" && (
          <AdventuresAdminTab />
        )}
        {/* Interactive Lab Tab */}
        {activeTab === "interactive" && (
          <InteractiveLabAdminTab />
        )}
        {/* Comprehensive Stats Tab */}
        {activeTab === "stats" && (
          <ComprehensiveStatsTab />
        )}
        {/* Recordings Tab */}
        {activeTab === "characters" && (
          <CharactersAdminTab />
        )}

        {activeTab === "admins" && (
          <AdminsManagementTab currentAdminEmail={localAdminSession?.email || user?.email || ""} />
        )}
        {activeTab === "school_registrations" && (
          <SchoolRegistrationsTab />
        )}
        {activeTab === "schools" && (
          <SchoolsManagementTab />
        )}
        {activeTab === "compare_schools" && (
          <SchoolsComparisonTab />
        )}
        {activeTab === "weekly_reports" && (
          <div className="p-4 md:p-6">
            <WeeklyReportPreview />
          </div>
        )}
        {activeTab === "users_management" && (
          <div className="p-4 md:p-6">
            <UsersManagementTab />
          </div>
        )}
        {activeTab === "user_growth" && (
          <div className="p-4 md:p-6">
            <UserGrowthCharts />
          </div>
        )}
        {activeTab === "email_subscribers" && (
          <EmailSubscribersTab />
        )}
        {activeTab === "recordings" && (
          <RecordingsSection
            allRecordings={allRecordings as any[]}
            ratingInputs={ratingInputs}
            setRatingInputs={setRatingInputs}
            rateRecordingMutation={rateRecordingMutation}
            approveRecordingMutation={approveRecordingMutation}
            deleteRecordingMutation={deleteRecordingMutation}
            addReactionMutation={addReactionMutation}
            deleteReactionMutation={deleteReactionMutation}
          />
        )}
        {false && (activeTab as string) === "recordings_old" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-xl">🎤</span>
              <h2 className="text-lg font-bold text-foreground">إدارة التسجيلات الصوتية</h2>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">{allRecordings.length} تسجيل</span>
            </div>
            {/* فلتر التسجيلات */}
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => { setRecFilter('all'); setSelectedChildForRec(null); }} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${recFilter === 'all' ? 'bg-purple-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>الكل</button>
              <button onClick={() => { setRecFilter('unrated'); setSelectedChildForRec(null); }} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${recFilter === 'unrated' ? 'bg-amber-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>غير مقيّم ⭐</button>
              {/* فلتر حسب الطفل */}
              {Array.from(new Set((allRecordings as any[]).map((r: any) => r.childId))).map((cid: any) => (
                <button key={cid} onClick={() => { setRecFilter(String(cid)); setSelectedChildForRec(cid); }} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${recFilter === String(cid) ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>طفل #{cid}</button>
              ))}
            </div>
            {/* عرض تسجيلات طفل محدد */}
            {selectedChildForRec !== null && (
              <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-lg">👶</span>
                  <h3 className="font-bold text-blue-800">تسجيلات الطفل #{selectedChildForRec}</h3>
                  <span className="text-xs bg-blue-200 text-blue-700 px-2 py-0.5 rounded-full">{(childRecordings as any[]).length} تسجيل</span>
                </div>
                {(childRecordings as any[]).length === 0 ? (
                  <p className="text-sm text-blue-600">لا توجد تسجيلات</p>
                ) : (
                  <div className="space-y-2">
                    {(childRecordings as any[]).map((rec: any) => (
                      <div key={rec.id} className="bg-white rounded-xl p-3 shadow-sm">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-base">🎤</span>
                          <div className="flex-1 min-w-0">
                            <p className="font-bold text-xs truncate">{rec.title}</p>
                            {rec.storyTitle && <p className="text-xs text-blue-600">📖 {rec.storyTitle} - صفحة {rec.pageNumber ?? '-'}</p>}
                            <p className="text-xs text-gray-400">{new Date(rec.createdAt).toLocaleDateString('ar-SA')}</p>
                          </div>
                          <button onClick={() => { const a = new Audio(rec.audioUrl); a.play().catch(() => window.open(rec.audioUrl, '_blank')); }} className="px-2 py-1 bg-purple-100 text-purple-600 rounded-lg text-xs font-bold hover:bg-purple-200">▶️ تشغيل</button>
                        </div>
                        <div className="flex items-center gap-1 mb-1">
                          {[1,2,3,4,5].map(star => (
                            <button key={star} onClick={() => setRatingInputs(prev => ({ ...prev, [`c_${rec.id}`]: { ...prev[`c_${rec.id}`], rating: star, comment: prev[`c_${rec.id}`]?.comment ?? '' } }))} className={`text-lg transition-transform hover:scale-110 ${(ratingInputs[`c_${rec.id}`]?.rating ?? rec.rating ?? 0) >= star ? 'text-amber-400' : 'text-gray-200'}`}>★</button>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <input type="text" placeholder="تعليق تشجيعي" value={ratingInputs[`c_${rec.id}`]?.comment ?? rec.ratingComment ?? ''} onChange={e => setRatingInputs(prev => ({ ...prev, [`c_${rec.id}`]: { ...prev[`c_${rec.id}`], rating: prev[`c_${rec.id}`]?.rating ?? rec.rating ?? 0, comment: e.target.value } }))} className="flex-1 text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:border-blue-400" />
                          <button onClick={() => { const r = ratingInputs[`c_${rec.id}`]; if (!r?.rating) { toast.error('اختر عدد النجوم'); return; } rateRecordingMutation.mutate({ id: rec.id, rating: r.rating, ratingComment: r.comment }, { onSuccess: () => refetchChildRec() }); }} className="px-2 py-1 bg-amber-500 text-white rounded-lg text-xs font-bold">حفظ ⭐</button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            {allRecordings.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-3">🎤</div>
                <p className="text-muted-foreground">لا توجد تسجيلات بعد</p>
              </div>
            ) : (
              <div className="space-y-3">
                {(allRecordings as any[]).filter((rec: any) => {
                  if (recFilter === 'unrated') return !rec.rating;
                  if (recFilter !== 'all' && recFilter !== 'unrated') return rec.childId === Number(recFilter);
                  return true;
                }).map((rec) => (
                  <div key={rec.id} className="bg-white rounded-2xl p-4 shadow-sm border border-border">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-xl flex-shrink-0">🎤</div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-sm truncate">{rec.title}</p>
                        <p className="text-xs text-muted-foreground">طفل #{rec.childId} • {new Date(rec.createdAt).toLocaleDateString('ar-SA')}</p>
                        {rec.durationSeconds > 0 && <p className="text-xs text-muted-foreground">المدة: {Math.floor(rec.durationSeconds/60)}:{String(rec.durationSeconds%60).padStart(2,'0')}</p>}
                        {rec.rating && <p className="text-xs text-amber-600 font-bold">{'⭐'.repeat(rec.rating)} تقييم محفوظ</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => { const a = new Audio(rec.audioUrl); a.play().catch(() => window.open(rec.audioUrl, '_blank')); }} className="p-2 bg-purple-100 text-purple-600 rounded-lg hover:bg-purple-200 text-xs font-bold">▶️ تشغيل</button>
                        {!rec.isApproved && (
                          <button onClick={() => approveRecordingMutation.mutate({ id: rec.id })} className="p-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 text-xs font-bold">اعتماد</button>
                        )}
                        {rec.isApproved && <span className="text-xs text-green-600 font-bold">✓ معتمد</span>}
                        <button onClick={() => deleteRecordingMutation.mutate({ id: rec.id })} className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                    {/* قسم التقييم */}
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <p className="text-xs font-bold text-gray-600 mb-2">تقييم التسجيل:</p>
                      <div className="flex items-center gap-1 mb-2">
                        {[1,2,3,4,5].map(star => (
                          <button
                            key={star}
                            onClick={() => setRatingInputs(prev => ({ ...prev, [rec.id]: { ...prev[rec.id], rating: star, comment: prev[rec.id]?.comment ?? '' } }))}
                            className={`text-xl transition-transform hover:scale-110 ${ (ratingInputs[rec.id]?.rating ?? rec.rating ?? 0) >= star ? 'text-amber-400' : 'text-gray-200' }`}
                          >★</button>
                        ))}
                        {(ratingInputs[rec.id]?.rating ?? rec.rating) && (
                          <span className="text-xs text-amber-600 font-bold mr-2">{ratingInputs[rec.id]?.rating ?? rec.rating} / 5</span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="تعليق تشجيعي للطفل (اختياري)"
                          value={ratingInputs[rec.id]?.comment ?? rec.ratingComment ?? ''}
                          onChange={e => setRatingInputs(prev => ({ ...prev, [rec.id]: { ...prev[rec.id], rating: prev[rec.id]?.rating ?? rec.rating ?? 0, comment: e.target.value } }))}
                          className="flex-1 text-xs border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-purple-400"
                        />
                        <button
                          onClick={() => {
                            const r = ratingInputs[rec.id];
                            if (!r?.rating) { toast.error('اختر عدد النجوم أولاً'); return; }
                            rateRecordingMutation.mutate({ id: rec.id, rating: r.rating, ratingComment: r.comment });
                          }}
                          className="px-3 py-1.5 bg-amber-500 text-white rounded-lg text-xs font-bold hover:bg-amber-600"
                        >حفظ ⭐</button>
                      </div>
                    </div>
                    {/* قسم ردود الفعل التعبيرية */}
                    <div className="mt-2 pt-2 border-t border-gray-100">
                      <p className="text-xs font-bold text-gray-600 mb-2">ردود الفعل التعبيرية:</p>
                      {/* عرض الردود المرسلة */}
                      {(rec as any).reactions?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-2">
                          {(rec as any).reactions.map((rx: any) => (
                            <span key={rx.id} className="inline-flex items-center gap-1 bg-yellow-50 border border-yellow-200 rounded-full px-2 py-0.5 text-xs">
                              <span className="text-base">{rx.emoji}</span>
                              <span className="text-yellow-700 font-medium">{rx.label}</span>
                              <button onClick={() => deleteReactionMutation.mutate({ reactionId: rx.id })} className="text-red-400 hover:text-red-600 ml-0.5 text-xs">×</button>
                            </span>
                          ))}
                        </div>
                      )}
                      {/* أزرار الردود السريعة */}
                      <div className="flex flex-wrap gap-1">
                        {[
                          { emoji: '🌟', label: 'أحسنت' },
                          { emoji: '👏', label: 'رائع' },
                          { emoji: '❤️', label: 'ممتاز' },
                          { emoji: '😊', label: 'جميل' },
                          { emoji: '🎉', label: 'برافو' },
                          { emoji: '👑', label: 'ملك القراءة' },
                          { emoji: '🔥', label: 'رائع جداً' },
                          { emoji: '💫', label: 'نجم متألق' },
                        ].map(({ emoji, label }) => (
                          <button
                            key={emoji}
                            onClick={() => addReactionMutation.mutate({ recordingId: rec.id, emoji, label })}
                            className="flex items-center gap-0.5 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-full px-2 py-0.5 text-xs transition-all hover:scale-105 active:scale-95"
                            title={label}
                          >
                            <span className="text-base">{emoji}</span>
                            <span className="text-purple-700 font-medium">{label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
      {/* Footer */}
      <footer className="py-3 px-4 text-center border-t border-border/30 bg-white/50">
        <p className="text-xs text-muted-foreground">
          <span className="font-semibold">جميع الحقوق محفوظة ©</span>{" · "}
          <span className="font-bold text-primary">تصميم وتنفيذ: زمرده عبد العزيز السماعيل</span>
          {" · "}<span>معلمة رياض أطفال · ماجستير تربية الطفولة المبكرة</span>
        </p>
      </footer>
    </div>
  );
}

// ─── // ─── Admins Management Tab ──────────────────────────────────────────────
function AdminsManagementTab({ currentAdminEmail }: { currentAdminEmail: string }) {
  const [showAddAdmin, setShowAddAdmin] = useState(false);
  const [adminForm, setAdminForm] = useState({ email: "", name: "", password: "" });
  const { data: admins = [], refetch } = trpc.admin.listAdmins.useQuery();
  const addAdminMut = trpc.admin.addAdmin.useMutation({
    onSuccess: () => { toast.success("تمت إضافة المدير بنجاح ✅"); refetch(); setShowAddAdmin(false); setAdminForm({ email: "", name: "", password: "" }); },
    onError: (e) => toast.error(e.message || "حدث خطأ"),
  });
  const removeAdminMut = trpc.admin.removeAdmin.useMutation({
    onSuccess: () => { toast.success("تم حذف المدير"); refetch(); },
    onError: (e) => toast.error(e.message || "حدث خطأ"),
  });
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">👥</span>
          <h2 className="text-xl font-bold text-foreground">إدارة المديرين</h2>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">{admins.length} مدير</span>
        </div>
        <Button onClick={() => setShowAddAdmin(v => !v)} className="rounded-2xl gap-2">
          <Plus className="h-4 w-4" />
          إضافة مدير جديد
        </Button>
      </div>

      {showAddAdmin && (
        <div className="bg-blue-50 rounded-2xl p-5 border border-blue-200 space-y-4">
          <h3 className="font-bold text-blue-800">إضافة مدير جديد</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <Label>الاسم الكامل</Label>
              <Input value={adminForm.name} onChange={e => setAdminForm(f => ({ ...f, name: e.target.value }))} placeholder="اسم المدير" />
            </div>
            <div>
              <Label>البريد الإلكتروني</Label>
              <Input type="email" value={adminForm.email} onChange={e => setAdminForm(f => ({ ...f, email: e.target.value }))} placeholder="email@example.com" dir="ltr" />
            </div>
            <div>
              <Label>كلمة المرور</Label>
              <Input type="password" value={adminForm.password} onChange={e => setAdminForm(f => ({ ...f, password: e.target.value }))} placeholder="كلمة مرور قوية" />
            </div>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => addAdminMut.mutate({ email: adminForm.email, name: adminForm.name, password: adminForm.password, addedBy: currentAdminEmail })} disabled={addAdminMut.isPending || !adminForm.email || !adminForm.name || !adminForm.password} className="rounded-2xl">
              {addAdminMut.isPending ? "جاري الإضافة..." : "حفظ المدير"}
            </Button>
            <Button variant="outline" onClick={() => setShowAddAdmin(false)} className="rounded-2xl">إلغاء</Button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {(admins as any[]).map((admin: any) => (
          <div key={admin.id} className="bg-white rounded-2xl border p-4 flex items-center justify-between hover:shadow-sm transition-shadow">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-lg">
                {admin.email === currentAdminEmail ? "👑" : "👤"}
              </div>
              <div>
                <p className="font-bold text-gray-800">{admin.name}</p>
                <p className="text-sm text-gray-500 dir-ltr">{admin.email}</p>
                <p className="text-xs text-gray-400">أضيفه: {admin.addedBy ?? "النظام"} • {new Date(admin.createdAt).toLocaleDateString("ar-SA")}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {admin.email === currentAdminEmail ? (
                <span className="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-bold">أنت</span>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-500 border-red-200 hover:bg-red-50 rounded-xl"
                  onClick={() => { if (confirm(`حذف ${admin.name} من المديرين؟`)) removeAdminMut.mutate({ id: admin.id }); }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        ))}
        {admins.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <div className="text-5xl mb-3">👤</div>
            <p>لا يوجد مديرون بعد</p>
          </div>
        )}
      </div>
    </div>
  );
}
// ─── Schools Management Tab ────────────────────────────────────────────────
// ─── Schools Comparison Tab ────────────────────────────────────────────────
function SchoolsComparisonTab() {
  const { data: allStats = [], isLoading } = trpc.schools.getAllStats.useQuery();
  const sendAllReportsMut = trpc.schools.sendAllWeeklyReports.useMutation({
    onSuccess: (data: any) => toast.success(`تم إرسال ${data.sent} تقرير من أصل ${data.total}`),
    onError: (e: any) => toast.error(e.message || "حدث خطأ"),
  });

  if (isLoading) return <div className="text-center py-10 text-muted-foreground">جارٍ تحميل البيانات...</div>;

  if (!allStats.length) return (
    <div className="text-center py-16" dir="rtl">
      <div className="text-6xl mb-4">🏫</div>
      <p className="text-muted-foreground">لا توجد مدارس مضافة بعد</p>
    </div>
  );

  // Sort by totalChildren descending
  const sorted = [...allStats].sort((a: any, b: any) => (b.stats?.totalChildren ?? 0) - (a.stats?.totalChildren ?? 0));
  const maxStudents = Math.max(...sorted.map((s: any) => s.stats?.totalChildren ?? 0), 1);
  const maxPoints = Math.max(...sorted.map((s: any) => s.stats?.avgPoints ?? 0), 1);

  const colors = [
    "bg-indigo-500", "bg-purple-500", "bg-pink-500", "bg-blue-500",
    "bg-green-500", "bg-yellow-500", "bg-orange-500", "bg-red-500",
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-3xl">📊</span>
          <div>
            <h2 className="text-xl font-bold text-foreground">مقارنة أداء المدارس</h2>
            <p className="text-sm text-muted-foreground">مقارنة شاملة بين جميع المدارس المسجلة</p>
          </div>
        </div>
        <Button onClick={() => { if (confirm("إرسال تقرير أسبوعي لجميع المدارس?")) sendAllReportsMut.mutate(); }} disabled={sendAllReportsMut.isPending} className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
          📧 إرسال للجميع
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm border">
          <div className="text-3xl font-bold text-indigo-600">{sorted.length}</div>
          <div className="text-sm text-muted-foreground">عدد المدارس</div>
        </div>
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm border">
          <div className="text-3xl font-bold text-green-600">{sorted.reduce((s: number, x: any) => s + (x.stats?.totalChildren ?? 0), 0)}</div>
          <div className="text-sm text-muted-foreground">إجمالي الطلاب</div>
        </div>
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm border">
          <div className="text-3xl font-bold text-yellow-600">
            {sorted.length ? Math.round(sorted.reduce((s: number, x: any) => s + (x.stats?.avgPoints ?? 0), 0) / sorted.length) : 0}
          </div>
          <div className="text-sm text-muted-foreground">متوسط النقاط</div>
        </div>
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm border">
          <div className="text-3xl font-bold text-purple-600">
            {sorted.length ? (sorted[0] as any).school?.name?.slice(0, 10) : "-"}
          </div>
          <div className="text-sm text-muted-foreground">الأعلى طلاباً</div>
        </div>
      </div>

      {/* Bar Chart - Students */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border">
        <h3 className="font-bold text-gray-700 mb-4">👥 عدد الطلاب لكل مدرسة</h3>
        <div className="space-y-3">
          {sorted.map((item: any, i: number) => {
            const count = item.stats?.totalChildren ?? 0;
            const pct = maxStudents > 0 ? Math.round((count / maxStudents) * 100) : 0;
            return (
              <div key={item.school.id} className="flex items-center gap-3">
                <div className="w-32 text-sm font-medium text-gray-700 truncate text-right">{item.school.name}</div>
                <div className="flex-1 bg-gray-100 rounded-full h-7 overflow-hidden">
                  <div
                    className={`h-full rounded-full flex items-center justify-end pr-3 text-white text-xs font-bold transition-all duration-500 ${colors[i % colors.length]}`}
                    style={{ width: `${Math.max(pct, 8)}%` }}
                  >
                    {count}
                  </div>
                </div>
                <div className="w-16 text-sm text-muted-foreground text-left">{count} طالب</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bar Chart - Avg Points */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border">
        <h3 className="font-bold text-gray-700 mb-4">⭐ متوسط نقاط كل مدرسة</h3>
        <div className="space-y-3">
          {sorted.map((item: any, i: number) => {
            const avg = item.stats?.avgPoints ?? 0;
            const pct = maxPoints > 0 ? Math.round((avg / maxPoints) * 100) : 0;
            return (
              <div key={item.school.id} className="flex items-center gap-3">
                <div className="w-32 text-sm font-medium text-gray-700 truncate text-right">{item.school.name}</div>
                <div className="flex-1 bg-gray-100 rounded-full h-7 overflow-hidden">
                  <div
                    className={`h-full rounded-full flex items-center justify-end pr-3 text-white text-xs font-bold transition-all duration-500 ${colors[(i + 3) % colors.length]}`}
                    style={{ width: `${Math.max(pct, 8)}%` }}
                  >
                    {avg}
                  </div>
                </div>
                <div className="w-20 text-sm text-muted-foreground text-left">{avg} نقطة</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Detailed Table */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border overflow-x-auto">
        <h3 className="font-bold text-gray-700 mb-4">📋 جدول تفصيلي</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-indigo-50">
              <th className="text-right py-3 px-4 font-bold text-indigo-700">المدرسة</th>
              <th className="text-center py-3 px-4 font-bold text-indigo-700">الطلاب</th>
              <th className="text-center py-3 px-4 font-bold text-indigo-700">متوسط النقاط</th>
              <th className="text-center py-3 px-4 font-bold text-indigo-700">البريد</th>
              <th className="text-center py-3 px-4 font-bold text-indigo-700">الترتيب</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((item: any, i: number) => (
              <tr key={item.school.id} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                <td className="py-3 px-4 font-medium text-gray-800">{item.school.name}</td>
                <td className="py-3 px-4 text-center text-green-700 font-bold">{item.stats?.totalChildren ?? 0}</td>
                <td className="py-3 px-4 text-center text-yellow-700 font-bold">{item.stats?.avgPoints ?? 0}</td>
                <td className="py-3 px-4 text-center text-gray-500 text-xs">{item.school.email}</td>
                <td className="py-3 px-4 text-center">
                  <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-white text-xs font-bold ${colors[i % colors.length]}`}>
                    {i + 1}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Schools Management Tab ────────────────────────────────────────────────
function SchoolsManagementTab() {
  const [showAddSchool, setShowAddSchool] = useState(false);
  const [schoolForm, setSchoolForm] = useState({ name: "", email: "", adminEmail: "", adminName: "", adminPassword: "" });
  const [selectedSchoolId, setSelectedSchoolId] = useState<number | null>(null);
  const [classroomName, setClassroomName] = useState("");
  const [showSchoolStats, setShowSchoolStats] = useState<number | null>(null);

  const { data: schools = [], refetch: refetchSchools } = trpc.schools.list.useQuery();
  const addSchoolMut = trpc.schools.create.useMutation({
    onSuccess: () => { toast.success("تمت إضافة المدرسة ✅"); refetchSchools(); setShowAddSchool(false); setSchoolForm({ name: "", email: "", adminEmail: "", adminName: "", adminPassword: "" }); },
    onError: (e: any) => toast.error(e.message || "حدث خطأ"),
  });
  const deleteSchoolMut = trpc.schools.delete.useMutation({
    onSuccess: () => { toast.success("تم حذف المدرسة"); refetchSchools(); },
    onError: (e: any) => toast.error(e.message || "حدث خطأ"),
  });
  const sendReportMut = trpc.schools.sendWeeklyReport.useMutation({
    onSuccess: (data: any) => toast.success(data.message || "تم إرسال التقرير"),
    onError: (e: any) => toast.error(e.message || "حدث خطأ في الإرسال"),
  });
  const addClassroomMut = trpc.schools.addClassroom.useMutation({
    onSuccess: () => { toast.success("تمت إضافة الفصل ✅"); setClassroomName(""); },
    onError: (e) => toast.error(e.message || "حدث خطأ"),
  });
  const { data: classrooms = [], refetch: refetchClassrooms } = trpc.schools.getClassrooms.useQuery(
    { schoolId: selectedSchoolId! },
    { enabled: !!selectedSchoolId }
  );
  const { data: schoolStats } = trpc.schools.getStats.useQuery(
    { schoolId: showSchoolStats! },
    { enabled: !!showSchoolStats }
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">🏫 إدارة المدارس</h2>
          <p className="text-sm text-muted-foreground">إضافة مدارس جديدة وإدارة فصولها ومديريها</p>
        </div>
        <Button onClick={() => setShowAddSchool(true)} className="gap-2">
          <Plus className="w-4 h-4" /> إضافة مدرسة
        </Button>
      </div>

      {showAddSchool && (
        <div className="bg-white rounded-2xl p-5 border shadow-sm">
          <h3 className="font-bold text-foreground mb-4">إضافة مدرسة جديدة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs font-bold mb-1 block">اسم المدرسة</Label>
              <Input value={schoolForm.name} onChange={e => setSchoolForm(p => ({...p, name: e.target.value}))} placeholder="روضة العلوم المريحة" className="h-9 rounded-xl" />
            </div>
            <div>
              <Label className="text-xs font-bold mb-1 block">إيميل مدير المدرسة</Label>
              <Input value={schoolForm.email} onChange={e => setSchoolForm(p => ({...p, email: e.target.value}))} placeholder="school@example.com" dir="ltr" className="h-9 rounded-xl" />
            </div>
            <div>
              <Label className="text-xs font-bold mb-1 block">إيميل حساب المدير (لتسجيل الدخول)</Label>
              <Input value={schoolForm.adminEmail} onChange={e => setSchoolForm(p => ({...p, adminEmail: e.target.value}))} placeholder="admin@school.com" dir="ltr" className="h-9 rounded-xl" />
            </div>
            <div>
              <Label className="text-xs font-bold mb-1 block">اسم المدير</Label>
              <Input value={schoolForm.adminName} onChange={e => setSchoolForm(p => ({...p, adminName: e.target.value}))} placeholder="اسم مدير المدرسة" className="h-9 rounded-xl" />
            </div>
            <div>
              <Label className="text-xs font-bold mb-1 block">كلمة مرور المدير</Label>
              <Input type="password" value={schoolForm.adminPassword} onChange={e => setSchoolForm(p => ({...p, adminPassword: e.target.value}))} placeholder="كلمة المرور" className="h-9 rounded-xl" />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <Button onClick={() => addSchoolMut.mutate({ name: schoolForm.name, email: schoolForm.email, adminEmail: schoolForm.adminEmail, adminName: schoolForm.adminName, adminPassword: schoolForm.adminPassword })} disabled={addSchoolMut.isPending} className="gap-2">
              {addSchoolMut.isPending ? "جارٍ..." : "حفظ المدرسة"}
            </Button>
            <Button variant="outline" onClick={() => setShowAddSchool(false)}>إلغاء</Button>
          </div>
        </div>
      )}

      {schools.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <div className="text-5xl mb-3">🏫</div>
          <p>لا توجد مدارس مضافة بعد</p>
        </div>
      ) : (
        <div className="space-y-4">
          {(schools as any[]).map((school) => (
            <div key={school.id} className="bg-white rounded-2xl p-5 border shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-foreground text-lg">{school.name}</h3>
                  <p className="text-sm text-muted-foreground">{school.email}</p>
                  <p className="text-xs text-muted-foreground mt-1">مدير: {school.adminName ?? "غير محدد"}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => { setSelectedSchoolId(school.id === selectedSchoolId ? null : school.id); }} className="gap-1 text-xs">
                    🎓 فصول
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setShowSchoolStats(school.id === showSchoolStats ? null : school.id)} className="gap-1 text-xs">
                    📊 إحصائيات
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => sendReportMut.mutate({ schoolId: school.id })} disabled={sendReportMut.isPending} className="gap-1 text-xs text-blue-600 border-blue-200">
                    📊 تقرير أسبوعي
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => { if (confirm(`حذف مدرسة "${school.name}"?`)) deleteSchoolMut.mutate({ id: school.id }); }} className="gap-1 text-xs text-red-600 border-red-200">
                    <Trash2 className="w-3 h-3" /> حذف
                  </Button>
                </div>
              </div>

              {selectedSchoolId === school.id && (
                <div className="mt-4 border-t pt-4">
                  <h4 className="font-bold text-sm mb-3">فصول {school.name}</h4>
                  <div className="flex gap-2 mb-3">
                    <Input value={classroomName} onChange={e => setClassroomName(e.target.value)} placeholder="فصل 1" className="h-9 rounded-xl flex-1" />
                    <Button size="sm" onClick={() => { if (classroomName.trim()) addClassroomMut.mutate({ schoolId: school.id, name: classroomName.trim() }); }} disabled={addClassroomMut.isPending}>
                      إضافة
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(classrooms as any[]).filter(c => c.schoolId === school.id).map((cls) => (
                      <span key={cls.id} className="bg-indigo-100 text-indigo-800 text-xs font-bold px-3 py-1 rounded-full">{cls.name}</span>
                    ))}
                    {(classrooms as any[]).filter(c => c.schoolId === school.id).length === 0 && (
                      <p className="text-xs text-muted-foreground">لا توجد فصول بعد - أضف فصلاً أعلاه</p>
                    )}
                  </div>
                </div>
              )}

              {showSchoolStats === school.id && schoolStats && (
                <div className="mt-4 border-t pt-4">
                  <h4 className="font-bold text-sm mb-3">إحصائيات {school.name}</h4>
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="bg-indigo-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-indigo-700">{(schoolStats as any).totalStudents ?? 0}</div>
                      <div className="text-xs text-indigo-500">طالب</div>
                    </div>
                    <div className="bg-green-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-green-700">{(schoolStats as any).totalPoints ?? 0}</div>
                      <div className="text-xs text-green-500">نقطة</div>
                    </div>
                    <div className="bg-yellow-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-yellow-700">{(schoolStats as any).avgPoints ?? 0}</div>
                      <div className="text-xs text-yellow-500">متوسط</div>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="text-right py-2 px-3">الطالب</th>
                          <th className="text-right py-2 px-3">الفصل</th>
                          <th className="text-right py-2 px-3">النقاط</th>
                          <th className="text-right py-2 px-3">القصص</th>
                          <th className="text-right py-2 px-3">الألعاب</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(schoolStats as any).students?.map((s: any, i: number) => (
                          <tr key={s.id} className="border-b border-gray-100">
                            <td className="py-2 px-3 font-medium">{s.name}</td>
                            <td className="py-2 px-3 text-muted-foreground">{s.classroom ?? "-"}</td>
                            <td className="py-2 px-3 text-yellow-600 font-bold">{s.totalPoints ?? 0}</td>
                            <td className="py-2 px-3 text-green-600">{s.storiesRead ?? 0}</td>
                            <td className="py-2 px-3 text-indigo-600">{s.gamesPlayed ?? 0}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
// ─── Games Management Tab ────────────────────────────────────────────────
function GamesManagementTab() {
  const [showAddGame, setShowAddGame] = useState(false);
  const [editingGame, setEditingGame] = useState<any | null>(null);
  const [gameForm, setGameForm] = useState({
    title: "", description: "", type: "letter_match" as string,
    level: "easy" as string, ageGroup: "all" as string,
    emoji: "\ud83c\udfae", pointsReward: 20, gameData: "{}",
  });

  const { data: games, refetch } = trpc.admin.allGames.useQuery();
  const addGameMut = trpc.admin.createGame.useMutation({
    onSuccess: () => { toast.success("تم إضافة اللعبة بنجاح"); refetch(); setShowAddGame(false); resetForm(); },
    onError: (e: any) => toast.error(e.message),
  });
  const deleteGameMut = trpc.admin.deleteGame.useMutation({
    onSuccess: () => { toast.success("تم حذف اللعبة"); refetch(); },
    onError: (e: any) => toast.error(e.message),
  });
  const updateGameMut = trpc.admin.updateGame.useMutation({
    onSuccess: () => { toast.success("تم تحديث اللعبة ✅"); refetch(); setEditingGame(null); },
    onError: (e: any) => toast.error(e.message),
  });
  const uploadImageMut = trpc.games.uploadImage.useMutation({
    onError: (e: any) => toast.error('فشل رفع الصورة: ' + e.message),
  });

  const resetForm = () => setGameForm({
    title: "", description: "", type: "letter_match",
    level: "easy", ageGroup: "all", emoji: "\ud83c\udfae", pointsReward: 20, gameData: "{}",
  });

  const handleAddGame = () => {
    if (!gameForm.title.trim()) { toast.error("الرجاء إدخال عنوان اللعبة"); return; }
    let parsedData: any;
    try { parsedData = JSON.parse(gameForm.gameData); } catch { toast.error("بيانات اللعبة غير صالحة (JSON)"); return; }
    addGameMut.mutate({
      title: gameForm.title, description: gameForm.description,
      type: gameForm.type as any, level: gameForm.level as any,
      ageGroup: gameForm.ageGroup as any, emoji: gameForm.emoji,
      pointsReward: gameForm.pointsReward, gameData: parsedData,
    });
  };

  const gameTypes = [
    { value: "letter_match", label: "تطابق الحروف" },
    { value: "count_objects", label: "عد الأشكال" },
    { value: "image_match", label: "تطابق الصور" },
    { value: "classification", label: "تصنيف" },
    { value: "missing_letter", label: "الحرف الناقص" },
    { value: "word_build", label: "بناء الكلمة" },
    { value: "number_order", label: "ترتيب الأرقام" },
    { value: "memory_game", label: "لعبة الذاكرة" },
    { value: "math_addition", label: "جمع" },
    { value: "math_subtraction", label: "طرح" },
    { value: "letter_sound", label: "صوت الحرف" },
  ];

  const levelLabels: Record<string, string> = { easy: "مبتدئ", medium: "متوسط", hard: "متقدم" };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">🎮 إدارة الألعاب التعليمية</h2>
        <Button onClick={() => setShowAddGame(!showAddGame)} className="gap-2 rounded-2xl">
          <Plus className="w-4 h-4" /> إضافة لعبة
        </Button>
      </div>

      {showAddGame && (
        <div className="bg-white rounded-2xl border p-5 space-y-4 shadow-sm">
          <h3 className="font-bold text-gray-700">إضافة لعبة جديدة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>عنوان اللعبة</Label>
              <Input value={gameForm.title} onChange={e => setGameForm(f => ({ ...f, title: e.target.value }))} placeholder="عنوان اللعبة" />
            </div>
            <div>
              <Label>الوصف</Label>
              <Input value={gameForm.description} onChange={e => setGameForm(f => ({ ...f, description: e.target.value }))} placeholder="وصف مختصر" />
            </div>
            <div>
              <Label>نوع اللعبة</Label>
              <Select value={gameForm.type} onValueChange={v => setGameForm(f => ({ ...f, type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {gameTypes.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>المستوى</Label>
              <Select value={gameForm.level} onValueChange={v => setGameForm(f => ({ ...f, level: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">مبتدئ</SelectItem>
                  <SelectItem value="medium">متوسط</SelectItem>
                  <SelectItem value="hard">متقدم</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>الفئة العمرية</Label>
              <Select value={gameForm.ageGroup} onValueChange={v => setGameForm(f => ({ ...f, ageGroup: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="4-6">4-6 سنوات</SelectItem>
                  <SelectItem value="6-8">6-8 سنوات</SelectItem>
                  <SelectItem value="8-10">8-10 سنوات</SelectItem>
                  <SelectItem value="all">الكل</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>الرمز التعبيري</Label>
              <Input value={gameForm.emoji} onChange={e => setGameForm(f => ({ ...f, emoji: e.target.value }))} placeholder="🎮" />
            </div>
            <div>
              <Label>النقاط</Label>
              <Input type="number" value={gameForm.pointsReward} onChange={e => setGameForm(f => ({ ...f, pointsReward: parseInt(e.target.value) || 0 }))} />
            </div>
          </div>
          <div>
            <Label>بيانات اللعبة (JSON)</Label>
            <textarea
              className="w-full h-40 p-3 border rounded-xl text-sm font-mono resize-y bg-gray-50 focus:ring-2 focus:ring-primary/30 focus:border-primary"
              value={gameForm.gameData}
              onChange={e => setGameForm(f => ({ ...f, gameData: e.target.value }))}
              dir="ltr"
              placeholder='{"instructions": "تعليمات اللعبة", "rounds": [...]}'
            />
          </div>
          <div className="flex gap-3">
            <Button onClick={handleAddGame} disabled={addGameMut.isPending} className="rounded-2xl">
              {addGameMut.isPending ? "جاري الإضافة..." : "إضافة اللعبة"}
            </Button>
            <Button variant="outline" onClick={() => { setShowAddGame(false); resetForm(); }} className="rounded-2xl">إلغاء</Button>
          </div>
        </div>
      )}

      {/* Games List by Level */}
      {["easy", "medium", "hard"].map(level => {
        const levelGames = (games ?? []).filter((g: any) => g.level === level);
        if (levelGames.length === 0) return null;
        return (
          <div key={level} className="space-y-2">
            <h3 className="font-bold text-gray-700">
              {level === "easy" ? "🟢 مستوى المبتدئ" : level === "medium" ? "🟡 مستوى المتوسط" : "🔴 مستوى المتقدم"}
              <span className="text-sm font-normal text-gray-400 mr-2">({levelGames.length} لعبة)</span>
            </h3>
            <div className="grid gap-3">
              {levelGames.map((game: any) => (
                <div key={game.id} className="bg-white rounded-2xl border p-4 flex items-center justify-between hover:shadow-sm transition-shadow">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{game.emoji}</span>
                    <div>
                      <h4 className="font-bold text-gray-800">{game.title}</h4>
                      <p className="text-xs text-gray-500">{game.description}</p>
                      <div className="flex gap-2 mt-1">
                        <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">
                          {gameTypes.find(t => t.value === game.type)?.label ?? game.type}
                        </span>
                        <span className="text-xs bg-yellow-50 text-yellow-600 px-2 py-0.5 rounded-full">
                          {game.pointsReward} نقطة
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="rounded-xl gap-1 text-xs"
                      onClick={() => setEditingGame({ ...game })}
                    >
                      <Edit className="w-3 h-3" />
                      تعديل
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 rounded-xl px-2"
                      onClick={() => {
                        if (confirm("هل أنت متأكد من حذف هذه اللعبة؟")) {
                          deleteGameMut.mutate({ id: game.id });
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {(!games || games.length === 0) && (
        <div className="text-center py-10 text-gray-400">
          <Gamepad2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>لا توجد ألعاب بعد. أضف لعبة جديدة!</p>
        </div>
      )}

      {/* Edit Game Modal */}
      {editingGame && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg my-4 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-xl font-bold">تعديل اللعبة ✏️</h3>
              <Button variant="ghost" size="sm" onClick={() => setEditingGame(null)}><X className="h-4 w-4" /></Button>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="col-span-2">
                <Label>عنوان اللعبة</Label>
                <Input value={editingGame.title} onChange={e => setEditingGame({ ...editingGame, title: e.target.value })} className="rounded-xl border-2" />
              </div>
              <div className="col-span-2">
                <Label>الوصف</Label>
                <Input value={editingGame.description || ''} onChange={e => setEditingGame({ ...editingGame, description: e.target.value })} className="rounded-xl border-2" />
              </div>
              <div>
                <Label>المستوى</Label>
                <Select value={editingGame.level} onValueChange={v => setEditingGame({ ...editingGame, level: v })}>
                  <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">مبتدئ</SelectItem>
                    <SelectItem value="medium">متوسط</SelectItem>
                    <SelectItem value="hard">متقدم</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>النقاط</Label>
                <Input type="number" value={editingGame.pointsReward} onChange={e => setEditingGame({ ...editingGame, pointsReward: parseInt(e.target.value) || 0 })} className="rounded-xl border-2" />
              </div>
              <div>
                <Label>الرمز التعبيري</Label>
                <Input value={editingGame.emoji || ''} onChange={e => setEditingGame({ ...editingGame, emoji: e.target.value })} className="rounded-xl border-2" placeholder="🎮" />
              </div>
              <div className="col-span-2">
                <Label>صورة الغلاف (اختياري)</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    value={editingGame.coverImageUrl || ''}
                    onChange={e => setEditingGame({ ...editingGame, coverImageUrl: e.target.value })}
                    placeholder="رابط الصورة https://..."
                    className="rounded-xl border-2 flex-1"
                    dir="ltr"
                  />
                  <label className="cursor-pointer">
                    <span className="px-3 py-2 bg-blue-50 border-2 border-blue-200 rounded-xl text-sm font-semibold text-blue-700 hover:bg-blue-100 transition-colors whitespace-nowrap">
                      📷 رفع صورة
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        if (file.size > 5 * 1024 * 1024) { toast.error('الصورة أكبر من 5MB'); return; }
                        const reader = new FileReader();
                        reader.onload = async (ev) => {
                          const base64 = ev.target?.result as string;
                          toast.loading('جاري رفع الصورة...');
                          try {
                            // سيتم استخدام mutation لرفع الصورة
                            const result = await uploadImageMut.mutateAsync({ base64, filename: file.name, contentType: file.type });
                            setEditingGame((g: any) => ({ ...g, coverImageUrl: result.url }));
                            toast.dismiss();
                            toast.success('تم رفع الصورة بنجاح ✅');
                          } catch (err: any) {
                            toast.dismiss();
                            toast.error('فشل رفع الصورة: ' + (err.message ?? ''));
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>
                {editingGame.coverImageUrl && (
                  <div className="mt-2 relative inline-block">
                    <img src={editingGame.coverImageUrl} alt="غلاف" className="h-20 w-32 object-cover rounded-xl border-2 border-blue-200" />
                    <button
                      onClick={() => setEditingGame((g: any) => ({ ...g, coverImageUrl: '' }))}
                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center"
                    >×</button>
                  </div>
                )}
              </div>
              <div>
                <Label>الفئة العمرية</Label>
                <Select value={editingGame.ageGroup} onValueChange={v => setEditingGame({ ...editingGame, ageGroup: v })}>
                  <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4-6">4-6</SelectItem>
                    <SelectItem value="6-8">6-8</SelectItem>
                    <SelectItem value="8-10">8-10</SelectItem>
                    <SelectItem value="all">الكل</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {/* محرر الأسئلة المرئي */}
            <GameQuestionsEditor
              gameData={editingGame.gameData}
              gameType={editingGame.type}
              onChange={(newData) => setEditingGame({ ...editingGame, gameData: newData })}
            />
            <div className="flex gap-3">
              <Button
                onClick={() => {
                  let parsedData: any = {};
                  try {
                    parsedData = typeof editingGame.gameData === 'string' ? JSON.parse(editingGame.gameData) : editingGame.gameData;
                  } catch { toast.error('بيانات اللعبة غير صالحة (JSON)'); return; }
                  updateGameMut.mutate({ id: editingGame.id, title: editingGame.title, description: editingGame.description, level: editingGame.level, emoji: editingGame.emoji, pointsReward: editingGame.pointsReward, gameData: parsedData });
                }}
                disabled={updateGameMut.isPending}
                className="flex-1 rounded-2xl h-12 font-bold gap-2"
              >
                <Save className="h-4 w-4" />
                {updateGameMut.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
              </Button>
              <Button variant="outline" onClick={() => setEditingGame(null)} className="rounded-2xl h-12 border-2">إلغاء</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Game Questions Editor ──────────────────────────────────────────────
function GameQuestionsEditor({ gameData, gameType, onChange }: { gameData: any; gameType: string; onChange: (d: any) => void }) {
  const [showJsonEditor, setShowJsonEditor] = useState(false);
  const [jsonText, setJsonText] = useState("");

  const parsed = (() => {
    try { return typeof gameData === 'string' ? JSON.parse(gameData) : (gameData ?? {}); }
    catch { return {}; }
  })();

  // تحديد مفتاح المصفوفة: rounds أو questions
  const arrayKey = Array.isArray(parsed?.rounds) ? 'rounds' : Array.isArray(parsed?.questions) ? 'questions' : null;
  const items: any[] = arrayKey ? parsed[arrayKey] : [];

  const updateItems = (newItems: any[]) => {
    const newData = { ...parsed, [arrayKey ?? 'rounds']: newItems };
    onChange(newData);
  };

  const addItem = () => {
    const newItem = arrayKey === 'questions'
      ? { question: "", options: ["", "", "", ""], correct: 0, image: "" }
      : { question: "", options: ["", "", "", ""], correct: 0 };
    updateItems([...items, newItem]);
  };

  const removeItem = (idx: number) => {
    updateItems(items.filter((_, i) => i !== idx));
  };

  const updateItem = (idx: number, field: string, value: any) => {
    const updated = items.map((item, i) => i === idx ? { ...item, [field]: value } : item);
    updateItems(updated);
  };

  const updateOption = (itemIdx: number, optIdx: number, value: string) => {
    const updated = items.map((item, i) => {
      if (i !== itemIdx) return item;
      const opts = [...(item.options ?? [])];
      opts[optIdx] = value;
      return { ...item, options: opts };
    });
    updateItems(updated);
  };

  return (
    <div className="space-y-4 border-2 border-primary/20 rounded-2xl p-4 bg-primary/5">
      <div className="flex items-center justify-between">
        <h4 className="font-bold text-primary">❓ إدارة الأسئلة ({items.length} سؤال)</h4>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => { setJsonText(JSON.stringify(parsed, null, 2)); setShowJsonEditor(v => !v); }} className="rounded-xl text-xs">
            {showJsonEditor ? "إخفاء JSON" : "تحرير JSON"}
          </Button>
          <Button size="sm" onClick={addItem} className="rounded-xl gap-1 text-xs">
            <Plus className="h-3 w-3" />سؤال جديد
          </Button>
        </div>
      </div>

      {showJsonEditor && (
        <div className="space-y-2">
          <textarea
            className="w-full h-40 p-3 border-2 rounded-xl text-xs font-mono resize-y bg-white"
            dir="ltr"
            value={jsonText}
            onChange={e => setJsonText(e.target.value)}
          />
          <div className="flex gap-2">
            <Button size="sm" onClick={() => {
              try { const d = JSON.parse(jsonText); onChange(d); setShowJsonEditor(false); toast.success('تم تحديث بيانات اللعبة ✅'); }
              catch { toast.error('خطأ في JSON - تحقق من الصياغة'); }
            }} className="rounded-xl text-xs">تطبيق</Button>
            <Button size="sm" variant="outline" onClick={() => setShowJsonEditor(false)} className="rounded-xl text-xs">إلغاء</Button>
          </div>
        </div>
      )}

      {items.length === 0 && (
        <div className="text-center py-6 text-muted-foreground">
          <p className="text-sm">لا توجد أسئلة بعد. اضغط "سؤال جديد" للبدء.</p>
        </div>
      )}

      <div className="space-y-4 max-h-[500px] overflow-y-auto">
        {items.map((item: any, idx: number) => (
          <div key={idx} className="bg-white rounded-xl border p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full">سؤال {idx + 1}</span>
              <Button size="sm" variant="outline" className="text-red-500 border-red-200 h-7 w-7 p-0 rounded-lg" onClick={() => removeItem(idx)}>
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
            <div>
              <Label className="text-xs">نص السؤال</Label>
              <Input
                value={item.question ?? ""}
                onChange={e => updateItem(idx, 'question', e.target.value)}
                placeholder="اكتب السؤال هنا..."
                className="rounded-xl mt-1"
              />
            </div>
            {arrayKey === 'questions' && (
              <div>
                <Label className="text-xs">رابط الصورة (اختياري)</Label>
                <Input
                  value={item.image ?? ""}
                  onChange={e => updateItem(idx, 'image', e.target.value)}
                  placeholder="https://..."
                  className="rounded-xl mt-1"
                  dir="ltr"
                />
              </div>
            )}
            <div>
              <Label className="text-xs">الخيارات (4 خيارات)</Label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                {[0,1,2,3].map(optIdx => (
                  <div key={optIdx} className="flex items-center gap-1">
                    <button
                      onClick={() => updateItem(idx, 'correct', optIdx)}
                      className={`w-6 h-6 rounded-full border-2 flex-shrink-0 transition-all ${
                        item.correct === optIdx ? 'bg-green-500 border-green-500' : 'border-gray-300 hover:border-green-400'
                      }`}
                      title="اضغط لتحديد كإجابة صحيحة"
                    />
                    <Input
                      value={(item.options ?? [])[optIdx] ?? ""}
                      onChange={e => updateOption(idx, optIdx, e.target.value)}
                      placeholder={`خيار ${optIdx + 1}`}
                      className="rounded-lg h-8 text-xs"
                    />
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">الدائرة الخضراء = الإجابة الصحيحة</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
// ─── Challenges Admin Tab ─────────────────────────────────────────────────
function ChallengesAdminTab() {
  const { data: challenges = [], refetch, isLoading } = trpc.challenges.getAdminDetails.useQuery();

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">التحديات اليومية 🔥</h2>
          <p className="text-sm text-muted-foreground mt-1">تتغير تلقائياً كل يوم — لا يتم اختيار محتوى مغلق</p>
        </div>
        <button
          onClick={() => refetch()}
          className="px-4 py-2 bg-orange-500 text-white rounded-xl font-semibold text-sm hover:bg-orange-600 transition-colors"
        >
          تحديث
        </button>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="text-4xl animate-bounce">🔥</div>
        </div>
      )}

      {!isLoading && (challenges as any[]).length === 0 && (
        <div className="bg-white rounded-2xl shadow-md p-8 text-center text-gray-400">
          <p className="text-4xl mb-3">🔥</p>
          <p className="font-semibold">لا توجد تحديات لليوم بعد</p>
          <p className="text-sm mt-1">سيتم إنشاؤها تلقائياً عند أول زيارة لصفحة التحديات</p>
        </div>
      )}

      {(challenges as any[]).map((challenge: any) => {
        const levelNum = challenge.dateKey?.split('-L')[1] ?? '1';
        return (
          <div key={challenge.id} className="bg-white rounded-2xl shadow-md p-5 border border-orange-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center text-xl">🔥</div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base text-gray-800">تحدي اليوم</h3>
                  <span className="bg-orange-100 text-orange-700 text-xs font-bold px-2 py-0.5 rounded-full">مستوى {levelNum}</span>
                </div>
                <p className="text-xs text-gray-400">{challenge.dateKey}</p>
              </div>
              <div className="bg-orange-50 border border-orange-200 rounded-xl px-3 py-1.5 text-center">
                <p className="text-xl font-bold text-orange-600">{challenge.bonusPoints}</p>
                <p className="text-xs text-orange-500">نقطة</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className={`rounded-xl p-3 border ${challenge.storyLocked ? 'bg-red-50 border-red-200' : 'bg-purple-50 border-purple-100'}`}>
                <p className="text-xl mb-1">📖</p>
                <p className="text-xs font-bold text-purple-700">اقرأ قصة</p>
                {challenge.storyTitle ? (
                  <p className="text-xs mt-1 text-gray-700 font-medium leading-tight" title={challenge.storyTitle}>{challenge.storyTitle}</p>
                ) : (
                  <p className="text-xs mt-1 text-gray-400">أي قصة متاحة</p>
                )}
                {challenge.storyLocked && <p className="text-xs text-red-500 font-bold mt-1">⚠️ مغلقة!</p>}
              </div>
              <div className={`rounded-xl p-3 border ${challenge.gameLocked ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-100'}`}>
                <p className="text-xl mb-1">🎮</p>
                <p className="text-xs font-bold text-green-700">العب لعبة</p>
                {challenge.gameTitle ? (
                  <p className="text-xs mt-1 text-gray-700 font-medium leading-tight" title={challenge.gameTitle}>{challenge.gameTitle}</p>
                ) : (
                  <p className="text-xs mt-1 text-gray-400">أي لعبة متاحة</p>
                )}
                {challenge.gameLocked && <p className="text-xs text-red-500 font-bold mt-1">⚠️ مغلقة!</p>}
              </div>
              <div className={`rounded-xl p-3 border ${challenge.adventureLocked ? 'bg-red-50 border-red-200' : 'bg-indigo-50 border-indigo-100'}`}>
                <p className="text-xl mb-1">🗺️</p>
                <p className="text-xs font-bold text-indigo-700">أكمل مغامرة</p>
                {challenge.adventureTitle ? (
                  <p className="text-xs mt-1 text-gray-700 font-medium leading-tight" title={challenge.adventureTitle}>{challenge.adventureTitle}</p>
                ) : (
                  <p className="text-xs mt-1 text-gray-400">أي مغامرة متاحة</p>
                )}
                {challenge.adventureLocked && <p className="text-xs text-red-500 font-bold mt-1">⚠️ مغلقة!</p>}
              </div>
            </div>
          </div>
        );
      })}

      {/* Info Note */}
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
        <h4 className="font-bold text-blue-800 mb-2">ℹ️ كيف تعمل التحديات اليومية؟</h4>
        <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
          <li>يتم إنشاء تحدي جديد تلقائياً كل يوم لكل مستوى عند أول زيارة لصفحة التحديات</li>
          <li>المحتوى يتغير تلقائياً كل يوم بناءً على تاريخ اليوم ومستوى الطفل</li>
          <li>لا يتم اختيار محتوى مغلق — إذا ظهر تحذير أحمر فهذا خطأ في البيانات</li>
          <li>عند إكمال جميع المهام، يحصل الطفل على مكافأة نقاط إضافية</li>
        </ul>
      </div>
    </div>
  );
}

// ─── Shop Admin Tab ───────────────────────────────────────────────────────────
function ShopAdminTab() {
  const [showAddItem, setShowAddItem] = useState(false);
  const [itemForm, setItemForm] = useState({
    name: "", description: "", type: "avatar_frame" as string,
    icon: "🖼️", pointsCost: 100, levelRequired: 1, value: "",
  });

  const { data: items, refetch } = trpc.shop.getAllAdminWithCount.useQuery();
  const addItemMut = trpc.shop.upsert.useMutation({
    onSuccess: () => { toast.success("تم إضافة العنصر بنجاح"); refetch(); setShowAddItem(false); resetForm(); },
    onError: (e: any) => toast.error(e.message),
  });
  const deleteItemMut = trpc.shop.delete.useMutation({
    onSuccess: () => { toast.success("تم حذف العنصر"); refetch(); },
    onError: (e: any) => toast.error(e.message),
  });

  const resetForm = () => setItemForm({
    name: "", description: "", type: "avatar_frame",
    icon: "🖼️", pointsCost: 100, levelRequired: 1, value: "",
  });

  const itemTypes = [
    { value: "avatar_frame", label: "إطار أفاتار 🖼️" },
    { value: "badge", label: "شارة 🏅" },
    { value: "title", label: "لقب 👑" },
    { value: "effect", label: "تأثير احتفالي 🎉" },
  ];

  const typeColors: Record<string, string> = {
    avatar_frame: "bg-purple-100 text-purple-700",
    badge: "bg-blue-100 text-blue-700",
    title: "bg-yellow-100 text-yellow-700",
    effect: "bg-pink-100 text-pink-700",
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">متجر المكافآت 🛍️</h2>
        <button
          onClick={() => setShowAddItem(true)}
          className="px-4 py-2 bg-pink-500 text-white rounded-xl font-semibold text-sm hover:bg-pink-600 transition-colors"
        >
          + إضافة عنصر
        </button>
      </div>

      {/* Add Item Form */}
      {showAddItem && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-pink-100">
          <h3 className="font-bold text-lg mb-4">إضافة عنصر جديد</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-gray-600 block mb-1">الاسم *</label>
              <input
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.name}
                onChange={(e) => setItemForm({ ...itemForm, name: e.target.value })}
                placeholder="اسم العنصر"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-gray-600 block mb-1">النوع</label>
              <select
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.type}
                onChange={(e) => setItemForm({ ...itemForm, type: e.target.value })}
              >
                {itemTypes.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-semibold text-gray-600 block mb-1">الأيقونة</label>
              <input
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.icon}
                onChange={(e) => setItemForm({ ...itemForm, icon: e.target.value })}
                placeholder="🖼️"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-gray-600 block mb-1">التكلفة (نقاط)</label>
              <input
                type="number"
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.pointsCost}
                onChange={(e) => setItemForm({ ...itemForm, pointsCost: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-gray-600 block mb-1">المستوى المطلوب</label>
              <input
                type="number"
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.levelRequired}
                onChange={(e) => setItemForm({ ...itemForm, levelRequired: parseInt(e.target.value) || 1 })}
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-gray-600 block mb-1">القيمة (CSS/نص)</label>
              <input
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.value}
                onChange={(e) => setItemForm({ ...itemForm, value: e.target.value })}
                placeholder="مثال: border-4 border-purple-500"
              />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-semibold text-gray-600 block mb-1">الوصف</label>
              <input
                className="w-full border rounded-xl px-3 py-2 text-sm"
                value={itemForm.description}
                onChange={(e) => setItemForm({ ...itemForm, description: e.target.value })}
                placeholder="وصف العنصر"
              />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button
              onClick={() => addItemMut.mutate({ ...itemForm, type: itemForm.type as any, isEnabled: true })}
              disabled={addItemMut.isPending}
              className="px-6 py-2 bg-pink-500 text-white rounded-xl font-semibold text-sm hover:bg-pink-600 disabled:opacity-50 transition-colors"
            >
              {addItemMut.isPending ? "جارٍ الإضافة..." : "إضافة"}
            </button>
            <button
              onClick={() => { setShowAddItem(false); resetForm(); }}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-xl font-semibold text-sm hover:bg-gray-200 transition-colors"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items?.map((item: any) => (
          <div key={item.id} className="bg-white rounded-2xl shadow-sm p-4 border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-3xl">{item.icon}</span>
                <div>
                  <p className="font-bold text-gray-800">{item.name}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${typeColors[item.type] ?? "bg-gray-100 text-gray-600"}`}>
                    {itemTypes.find((t) => t.value === item.type)?.label ?? item.type}
                  </span>
                </div>
              </div>
              <button
                onClick={() => { if (confirm("حذف هذا العنصر؟")) deleteItemMut.mutate({ id: item.id }); }}
                className="text-red-400 hover:text-red-600 text-sm font-semibold transition-colors"
              >
                حذف
              </button>
            </div>
            {item.description && <p className="text-xs text-gray-500 mb-3">{item.description}</p>}
            <div className="flex gap-2 flex-wrap">
              <span className="bg-yellow-50 text-yellow-700 text-xs px-2 py-1 rounded-lg border border-yellow-200 font-semibold">
                💰 {item.pointsCost} نقطة
              </span>
              <span className="bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-lg border border-blue-200 font-semibold">
                🎯 مستوى {item.levelRequired}+
              </span>
              <span className={`text-xs px-2 py-1 rounded-lg border font-semibold ${
                (item as any).purchaseCount > 0
                  ? 'bg-green-50 text-green-700 border-green-200'
                  : 'bg-gray-50 text-gray-500 border-gray-200'
              }`}>
                🛒 {(item as any).purchaseCount ?? 0} شراء
              </span>
            </div>
          </div>
        ))}
      </div>

      {(!items || items.length === 0) && (
        <div className="text-center py-16 text-gray-400">
          <p className="text-4xl mb-3">🛍️</p>
          <p className="font-semibold">لا توجد عناصر في المتجر بعد</p>
          <p className="text-sm mt-1">أضف عناصر جديدة أو انتظر حتى يتم إنشاؤها تلقائياً</p>
        </div>
      )}
    </div>
  );
}

// ─── Adventure Node Editor ────────────────────────────────────────────────────
type AdventureChoice = { id: string; text: string; emoji: string; type: string; points: number; nextNodeId: string; };
type AdventureNode = { id: string; text: string; emoji: string; choices?: AdventureChoice[]; isEnding?: boolean; endingKey?: string; endingType?: string; endingTitle?: string; };
type AdventureDataType = { nodes: AdventureNode[]; startNodeId: string; };

function AdventureNodesEditor({ adv, onClose, onSave }: { adv: any; onClose: () => void; onSave: (data: AdventureDataType) => void }) {
  const rawData = adv.adventureData as any;
  const [data, setData] = useState<AdventureDataType>(() => {
    const d = rawData || {};
    return { nodes: Array.isArray(d.nodes) ? d.nodes : [], startNodeId: d.startNodeId || '' };
  });
  const [editingNodeIdx, setEditingNodeIdx] = useState<number | null>(null);

  const genId = () => Math.random().toString(36).slice(2, 8);

  const addNode = () => {
    const id = genId();
    const newNode: AdventureNode = { id, text: 'مشهد جديد', emoji: '📖', choices: [] };
    setData(d => ({ ...d, nodes: [...d.nodes, newNode], startNodeId: d.startNodeId || id }));
  };

  const deleteNode = (idx: number) => {
    setData(d => {
      const nodes = d.nodes.filter((_, i) => i !== idx);
      return { ...d, nodes, startNodeId: d.startNodeId === d.nodes[idx]?.id ? (nodes[0]?.id || '') : d.startNodeId };
    });
    if (editingNodeIdx === idx) setEditingNodeIdx(null);
  };

  const updateNode = (idx: number, patch: Partial<AdventureNode>) => {
    setData(d => { const nodes = [...d.nodes]; nodes[idx] = { ...nodes[idx], ...patch }; return { ...d, nodes }; });
  };

  const addChoice = (nodeIdx: number) => {
    const choice: AdventureChoice = { id: genId(), text: 'خيار جديد', emoji: '👉', type: 'safe', points: 10, nextNodeId: '' };
    setData(d => { const nodes = [...d.nodes]; nodes[nodeIdx] = { ...nodes[nodeIdx], choices: [...(nodes[nodeIdx].choices || []), choice] }; return { ...d, nodes }; });
  };

  const deleteChoice = (nodeIdx: number, choiceIdx: number) => {
    setData(d => { const nodes = [...d.nodes]; nodes[nodeIdx] = { ...nodes[nodeIdx], choices: (nodes[nodeIdx].choices || []).filter((_, i) => i !== choiceIdx) }; return { ...d, nodes }; });
  };

  const updateChoice = (nodeIdx: number, choiceIdx: number, patch: Partial<AdventureChoice>) => {
    setData(d => {
      const nodes = [...d.nodes];
      const choices = [...(nodes[nodeIdx].choices || [])];
      choices[choiceIdx] = { ...choices[choiceIdx], ...patch };
      nodes[nodeIdx] = { ...nodes[nodeIdx], choices };
      return { ...d, nodes };
    });
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-start justify-center z-50 p-3 overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-3xl my-4 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-5 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-white">محرر مشاهد المغامرة 🗺️</h3>
            <p className="text-purple-200 text-sm mt-0.5">{adv.emoji} {adv.title}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} className="text-white hover:bg-white/20"><X className="h-5 w-5" /></Button>
        </div>

        <div className="p-5">
          {/* Start Node Selector */}
          <div className="mb-4 p-3 bg-purple-50 rounded-2xl border border-purple-200">
            <Label className="text-sm font-bold text-purple-700 mb-1 block">🚀 المشهد الأول (startNodeId)</Label>
            <select
              value={data.startNodeId}
              onChange={e => setData(d => ({ ...d, startNodeId: e.target.value }))}
              className="w-full border-2 border-purple-200 rounded-xl px-3 py-2 text-sm bg-white"
            >
              <option value="">-- اختر المشهد الأول --</option>
              {data.nodes.map(n => <option key={n.id} value={n.id}>{n.emoji} {n.text.slice(0, 40)}</option>)}
            </select>
          </div>

          {/* Nodes List */}
          <div className="space-y-3 mb-4">
            {data.nodes.map((n, idx) => (
              <div key={n.id} className={`rounded-2xl border-2 overflow-hidden ${editingNodeIdx === idx ? 'border-purple-400' : 'border-gray-200'}`}>
                {/* Node Header */}
                <div className="flex items-center gap-3 p-3 bg-gray-50 cursor-pointer" onClick={() => setEditingNodeIdx(editingNodeIdx === idx ? null : idx)}>
                  <span className="text-xl">{n.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{n.text}</p>
                    <div className="flex gap-2 mt-0.5">
                      <span className="text-xs text-gray-400">ID: {n.id}</span>
                      {data.startNodeId === n.id && <span className="text-xs bg-green-100 text-green-700 px-1.5 rounded-full">بداية</span>}
                      {n.isEnding && <span className="text-xs bg-orange-100 text-orange-700 px-1.5 rounded-full">نهاية</span>}
                      <span className="text-xs text-gray-400">{(n.choices || []).length} خيار</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={e => { e.stopPropagation(); deleteNode(idx); }} className="text-red-400 hover:text-red-600 h-7 w-7 p-0">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                {/* Node Edit Form */}
                {editingNodeIdx === idx && (
                  <div className="p-4 border-t border-gray-100 bg-white">
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div className="col-span-2">
                        <Label className="text-xs font-bold mb-1 block">نص المشهد</Label>
                        <textarea
                          value={n.text}
                          onChange={e => updateNode(idx, { text: e.target.value })}
                          className="w-full border-2 rounded-xl px-3 py-2 text-sm resize-none h-20"
                          placeholder="اكتب نص المشهد هنا..."
                        />
                      </div>
                      <div>
                        <Label className="text-xs font-bold mb-1 block">الإيموجي</Label>
                        <Input value={n.emoji} onChange={e => updateNode(idx, { emoji: e.target.value })} className="rounded-xl border-2 text-xl" />
                      </div>
                      <div className="flex items-end gap-2">
                        <div className="flex-1">
                          <Label className="text-xs font-bold mb-1 block">نوع المشهد</Label>
                          <select
                            value={n.isEnding ? 'ending' : 'normal'}
                            onChange={e => updateNode(idx, { isEnding: e.target.value === 'ending' })}
                            className="w-full border-2 rounded-xl px-3 py-2 text-sm"
                          >
                            <option value="normal">عادي (له خيارات)</option>
                            <option value="ending">نهاية</option>
                          </select>
                        </div>
                      </div>
                      {n.isEnding && (
                        <>
                          <div>
                            <Label className="text-xs font-bold mb-1 block">مفتاح النهاية</Label>
                            <Input value={n.endingKey || ''} onChange={e => updateNode(idx, { endingKey: e.target.value })} className="rounded-xl border-2" placeholder="ending_good" />
                          </div>
                          <div>
                            <Label className="text-xs font-bold mb-1 block">نوع النهاية</Label>
                            <select
                              value={n.endingType || 'good'}
                              onChange={e => updateNode(idx, { endingType: e.target.value })}
                              className="w-full border-2 rounded-xl px-3 py-2 text-sm"
                            >
                              <option value="good">جيدة</option>
                              <option value="great">ممتازة</option>
                              <option value="learning">تعليمية</option>
                              <option value="surprise">مفاجأة</option>
                              <option value="bad">سيئة</option>
                            </select>
                          </div>
                          <div className="col-span-2">
                            <Label className="text-xs font-bold mb-1 block">عنوان النهاية</Label>
                            <Input value={n.endingTitle || ''} onChange={e => updateNode(idx, { endingTitle: e.target.value })} className="rounded-xl border-2" placeholder="نهاية سعيدة!" />
                          </div>
                        </>
                      )}
                    </div>

                    {/* Choices */}
                    {!n.isEnding && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs font-bold">الخيارات ({(n.choices || []).length})</Label>
                          <Button size="sm" variant="outline" onClick={() => addChoice(idx)} className="h-7 text-xs rounded-xl gap-1">
                            <Plus className="h-3 w-3" /> إضافة خيار
                          </Button>
                        </div>
                        <div className="space-y-2">
                          {(n.choices || []).map((c, ci) => (
                            <div key={c.id} className="bg-gray-50 rounded-xl p-3 border border-gray-200">
                              <div className="grid grid-cols-2 gap-2">
                                <div className="col-span-2 flex gap-2">
                                  <Input
                                    value={c.emoji}
                                    onChange={e => updateChoice(idx, ci, { emoji: e.target.value })}
                                    className="w-14 rounded-lg border text-center text-lg"
                                  />
                                  <Input
                                    value={c.text}
                                    onChange={e => updateChoice(idx, ci, { text: e.target.value })}
                                    className="flex-1 rounded-lg border text-sm"
                                    placeholder="نص الخيار"
                                  />
                                  <Button variant="ghost" size="sm" onClick={() => deleteChoice(idx, ci)} className="text-red-400 h-9 w-9 p-0">
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </Button>
                                </div>
                                <div>
                                  <Label className="text-xs text-gray-500 mb-1 block">يؤدي إلى (Node ID)</Label>
                                  <select
                                    value={c.nextNodeId}
                                    onChange={e => updateChoice(idx, ci, { nextNodeId: e.target.value })}
                                    className="w-full border rounded-lg px-2 py-1.5 text-xs"
                                  >
                                    <option value="">-- اختر مشهداً --</option>
                                    {data.nodes.filter((_, ni) => ni !== idx).map(nn => (
                                      <option key={nn.id} value={nn.id}>{nn.emoji} {nn.text.slice(0, 30)}</option>
                                    ))}
                                  </select>
                                </div>
                                <div>
                                  <Label className="text-xs text-gray-500 mb-1 block">النقاط</Label>
                                  <Input
                                    type="number"
                                    value={c.points}
                                    onChange={e => updateChoice(idx, ci, { points: Number(e.target.value) })}
                                    className="rounded-lg border text-sm"
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          <Button variant="outline" onClick={addNode} className="w-full rounded-2xl h-11 border-2 border-dashed gap-2 mb-4">
            <Plus className="h-4 w-4" /> إضافة مشهد جديد
          </Button>

          <div className="flex gap-3">
            <Button onClick={() => onSave(data)} className="flex-1 rounded-2xl h-12 font-bold gap-2">
              <Save className="h-4 w-4" /> حفظ جميع المشاهد
            </Button>
            <Button variant="outline" onClick={onClose} className="rounded-2xl h-12 border-2">إلغاء</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Adventures Admin Tab ────────────────────────────────────────────────────
function AdventuresAdminTab() {
  const [showAdd, setShowAdd] = useState(false);
  const [editingAdv, setEditingAdv] = useState<any | null>(null);
  const [editingNodes, setEditingNodes] = useState<any | null>(null);
  const [form, setForm] = useState({
    title: "", description: "", emoji: "🗺️",
    level: "easy" as "easy" | "medium" | "hard",
    ageGroup: "all" as "4-6" | "6-8" | "8-10" | "all",
    pointsReward: 50, totalEndings: 2, isPublished: true, orderIndex: 0,
  });

  const { data: adventures, refetch } = trpc.admin.allAdventures.useQuery();
  const createMut = trpc.admin.createAdventure.useMutation({
    onSuccess: () => { toast.success("تم إضافة المغامرة بنجاح 🗺️"); refetch(); setShowAdd(false); resetForm(); },
    onError: (e: any) => toast.error(e.message),
  });
  const deleteMut = trpc.admin.deleteAdventure.useMutation({
    onSuccess: () => { toast.success("تم حذف المغامرة"); refetch(); },
    onError: (e: any) => toast.error(e.message),
  });
  const updateMut = trpc.admin.updateAdventure.useMutation({
    onSuccess: () => { toast.success("تم تحديث المغامرة"); refetch(); },
    onError: (e: any) => toast.error(e.message),
  });

  const resetForm = () => setForm({ title: "", description: "", emoji: "🗺️", level: "easy", ageGroup: "all", pointsReward: 50, totalEndings: 2, isPublished: true, orderIndex: 0 });

  const levelLabel = (l: string) => l === "easy" ? "مبتدئ" : l === "medium" ? "متوسط" : "متقدم";
  const levelColor = (l: string) => l === "easy" ? "bg-green-100 text-green-700" : l === "medium" ? "bg-yellow-100 text-yellow-700" : "bg-red-100 text-red-700";

  return (
    <div className="container py-6 max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">إدارة المغامرات</h2>
          <p className="text-sm text-muted-foreground mt-1">إجمالي المغامرات: {(adventures || []).length}</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="rounded-2xl gap-2 font-bold">
          <Plus className="h-4 w-4" />
          إضافة مغامرة
        </Button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-3xl p-6 shadow-lg mb-6 border-2 border-primary/20">
          <h3 className="font-bold text-lg mb-4">مغامرة جديدة</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="col-span-2">
              <Label className="text-sm font-bold mb-1 block">العنوان *</Label>
              <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="rounded-xl border-2" placeholder="عنوان المغامرة" />
            </div>
            <div className="col-span-2">
              <Label className="text-sm font-bold mb-1 block">الوصف</Label>
              <Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="rounded-xl border-2" placeholder="وصف قصير للمغامرة" />
            </div>
            <div>
              <Label className="text-sm font-bold mb-1 block">الإيموجي</Label>
              <Input value={form.emoji} onChange={e => setForm({ ...form, emoji: e.target.value })} className="rounded-xl border-2 text-2xl" />
            </div>
            <div>
              <Label className="text-sm font-bold mb-1 block">المستوى</Label>
              <Select value={form.level} onValueChange={v => setForm({ ...form, level: v as any })}>
                <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">مبتدئ</SelectItem>
                  <SelectItem value="medium">متوسط</SelectItem>
                  <SelectItem value="hard">متقدم</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-bold mb-1 block">الفئة العمرية</Label>
              <Select value={form.ageGroup} onValueChange={v => setForm({ ...form, ageGroup: v as any })}>
                <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="4-6">٤-٦</SelectItem>
                  <SelectItem value="6-8">٦-٨</SelectItem>
                  <SelectItem value="8-10">٨-١٠</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-bold mb-1 block">النقاط</Label>
              <Input type="number" value={form.pointsReward} onChange={e => setForm({ ...form, pointsReward: Number(e.target.value) })} className="rounded-xl border-2" />
            </div>
            <div>
              <Label className="text-sm font-bold mb-1 block">عدد النهايات</Label>
              <Input type="number" value={form.totalEndings} onChange={e => setForm({ ...form, totalEndings: Number(e.target.value) })} className="rounded-xl border-2" />
            </div>
            <div>
              <Label className="text-sm font-bold mb-1 block">الترتيب</Label>
              <Input type="number" value={form.orderIndex} onChange={e => setForm({ ...form, orderIndex: Number(e.target.value) })} className="rounded-xl border-2" />
            </div>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => createMut.mutate({ ...form, adventureData: { scenes: [] } })} disabled={createMut.isPending} className="flex-1 rounded-2xl h-12 font-bold">
              {createMut.isPending ? "جارٍ الحفظ..." : "حفظ المغامرة"}
            </Button>
            <Button variant="outline" onClick={() => { setShowAdd(false); resetForm(); }} className="rounded-2xl h-12 border-2">إلغاء</Button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {(adventures || []).map(adv => (
          <div key={adv.id} className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 flex items-center gap-4">
            <span className="text-3xl">{adv.emoji}</span>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-foreground truncate">{adv.title}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${levelColor(adv.level)}`}>{levelLabel(adv.level)}</span>
                <span className="text-xs text-muted-foreground">⭐ {adv.pointsReward} نقطة</span>
                <span className="text-xs text-muted-foreground">🔚 {adv.totalEndings} نهايات</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${adv.isPublished ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                  {adv.isPublished ? "منشور" : "مخفي"}
                </span>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditingAdv({ ...adv })}
                className="rounded-xl border-2 text-xs gap-1"
              >
                <Edit className="h-3 w-3" />
                تعديل
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditingNodes({ ...adv })}
                className="rounded-xl border-2 text-xs gap-1 text-purple-600 border-purple-300 hover:bg-purple-50"
              >
                🗺️ المشاهد
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateMut.mutate({ id: adv.id, isPublished: !adv.isPublished })}
                className="rounded-xl border-2 text-xs"
              >
                {adv.isPublished ? "إخفاء" : "نشر"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => { if (confirm(`حذف "${adv.title}"؟`)) deleteMut.mutate({ id: adv.id }); }}
                className="rounded-xl border-2 text-destructive hover:bg-destructive/10 px-2"
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          </div>
        ))}
        {(!adventures || adventures.length === 0) && (
          <div className="text-center py-16 text-gray-400">
            <p className="text-4xl mb-3">🗺️</p>
            <p className="font-semibold">لا توجد مغامرات بعد</p>
          </div>
        )}
      </div>

      {/* Nodes Editor */}
      {editingNodes && (
        <AdventureNodesEditor
          adv={editingNodes}
          onClose={() => setEditingNodes(null)}
          onSave={(data) => {
            updateMut.mutate(
              { id: editingNodes.id, adventureData: data },
              { onSuccess: () => { setEditingNodes(null); toast.success('تم حفظ المشاهد بنجاح 🗺️'); } }
            );
          }}
        />
      )}

      {/* Edit Adventure Modal */}
      {editingAdv && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg my-4 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-xl font-bold">تعديل المغامرة ✏️</h3>
              <Button variant="ghost" size="sm" onClick={() => setEditingAdv(null)}><X className="h-4 w-4" /></Button>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="col-span-2">
                <Label className="text-sm font-bold mb-1 block">عنوان المغامرة</Label>
                <Input value={editingAdv.title} onChange={e => setEditingAdv({ ...editingAdv, title: e.target.value })} className="rounded-xl border-2" />
              </div>
              <div className="col-span-2">
                <Label className="text-sm font-bold mb-1 block">الوصف</Label>
                <Input value={editingAdv.description || ''} onChange={e => setEditingAdv({ ...editingAdv, description: e.target.value })} className="rounded-xl border-2" />
              </div>
              <div>
                <Label className="text-sm font-bold mb-1 block">الإيموجي</Label>
                <Input value={editingAdv.emoji} onChange={e => setEditingAdv({ ...editingAdv, emoji: e.target.value })} className="rounded-xl border-2 text-2xl" />
              </div>
              <div>
                <Label className="text-sm font-bold mb-1 block">المستوى</Label>
                <Select value={editingAdv.level} onValueChange={v => setEditingAdv({ ...editingAdv, level: v })}>
                  <SelectTrigger className="rounded-xl border-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">مبتدئ</SelectItem>
                    <SelectItem value="medium">متوسط</SelectItem>
                    <SelectItem value="hard">متقدم</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-bold mb-1 block">النقاط</Label>
                <Input type="number" value={editingAdv.pointsReward} onChange={e => setEditingAdv({ ...editingAdv, pointsReward: Number(e.target.value) })} className="rounded-xl border-2" />
              </div>
              <div>
                <Label className="text-sm font-bold mb-1 block">عدد النهايات</Label>
                <Input type="number" value={editingAdv.totalEndings} onChange={e => setEditingAdv({ ...editingAdv, totalEndings: Number(e.target.value) })} className="rounded-xl border-2" />
              </div>
              <div className="col-span-2 flex items-center gap-3 p-3 bg-muted/30 rounded-xl">
                <input type="checkbox" id="advPublished" checked={!!editingAdv.isPublished} onChange={e => setEditingAdv({ ...editingAdv, isPublished: e.target.checked })} className="w-4 h-4" />
                <Label htmlFor="advPublished" className="text-sm font-bold cursor-pointer">منشور (ظاهر للأطفال)</Label>
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => updateMut.mutate({ id: editingAdv.id, title: editingAdv.title, description: editingAdv.description, emoji: editingAdv.emoji, level: editingAdv.level, pointsReward: editingAdv.pointsReward, totalEndings: editingAdv.totalEndings, isPublished: editingAdv.isPublished }, { onSuccess: () => setEditingAdv(null) })}
                disabled={updateMut.isPending}
                className="flex-1 rounded-2xl h-12 font-bold gap-2"
              >
                <Save className="h-4 w-4" />
                {updateMut.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
              </Button>
              <Button variant="outline" onClick={() => setEditingAdv(null)} className="rounded-2xl h-12 border-2">إلغاء</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Interactive Lab Admin Tab ────────────────────────────────────────────────
function InteractiveLabAdminTab() {
  const { data: labStats } = trpc.admin.interactiveLabStats.useQuery();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [editingGame, setEditingGame] = useState<any | null>(null);
  const [editingGameJson, setEditingGameJson] = useState("");
  const [showAddGame, setShowAddGame] = useState(false);
  const [newGameJson, setNewGameJson] = useState("");
  const [newGameCategory, setNewGameCategory] = useState("memory");
  const [jsonError, setJsonError] = useState("");

  const CATEGORIES = [
    { id: "memory", label: "🧠 الذاكرة والمطابقة", games: memoryGames, color: "bg-purple-50 border-purple-200" },
    { id: "sorting", label: "📦 التصنيف والترتيب", games: sortingGames, color: "bg-green-50 border-green-200" },
    { id: "sequencing", label: "🔢 الترتيب المنطقي", games: sequencingGames, color: "bg-orange-50 border-orange-200" },
    { id: "build_logic", label: "🏗️ البناء والمنطق", games: buildLogicGames, color: "bg-pink-50 border-pink-200" },
    { id: "logic_puzzle", label: "🧩 الذكاء المنطقي", games: logicPuzzleGames, color: "bg-indigo-50 border-indigo-200" },
    { id: "coloring", label: "🎨 التلوين الرقمي", games: coloringGames, color: "bg-yellow-50 border-yellow-200" },
  ];

  const selectedCat = CATEGORIES.find(c => c.id === selectedCategory);

  const handleEditGame = (game: any) => {
    setEditingGame(game);
    setEditingGameJson(JSON.stringify(game, null, 2));
    setJsonError("");
  };

  return (
    <div className="container py-6 max-w-5xl" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">إدارة الألعاب التفاعلية 🎮</h2>
          <p className="text-sm text-muted-foreground mt-1">مختبر التعلم التفاعلي — 7 أقسام</p>
        </div>
        <Button onClick={() => setShowAddGame(true)} className="rounded-2xl gap-2 bg-indigo-600 hover:bg-indigo-700">
          <Plus className="h-4 w-4" /> إضافة لعبة
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 text-center">
          <p className="text-2xl font-bold text-primary">{labStats?.totalPlays ?? 0}</p>
          <p className="text-xs text-muted-foreground mt-1">إجمالي المحاولات</p>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 text-center">
          <p className="text-2xl font-bold text-green-600">{labStats?.completedGames ?? 0}</p>
          <p className="text-xs text-muted-foreground mt-1">ألعاب مكتملة</p>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 text-center">
          <p className="text-2xl font-bold text-indigo-600">{CATEGORIES.length}</p>
          <p className="text-xs text-muted-foreground mt-1">أقسام</p>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 text-center">
          <p className="text-2xl font-bold text-orange-600">{CATEGORIES.reduce((a, c) => a + c.games.length, 0)}</p>
          <p className="text-xs text-muted-foreground mt-1">إجمالي الألعاب</p>
        </div>
      </div>

      {/* Category Grid */}
      {!selectedCategory && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`${cat.color} border-2 rounded-2xl p-5 text-right hover:shadow-md transition-all`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-3xl">{cat.label.split(' ')[0]}</span>
                <span className="bg-white text-xs font-bold px-2 py-1 rounded-full shadow-sm">{cat.games.length} لعبة</span>
              </div>
              <p className="font-bold text-sm">{cat.label.substring(2)}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {(labStats?.byCategory || []).find((b: any) => b.category === cat.id)?.plays ?? 0} محاولة
              </p>
            </button>
          ))}
        </div>
      )}

      {/* Selected Category Games */}
      {selectedCategory && selectedCat && (
        <div>
          <div className="flex items-center gap-3 mb-4">
            <Button variant="outline" size="sm" onClick={() => setSelectedCategory(null)} className="rounded-xl gap-1">
              <ArrowRight className="h-4 w-4" /> الأقسام
            </Button>
            <h3 className="font-bold text-lg">{selectedCat.label}</h3>
            <span className="bg-muted text-xs px-2 py-1 rounded-full">{selectedCat.games.length} لعبة</span>
          </div>
          <div className="space-y-3">
            {selectedCat.games.map((game: any, idx: number) => (
              <div key={game.id} className={`${selectedCat.color} border-2 rounded-2xl p-4`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs bg-white px-2 py-0.5 rounded-full font-bold text-muted-foreground">#{idx + 1}</span>
                      <p className="font-bold text-sm">{game.title}</p>
                      {game.type && <span className="text-xs bg-white/70 px-2 py-0.5 rounded-full text-muted-foreground">{game.type}</span>}
                    </div>
                    {game.description && <p className="text-xs text-muted-foreground">{game.description}</p>}
                    <p className="text-xs text-muted-foreground mt-1 font-mono">ID: {game.id}</p>
                    {/* عرض عدد الأسئلة/الجولات */}
                    {game.questions && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{game.questions.length} سؤال</span>}
                    {game.rounds && <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">{game.rounds.length} جولة</span>}
                    {game.pairs && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">{game.pairs.length} زوج</span>}
                    {game.items && <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">{game.items.length} عنصر</span>}
                    {game.leftItems && <span className="text-xs bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full">{game.leftItems.length} مطابقة</span>}
                    {game.categories && <span className="text-xs bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full">{game.categories.length} فئة</span>}
                  </div>
                  <Button size="sm" variant="outline" onClick={() => handleEditGame(game)} className="rounded-xl gap-1 text-xs flex-shrink-0">
                    <Edit className="h-3 w-3" /> تعديل
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-2xl text-sm text-blue-700">
            <p className="font-bold mb-1">ℹ️ ملاحظة للمطور</p>
            <p>الألعاب التفاعلية مخزّنة في ملف <code className="bg-blue-100 px-1 rounded">client/src/lib/interactiveGamesData.ts</code>. لإضافة لعبة جديدة أو تعديل محتوى لعبة موجودة، استخدم محرر JSON أدناه ثم طبّق التغييرات في الكود.</p>
          </div>
        </div>
      )}

      {/* Edit Game Modal */}
      {editingGame && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 w-full max-w-2xl my-4 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">تعديل اللعبة: {editingGame.title}</h3>
              <Button variant="ghost" size="sm" onClick={() => { setEditingGame(null); setJsonError(""); }}><X className="h-4 w-4" /></Button>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">المعرّف (ID)</Label>
                  <Input value={editingGame.id} disabled className="rounded-xl border-2 text-xs font-mono bg-muted" />
                </div>
                <div>
                  <Label className="text-xs">العنوان</Label>
                  <Input
                    value={editingGame.title}
                    onChange={e => {
                      const updated = { ...editingGame, title: e.target.value };
                      setEditingGame(updated);
                      setEditingGameJson(JSON.stringify(updated, null, 2));
                    }}
                    className="rounded-xl border-2 text-xs"
                  />
                </div>
              </div>
              {editingGame.description !== undefined && (
                <div>
                  <Label className="text-xs">الوصف</Label>
                  <Input
                    value={editingGame.description || ''}
                    onChange={e => {
                      const updated = { ...editingGame, description: e.target.value };
                      setEditingGame(updated);
                      setEditingGameJson(JSON.stringify(updated, null, 2));
                    }}
                    className="rounded-xl border-2 text-xs"
                  />
                </div>
              )}
              <div>
                <Label className="text-xs">بيانات اللعبة الكاملة (JSON)</Label>
                <textarea
                  className="w-full h-64 p-3 border-2 rounded-xl text-xs font-mono resize-y bg-gray-50"
                  dir="ltr"
                  value={editingGameJson}
                  onChange={e => {
                    setEditingGameJson(e.target.value);
                    setJsonError("");
                    try {
                      const parsed = JSON.parse(e.target.value);
                      setEditingGame(parsed);
                    } catch {
                      setJsonError("⚠️ JSON غير صالح — تحقق من الصياغة");
                    }
                  }}
                />
                {jsonError && <p className="text-xs text-red-500 mt-1">{jsonError}</p>}
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-700">
                <p className="font-bold">📝 تعليمات التطبيق</p>
                <p>بعد الحفظ، انسخ JSON المعدّل وطبّقه في ملف <code>interactiveGamesData.ts</code> في الكود المصدري لتصبح التغييرات دائمة.</p>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button
                onClick={() => {
                  if (jsonError) { toast.error('يوجد خطأ في JSON'); return; }
                  try {
                    JSON.parse(editingGameJson);
                    toast.success('تم التحقق من البيانات ✅ — انسخ JSON وطبّقه في الكود');
                    navigator.clipboard?.writeText(editingGameJson).then(() => toast.info('تم النسخ للحافظة 📋'));
                  } catch { toast.error('JSON غير صالح'); }
                }}
                className="flex-1 rounded-2xl h-11 font-bold gap-2"
              >
                <Save className="h-4 w-4" /> نسخ JSON
              </Button>
              <Button variant="outline" onClick={() => { setEditingGame(null); setJsonError(""); }} className="rounded-2xl h-11 border-2">إغلاق</Button>
            </div>
          </div>
        </div>
      )}

      {/* Add Game Modal */}
      {showAddGame && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 w-full max-w-2xl my-4 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">إضافة لعبة جديدة ➕</h3>
              <Button variant="ghost" size="sm" onClick={() => { setShowAddGame(false); setNewGameJson(""); setJsonError(""); }}><X className="h-4 w-4" /></Button>
            </div>
            <div className="space-y-3">
              <div>
                <Label className="text-xs">القسم</Label>
                <select
                  className="w-full border-2 rounded-xl p-2 text-sm"
                  value={newGameCategory}
                  onChange={e => setNewGameCategory(e.target.value)}
                >
                  {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <Label className="text-xs">بيانات اللعبة (JSON)</Label>
                <textarea
                  className="w-full h-72 p-3 border-2 rounded-xl text-xs font-mono resize-y bg-gray-50"
                  dir="ltr"
                  placeholder={`{\n  "id": "${newGameCategory}-new-game",\n  "title": "اسم اللعبة",\n  "description": "وصف اللعبة",\n  "type": "quiz",\n  "questions": []\n}`}
                  value={newGameJson}
                  onChange={e => {
                    setNewGameJson(e.target.value);
                    setJsonError("");
                    try { JSON.parse(e.target.value); }
                    catch { if (e.target.value.trim()) setJsonError("⚠️ JSON غير صالح"); }
                  }}
                />
                {jsonError && <p className="text-xs text-red-500 mt-1">{jsonError}</p>}
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-700">
                <p className="font-bold">📝 كيفية الإضافة</p>
                <p>أدخل بيانات اللعبة بصيغة JSON ثم انسخها وأضفها في مصفوفة <code>{newGameCategory}Games</code> في ملف <code>interactiveGamesData.ts</code>.</p>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button
                onClick={() => {
                  try {
                    const parsed = JSON.parse(newGameJson);
                    if (!parsed.id || !parsed.title) { toast.error('يجب أن تحتوي اللعبة على id وtitle'); return; }
                    toast.success('تم التحقق ✅ — انسخ JSON وأضفه للكود');
                    navigator.clipboard?.writeText(newGameJson).then(() => toast.info('تم النسخ للحافظة 📋'));
                  } catch { toast.error('JSON غير صالح'); }
                }}
                className="flex-1 rounded-2xl h-11 font-bold gap-2"
              >
                <Plus className="h-4 w-4" /> نسخ JSON للإضافة
              </Button>
              <Button variant="outline" onClick={() => { setShowAddGame(false); setNewGameJson(""); setJsonError(""); }} className="rounded-2xl h-11 border-2">إغلاق</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Comprehensive Stats Tab ──────────────────────────────────────────────────
function ComprehensiveStatsTab() {
  const { data: stats, isLoading } = trpc.admin.comprehensiveStats.useQuery();

  const handlePrintPDF = () => {
    window.print();
  };

  const classroomLabel = (cls: string) => {
    const map: Record<string, string> = { "مرح": "فصل المرح", "نجوم": "فصل النجوم", "غيوم": "فصل الغيوم", "ألوان": "فصل الألوان" };
    return map[cls] || cls;
  };

  const categoryLabel = (cat: string) => {
    const map: Record<string, string> = { memory: "الذاكرة", sorting: "التصنيف", sequencing: "الترتيب", build_logic: "البناء" };
    return map[cat] || cat;
  };

  if (isLoading) return (
    <div className="flex items-center justify-center py-24">
      <div className="text-5xl animate-bounce">📊</div>
    </div>
  );

  if (!stats) return (
    <div className="text-center py-16 text-muted-foreground">لا توجد بيانات</div>
  );

  return (
    <div className="container py-6 max-w-5xl" id="stats-print-area">
      {/* Print Styles */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #stats-print-area, #stats-print-area * { visibility: visible; }
          #stats-print-area { position: absolute; left: 0; top: 0; width: 100%; }
          .no-print { display: none !important; }
          .print-break { page-break-before: always; }
        }
      `}</style>

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">📊 الإحصائيات الشاملة</h2>
          <p className="text-sm text-muted-foreground mt-1">
            تاريخ التقرير: {new Date(stats.generatedAt).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
        <Button onClick={handlePrintPDF} className="rounded-2xl gap-2 font-bold no-print" variant="outline">
          🖨️ طباعة / PDF
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: "إجمالي المتعلمين", value: stats.children.total, icon: "👧", color: "text-blue-600" },
          { label: "إجمالي القصص", value: stats.content.stories, icon: "📚", color: "text-purple-600" },
          { label: "إجمالي الألعاب", value: stats.content.games, icon: "🎮", color: "text-green-600" },
          { label: "إجمالي المغامرات", value: stats.content.adventures, icon: "🗺️", color: "text-orange-600" },
          { label: "قراءات مكتملة", value: stats.engagement.storyReads, icon: "✅", color: "text-teal-600" },
          { label: "محاولات الألعاب", value: stats.engagement.gamePlays, icon: "🕹️", color: "text-indigo-600" },
          { label: "إجمالي النقاط", value: stats.points.total, icon: "⭐", color: "text-yellow-600" },
          { label: "متوسط النقاط", value: stats.points.average, icon: "📈", color: "text-pink-600" },
        ].map(card => (
          <div key={card.label} className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 text-center">
            <p className="text-2xl mb-1">{card.icon}</p>
            <p className={`text-2xl font-bold ${card.color}`}>{card.value.toLocaleString("ar-SA")}</p>
            <p className="text-xs text-muted-foreground mt-1">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Children Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Kindergarten vs Outside */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-border/30">
          <h3 className="font-bold text-lg mb-4">توزيع المتعلمين</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-2xl">
              <span className="font-medium text-sm">🏫 داخل الروضة</span>
              <span className="font-bold text-blue-700">{stats.children.kindergarten}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-2xl">
              <span className="font-medium text-sm">🏠 خارج الروضة</span>
              <span className="font-bold text-green-700">{stats.children.outside}</span>
            </div>
            <div className="mt-2 pt-2 border-t border-border/30">
              <p className="text-sm font-bold mb-2">توزيع الفصول:</p>
              {stats.children.classroomBreakdown.map((cls: any) => (
                <div key={cls.name} className="flex items-center justify-between py-1">
                  <span className="text-sm text-muted-foreground">{classroomLabel(cls.name)}</span>
                  <span className="font-semibold text-sm">{cls.count} متعلم</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Level Breakdown */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-border/30">
          <h3 className="font-bold text-lg mb-4">توزيع المستويات</h3>
          <div className="space-y-2">
            {stats.children.levelBreakdown.filter((l: any) => l.count > 0).map((lvl: any) => (
              <div key={lvl.level} className="flex items-center gap-3">
                <span className="text-xs font-bold w-16 text-muted-foreground">المستوى {lvl.level}</span>
                <div className="flex-1 bg-muted/30 rounded-full h-4 overflow-hidden">
                  <div
                    className="h-full bg-primary/70 rounded-full transition-all"
                    style={{ width: `${stats.children.total > 0 ? (lvl.count / stats.children.total) * 100 : 0}%` }}
                  />
                </div>
                <span className="text-xs font-bold w-8 text-right">{lvl.count}</span>
              </div>
            ))}
            {stats.children.levelBreakdown.every((l: any) => l.count === 0) && (
              <p className="text-sm text-muted-foreground text-center py-4">لا توجد بيانات مستويات بعد</p>
            )}
          </div>
        </div>
      </div>

      {/* Top 10 Children */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-border/30 mb-6">
        <h3 className="font-bold text-lg mb-4">🏆 أفضل 10 متعلمين</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/30">
                <th className="text-right py-2 px-3 font-bold text-muted-foreground">#</th>
                <th className="text-right py-2 px-3 font-bold text-muted-foreground">الاسم</th>
                <th className="text-right py-2 px-3 font-bold text-muted-foreground">النقاط</th>
                <th className="text-right py-2 px-3 font-bold text-muted-foreground">المستوى</th>
                <th className="text-right py-2 px-3 font-bold text-muted-foreground">الفصل</th>
              </tr>
            </thead>
            <tbody>
              {stats.children.topChildren.map((child: any, i: number) => (
                <tr key={i} className={`border-b border-border/10 ${i < 3 ? "bg-yellow-50/50" : ""}`}>
                  <td className="py-2 px-3 font-bold">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</td>
                  <td className="py-2 px-3 font-semibold">{child.name}</td>
                  <td className="py-2 px-3 text-yellow-600 font-bold">{child.points.toLocaleString("ar-SA")} ⭐</td>
                  <td className="py-2 px-3">المستوى {child.level}</td>
                  <td className="py-2 px-3 text-muted-foreground">{child.classroom ? classroomLabel(child.classroom) : "خارج الروضة"}</td>
                </tr>
              ))}
              {stats.children.topChildren.length === 0 && (
                <tr><td colSpan={5} className="text-center py-6 text-muted-foreground">لا توجد بيانات بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Most Read Stories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 print-break">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-border/30">
          <h3 className="font-bold text-lg mb-4">📚 أكثر القصص قراءةً</h3>
          <div className="space-y-2">
            {stats.storyReadCounts.map((s: any, i: number) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted/20">
                <span className="text-lg">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📖"}</span>
                <span className="flex-1 text-sm font-medium truncate">{s.title}</span>
                <span className="text-sm font-bold text-primary">{s.reads} قراءة</span>
              </div>
            ))}
            {stats.storyReadCounts.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">لا توجد قراءات بعد</p>
            )}
          </div>
        </div>

        {/* Interactive Games Stats */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-border/30">
          <h3 className="font-bold text-lg mb-4">🧠 الألعاب التفاعلية</h3>
          <div className="space-y-3">
            {stats.interactiveByCategory.map((cat: any) => (
              <div key={cat.category} className="p-3 bg-muted/20 rounded-2xl">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-sm">{categoryLabel(cat.category)}</span>
                  <span className="text-xs text-muted-foreground">{cat.plays} محاولة</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-muted/40 rounded-full h-2">
                    <div
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${cat.plays > 0 ? (cat.completed / cat.plays) * 100 : 0}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-green-600">{cat.completed} مكتملة</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reviews Summary */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-border/30 mb-6">
        <h3 className="font-bold text-lg mb-4">⭐ ملخص التقييمات</h3>
        <div className="flex items-center gap-8">
          <div className="text-center">
            <p className="text-4xl font-bold text-yellow-500">{stats.reviews.avgRating}</p>
            <p className="text-sm text-muted-foreground mt-1">متوسط التقييم</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-primary">{stats.reviews.total}</p>
            <p className="text-sm text-muted-foreground mt-1">إجمالي التقييمات</p>
          </div>
          <div className="flex-1 text-center">
            <p className="text-4xl font-bold text-teal-600">{stats.engagement.adventurePlays}</p>
            <p className="text-sm text-muted-foreground mt-1">مغامرات مكتملة</p>
          </div>
          <div className="flex-1 text-center">
            <p className="text-4xl font-bold text-indigo-600">{stats.engagement.interactivePlays}</p>
            <p className="text-sm text-muted-foreground mt-1">محاولات تفاعلية</p>
          </div>
        </div>
      </div>

      {/* Print Footer */}
      <div className="text-center text-xs text-muted-foreground mt-8 pt-4 border-t border-border/30">
        <p>منصة قصة وفكرة · تقرير إحصائي شامل · {new Date(stats.generatedAt).toLocaleDateString("ar-SA")}</p>
        <p className="mt-1">تصميم وتنفيذ: زمرده عبد العزيز السماعيل · معلمة رياض أطفال · ماجستير تربية الطفولة المبكرة</p>
      </div>
    </div>
  );
}

// ─── Characters Admin Tab ────────────────────────────────────────────────────
function CharactersAdminTab() {
  const [editingChar, setEditingChar] = useState<any | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');

  const handleEditOpen = (char: any) => {
    setEditingChar({ ...char });
    setPreviewUrl(char.imageUrl || '');
  };

  return (
    <div className="container py-6 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground">الشخصيات المرافقة 🧑‍🎤</h2>
        <p className="text-sm text-muted-foreground mt-1">إجمالي الشخصيات: {CHARACTERS.length} شخصية</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {CHARACTERS.map((char) => (
          <div key={char.id} className="bg-white rounded-2xl p-4 shadow-sm border border-border/30 flex flex-col items-center gap-3">
            <div className="relative">
              <img
                src={char.imageUrl}
                alt={char.name}
                className="w-24 h-24 object-contain rounded-2xl bg-gradient-to-br from-purple-50 to-indigo-50 p-1"
                onError={(e) => { (e.target as HTMLImageElement).src = char.emoji; }}
              />
              <span className={`absolute -top-1 -right-1 text-xs px-1.5 py-0.5 rounded-full font-bold ${char.gender === 'boy' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'}`}>
                {char.gender === 'boy' ? '👦' : '👧'}
              </span>
            </div>
            <div className="text-center">
              <p className="font-bold text-sm">{char.name}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{char.personality}</p>
              <div className="flex gap-1 justify-center mt-1">
                <span className="text-xs bg-yellow-50 text-yellow-700 px-2 py-0.5 rounded-full border border-yellow-200">
                  💰 {char.pointsCost} نقطة
                </span>
                <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full border border-blue-200">
                  🎯 م{char.levelRequired}+
                </span>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleEditOpen(char)}
              className="w-full rounded-xl border-2 text-xs gap-1"
            >
              <Edit className="h-3 w-3" />
              معاينة / تعديل
            </Button>
          </div>
        ))}
      </div>

      {/* Character Preview/Edit Modal */}
      {editingChar && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 w-full max-w-md my-4 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-xl font-bold">معاينة الشخصية 🧑‍🎤</h3>
              <Button variant="ghost" size="sm" onClick={() => setEditingChar(null)}><X className="h-4 w-4" /></Button>
            </div>

            {/* Preview */}
            <div className="flex flex-col items-center mb-5 p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl">
              {previewUrl ? (
                <img
                  src={previewUrl}
                  alt={editingChar.name}
                  className="w-32 h-32 object-contain"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
              ) : (
                <div className="w-32 h-32 flex items-center justify-center text-6xl">{editingChar.emoji}</div>
              )}
              <p className="font-bold text-lg mt-2">{editingChar.name}</p>
              <p className="text-sm text-muted-foreground">{editingChar.personality}</p>
            </div>

            {/* Image URL with live preview */}
            <div className="mb-4">
              <Label className="text-sm font-bold mb-1 block">رابط الصورة (CDN)</Label>
              <Input
                value={previewUrl}
                onChange={e => setPreviewUrl(e.target.value)}
                className="rounded-xl border-2 text-xs"
                placeholder="https://d2xsxph8kpxj0f.cloudfront.net/..."
              />
              <p className="text-xs text-muted-foreground mt-1">تغيير الرابط يُحدّث المعاينة فوراً</p>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <Label className="text-xs font-bold mb-1 block">الاسم</Label>
                <Input value={editingChar.name} onChange={e => setEditingChar({ ...editingChar, name: e.target.value })} className="rounded-xl border-2 text-sm" />
              </div>
              <div>
                <Label className="text-xs font-bold mb-1 block">الإيموجي</Label>
                <Input value={editingChar.emoji} onChange={e => setEditingChar({ ...editingChar, emoji: e.target.value })} className="rounded-xl border-2 text-xl" />
              </div>
              <div>
                <Label className="text-xs font-bold mb-1 block">الجنس</Label>
                <select
                  value={editingChar.gender}
                  onChange={e => setEditingChar({ ...editingChar, gender: e.target.value })}
                  className="w-full border-2 rounded-xl px-3 py-2 text-sm"
                >
                  <option value="boy">ولد 👦</option>
                  <option value="girl">بنت 👧</option>
                </select>
              </div>
              <div>
                <Label className="text-xs font-bold mb-1 block">التكلفة (نقاط)</Label>
                <Input type="number" value={editingChar.pointsCost} onChange={e => setEditingChar({ ...editingChar, pointsCost: Number(e.target.value) })} className="rounded-xl border-2 text-sm" />
              </div>
              <div className="col-span-2">
                <Label className="text-xs font-bold mb-1 block">الوصف</Label>
                <Input value={editingChar.description} onChange={e => setEditingChar({ ...editingChar, description: e.target.value })} className="rounded-xl border-2 text-sm" />
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4">
              <p className="text-xs text-amber-700 font-semibold">⚠️ ملاحظة: التعديلات هنا للمعاينة فقط. لتطبيق التغييرات بشكل دائم، يجب تعديل ملف <code className="bg-amber-100 px-1 rounded">charactersData.ts</code> مباشرة.</p>
            </div>

            <Button variant="outline" onClick={() => setEditingChar(null)} className="w-full rounded-2xl h-11 border-2">إغلاق</Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── RecordingsSection ──────────────────────────────────────────────────────
function RecordingsSection({
  allRecordings,
  ratingInputs,
  setRatingInputs,
  rateRecordingMutation,
  approveRecordingMutation,
  deleteRecordingMutation,
  addReactionMutation,
  deleteReactionMutation,
}: {
  allRecordings: any[];
  ratingInputs: Record<string, { rating: number; comment: string }>;
  setRatingInputs: React.Dispatch<React.SetStateAction<Record<string, { rating: number; comment: string }>>>;
  rateRecordingMutation: any;
  approveRecordingMutation: any;
  deleteRecordingMutation: any;
  addReactionMutation: any;
  deleteReactionMutation: any;
}) {
  const [selectedChildId, setSelectedChildId] = useState<number | null>(null);
  const [filter, setFilter] = useState<'all' | 'unrated'>('all');
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [audioRef] = useState<{ current: HTMLAudioElement | null }>({ current: null });

  // تجميع التسجيلات حسب الطفل
  const childrenMap = new Map<number, { name: string; recordings: any[] }>();
  for (const rec of allRecordings) {
    if (!childrenMap.has(rec.childId)) {
      childrenMap.set(rec.childId, { name: rec.childName || `طفل #${rec.childId}`, recordings: [] });
    }
    childrenMap.get(rec.childId)!.recordings.push(rec);
  }
  const childrenList = Array.from(childrenMap.entries()).map(([id, v]) => ({ id, ...v }));

  // التسجيلات المعروضة
  const displayedRecordings = selectedChildId !== null
    ? (childrenMap.get(selectedChildId)?.recordings ?? [])
    : allRecordings;
  const filteredRecordings = filter === 'unrated'
    ? displayedRecordings.filter((r: any) => !r.rating)
    : displayedRecordings;

  // عدد غير المقيّمة
  const unratedCount = allRecordings.filter((r: any) => !r.rating).length;

  const handlePlay = (rec: any) => {
    if (playingId === rec.id) {
      // إيقاف
      audioRef.current?.pause();
      audioRef.current = null;
      setPlayingId(null);
      return;
    }
    // إيقاف الصوت الحالي
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    const audio = new Audio(rec.audioUrl);
    audioRef.current = audio;
    setPlayingId(rec.id);
    audio.play().catch(() => window.open(rec.audioUrl, '_blank'));
    audio.onended = () => { setPlayingId(null); audioRef.current = null; };
    audio.onerror = () => { setPlayingId(null); audioRef.current = null; window.open(rec.audioUrl, '_blank'); };
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xl">🎤</span>
        <h2 className="text-lg font-bold text-foreground">إدارة التسجيلات الصوتية</h2>
        <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">{allRecordings.length} تسجيل</span>
        {unratedCount > 0 && (
          <span className="text-xs bg-amber-100 text-amber-700 font-bold px-2 py-1 rounded-full animate-pulse">
            {unratedCount} غير مقيّم ⭐
          </span>
        )}
      </div>

      {/* فلتر الأطفال - بالأسماء */}
      <div className="bg-white rounded-2xl border border-border p-3">
        <p className="text-xs font-bold text-gray-500 mb-2">اختر طالباً لعرض تسجيلاته:</p>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedChildId(null)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedChildId === null ? 'bg-purple-500 text-white shadow' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            الكل ({allRecordings.length})
          </button>
          {childrenList.map(child => (
            <button
              key={child.id}
              onClick={() => setSelectedChildId(child.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedChildId === child.id ? 'bg-blue-500 text-white shadow' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              {child.name} ({child.recordings.length})
            </button>
          ))}
        </div>
        {/* فلتر مقيّم/غير مقيّم */}
        <div className="flex gap-2 mt-2 pt-2 border-t border-gray-100">
          <button onClick={() => setFilter('all')} className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${filter === 'all' ? 'bg-purple-100 text-purple-700' : 'text-gray-500 hover:bg-gray-100'}`}>الكل</button>
          <button onClick={() => setFilter('unrated')} className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${filter === 'unrated' ? 'bg-amber-100 text-amber-700' : 'text-gray-500 hover:bg-gray-100'}`}>غير مقيّم فقط</button>
        </div>
      </div>

      {/* قائمة التسجيلات */}
      {filteredRecordings.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-5xl mb-3">🎤</div>
          <p className="text-muted-foreground">لا توجد تسجيلات</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredRecordings.map((rec: any) => (
            <div key={rec.id} className="bg-white rounded-2xl p-4 shadow-sm border border-border">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-xl flex-shrink-0">🎤</div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate">{rec.title}</p>
                  <p className="text-xs text-purple-600 font-semibold">{rec.childName || `طفل #${rec.childId}`}</p>
                  <p className="text-xs text-muted-foreground">{new Date(rec.createdAt).toLocaleDateString('ar-SA')}</p>
                  {rec.rating && <p className="text-xs text-amber-600 font-bold">{'⭐'.repeat(rec.rating)} تقييم محفوظ</p>}
                </div>
                <div className="flex items-center gap-2">
                  {/* زر تشغيل/إيقاف */}
                  <button
                    onClick={() => handlePlay(rec)}
                    className={`p-2 rounded-lg text-xs font-bold transition-all ${playingId === rec.id ? 'bg-red-100 text-red-600 hover:bg-red-200' : 'bg-purple-100 text-purple-600 hover:bg-purple-200'}`}
                  >
                    {playingId === rec.id ? '⏹ إيقاف' : '▶️ تشغيل'}
                  </button>
                  {!rec.isApproved && (
                    <button onClick={() => approveRecordingMutation.mutate({ id: rec.id })} className="p-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 text-xs font-bold">اعتماد</button>
                  )}
                  {rec.isApproved && <span className="text-xs text-green-600 font-bold">✓ معتمد</span>}
                  <button onClick={() => deleteRecordingMutation.mutate({ id: rec.id })} className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              {/* قسم التقييم */}
              <div className="mt-3 pt-3 border-t border-gray-100">
                <p className="text-xs font-bold text-gray-600 mb-2">تقييم التسجيل:</p>
                <div className="flex items-center gap-1 mb-2">
                  {[1,2,3,4,5].map(star => (
                    <button
                      key={star}
                      onClick={() => setRatingInputs(prev => ({ ...prev, [rec.id]: { ...prev[rec.id], rating: star, comment: prev[rec.id]?.comment ?? '' } }))}
                      className={`text-xl transition-transform hover:scale-110 ${ (ratingInputs[rec.id]?.rating ?? rec.rating ?? 0) >= star ? 'text-amber-400' : 'text-gray-200' }`}
                    >★</button>
                  ))}
                  {(ratingInputs[rec.id]?.rating ?? rec.rating) && (
                    <span className="text-xs text-amber-600 font-bold mr-2">{ratingInputs[rec.id]?.rating ?? rec.rating} / 5</span>
                  )}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="تعليق تشجيعي للطفل (اختياري)"
                    value={ratingInputs[rec.id]?.comment ?? rec.ratingComment ?? ''}
                    onChange={e => setRatingInputs(prev => ({ ...prev, [rec.id]: { ...prev[rec.id], rating: prev[rec.id]?.rating ?? rec.rating ?? 0, comment: e.target.value } }))}
                    className="flex-1 text-xs border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-purple-400"
                  />
                  <button
                    onClick={() => {
                      const r = ratingInputs[rec.id];
                      if (!r?.rating) { toast.error('اختر عدد النجوم أولاً'); return; }
                      rateRecordingMutation.mutate({ id: rec.id, rating: r.rating, ratingComment: r.comment });
                    }}
                    className="px-3 py-1.5 bg-amber-500 text-white rounded-lg text-xs font-bold hover:bg-amber-600"
                  >حفظ ⭐</button>
                </div>
              </div>
              {/* قسم ردود الفعل التعبيرية */}
              <div className="mt-2 pt-2 border-t border-gray-100">
                <p className="text-xs font-bold text-gray-600 mb-2">ردود الفعل التعبيرية:</p>
                {(rec as any).reactions?.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {(rec as any).reactions.map((rx: any) => (
                      <span key={rx.id} className="inline-flex items-center gap-1 bg-yellow-50 border border-yellow-200 rounded-full px-2 py-0.5 text-xs">
                        <span className="text-base">{rx.emoji}</span>
                        <span className="text-yellow-700 font-medium">{rx.label}</span>
                        <button onClick={() => deleteReactionMutation.mutate({ reactionId: rx.id })} className="text-red-400 hover:text-red-600 ml-0.5 text-xs">×</button>
                      </span>
                    ))}
                  </div>
                )}
                <div className="flex flex-wrap gap-1">
                  {[
                    { emoji: '🌟', label: 'أحسنت' },
                    { emoji: '👏', label: 'رائع' },
                    { emoji: '❤️', label: 'ممتاز' },
                    { emoji: '😊', label: 'جميل' },
                    { emoji: '🎉', label: 'برافو' },
                    { emoji: '👑', label: 'ملك القراءة' },
                    { emoji: '🔥', label: 'رائع جداً' },
                    { emoji: '💫', label: 'نجم متألق' },
                  ].map(({ emoji, label }) => (
                    <button
                      key={emoji}
                      onClick={() => addReactionMutation.mutate({ recordingId: rec.id, emoji, label })}
                      className="flex items-center gap-0.5 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-full px-2 py-0.5 text-xs transition-all hover:scale-105 active:scale-95"
                      title={label}
                    >
                      <span className="text-base">{emoji}</span>
                      <span className="text-purple-700 font-medium">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
