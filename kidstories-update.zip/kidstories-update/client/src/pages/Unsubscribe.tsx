import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Unsubscribe() {
  const [location] = useLocation();
  const token = new URLSearchParams(window.location.search).get("token") || "";
  const [status, setStatus] = useState<"loading" | "success" | "already" | "error">("loading");
  const [email, setEmail] = useState("");

  const unsubMut = trpc.email.unsubscribe.useMutation({
    onSuccess: (data) => {
      if (data.alreadyUnsubscribed) {
        setStatus("already");
      } else {
        setStatus("success");
        setEmail(data.email || "");
      }
    },
    onError: () => setStatus("error"),
  });

  const resubMut = trpc.email.resubscribe.useMutation({
    onSuccess: () => setStatus("loading"),
  });

  useEffect(() => {
    if (token) {
      unsubMut.mutate({ token });
    } else {
      setStatus("error");
    }
  }, [token]);

  return (
    <div
      dir="rtl"
      className="min-h-screen flex items-center justify-center"
      style={{ background: "linear-gradient(135deg, #f0f4ff 0%, #fdf4ff 100%)" }}
    >
      <div className="max-w-md w-full mx-4 bg-white rounded-3xl shadow-xl overflow-hidden">
        {/* Header */}
        <div
          className="p-8 text-center text-white"
          style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
        >
          <div className="text-5xl mb-3">📚</div>
          <h1 className="text-xl font-bold">عالم القصص التعليمي</h1>
        </div>

        {/* Body */}
        <div className="p-8 text-center">
          {status === "loading" && (
            <div>
              <div className="text-4xl mb-4 animate-spin">⏳</div>
              <p className="text-gray-500">جارٍ معالجة طلبك...</p>
            </div>
          )}

          {status === "success" && (
            <div>
              <div className="text-5xl mb-4">✅</div>
              <h2 className="text-xl font-bold text-gray-800 mb-3">
                تم إلغاء الاشتراك بنجاح
              </h2>
              <p className="text-gray-500 text-sm mb-2">
                لن تتلقى رسائل بريدية بعد الآن على:
              </p>
              <p className="text-indigo-600 font-bold mb-6">{email}</p>
              <p className="text-gray-400 text-sm mb-6">
                غيّرت رأيك؟ يمكنك إعادة الاشتراك في أي وقت.
              </p>
              <button
                onClick={() => resubMut.mutate({ token })}
                disabled={resubMut.isPending}
                className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all"
                style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
              >
                {resubMut.isPending ? "جارٍ إعادة الاشتراك..." : "🔔 إعادة الاشتراك في الرسائل"}
              </button>
            </div>
          )}

          {status === "already" && (
            <div>
              <div className="text-5xl mb-4">ℹ️</div>
              <h2 className="text-xl font-bold text-gray-800 mb-3">
                أنت غير مشترك مسبقاً
              </h2>
              <p className="text-gray-500 text-sm mb-6">
                لم يتم العثور على اشتراك نشط لهذا البريد الإلكتروني.
              </p>
              <button
                onClick={() => resubMut.mutate({ token })}
                disabled={resubMut.isPending}
                className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all"
                style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
              >
                {resubMut.isPending ? "جارٍ الاشتراك..." : "🔔 الاشتراك في الرسائل"}
              </button>
            </div>
          )}

          {status === "error" && (
            <div>
              <div className="text-5xl mb-4">❌</div>
              <h2 className="text-xl font-bold text-gray-800 mb-3">
                رابط غير صالح
              </h2>
              <p className="text-gray-500 text-sm">
                الرابط الذي استخدمته غير صالح أو منتهي الصلاحية.
                يرجى استخدام الرابط الموجود في آخر رسالة بريدية تلقيتها.
              </p>
            </div>
          )}

          <a
            href="/"
            className="block mt-6 text-indigo-500 text-sm hover:underline"
          >
            ← العودة إلى الموقع
          </a>
        </div>
      </div>
    </div>
  );
}
