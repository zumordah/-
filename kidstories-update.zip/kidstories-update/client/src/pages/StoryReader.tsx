import { useState, useRef, useEffect, useCallback } from "react";
import { useLocation, useParams, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  ChevronRight, ChevronLeft, Home, Trophy, Star, BookOpen,
  Bookmark, BookmarkCheck, Volume2, VolumeX, Play, Pause, ArrowRight,
  Mic, Square, CheckCircle2, Trash2
} from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

// ─── مكوّن تسجيل صوت الصفحة ───────────────────────────────────────────────
interface PageVoiceRecorderProps {
  childId: number;
  storyId: number;
  pageNumber: number;
  storyTitle: string;
  onStopStoryAudio?: () => void;
}

function PageVoiceRecorder({ childId, storyId, pageNumber, storyTitle, onStopStoryAudio }: PageVoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showPanel, setShowPanel] = useState(false);
  // مرحلة المراجعة: blob + objectURL للتسجيل الجديد قبل الرفع
  const [previewBlob, setPreviewBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);
  // تشغيل التسجيل المحفوظ
  const [isSavedPlaying, setIsSavedPlaying] = useState(false);
  // مدة التسجيل المحفوظ
  const [savedDuration, setSavedDuration] = useState<number | null>(null);
  // مدة التسجيل الجديد (بالثواني)
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  // نوع الميديا المدعوم
  const [mimeType, setMimeType] = useState('audio/webm');
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  // نستخدم ref واحد ثابت للـ audio elements لتجنب مشاكل iOS
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const savedAudioRef = useRef<HTMLAudioElement | null>(null);

  // اختيار نوع الميديا المدعوم عند التحميل
  useEffect(() => {
    const types = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/ogg;codecs=opus',
      'audio/ogg',
      'audio/mp4',
      'audio/aac',
      '',
    ];
    const supported = types.find(t => t === '' || MediaRecorder.isTypeSupported(t));
    if (supported) setMimeType(supported);
  }, []);

  const { data: existingRec, refetch } = trpc.recordings.getPageRecording.useQuery(
    { childId, storyId, pageNumber },
    { enabled: !!childId && !!storyId }
  );

  const saveMutation = trpc.recordings.saveRecording.useMutation({
    onSuccess: (res) => {
      toast.success(res.replaced ? 'تم استبدال التسجيل السابق ✅' : 'تم حفظ تسجيلك ✅');
      refetch();
      setIsUploading(false);
      setPreviewBlob(null);
      if (previewUrl) { URL.revokeObjectURL(previewUrl); setPreviewUrl(null); }
    },
    onError: () => { toast.error('حدث خطأ أثناء الحفظ'); setIsUploading(false); },
  });

  const deleteMutation = trpc.recordings.deleteRecording.useMutation({
    onSuccess: () => { toast.success('تم حذف التسجيل'); refetch(); },
  });

  // (تم نقل جلب مدة التسجيل المحفوظ إلى useEffect الخاص بـ savedAudioRef)

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const startRecording = async () => {
    // إيقاف صوت القصة إن كان يعمل
    onStopStoryAudio?.();
    // إيقاف أي تشغيل صوتي حالي
    if (previewAudioRef.current) { previewAudioRef.current.pause(); previewAudioRef.current = null; }
    if (savedAudioRef.current) { savedAudioRef.current.pause(); savedAudioRef.current = null; }
    setIsPreviewPlaying(false);
    setIsSavedPlaying(false);
    // إلغاء المعاينة السابقة إن وجدت
    if (previewUrl) { URL.revokeObjectURL(previewUrl); setPreviewUrl(null); }
    setPreviewBlob(null);
    setRecordingSeconds(0);
    try {
      // طلب صلاحية الميكروفون مع إعدادات محسّنة للجوال
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100,
        }
      });
      // اختيار نوع الميديا المدعوم
      const options: MediaRecorderOptions = {};
      if (mimeType) options.mimeType = mimeType;
      let mr: MediaRecorder;
      try {
        mr = new MediaRecorder(stream, options);
      } catch {
        // fallback بدون mimeType محدد
        mr = new MediaRecorder(stream);
      }
      const actualMime = mr.mimeType || 'audio/webm';
      chunksRef.current = [];
      // طلب البيانات كل 250ms لضمان الحصول عليها على iOS
      mr.ondataavailable = (e) => { if (e.data && e.data.size > 0) chunksRef.current.push(e.data); };
      mr.onstop = () => {
        stream.getTracks().forEach(t => t.stop());
        if (recordingTimerRef.current) { clearInterval(recordingTimerRef.current); recordingTimerRef.current = null; }
        if (chunksRef.current.length === 0) {
          toast.error('لم يتم التقاط أي صوت، حاول مرة أخرى');
          return;
        }
        const blob = new Blob(chunksRef.current, { type: actualMime });
        const url = URL.createObjectURL(blob);
        setPreviewBlob(blob);
        setPreviewUrl(url);
        // إنشاء عنصر audio مسبقاً لتجاوز قيود iOS autoplay
        const audio = new Audio();
        audio.preload = 'auto';
        audio.src = url;
        audio.onended = () => { setIsPreviewPlaying(false); };
        audio.onerror = () => { setIsPreviewPlaying(false); toast.error('تعذّر تحميل التسجيل'); };
        previewAudioRef.current = audio;
      };
      mr.start(250); // timeslice 250ms لضمان ondataavailable على iOS
      mediaRecorderRef.current = mr;
      setIsRecording(true);
      // تتبع مدة التسجيل
      recordingTimerRef.current = setInterval(() => setRecordingSeconds(s => s + 1), 1000);
    } catch (err: any) {
      console.error('Recording error:', err);
      if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError') {
        toast.error('يرجى السماح للتطبيق باستخدام الميكروفون من إعدادات الجهاز');
      } else if (err?.name === 'NotFoundError') {
        toast.error('لم يتم العثور على ميكروفون في هذا الجهاز');
      } else {
        toast.error('تعذّر بدء التسجيل، تأكد من السماح باستخدام الميكروفون');
      }
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
    if (recordingTimerRef.current) { clearInterval(recordingTimerRef.current); recordingTimerRef.current = null; }
    // لا نرفع تلقائياً — ننتظر قرار الطفل
  };

  const discardPreview = () => {
    previewAudioRef.current?.pause();
    setIsPreviewPlaying(false);
    if (previewUrl) { URL.revokeObjectURL(previewUrl); }
    setPreviewUrl(null);
    setPreviewBlob(null);
  };

  const togglePreviewPlay = () => {
    if (!previewUrl || !previewAudioRef.current) return;
    if (isPreviewPlaying) {
      previewAudioRef.current.pause();
      previewAudioRef.current.currentTime = 0;
      setIsPreviewPlaying(false);
    } else {
      // إعادة تعيين الوقت للبداية
      previewAudioRef.current.currentTime = 0;
      previewAudioRef.current.onended = () => setIsPreviewPlaying(false);
      previewAudioRef.current.onerror = () => {
        setIsPreviewPlaying(false);
        toast.error('تعذّر تشغيل التسجيل');
      };
      const playPromise = previewAudioRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPreviewPlaying(true))
          .catch((err) => {
            console.error('Preview play failed:', err);
            toast.error('اضغط على الزر مرة أخرى لتشغيل التسجيل');
          });
      } else {
        setIsPreviewPlaying(true);
      }
    }
  };

  const confirmUpload = async () => {
    if (!previewBlob) return;
    // إيقاف المعاينة قبل الرفع
    if (previewAudioRef.current) { previewAudioRef.current.pause(); }
    setIsPreviewPlaying(false);
    setIsUploading(true);
    try {
      // تحديد الامتداد الصحيح حسب نوع الميديا
      const ext = previewBlob.type.includes('mp4') ? 'mp4'
        : previewBlob.type.includes('ogg') ? 'ogg'
        : previewBlob.type.includes('aac') ? 'aac'
        : 'webm';
      const formData = new FormData();
      formData.append('file', previewBlob, `rec_${storyId}_p${pageNumber}.${ext}`);
      formData.append('childId', String(childId)); // ضروري لتنظيم الملفات
      const res = await fetch('/api/upload-recording', { method: 'POST', body: formData });
      if (!res.ok) throw new Error('Upload failed');
      const { url, key } = await res.json();
      await saveMutation.mutateAsync({
        childId,
        title: `صفحة ${pageNumber} - ${storyTitle}`,
        audioUrl: url,
        audioKey: key,
        durationSeconds: recordingSeconds,
        storyId,
        pageNumber,
      });
    } catch {
      toast.error('فشل رفع التسجيل');
      setIsUploading(false);
    }
  };

  // إنشاء عنصر audio للتسجيل المحفوظ عند تغيير الرابط
  useEffect(() => {
    if (!existingRec?.audioUrl) {
      savedAudioRef.current = null;
      return;
    }
    const audio = new Audio();
    audio.preload = 'auto';
    audio.src = existingRec.audioUrl;
    audio.onloadedmetadata = () => {
      if (isFinite(audio.duration)) setSavedDuration(Math.round(audio.duration));
    };
    audio.onended = () => { setIsSavedPlaying(false); };
    audio.onerror = () => { setIsSavedPlaying(false); };
    savedAudioRef.current = audio;
    audio.load();
    return () => { audio.pause(); };
  }, [existingRec?.audioUrl]);

  const toggleSavedPlay = () => {
    if (!existingRec?.audioUrl || !savedAudioRef.current) return;
    if (isSavedPlaying) {
      savedAudioRef.current.pause();
      savedAudioRef.current.currentTime = 0;
      setIsSavedPlaying(false);
      return;
    }
    savedAudioRef.current.currentTime = 0;
    const playPromise = savedAudioRef.current.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => setIsSavedPlaying(true))
        .catch((err) => {
          console.error('Saved play failed:', err);
          // محاولة ثانية بعد تفاعل المستخدم (مشكلة iOS)
          toast.error('اضغط مرة أخرى لتشغيل التسجيل');
        });
    } else {
      setIsSavedPlaying(true);
    }
  };

  const handleDelete = () => {
    if (!existingRec) return;
    if (confirm('هل تريد حذف تسجيل هذه الصفحة؟')) {
      deleteMutation.mutate({ id: existingRec.id, childId });
    }
  };

  return (
    <div className="flex flex-col items-center gap-2">
      {/* الزر الرئيسي: إذا كان هناك تسجيل محفوظ يظهر زر تشغيل إضافي */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={() => setShowPanel(p => !p)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            existingRec ? 'bg-green-100 text-green-700 border border-green-300' : 'bg-pink-100 text-pink-700 border border-pink-300'
          }`}
        >
          <Mic className="w-3.5 h-3.5" />
          {existingRec ? 'سجّلت صوتك ✓' : 'سجّل صوتك'}
        </button>
        {existingRec && (
          <div className="flex items-center gap-1">
            <button
              onClick={(e) => { e.stopPropagation(); toggleSavedPlay(); }}
              title={isSavedPlaying ? 'إيقاف التسجيل' : 'استمع لتسجيلك'}
              className={`p-1.5 rounded-full transition-all ${
                isSavedPlaying
                  ? 'bg-purple-500 text-white shadow-md animate-pulse'
                  : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
              }`}
            >
              {isSavedPlaying ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            </button>
            {savedDuration !== null && (
              <span className="text-[10px] text-purple-500 font-mono">{formatDuration(savedDuration)}</span>
            )}
          </div>
        )}
      </div>

      {showPanel && (
        <div className="bg-white rounded-2xl shadow-lg border border-purple-100 p-3 w-full max-w-xs" dir="rtl">
          <p className="text-xs text-gray-400 text-center mb-2">
            يمكن حفظ تسجيل واحد فقط لكل صفحة — التسجيل الجديد يستبدل السابق
          </p>

          {/* التسجيل المحفوظ */}
          {existingRec && !previewBlob && (
            <div className="flex items-center gap-2 bg-green-50 rounded-xl p-2 mb-2">
              <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
              <span className="text-xs text-green-700 flex-1">تسجيل محفوظ</span>
              <button onClick={toggleSavedPlay} className="p-1 rounded-full bg-purple-100 text-purple-600 hover:bg-purple-200" title="تشغيل">
                {isSavedPlaying ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              </button>
              <button onClick={handleDelete} className="p-1 rounded-full bg-red-100 text-red-500 hover:bg-red-200" title="حذف">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* مرحلة المراجعة: بعد التسجيل وقبل الرفع */}
          {previewBlob && !isUploading && (
            <div className="bg-purple-50 rounded-xl p-3 mb-2 border border-purple-200">
              <p className="text-xs font-bold text-purple-700 text-center mb-2">🎧 استمع لتسجيلك أولاً</p>
              <div className="flex justify-center gap-2 mb-3">
                <button
                  onClick={togglePreviewPlay}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${
                    isPreviewPlaying ? 'bg-purple-600 text-white' : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                  }`}
                >
                  {isPreviewPlaying ? <><Square className="w-3 h-3" /> إيقاف</> : <><Play className="w-3 h-3" /> استمع</>}
                </button>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={discardPreview}
                  className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-full text-xs font-bold bg-gray-100 text-gray-600 hover:bg-gray-200"
                >
                  <Mic className="w-3 h-3" /> أعد التسجيل
                </button>
                <button
                  onClick={confirmUpload}
                  className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-full text-xs font-bold bg-green-500 text-white hover:bg-green-600"
                >
                  <CheckCircle2 className="w-3 h-3" /> احفظ
                </button>
              </div>
            </div>
          )}

          {/* أزرار التسجيل */}
          {!previewBlob && (
            <div className="flex justify-center">
              {isUploading ? (
                <div className="text-xs text-purple-500 animate-pulse">جاري حفظ التسجيل...</div>
              ) : isRecording ? (
                <button
                  onClick={stopRecording}
                  className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-full text-sm font-bold animate-pulse"
                >
                  <Square className="w-4 h-4" /> إيقاف التسجيل
                </button>
              ) : (
                <button
                  onClick={startRecording}
                  className="flex items-center gap-2 px-4 py-2 bg-pink-500 text-white rounded-full text-sm font-bold hover:bg-pink-600"
                >
                  <Mic className="w-4 h-4" /> {existingRec ? 'إعادة التسجيل' : 'ابدأ التسجيل'}
                </button>
              )}
            </div>
          )}

          {isUploading && (
            <div className="text-xs text-purple-500 animate-pulse text-center">جاري حفظ التسجيل...</div>
          )}
        </div>
      )}
    </div>
  );
}

function AudioButton({ isPlaying, hasAudio, onToggle }: { isPlaying: boolean; hasAudio: boolean; onToggle: () => void }) {
  return (
    <button onClick={onToggle}
      className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all duration-200 shadow-md hover:shadow-lg active:scale-95
        ${isPlaying ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white ring-4 ring-purple-300"
          : hasAudio ? "bg-white border-2 border-purple-300 text-purple-700 hover:bg-purple-50"
          : "bg-white border-2 border-gray-200 text-gray-500 hover:bg-gray-50"}`}
      title={isPlaying ? "إيقاف الصوت" : "تشغيل الصوت"}>
      {isPlaying ? (
        <>
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
          </span>
          <Pause className="h-4 w-4" /><span>إيقاف</span>
        </>
      ) : (
        <><Volume2 className={`h-4 w-4 ${hasAudio ? "text-purple-600" : "text-gray-400"}`} /><span>{hasAudio ? "استمع" : "استمع (TTS)"}</span></>
      )}
    </button>
  );
}

export default function StoryReader() {
  const params = useParams<{ id: string }>();
  const storyId = parseInt(params.id || "0");
  const [, navigate] = useLocation();
  const search = useSearch();
  const { child } = useChild();
  const fromChallenge = new URLSearchParams(search).get('from') === 'daily-challenge';
  const backPath = fromChallenge ? '/challenges' : '/home';
  const backLabel = fromChallenge ? 'التحديات' : 'المكتبة';

  const [currentPage, setCurrentPage] = useState(1);
  const [isFlipping, setIsFlipping] = useState(false);
  const [flipDirection, setFlipDirection] = useState<"forward" | "backward">("forward");
  const [showCompletion, setShowCompletion] = useState(false);
  const [newAchievements, setNewAchievements] = useState<any[]>([]);
  const [pointsEarned, setPointsEarned] = useState(0);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false); // false = لا يشتغل تلقائياً
  const [progressLoaded, setProgressLoaded] = useState(false); // منع إعادة تعيين الصفحة بعد التحميل الأول
  const [showResumeDialog, setShowResumeDialog] = useState(false); // حوار الاستئناف
  const [savedPageForResume, setSavedPageForResume] = useState(0); // الصفحة المحفوظة للاستئناف
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ttsRef = useRef<SpeechSynthesisUtterance | null>(null);

  const { data, isLoading } = trpc.stories.getById.useQuery({ id: storyId });
  const { data: progress } = trpc.stories.getProgress.useQuery({ childId: child?.id!, storyId }, { enabled: !!child });
  const { data: storyRecordings = [] } = trpc.recordings.getMyRecordings.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  // ردود الفعل التعبيرية من المعلم
  const { data: myReactions = [], refetch: refetchReactions } = trpc.recordings.getMyReactions.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const markReactionsSeenMutation = trpc.recordings.markReactionsSeen.useMutation();
  // مجموعة أرقام الصفحات التي تحتوي على تسجيل محفوظ
  const recordedPages = new Set(
    storyRecordings
      .filter(r => r.storyId === storyId && r.pageNumber != null)
      .map(r => r.pageNumber as number)
  );
  const updateProgressMutation = trpc.stories.updateProgress.useMutation();
  const utils = trpc.useUtils();

  const story = data?.story;
  const pages = data?.pages || [];
  const currentPageData = pages.find((p) => p.pageNumber === currentPage);
  const totalPages = pages.length;
  const hasAudioFile = !!currentPageData?.audioUrl;

  const stopAllAudio = useCallback(() => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.src = ""; audioRef.current = null; }
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setIsPlaying(false);
  }, []);

  // playCurrentPage: تُستخدم فقط عند الضغط على زر الصوت يدوياً
  const playCurrentPage = useCallback(() => {
    if (!audioEnabled) return;
    stopAllAudio();
    const pageData = pages.find((p) => p.pageNumber === currentPage);
    if (pageData?.audioUrl) {
      const audio = new Audio(pageData.audioUrl);
      audioRef.current = audio;
      audio.onplay = () => setIsPlaying(true);
      audio.onended = () => setIsPlaying(false);
      audio.onpause = () => setIsPlaying(false);
      audio.onerror = () => setIsPlaying(false);
      audio.play().catch(() => setIsPlaying(false));
    } else if (pageData?.text && window.speechSynthesis) {
      const utterance = new SpeechSynthesisUtterance(pageData.text);
      utterance.lang = "ar-SA"; utterance.rate = 0.85; utterance.pitch = 1.1;
      const voices = window.speechSynthesis.getVoices();
      const arabicVoice = voices.find((v) => v.lang.startsWith("ar") || v.name.includes("Arabic"));
      if (arabicVoice) utterance.voice = arabicVoice;
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);
      ttsRef.current = utterance;
      window.speechSynthesis.speak(utterance);
      setIsPlaying(true);
    }
  }, [audioEnabled, currentPage, pages, stopAllAudio]);

  const toggleAudio = useCallback(() => {
    if (isPlaying) { stopAllAudio(); setAudioEnabled(false); } else { setAudioEnabled(true); playCurrentPage(); }
  }, [isPlaying, stopAllAudio, playCurrentPage]);

  // useEffect منفصل لتشغيل الصوت تلقائياً عند تغيير الصفحة
  // تشغيل الصوت فقط عند الضغط على زر استمع (audioEnabled=true)
  // عند تغيير الصفحة: نوقف الصوت الحالي فقط ولا نشغّل تلقائياً
  useEffect(() => {
    // إيقاف أي صوت عند تغيير الصفحة
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.src = ""; audioRef.current = null; }
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setIsPlaying(false);
    // إعادة تعيين audioEnabled عند تغيير الصفحة لكي يضغط المستخدم مجدداً
    setAudioEnabled(false);
  }, [currentPage]);

  // تشغيل الصوت عند الضغط على زر استمع (audioEnabled يصبح true)
  useEffect(() => {
    if (!data || pages.length === 0 || !audioEnabled) return;
    const pageData = pages.find((p) => p.pageNumber === currentPage);
    if (!pageData) return;

    const timer = setTimeout(() => {
      if (pageData.audioUrl) {
        const audio = new Audio(pageData.audioUrl);
        audioRef.current = audio;
        audio.onplay = () => setIsPlaying(true);
        audio.onended = () => { setIsPlaying(false); setAudioEnabled(false); };
        audio.onpause = () => setIsPlaying(false);
        audio.onerror = () => setIsPlaying(false);
        audio.play().catch(() => setIsPlaying(false));
      } else if (pageData.text && window.speechSynthesis) {
        const utterance = new SpeechSynthesisUtterance(pageData.text);
        utterance.lang = "ar-SA";
        utterance.rate = 0.85;
        utterance.pitch = 1.1;
        const trySpeak = () => {
          const voices = window.speechSynthesis.getVoices();
          const arabicVoice = voices.find((v) => v.lang.startsWith("ar") || v.name.includes("Arabic"));
          if (arabicVoice) utterance.voice = arabicVoice;
          utterance.onstart = () => setIsPlaying(true);
          utterance.onend = () => { setIsPlaying(false); setAudioEnabled(false); };
          utterance.onerror = () => setIsPlaying(false);
          ttsRef.current = utterance;
          window.speechSynthesis.speak(utterance);
          setIsPlaying(true);
        };
        if (window.speechSynthesis.getVoices().length > 0) {
          trySpeak();
        } else {
          window.speechSynthesis.onvoiceschanged = () => { trySpeak(); window.speechSynthesis.onvoiceschanged = null; };
        }
      }
    }, 100);

    return () => {
      clearTimeout(timer);
      if (audioRef.current) { audioRef.current.pause(); audioRef.current.src = ""; audioRef.current = null; }
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      setIsPlaying(false);
    };
  }, [audioEnabled, data, pages, currentPage]);

  useEffect(() => { return () => { stopAllAudio(); }; }, []);

  useEffect(() => {
    if (!child || !storyId || progressLoaded) return; // تشغيل مرة واحدة فقط عند التحميل الأول
    if (progress === undefined) return; // انتظر حتى يتم تحميل التقدم
    const key = `bookmark_${child.id}_${storyId}`;
    const savedBookmark = localStorage.getItem(key);
    const savedPage = savedBookmark ? parseInt(savedBookmark) : null;
    if (savedPage && !isNaN(savedPage) && savedPage > 0) setIsBookmarked(true);
    const dbPage = progress?.currentPage ?? 0;
    const isDbCompleted = progress?.isCompleted ?? false;
    // إذا كان هناك تقدم محفوظ (صفحة > 1) وغير مكتملة، اعرض حوار الاستئناف
    if (dbPage > 1 && !isDbCompleted) {
      setSavedPageForResume(dbPage);
      setShowResumeDialog(true);
    } else if (savedPage && savedPage > 1 && !isDbCompleted) {
      setSavedPageForResume(savedPage);
      setShowResumeDialog(true);
    }
    setProgressLoaded(true); // تعيين العلامة لمنع التشغيل مرة أخرى
  }, [child, storyId, progress, progressLoaded]);

  const toggleBookmark = () => {
    if (!child) return;
    const key = `bookmark_${child.id}_${storyId}`;
    if (isBookmarked) { localStorage.removeItem(key); setIsBookmarked(false); toast.success("تم حذف الإشارة المرجعية"); }
    else { localStorage.setItem(key, String(currentPage)); setIsBookmarked(true); toast.success(`تم حفظ الصفحة ${currentPage} كإشارة مرجعية`); }
  };

  useEffect(() => {
    if (child && storyId && isBookmarked) localStorage.setItem(`bookmark_${child.id}_${storyId}`, String(currentPage));
  }, [currentPage, child, storyId, isBookmarked]);

  const saveProgress = async (page: number, completed = false) => {
    if (!child) return;
    try {
      const result = await updateProgressMutation.mutateAsync({ childId: child.id, storyId, currentPage: page, isCompleted: completed });
      if (completed) { setPointsEarned(result.pointsEarned); setNewAchievements(result.newAchievements || []); setShowCompletion(true); }
      utils.children.getById.invalidate({ id: child.id });
    } catch (error) { console.error("Failed to save progress:", error); }
  };

  const goToPage = (direction: "next" | "prev") => {
    if (isFlipping) return;
    const newPage = direction === "next" ? currentPage + 1 : currentPage - 1;
    if (newPage < 1 || newPage > totalPages) return;
    stopAllAudio();
    setFlipDirection(direction === "next" ? "forward" : "backward");
    setIsFlipping(true);
    setTimeout(() => { setCurrentPage(newPage); setIsFlipping(false); saveProgress(newPage, newPage === totalPages); }, 300);
  };

  const jumpToPage = (pageNum: number) => {
    if (isFlipping || pageNum === currentPage) return;
    stopAllAudio();
    setFlipDirection(pageNum > currentPage ? "forward" : "backward");
    setIsFlipping(true);
    setTimeout(() => { setCurrentPage(pageNum); setIsFlipping(false); saveProgress(pageNum, pageNum === totalPages); }, 300);
  };

  if (isLoading) return (
    <div className="min-h-screen bg-kids-gradient flex items-center justify-center">
      <div className="text-center"><div className="text-6xl animate-bounce mb-4">📖</div><p className="text-muted-foreground text-lg">جارٍ تحميل القصة...</p></div>
    </div>
  );

  if (!story || pages.length === 0) return (
    <div className="min-h-screen bg-kids-gradient flex items-center justify-center">
      <div className="text-center"><div className="text-6xl mb-4">😕</div><p className="text-muted-foreground">لم نجد هذه القصة</p>
        <Button onClick={() => navigate(backPath)} className="mt-4 rounded-2xl">العودة</Button></div>
    </div>
  );

  const isCoverPage = currentPage === 1;

  return (
    <div className="min-h-screen bg-kids-gradient flex flex-col" dir="rtl">
      <header className="bg-white/90 backdrop-blur-sm border-b border-border/50 sticky top-0 z-50 shadow-sm">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {fromChallenge ? (
              <Button
                size="sm"
                onClick={() => { stopAllAudio(); navigate(backPath); }}
                className="gap-1 rounded-xl font-bold bg-orange-500 hover:bg-orange-600 text-white shadow-md"
              >
                <ArrowRight className="h-4 w-4" />
                <span>التحديات</span>
              </Button>
            ) : (
              <>
                <button onClick={() => { stopAllAudio(); navigate(backPath); }} className="flex-shrink-0">
                  <img src={LOGO_URL} alt="قصة وفكرة" className="w-8 h-8 object-contain" />
                </button>
                <Button variant="ghost" size="sm" onClick={() => { stopAllAudio(); navigate(backPath); }} className="gap-1 rounded-xl font-bold">
                  <Home className="h-4 w-4" /><span className="hidden sm:inline">{backLabel}</span>
                </Button>
              </>
            )}
          </div>
          <div className="text-center"><h1 className="font-bold text-foreground text-sm sm:text-base truncate max-w-[180px]">{story.title}</h1></div>
          <button onClick={toggleBookmark}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-sm ${isBookmarked ? "bg-amber-100 text-amber-500 hover:bg-amber-200 ring-2 ring-amber-300" : "bg-muted/60 text-muted-foreground hover:bg-muted"}`}
            title={isBookmarked ? "حذف الإشارة" : "حفظ موضعك"}>
            {isBookmarked ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
          </button>
        </div>
      </header>

      <div className="w-full bg-muted/40" style={{ height: "6px" }}>
        <div className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500 ease-out" style={{ width: `${totalPages > 0 ? Math.round((currentPage / totalPages) * 100) : 0}%` }} />
      </div>

      <div className="container pt-3 pb-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-primary">{totalPages > 0 ? Math.round((currentPage / totalPages) * 100) : 0}%</span>
            <span className="text-xs text-muted-foreground">{isCoverPage ? "الغلاف" : `صفحة ${currentPage} من ${totalPages}`}</span>
          </div>
          <div className="flex gap-1 items-center">
            {Array.from({ length: totalPages }).map((_, i) => (
              <div key={i} className={`rounded-full transition-all duration-300 ${i + 1 === currentPage ? "w-4 h-2 bg-primary" : i + 1 < currentPage ? "w-2 h-2 bg-primary/60" : "w-2 h-2 bg-muted-foreground/20"}`} />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">{currentPage < totalPages ? `تبقى ${totalPages - currentPage} صفحة` : "أتممتها!"}</span>
        </div>
      </div>

      <main className="flex-1 container py-4">
        <div className="max-w-2xl mx-auto">
          <div className={`transition-all duration-300 ${isFlipping ? (flipDirection === "forward" ? "opacity-0 translate-x-4" : "opacity-0 -translate-x-4") : "opacity-100 translate-x-0"}`}>
            {currentPageData?.imageUrl && (
              <div className="bg-white rounded-3xl shadow-xl overflow-hidden border-4 border-white mb-4" style={{ boxShadow: "0 8px 32px rgba(0,0,0,0.12)", aspectRatio: "16/9" }}>
                <img src={currentPageData.imageUrl} alt={isCoverPage ? `غلاف قصة ${story.title}` : `صفحة ${currentPage}`} className="w-full h-full block" style={{ objectFit: "cover" }} />
              </div>
            )}
            <div className="bg-white rounded-3xl shadow-lg border border-border/20 p-5 sm:p-7">
              {isCoverPage ? (
                <div className="text-center">
                  <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-3" style={{ fontFamily: "Fredoka One, Tajawal, sans-serif" }}>{story.title}</h2>
                  {story.description && <p className="text-muted-foreground text-base sm:text-lg leading-relaxed mb-4" style={{ fontFamily: "Tajawal, sans-serif" }}>{story.description}</p>}
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full font-bold">{story.ageGroup} سنوات</span>
                    <span className="text-xs bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full font-bold flex items-center gap-1"><Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />{story.pointsReward} نقطة</span>
                  </div>
                  <div className="flex justify-center"><AudioButton isPlaying={isPlaying} hasAudio={hasAudioFile} onToggle={toggleAudio} /></div>
                </div>
              ) : (
                <div>
                  <p className="text-foreground text-xl sm:text-2xl text-center leading-loose mb-5" style={{ fontFamily: "Tajawal, sans-serif", fontWeight: 600, lineHeight: "2" }}>{currentPageData?.text}</p>
                  <div className="flex items-center justify-center gap-3 pt-2 border-t border-gray-100 flex-wrap">
                    <AudioButton isPlaying={isPlaying} hasAudio={hasAudioFile} onToggle={toggleAudio} />
                    {child && (
                      <PageVoiceRecorder
                        childId={child.id}
                        storyId={storyId}
                        pageNumber={currentPage}
                        storyTitle={story?.title ?? ''}
                        onStopStoryAudio={stopAllAudio}
                      />
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between max-w-2xl mx-auto mt-5 gap-4">
          <Button onClick={() => goToPage("prev")} disabled={currentPage === 1 || isFlipping} variant="outline" className="gap-2 rounded-2xl h-12 px-6 border-2 font-bold flex-1 sm:flex-none">
            <ChevronRight className="h-5 w-5" /> السابقة
          </Button>
          <div className="flex gap-1.5 items-center">
            {Array.from({ length: totalPages }).map((_, i) => (
              <div key={i} className="relative flex items-center justify-center">
                <button
                  onClick={() => jumpToPage(i + 1)}
                  className={`rounded-full transition-all ${i + 1 === currentPage ? "w-5 h-3 bg-primary" : "w-2.5 h-2.5 bg-muted-foreground/30 hover:bg-primary/50"}`}
                />
                {recordedPages.has(i + 1) && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full border border-white" />
                )}
              </div>
            ))}
          </div>
          <Button onClick={() => goToPage("next")} disabled={currentPage === totalPages || isFlipping} className="gap-2 rounded-2xl h-12 px-6 font-bold flex-1 sm:flex-none">
            التالية <ChevronLeft className="h-5 w-5" />
          </Button>
        </div>
      </main>

      {/* Resume Dialog - حوار الاستئناف */}
      {showResumeDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-7 max-w-sm w-full text-center shadow-2xl" dir="rtl">
            <div className="text-5xl mb-4">📖</div>
            <h2 className="text-xl font-bold text-foreground mb-2" style={{ fontFamily: "Tajawal, sans-serif" }}>أكمل من حيث توقفت!</h2>
            <p className="text-muted-foreground text-sm mb-5">
              توقفت عند <span className="font-bold text-primary">الصفحة {savedPageForResume}</span>. هل تريد الاستمرار من هناك؟
            </p>
            <div className="space-y-3">
              <button
                onClick={() => { setCurrentPage(savedPageForResume); setShowResumeDialog(false); }}
                className="w-full bg-gradient-to-r from-primary to-secondary text-white font-bold py-3 rounded-2xl shadow-md hover:shadow-lg transition-all active:scale-95"
              >
                ▶️ استمر من الصفحة {savedPageForResume}
              </button>
              <button
                onClick={() => { setCurrentPage(1); setShowResumeDialog(false); }}
                className="w-full bg-white border-2 border-gray-200 text-gray-600 font-bold py-3 rounded-2xl hover:bg-gray-50 transition-all"
              >
                🔄 ابدأ من البداية
              </button>
            </div>
          </div>
        </div>
      )}

      {showCompletion && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl">
            <div className="text-7xl mb-4 animate-bounce">🎉</div>
            <h2 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: "Tajawal, sans-serif" }}>أحسنت! أكملت القصة!</h2>
            <p className="text-muted-foreground mb-4">لقد قرأت "{story.title}" بالكامل</p>
            {pointsEarned > 0 && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-3 mb-4 flex items-center justify-center gap-2">
                <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" /><span className="font-bold text-yellow-700">+{pointsEarned} نقطة مكتسبة!</span>
              </div>
            )}
            {newAchievements.length > 0 && (
              <div className="mb-4">
                <p className="text-sm font-bold text-foreground mb-2">إنجازات جديدة!</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {newAchievements.map((ach: any) => (
                    <div key={ach.key} className="bg-primary/10 rounded-xl px-3 py-2 text-center">
                      <div className="text-2xl">{ach.emoji}</div><div className="text-xs font-bold text-primary">{ach.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {/* ردود فعل المعلم */}
            {myReactions.length > 0 && (() => {
              const unseenReactions = (myReactions as any[]).filter((rx: any) => !rx.seenByChild);
              const allReactions = myReactions as any[];
              return (
                <div className="bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-200 rounded-2xl p-4 mb-4">
                  <p className="text-sm font-bold text-yellow-800 mb-2 flex items-center gap-1">
                    <span className="text-lg">💌</span>
                    رسائل من المعلمة!
                    {unseenReactions.length > 0 && (
                      <span className="bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5 mr-1">{unseenReactions.length} جديد</span>
                    )}
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {allReactions.map((rx: any) => (
                      <div key={rx.id} className={`flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl border-2 transition-all ${
                        !rx.seenByChild ? 'bg-yellow-100 border-yellow-400 animate-pulse' : 'bg-white border-yellow-200'
                      }`}>
                        <span className="text-3xl">{rx.emoji}</span>
                        <span className="text-xs font-bold text-yellow-700">{rx.label}</span>
                        {rx.recordingTitle && <span className="text-xs text-gray-400 truncate max-w-20">{rx.recordingTitle}</span>}
                      </div>
                    ))}
                  </div>
                  {unseenReactions.length > 0 && (
                    <button
                      onClick={() => {
                        const ids = unseenReactions.map((rx: any) => rx.id);
                        markReactionsSeenMutation.mutate({ reactionIds: ids }, {
                          onSuccess: () => refetchReactions()
                        });
                      }}
                      className="mt-2 w-full text-xs text-yellow-600 underline hover:text-yellow-800"
                    >تم الاطلاع عليها ✓</button>
                  )}
                </div>
              );
            })()}
            {/* زر اسمع قصتي كاملة */}
            {(() => {
              const myStoryRecs = storyRecordings
                .filter(r => r.storyId === storyId && r.pageNumber != null)
                .sort((a, b) => (a.pageNumber ?? 0) - (b.pageNumber ?? 0));
              const allPagesRecorded = myStoryRecs.length > 0 && myStoryRecs.length >= totalPages;
              return (
                <>
                  {myStoryRecs.length > 0 && (
                    <div className="bg-purple-50 rounded-2xl p-3 mb-3">
                      <p className="text-xs font-bold text-purple-700 mb-2">🎤 لديك {myStoryRecs.length} تسجيل في هذه القصة</p>
                      <button
                        onClick={() => {
                          let idx = 0;
                          const playNext = () => {
                            if (idx >= myStoryRecs.length) return;
                            const audio = new Audio(myStoryRecs[idx].audioUrl);
                            audio.onended = () => { idx++; playNext(); };
                            audio.play();
                          };
                          playNext();
                          toast.success('تشغيل قصتك كاملة... 🎧');
                        }}
                        className="w-full py-2 bg-purple-500 text-white rounded-xl text-sm font-bold hover:bg-purple-600 flex items-center justify-center gap-2"
                      >
                        🎧 اسمع قصتي كاملة
                      </button>
                      {allPagesRecorded && (
                        <button
                          onClick={() => {
                            const shareText = `📖 سجّلتي قصة "${story?.title}" كاملة! 🌟
عدد الصفحات: ${totalPages} صفحة
استمع لتسجيلاتي من صفحة قصتي!`;
                            if (navigator.share) {
                              navigator.share({ title: `قصتي: ${story?.title}`, text: shareText })
                                .catch(() => {});
                            } else {
                              navigator.clipboard.writeText(shareText);
                              toast.success('تم نسخ الرسالة — الصقها لمشاركتها! 📋');
                            }
                          }}
                          className="w-full mt-2 py-2 bg-green-500 text-white rounded-xl text-sm font-bold hover:bg-green-600 flex items-center justify-center gap-2"
                        >
                          💬 شاركي قصتي مع ولي الأمر
                        </button>
                      )}
                    </div>
                  )}
                </>
              );
            })()}
            <div className="space-y-2">
              <Button onClick={() => { setShowCompletion(false); stopAllAudio(); navigate(backPath); }} className="w-full rounded-2xl h-12 font-bold">
                <BookOpen className="ml-2 h-4 w-4" /> {fromChallenge ? 'العودة للتحديات' : 'العودة إلى مكتبة القصص'}
              </Button>
              <Button variant="outline" onClick={() => { setShowCompletion(false); stopAllAudio(); navigate("/dashboard"); }} className="w-full rounded-2xl h-12 font-bold">
                <Trophy className="ml-2 h-4 w-4" /> شاهد إنجازاتي
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
