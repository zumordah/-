import { useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function SubmitDrawing() {
  const [, params] = useRoute("/submit-drawing/:storyId");
  const [imageUrl, setImageUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const submitMutation = trpc.drawings.submit.useMutation();
  const meQuery = trpc.auth.me.useQuery();

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);
    
    try {
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      setImageUrl(data.url);
    } catch (err) {
      console.error("Upload failed:", err);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async () => {
    if (!imageUrl || !params?.storyId) return;
    await submitMutation.mutateAsync({
      storyId: parseInt(params.storyId),
      imageUrl,
    });
    setImageUrl("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50 p-4">
      <Card className="max-w-md mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4 text-center">ارسم شخصيات القصة</h1>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">اسم الطفل</label>
            <Input value={meQuery.data?.name || ""} disabled />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">رفع صورة الرسمة</label>
            <Input type="file" accept="image/*" onChange={handleImageUpload} disabled={uploading} />
            {imageUrl && <img src={imageUrl} alt="preview" className="w-full mt-2 rounded" />}
          </div>

          <Button onClick={handleSubmit} disabled={!imageUrl || submitMutation.isPending} className="w-full">
            {submitMutation.isPending ? "جاري الإرسال..." : "إرسال الرسمة"}
          </Button>
        </div>
      </Card>
    </div>
  );
}
