import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { CheckCircle, Gamepad2, Play, Star, Trophy, Lock, ShoppingBag } from "lucide-react";
import { getCharacterById, getDefaultCharacter } from "@/data/charactersData";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

type Level = "easy" | "medium" | "hard";

const LEVEL_CONFIG: Record<Level, {
  label: string; emoji: string;
  gradient: string; lightBg: string; border: string;
  textColor: string; badgeBg: string; badgeText: string;
  progressColor: string;
}> = {
  easy: {
    label: "مبتدئ", emoji: "🟢",
    gradient: "from-emerald-400 to-green-500",
    lightBg: "bg-emerald-50", border: "border-emerald-200",
    textColor: "text-emerald-700", badgeBg: "bg-emerald-100", badgeText: "text-emerald-700",
    progressColor: "from-emerald-400 to-green-500",
  },
  medium: {
    label: "متوسط", emoji: "🟡",
    gradient: "from-amber-400 to-orange-500",
    lightBg: "bg-amber-50", border: "border-amber-200",
    textColor: "text-amber-700", badgeBg: "bg-amber-100", badgeText: "text-amber-700",
    progressColor: "from-amber-400 to-orange-500",
  },
  hard: {
    label: "متقدم", emoji: "🔴",
    gradient: "from-rose-400 to-red-600",
    lightBg: "bg-rose-50", border: "border-rose-200",
    textColor: "text-rose-700", badgeBg: "bg-rose-100", badgeText: "text-rose-700",
    progressColor: "from-rose-400 to-red-600",
  },
};

const TYPE_LABELS: Record<string, string> = {
  letter_match: "تعرّف وأسئلة",
  number_order: "ترتيب",
  count_objects: "عدّ وحساب",
  image_match: "تطابق وتعرّف",
  classification: "تصنيف",
  missing_letter: "كلمة ناقصة",
  word_build: "تركيب كلمات",
  memory_game: "لعبة الذاكرة",
  math_addition: "حساب ذهني",
  math_subtraction: "حساب ذهني",
  letter_sound: "صوت الحرف",
  national_identity: "هوية وثقافة",
  culture: "ثقافة وطنية",
};

type GameItem = {
  id: number;
  title: string;
  description: string | null;
  type: string;
  level: string;
  emoji: string | null;
  pointsReward: number;
  isLocked: boolean;
  lockCost: number;
};

function LevelProgressBar({
  completed, total, gradient, label,
}: { completed: number; total: number; gradient: string; label: string }) {
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between items-center text-xs">
        <span className="text-gray-500 font-medium">{label}</span>
        <span className="font-bold text-gray-700">{completed} / {total}</span>
      </div>
      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${gradient} rounded-full transition-all duration-700`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex justify-between items-center">
        <span className="text-xs text-gray-400">{pct}% مكتمل</span>
        {completed === total && total > 0 && (
          <span className="text-xs font-bold text-green-600 flex items-center gap-1">
            <Trophy className="w-3 h-3" /> مستوى مكتمل!
          </span>
        )}
      </div>
    </div>
  );
}

export default function EduGames() {
  const [, navigate] = useLocation();
  const search = useSearch();
  const { child } = useChild();
  // قراءة المستوى من URL عند العودة من اللعبة
  const urlLevel = new URLSearchParams(search).get('level') as Level | null;
  const [activeLevel, setActiveLevel] = useState<Level>(
    (urlLevel && ['easy','medium','hard'].includes(urlLevel)) ? urlLevel : "easy"
  );
  // مزامنة المستوى مع URL عند تغيّره
  useEffect(() => {
    if (urlLevel && ['easy','medium','hard'].includes(urlLevel) && urlLevel !== activeLevel) {
      setActiveLevel(urlLevel as Level);
    }
  }, [urlLevel]);
  const [unlockingId, setUnlockingId] = useState<number | null>(null);
  const [toastMsg, setToastMsg] = useState<{ msg: string; type: "success" | "error" } | null>(null);

  const { data: companionData } = trpc.companion.getMyCompanion.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id, staleTime: 60000 }
  );
  const characterId = (companionData as any)?.characterId ?? 'sami';
  const character = getCharacterById(characterId) ?? getDefaultCharacter();

  const { data: allGames, isLoading, refetch: refetchGames } = trpc.games.list.useQuery({});
  const { data: myProgress } = trpc.games.myProgress.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: unlockedGameIds = [], refetch: refetchUnlocked } = trpc.games.getUnlockedGameIds.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: childData, refetch: refetchChild } = trpc.children.getById.useQuery(
    { id: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const unlockGame = trpc.games.unlockGame.useMutation({
    onSuccess: async (result) => {
      if (result.success) {
        await refetchGames();
        await refetchUnlocked();
        await refetchChild();
        showToast(result.message, "success");
      } else {
        showToast(result.message, "error");
      }
    },
    onError: (e) => showToast(e.message, "error"),
    onSettled: () => setUnlockingId(null),
  });

  function showToast(msg: string, type: "success" | "error") {
    setToastMsg({ msg, type });
    setTimeout(() => setToastMsg(null), 3000);
  }

  const completedGameIds = new Set(
    (myProgress ?? [])
      .filter((p: { isCompleted: boolean; gameId: number }) => p.isCompleted)
      .map((p: { isCompleted: boolean; gameId: number }) => p.gameId)
  );
  const unlockedSet = new Set(unlockedGameIds);

  // توزيع جميع الألعاب (بما فيها id >= 90000) على المستويات حسب حقل level
  const gamesByLevel: Record<Level, GameItem[]> = {
    easy:   (allGames ?? []).filter((g: GameItem) => g.level === "easy"),
    medium: (allGames ?? []).filter((g: GameItem) => g.level === "medium"),
    hard:   (allGames ?? []).filter((g: GameItem) => g.level === "hard"),
  };

  const completedByLevel = (level: Level) =>
    gamesByLevel[level].filter((g) => completedGameIds.has(g.id)).length;

  const availableGamesByLevel: Record<Level, GameItem[]> = {
    easy:   gamesByLevel.easy.filter((g) => !g.isLocked || unlockedSet.has(g.id)),
    medium: gamesByLevel.medium.filter((g) => !g.isLocked || unlockedSet.has(g.id)),
    hard:   gamesByLevel.hard.filter((g) => !g.isLocked || unlockedSet.has(g.id)),
  };

  const lockedGamesByLevel: Record<Level, GameItem[]> = {
    easy:   gamesByLevel.easy.filter((g) => g.isLocked && !unlockedSet.has(g.id)),
    medium: gamesByLevel.medium.filter((g) => g.isLocked && !unlockedSet.has(g.id)),
    hard:   gamesByLevel.hard.filter((g) => g.isLocked && !unlockedSet.has(g.id)),
  };

  const totalCompleted = completedGameIds.size;
  const totalGames = (allGames ?? []).length;
  const cfg = LEVEL_CONFIG[activeLevel];
  const currentGames = availableGamesByLevel[activeLevel];
  const currentLockedGames = lockedGamesByLevel[activeLevel];
  const currentCompleted = completedByLevel(activeLevel);
  const currentPoints = childData?.totalPoints ?? child?.totalPoints ?? 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-teal-50 to-blue-50 pb-20" dir="rtl">
      {/* Toast */}
      {toastMsg && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl shadow-lg font-bold text-sm transition-all ${
          toastMsg.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"
        }`}>
          {toastMsg.msg}
        </div>
      )}

      {/* ─── Header ─────────────────────────────────────────────── */}
      <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm shadow-sm">
        <div className="px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="flex-shrink-0">
            <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
          </button>
          <button
            onClick={() => navigate("/activities")}
            className="flex items-center gap-1 text-xs text-green-600 bg-green-50 border border-green-200 px-2 py-1.5 rounded-full hover:bg-green-100 transition-colors flex-shrink-0"
          >
            ← مركز الأنشطة
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-green-800">ألعاب تعليمية 🎮</h1>
            {child && (
              <img
                src={character.imageUrl}
                alt={character.name}
                className="w-8 h-8 object-contain"
                style={{ filter: `drop-shadow(0 0 4px ${character.color})`, animation: 'bounce 2s infinite' }}
              />
            )}
            <p className="text-xs text-green-500">{totalGames} لعبة إبداعية متنوعة</p>
          </div>
          {child && (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-yellow-50 border border-yellow-200 px-3 py-1.5 rounded-full">
                <Trophy className="w-4 h-4 text-yellow-500" />
                <span className="text-sm font-bold text-yellow-700">{totalCompleted}</span>
                <span className="text-xs text-yellow-500">/ {totalGames}</span>
              </div>
              <button
                onClick={() => navigate("/shop")}
                className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-full text-amber-700 hover:bg-amber-100 transition-colors"
              >
                <ShoppingBag className="w-4 h-4" />
                <span className="text-xs font-bold">المتجر</span>
              </button>
            </div>
          )}
        </div>

        {/* Level Tabs - ثلاثة مستويات فقط */}
        <div className="flex px-4 pb-3 gap-2">
          {(["easy", "medium", "hard"] as Level[]).map((lvl) => {
            const c = LEVEL_CONFIG[lvl];
            const isActive = activeLevel === lvl;
            const lvlCompleted = completedByLevel(lvl);
            const lvlTotal = gamesByLevel[lvl].length;
            const lockedCount = lockedGamesByLevel[lvl].length;
            return (
              <button
                key={lvl}
                onClick={() => setActiveLevel(lvl)}
                className={`flex-1 py-2.5 px-2 rounded-xl text-sm font-bold transition-all border-2 relative ${
                  isActive
                    ? `bg-gradient-to-r ${c.gradient} text-white border-transparent shadow-md`
                    : `${c.lightBg} ${c.textColor} ${c.border} hover:shadow-sm`
                }`}
              >
                <div>{c.emoji} {c.label}</div>
                <div className={`text-xs font-normal mt-0.5 ${isActive ? "text-white/80" : "opacity-60"}`}>
                  {lvlCompleted}/{lvlTotal}
                </div>
                {lvlCompleted === lvlTotal && lvlTotal > 0 && (
                  <span className="absolute -top-1 -left-1 w-4 h-4 bg-yellow-400 rounded-full flex items-center justify-center text-[9px]">✓</span>
                )}
                {lockedCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-400 rounded-full flex items-center justify-center text-[9px] text-white">🔒</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 pt-4 space-y-4">

        {/* ─── Progress Card ───────────────────────────────────────── */}
        <div className={`${cfg.lightBg} border ${cfg.border} rounded-2xl p-4`}>
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${cfg.gradient} flex items-center justify-center text-white text-sm font-bold`}>
              {cfg.emoji}
            </div>
            <div>
              <h2 className={`font-bold text-sm ${cfg.textColor}`}>مستوى {cfg.label}</h2>
              <p className="text-xs text-gray-500">{gamesByLevel[activeLevel].length} لعبة في هذا المستوى</p>
            </div>
            {currentCompleted === currentGames.length && currentGames.length > 0 && (
              <div className="mr-auto flex items-center gap-1 bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-bold">
                <Trophy className="w-3 h-3" /> مكتمل!
              </div>
            )}
          </div>
          <LevelProgressBar
            completed={currentCompleted}
            total={gamesByLevel[activeLevel].length}
            gradient={cfg.progressColor}
            label={child ? "تقدمك في هذا المستوى" : "سجّل دخولك لتتبع تقدمك"}
          />
          {!child && (
            <p className="text-xs text-gray-400 mt-2 text-center">
              🔑 سجّل دخولك لحفظ تقدمك وكسب النقاط
            </p>
          )}
        </div>

        {/* ─── Overall Progress ─────────────────────────────────────── */}
        {child && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              تقدمك الإجمالي في الألعاب
            </h3>
            <div className="space-y-3">
              {(["easy", "medium", "hard"] as Level[]).map((lvl) => {
                const c = LEVEL_CONFIG[lvl];
                const done = completedByLevel(lvl);
                const tot = gamesByLevel[lvl].length;
                return (
                  <div key={lvl} className="flex items-center gap-3">
                    <span className="text-sm w-14 font-medium text-gray-600">{c.emoji} {c.label}</span>
                    <div className="flex-1 h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${c.progressColor} rounded-full transition-all duration-700`}
                        style={{ width: `${tot > 0 ? (done / tot) * 100 : 0}%` }}
                      />
                    </div>
                    <span className="text-xs font-bold text-gray-600 w-10 text-left">{done}/{tot}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── Games Grid ──────────────────────────────────────────── */}
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl h-36 animate-pulse" />
            ))}
          </div>
        ) : currentGames.length === 0 && currentLockedGames.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <Gamepad2 className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p className="font-semibold">لا توجد ألعاب في هذا المستوى</p>
          </div>
        ) : (
          <>
            {currentGames.length > 0 && (
              <div className="grid grid-cols-2 gap-3">
                {currentGames.map((game) => {
                  const done = completedGameIds.has(game.id);
                  // أزرق = مفتوحة لم تُلعب، أخضر = مكتملة
                  const cardBg = done ? "bg-green-50 border-2 border-green-300" : "bg-blue-50 border-2 border-blue-200";
                  const headerGrad = done ? "from-green-400 to-emerald-500" : "from-blue-400 to-indigo-500";
                  return (
                    <button
                      key={game.id}
                      onClick={() => navigate(`/game/${game.id}?level=${activeLevel}`)}
                      className={`${cardBg} rounded-2xl shadow-sm overflow-hidden transition-all text-right hover:shadow-md active:scale-95`}
                    >
                      <div className={`bg-gradient-to-r ${headerGrad} p-3 flex items-center justify-between`}>
                        <span className="text-2xl">{game.emoji ?? "🎮"}</span>
                        {done ? (
                          <CheckCircle className="w-5 h-5 text-white drop-shadow" />
                        ) : (
                          <Play className="w-4 h-4 text-white/80" />
                        )}
                      </div>
                      <div className="p-3">
                        <h3 className={`font-bold text-sm leading-tight mb-1 line-clamp-2 ${done ? 'text-green-800' : 'text-blue-800'}`}>{game.title}</h3>
                        <p className="text-xs text-gray-400 mb-2">{TYPE_LABELS[game.type] ?? game.type}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            <span className="text-xs font-semibold text-yellow-600">{game.pointsReward}</span>
                          </div>
                          {done ? (
                            <span className="text-xs font-bold text-green-600">✅ مكتمل</span>
                          ) : (
                            <span className="text-xs font-bold text-blue-500">▶ العب</span>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
            {/* ─── Locked Games ──────────────────────────────────────────── */}
            {currentLockedGames.length > 0 && (
              <div className="mt-4">
                <div className="flex items-center gap-2 mb-3">
                  <Lock className="w-4 h-4 text-gray-500" />
                  <h3 className="font-bold text-gray-700 text-sm">ألعاب مقفلة 🔒</h3>
                  <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">افتحها بالنقاط</span>
                </div>
                {child && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-2 mb-3 text-xs text-amber-700 flex items-center gap-2">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    نقاطك الحالية: <span className="font-bold">{currentPoints}</span>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  {currentLockedGames.map((game) => {
                    const canAfford = currentPoints >= game.lockCost;
                    const isUnlocking = unlockingId === game.id;
                    return (
                      <div
                        key={game.id}
                        className="bg-white rounded-2xl shadow-sm overflow-hidden border-2 border-dashed border-gray-200 opacity-80"
                      >
                        <div className="bg-gray-200 p-3 flex items-center justify-between">
                          <span className="text-2xl grayscale">{game.emoji ?? "🎮"}</span>
                          <Lock className="w-5 h-5 text-gray-400" />
                        </div>
                        <div className="p-3">
                          <h3 className="font-bold text-gray-600 text-sm leading-tight mb-1 line-clamp-2">{game.title}</h3>
                          <p className="text-xs text-gray-400 mb-2">{TYPE_LABELS[game.type] ?? game.type}</p>
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                            <span className="text-xs font-bold text-amber-600">{game.lockCost} نقطة للفتح</span>
                          </div>
                          {child ? (
                            <div className="space-y-1.5">
                              <button
                                onClick={() => {
                                  if (!canAfford) {
                                    showToast(`تحتاج ${game.lockCost} نقطة لفتح هذه اللعبة`, "error");
                                    return;
                                  }
                                  setUnlockingId(game.id);
                                  unlockGame.mutate({ childId: child.id, gameId: game.id });
                                }}
                                disabled={isUnlocking || !canAfford}
                                className={`w-full py-1.5 rounded-xl text-xs font-bold transition-colors ${
                                  canAfford
                                    ? "bg-amber-500 text-white hover:bg-amber-600"
                                    : "bg-gray-100 text-gray-400 cursor-not-allowed"
                                }`}
                              >
                                {isUnlocking ? "..." : canAfford ? "🔓 افتح الآن" : "نقاط غير كافية"}
                              </button>
                              {!canAfford && (
                                <button
                                  onClick={() => navigate("/shop")}
                                  className="w-full py-1.5 rounded-xl text-xs font-bold bg-purple-100 text-purple-700 hover:bg-purple-200 transition-colors flex items-center justify-center gap-1"
                                >
                                  <ShoppingBag className="w-3 h-3" />
                                  اشترِ من المتجر
                                </button>
                              )}
                            </div>
                          ) : (
                            <div className="space-y-1.5">
                              <div className="w-full py-1.5 bg-gray-100 text-gray-400 rounded-xl text-xs font-bold text-center">
                                سجّل دخولك للفتح
                              </div>
                              <button
                                onClick={() => navigate("/shop")}
                                className="w-full py-1.5 rounded-xl text-xs font-bold bg-purple-100 text-purple-700 hover:bg-purple-200 transition-colors flex items-center justify-center gap-1"
                              >
                                <ShoppingBag className="w-3 h-3" />
                                اشترِ من المتجر
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-3 text-center">
                  <button
                    onClick={() => navigate("/shop")}
                    className="text-xs text-amber-600 hover:text-amber-700 flex items-center gap-1 mx-auto font-semibold"
                  >
                    <ShoppingBag className="w-3 h-3" />
                    اذهب للمتجر لشراء المزيد من المكافآت
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
