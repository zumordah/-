import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import {
  BookOpen, ChevronRight, Star, Trophy, Zap,
  Lock, CheckCircle, RefreshCw, Sparkles, Map
} from "lucide-react";
import { toast } from "sonner";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

type Level = "easy" | "medium" | "hard";

const LEVEL_CONFIG: Record<Level, {
  label: string; emoji: string;
  gradient: string; lightBg: string; border: string; textColor: string;
}> = {
  easy: { label: "مبتدئ", emoji: "🟢", gradient: "from-emerald-400 to-green-500", lightBg: "bg-emerald-50", border: "border-emerald-200", textColor: "text-emerald-700" },
  medium: { label: "متوسط", emoji: "🟡", gradient: "from-amber-400 to-orange-500", lightBg: "bg-amber-50", border: "border-amber-200", textColor: "text-amber-700" },
  hard: { label: "متقدم", emoji: "🔴", gradient: "from-rose-400 to-red-600", lightBg: "bg-rose-50", border: "border-rose-200", textColor: "text-rose-700" },
};

type Adventure = {
  id: number; title: string; description: string | null;
  emoji: string | null; level: string; pointsReward: number;
  totalEndings: number; orderIndex: number | null;
  isLocked?: boolean; lockCost?: number;
};

type Progress = {
  adventureId: number; isCompleted: boolean;
  endingsDiscovered: string[] | null; pointsEarned: number | null; attempts: number | null;
};

export default function StoryAdventures() {
  const [, navigate] = useLocation();
  const { child } = useChild();
  const [activeLevel, setActiveLevel] = useState<Level>("easy");
  const [unlockingId, setUnlockingId] = useState<number | null>(null);

  const { data: adventures = [], isLoading } = trpc.adventures.list.useQuery({});
  const { data: myProgress = [] } = trpc.adventures.getChildProgress.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: unlockedAdvIds = [], refetch: refetchUnlocked } = trpc.adventures.getUnlockedAdventureIds.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: childData, refetch: refetchChild } = trpc.children.getById.useQuery(
    { id: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const unlockedAdvSet = new Set(unlockedAdvIds as number[]);

  const unlockAdventureMutation = trpc.adventures.unlockAdventure.useMutation({
    onSuccess: (data: any) => {
      toast.success(`🎉 تم فتح "${data?.title ?? 'المغامرة'}" بنجاح!`);
      refetchUnlocked();
      refetchChild();
      setUnlockingId(null);
    },
    onError: (err: any) => {
      toast.error(err.message ?? 'حدث خطأ أثناء الفتح');
      setUnlockingId(null);
    },
  });

  const childPoints = (childData as any)?.points ?? 0;

  const progressMap: Record<number, Progress> = {};
  (myProgress as Progress[]).forEach((p) => { progressMap[p.adventureId] = p; });

  const byLevel = (adventures as Adventure[]).filter((a) => a.level === activeLevel && (!a.isLocked || unlockedAdvSet.has(a.id)));
  const lockedByLevel = (adventures as Adventure[]).filter((a) => a.level === activeLevel && a.isLocked && !unlockedAdvSet.has(a.id));

  const totalCompleted = (myProgress as Progress[]).filter((p) => p.isCompleted).length;
  const totalEndingsFound = (myProgress as Progress[]).reduce(
    (sum, p) => sum + ((p.endingsDiscovered as string[] | null)?.length ?? 0), 0
  );

  const levelStats = (lvl: Level) => {
    const lvlAdventures = (adventures as Adventure[]).filter((a) => a.level === lvl);
    const completed = lvlAdventures.filter((a) => progressMap[a.id]?.isCompleted).length;
    return { total: lvlAdventures.length, completed };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-20" dir="rtl">

      {/* ─── Header ─────────────────────────────────────────────── */}
      <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm shadow-sm">
        <div className="px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="flex-shrink-0">
            <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
          </button>
          <button
            onClick={() => navigate("/activities")}
            className="flex items-center gap-1 text-xs text-purple-600 bg-purple-50 border border-purple-200 px-2 py-1.5 rounded-full hover:bg-purple-100 transition-colors flex-shrink-0"
          >
            ← مركز الأنشطة
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-purple-800 flex items-center gap-2">
              <Map className="w-5 h-5 text-purple-500" />
              مغامرات القصة 🧩
            </h1>
            <p className="text-xs text-purple-500">اختر مغامرتك وقرر مصيرها!</p>
          </div>

          {child && (
            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center gap-1 bg-purple-50 border border-purple-200 px-2 py-1 rounded-full">
                <Trophy className="w-3.5 h-3.5 text-purple-500" />
                <span className="text-xs font-bold text-purple-700">{totalCompleted} مكتملة</span>
              </div>
              <div className="flex items-center gap-1 bg-yellow-50 border border-yellow-200 px-2 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
                <span className="text-xs font-bold text-yellow-700">{totalEndingsFound} نهاية</span>
              </div>
            </div>
          )}
        </div>

        {/* Level Tabs */}
        <div className="flex px-4 pb-3 gap-2">
          {(["easy", "medium", "hard"] as Level[]).map((lvl) => {
            const c = LEVEL_CONFIG[lvl];
            const isActive = activeLevel === lvl;
            const stats = levelStats(lvl);
            return (
              <button
                key={lvl}
                onClick={() => setActiveLevel(lvl)}
                className={`flex-1 py-2.5 px-2 rounded-xl text-sm font-bold transition-all border-2 relative ${
                  isActive
                    ? `bg-gradient-to-r ${c.gradient} text-white border-transparent shadow-md`
                    : `${c.lightBg} ${c.textColor} ${c.border} hover:shadow-sm`
                }`}
              >
                <div>{c.emoji} {c.label}</div>
                <div className={`text-xs font-normal mt-0.5 ${isActive ? "text-white/80" : "opacity-60"}`}>
                  {stats.completed}/{stats.total}
                </div>
                {stats.completed === stats.total && stats.total > 0 && (
                  <span className="absolute -top-1 -left-1 w-4 h-4 bg-yellow-400 rounded-full flex items-center justify-center text-[9px]">✓</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 pt-4 space-y-4">

        {/* ─── Intro Banner ─────────────────────────────────────────── */}
        <div className={`bg-gradient-to-r ${LEVEL_CONFIG[activeLevel].gradient} rounded-2xl p-4 text-white`}>
          <div className="flex items-center gap-3">
            <div className="text-4xl">🧩</div>
            <div>
              <h2 className="font-bold text-lg">مغامرات مستوى {LEVEL_CONFIG[activeLevel].label}</h2>
              <p className="text-white/80 text-sm">كل قرار يغير مسار القصة! اكتشف جميع النهايات</p>
            </div>
          </div>
          <div className="mt-3 flex gap-3 text-sm">
            <div className="bg-white/20 rounded-lg px-3 py-1.5 flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-white" /> +50 نقطة للإكمال
            </div>
            <div className="bg-white/20 rounded-lg px-3 py-1.5 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> +20 نهاية جديدة
            </div>
          </div>
        </div>

        {/* ─── Points Guide ─────────────────────────────────────────── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-500" /> نظام النقاط
          </h3>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-green-50 rounded-xl p-2 border border-green-100">
              <div className="text-lg">🟢</div>
              <div className="font-bold text-green-700">اختيار آمن</div>
              <div className="text-green-600">+10 نقطة</div>
            </div>
            <div className="bg-amber-50 rounded-xl p-2 border border-amber-100">
              <div className="text-lg">🟡</div>
              <div className="font-bold text-amber-700">اختيار مغامرة</div>
              <div className="text-amber-600">+20 نقطة</div>
            </div>
            <div className="bg-rose-50 rounded-xl p-2 border border-rose-100">
              <div className="text-lg">🔴</div>
              <div className="font-bold text-rose-700">اختيار تعلم</div>
              <div className="text-rose-600">+5 نقطة</div>
            </div>
          </div>
        </div>

        {/* ─── Adventures List ──────────────────────────────────────── */}
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl h-28 animate-pulse" />
          ))
        ) : byLevel.length === 0 ? (
          <div className="text-center py-16 text-purple-400">
            <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="font-semibold">لا توجد مغامرات في هذا المستوى بعد</p>
          </div>
        ) : (
          byLevel.map((adv: Adventure, idx: number) => {
            const prog = progressMap[adv.id];
            const isCompleted = prog?.isCompleted ?? false;
            const endingsFound = (prog?.endingsDiscovered as string[] | null)?.length ?? 0;
            const attempts = prog?.attempts ?? 0;
            const cfg = LEVEL_CONFIG[activeLevel];

            return (
              <button
                key={adv.id}
                onClick={() => navigate(`/adventure/${adv.id}`)}
                className="w-full bg-white rounded-2xl shadow-sm hover:shadow-md transition-all overflow-hidden border border-gray-100 active:scale-[0.99] text-right"
              >
                <div className={`bg-gradient-to-r ${cfg.gradient} p-3 flex items-center gap-3`}>
                  <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center text-3xl flex-shrink-0">
                    {adv.emoji ?? "🌟"}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-white/60 text-xs">#{idx + 1}</span>
                      <h3 className="font-bold text-white text-base">{adv.title}</h3>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-white/70 text-xs">{adv.totalEndings} نهايات</span>
                      <span className="text-white/50 text-xs">•</span>
                      <span className="text-white/70 text-xs flex items-center gap-0.5">
                        <Star className="w-3 h-3 fill-white/70" /> {adv.pointsReward} نقطة
                      </span>
                    </div>
                  </div>
                  {isCompleted ? (
                    <CheckCircle className="w-7 h-7 text-white flex-shrink-0" />
                  ) : (
                    <ChevronRight className="w-6 h-6 text-white/80 flex-shrink-0" />
                  )}
                </div>

                <div className="p-3">
                  {adv.description && (
                    <p className="text-gray-600 text-sm mb-3 leading-relaxed">{adv.description}</p>
                  )}
                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      {endingsFound > 0 && (
                        <span className="bg-yellow-50 text-yellow-700 border border-yellow-200 text-xs px-2 py-1 rounded-full font-medium">
                          🔍 {endingsFound}/{adv.totalEndings} نهايات
                        </span>
                      )}
                      {attempts > 0 && (
                        <span className="bg-purple-50 text-purple-700 border border-purple-200 text-xs px-2 py-1 rounded-full font-medium">
                          <RefreshCw className="w-3 h-3 inline ml-1" />{attempts} مرة
                        </span>
                      )}
                    </div>
                    <span className={`text-xs font-bold px-3 py-1.5 rounded-full ${
                      isCompleted
                        ? "bg-green-100 text-green-700"
                        : `${cfg.lightBg} ${cfg.textColor}`
                    }`}>
                      {isCompleted ? "✅ مكتملة" : "▶️ ابدأ"}
                    </span>
                  </div>
                </div>
              </button>
            );
          })
        )}

        {/* ─── Locked Adventures Section ─────────────────────────────── */}
        {lockedByLevel.length > 0 && (
          <div className="mt-2">
            <div className="flex items-center gap-2 mb-3">
              <Lock className="w-4 h-4 text-gray-500" />
              <h3 className="font-bold text-gray-700 text-sm">مغامرات مقفلة 🔒</h3>
              {child && <span className="text-xs text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded-full">نقاطك: {childPoints} ⭐</span>}
            </div>
            <div className="space-y-3">
              {lockedByLevel.map((adv) => {
                const cost = adv.lockCost ?? 0;
                const canAfford = childPoints >= cost;
                const isUnlocking = unlockingId === adv.id;
                return (
                  <div key={adv.id} className="bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 overflow-hidden opacity-90">
                    <div className="bg-gray-200 p-3 flex items-center gap-3">
                      <div className="w-14 h-14 rounded-xl bg-gray-300 flex items-center justify-center text-3xl flex-shrink-0 grayscale">
                        {adv.emoji ?? "⚔️"}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-600 text-base">{adv.title}</h3>
                        <div className="flex items-center gap-1 mt-1">
                          <Lock className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-amber-600 font-bold">{cost} نقطة للفتح</span>
                        </div>
                      </div>
                      {child ? (
                        <div className="flex flex-col items-end gap-1">
                          <button
                            disabled={!canAfford || isUnlocking}
                            onClick={() => {
                              if (!canAfford) {
                                const needed = cost - childPoints;
                                const storiesNeeded = Math.ceil(needed / 10);
                                toast.error(`🌟 تحتاج ${needed} نقطة إضافية! أكمل ${storiesNeeded} قصة لتحصل عليها 📚`, { duration: 4000 });
                                return;
                              }
                              setUnlockingId(adv.id);
                              unlockAdventureMutation.mutate({ childId: child.id, adventureId: adv.id });
                            }}
                            className={`flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-xl transition-colors flex-shrink-0 ${
                              isUnlocking ? 'bg-gray-300 text-gray-500 cursor-wait'
                              : canAfford ? 'bg-amber-500 text-white hover:bg-amber-600'
                              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            }`}
                          >
                            {isUnlocking ? '⏳' : canAfford ? '🔓 افتح' : `🔒 ${cost} نقطة`}
                          </button>
                          {!canAfford && (
                            <span className="text-[9px] text-amber-600 text-center leading-tight">
                              تنقصك {cost - childPoints} نقطة
                            </span>
                          )}
                        </div>
                      ) : (
                        <button
                          onClick={() => navigate("/home")}
                          className="flex items-center gap-1 bg-purple-500 text-white text-xs font-bold px-3 py-1.5 rounded-xl hover:bg-purple-600 transition-colors flex-shrink-0"
                        >
                          سجّل دخولك
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── Not Logged In Banner ─────────────────────────────────── */}
        {!child && (
          <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 text-center">
            <Lock className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <p className="text-purple-700 font-semibold text-sm">سجّل دخولك لحفظ تقدمك وكسب النقاط!</p>
            <button
              onClick={() => navigate("/home")}
              className="mt-2 bg-purple-600 text-white text-sm px-4 py-2 rounded-xl font-bold"
            >
              تسجيل الدخول
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
