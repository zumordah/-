import { useLocation } from "wouter";
import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { Button } from "@/components/ui/button";
import { BookOpen, Gamepad2, Star, Trophy, Home, ArrowRight, Zap, Crown, Map, Sparkles, CalendarDays, ShoppingBag, Camera, X, Upload } from "lucide-react";
import { useChildAppearance } from "@/hooks/useChildAppearance";
import { getCharacterById, getDefaultCharacter } from "@/data/charactersData";
import { toast } from "sonner";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

function AdventuresProgress({ childId }: { childId: number }) {
  const [, navigate] = useLocation();
  const { data: progress = [] } = trpc.adventures.getChildProgress.useQuery({ childId });
  const { data: adventures = [] } = trpc.adventures.list.useQuery({});

  const total = (adventures as { id: number }[]).length;
  const completed = (progress as { isCompleted: boolean }[]).filter((p) => p.isCompleted).length;
  const totalEndings = (progress as { endingsDiscovered: string[] | null }[]).reduce(
    (sum, p) => sum + (p.endingsDiscovered?.length ?? 0), 0
  );
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

  if (total === 0) {
    return (
      <div className="text-center py-4">
        <div className="text-3xl mb-2">🧩</div>
        <p className="text-sm text-muted-foreground">ابدأ مغامرتك الأولى!</p>
        <button onClick={() => navigate("/adventures")} className="mt-2 text-indigo-600 text-sm font-bold">اذهب للمغامرات →</button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{completed} / {total} مغامرة مكتملة</span>
        <span className="text-sm font-bold text-indigo-600">{pct}%</span>
      </div>
      <div className="h-3 bg-indigo-100 rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-indigo-400 to-purple-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
          <span>{totalEndings} نهاية مكتشفة</span>
        </div>
        <button onClick={() => navigate("/adventures")} className="text-indigo-600 font-bold">اكمل المغامرات →</button>
      </div>
    </div>
  );
}

function DailyChallengeCard({ childId }: { childId: number }) {
  const [, navigate] = useLocation();
  const { data: challenge } = trpc.challenges.getToday.useQuery();
  const { data: progress } = trpc.challenges.getProgress.useQuery(
    { childId },
    { enabled: !!challenge }
  );

  if (!challenge) return null;

  const tasks = [
    { key: 'readStory', label: 'اقرأ قصة', emoji: '📖', done: progress?.readStoryDone ?? false, path: challenge?.readStoryId ? `/story/${challenge.readStoryId}?from=daily-challenge` : '/home?from=daily-challenge' },
    { key: 'playGame', label: 'العب لعبة', emoji: '🎮', done: progress?.playGameDone ?? false, path: challenge?.playGameId ? `/game/${challenge.playGameId}?from=daily-challenge` : '/activities/games?from=daily-challenge' },
    { key: 'playAdventure', label: 'أكمل مغامرة', emoji: '🗺️', done: progress?.playAdventureDone ?? false, path: challenge?.playAdventureId ? `/adventure/${challenge.playAdventureId}?from=daily-challenge` : '/adventures?from=daily-challenge' },
  ];
  const completedCount = tasks.filter((t) => t.done).length;
  const allDone = completedCount === 3;

  return (
    <div className={`rounded-3xl p-5 shadow-sm border-2 ${
      allDone ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-300' : 'bg-white border-orange-100'
    }`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-foreground text-lg flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-orange-500" />
          تحدي اليوم 🔥
        </h3>
        {allDone ? (
          <span className="bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-full">مكتمل 🎉</span>
        ) : (
          <span className="bg-orange-100 text-orange-700 text-xs font-bold px-3 py-1 rounded-full">{completedCount}/3</span>
        )}
      </div>
      <div className="grid grid-cols-3 gap-2 mb-3">
        {tasks.map((task) => (
          <button
            key={task.key}
            onClick={() => navigate(task.path)}
            className={`rounded-2xl p-3 text-center transition-all ${
              task.done
                ? 'bg-green-100 border-2 border-green-400'
                : 'bg-gray-50 border-2 border-gray-200 hover:border-orange-300'
            }`}
          >
            <div className="text-2xl mb-1">{task.done ? '✅' : task.emoji}</div>
            <p className={`text-xs font-semibold ${
              task.done ? 'text-green-700' : 'text-gray-600'
            }`}>{task.label}</p>
          </button>
        ))}
      </div>
      <div className="h-2 bg-orange-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-orange-400 to-yellow-400 rounded-full transition-all"
          style={{ width: `${(completedCount / 3) * 100}%` }}
        />
      </div>
      {allDone && (
        <p className="text-center text-sm font-bold text-yellow-700 mt-2">
          🌟 حصلت على {challenge.bonusPoints} نقطة مكافأة!
        </p>
      )}
    </div>
  );
}

export default function ChildDashboard() {
  const [, navigate] = useLocation();
  const { child, logout } = useChild();
  const appearance = useChildAppearance(child?.id);

  const { data: companionData } = trpc.companion.getMyCompanion.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id, staleTime: 60000 }
  );
  const characterId = (companionData as any)?.characterId ?? 'sami';
  const character = getCharacterById(characterId) ?? getDefaultCharacter();
  const [showRatingNotif, setShowRatingNotif] = useState(false);
  const [newRatings, setNewRatings] = useState<{ id: number; title: string; rating: number; ratingComment: string | null }[]>([]);
  // نافذة تغيير الصورة الشخصية
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const uploadAvatarMutation = trpc.children.uploadAvatar.useMutation();
  const { setChild } = useChild();

  const { data, isLoading } = trpc.children.getDashboard.useQuery(
    { childId: child?.id! },
    { enabled: !!child }
  );

  const { data: newRatingsData } = trpc.recordings.getNewRatings.useQuery(
    { childId: child?.id! },
    { enabled: !!child }
  );

  const { data: myReactions = [], refetch: refetchReactions } = trpc.recordings.getMyReactions.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const markReactionsSeenMutation = trpc.recordings.markReactionsSeen.useMutation();
  const markSeenMutation = trpc.recordings.markRatingsSeen.useMutation();

  useEffect(() => {
    if (newRatingsData && newRatingsData.length > 0) {
      setNewRatings(newRatingsData as { id: number; title: string; rating: number; ratingComment: string | null }[]);
      setShowRatingNotif(true);
    }
  }, [newRatingsData]);

  const handleCloseRatingNotif = () => {
    if (child && newRatings.length > 0) {
      markSeenMutation.mutate({ childId: child.id, ids: newRatings.map(r => r.id) });
    }
    setShowRatingNotif(false);
  };

  // دوال تغيير الصورة الشخصية
  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("حجم الصورة كبير جداً! اختر صورة أصغر من 5 ميغابايت");
      return;
    }
    setAvatarFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setAvatarPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleAvatarUpload = async () => {
    if (!avatarFile || !child) return;
    setUploadingAvatar(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve, reject) => {
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(avatarFile);
      });
      const result = await uploadAvatarMutation.mutateAsync({
        childId: child.id,
        base64,
        contentType: avatarFile.type || "image/jpeg",
      });
      // تحديث الجلسة بالصورة الجديدة
      setChild({ ...child, avatarUrl: (result as any).avatarUrl } as any);
      toast.success("تم تغيير صورتك بنجاح! 🎉");
      setShowAvatarModal(false);
      setAvatarPreview(null);
      setAvatarFile(null);
    } catch {
      toast.error("حدث خطأ أثناء رفع الصورة، حاول مرة أخرى");
    } finally {
      setUploadingAvatar(false);
    }
  };

  if (!child) { navigate("/"); return null; }

  const POINTS_PER_LEVEL = 100;
  const MAX_LEVEL = 10;
  const currentLevel = Math.min(Math.floor(child.totalPoints / POINTS_PER_LEVEL) + 1, MAX_LEVEL);
  const levelProgress = child.totalPoints % POINTS_PER_LEVEL;
  const nextLevelPoints = POINTS_PER_LEVEL;
  const pointsToNextLevel = nextLevelPoints - levelProgress;
  const progressPct = (levelProgress / nextLevelPoints) * 100;

  const earnedAchievements = data?.earnedAchievements || [];
  const allAchievements = data?.allAchievements || [];

  return (
    <div className="min-h-screen bg-kids-gradient">
      {/* إشعار تقييم جديد */}
      {showRatingNotif && newRatings.length > 0 && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4" onClick={handleCloseRatingNotif}>
          <div
            className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl text-center animate-bounce-in"
            onClick={e => e.stopPropagation()}
          >
            <div className="text-6xl mb-3">🎉</div>
            <h2 className="text-xl font-bold text-purple-700 mb-1">المعلمة قيّمت تسجيلك!</h2>
            {newRatings.slice(0, 3).map(r => (
              <div key={r.id} className="bg-purple-50 rounded-2xl p-3 mb-2 text-right">
                <p className="text-sm font-bold text-gray-700 mb-1">{r.title}</p>
                <div className="flex justify-center gap-1 mb-1">
                  {[1,2,3,4,5].map(s => (
                    <span key={s} className={`text-xl ${s <= r.rating ? 'text-yellow-400' : 'text-gray-200'}`}>⭐</span>
                  ))}
                </div>
                {r.ratingComment && <p className="text-xs text-purple-600 italic">"{r.ratingComment}"</p>}
              </div>
            ))}
            {newRatings.length > 3 && (
              <p className="text-sm text-gray-500 mb-2">و {newRatings.length - 3} تسجيلات أخرى...</p>
            )}
            <Button
              onClick={handleCloseRatingNotif}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl mt-2"
            >
              رائع! شكراً 💜
            </Button>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-border/50 sticky top-0 z-50">
        <div className="container py-3 flex items-center justify-between">
          <button onClick={() => navigate("/home")} className="flex-shrink-0">
            <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
          </button>
          <h1 className="font-bold text-foreground">لوحتي ✨</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            className="text-xs text-destructive hover:text-destructive rounded-xl"
          >
            خروج
          </Button>
        </div>
      </header>

      <main className="container py-6 max-w-2xl mx-auto space-y-5">
        {/* Profile Card */}
        <div className={`bg-gradient-to-r ${appearance.themeGradient} rounded-3xl p-6 text-white relative overflow-hidden transition-all duration-500`}>
          <div className="absolute top-2 right-4 text-5xl opacity-20 animate-float">✨</div>
          <div className="flex items-center gap-4">
            {/* صورة الشخصية مع زر تغيير الصورة */}
            <div className="relative">
              <div className={`relative w-20 h-20 rounded-full bg-white/20 flex items-center justify-center transition-all duration-300 ${appearance.frameClass} overflow-hidden`}>
                {companionData ? (
                  <img
                    src={character.imageUrl}
                    alt={character.name}
                    className="w-16 h-16 object-contain animate-bounce"
                    style={{ filter: `drop-shadow(0 0 6px ${character.color})` }}
                  />
                ) : (child as any)?.avatarUrl ? (
                  <img
                    src={(child as any).avatarUrl}
                    alt={child.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-5xl">{appearance.avatarOverride ?? child.avatarEmoji}</span>
                )}
              </div>
              {/* زر تغيير الصورة */}
              <button
                onClick={() => setShowAvatarModal(true)}
                className="absolute -bottom-1 -left-1 w-7 h-7 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-purple-300 hover:scale-110 transition-transform"
                title="غيّر صورتك"
              >
                <Camera className="w-3.5 h-3.5 text-purple-600" />
              </button>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold" style={{ fontFamily: "Fredoka One, Tajawal, sans-serif" }}>
                {child.name}
              </h2>
              <p className="text-white/70 text-sm">الفئة العمرية: {child.ageGroup} سنوات</p>
              <div className="flex items-center gap-2 mt-1">
                <Crown className="h-4 w-4 text-yellow-300" />
                <span className="font-bold text-yellow-300">المستوى {currentLevel} من {MAX_LEVEL}</span>
              </div>
            </div>
          </div>

          {/* Level Progress */}
          <div className="mt-4 bg-white/20 rounded-2xl p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-bold">التقدم للمستوى {Math.min(currentLevel + 1, MAX_LEVEL)}</span>
              <span className="text-xs text-white/70">{levelProgress}/{nextLevelPoints} نقطة</span>
            </div>
            <div className="h-3 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-1000"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <p className="text-xs text-white/60 mt-1 text-center">
              تحتاج {pointsToNextLevel} نقطة للوصول للمستوى {Math.min(currentLevel + 1, MAX_LEVEL)} (كل {POINTS_PER_LEVEL} نقطة = مستوى)
            </p>
          </div>
          {/* Story Level Indicator - مؤشر مستوى القصص */}
          <div className="mt-3 bg-white/10 rounded-2xl p-3">
            <p className="text-xs text-white/80 font-bold mb-2 text-center">مستوىك في القصص</p>
            <div className="flex gap-2 justify-center">
              {([
                { key: 'easy' as const, label: 'مبتدئ', emoji: '🟢', activeClass: 'bg-green-400 ring-4 ring-green-200 scale-110 shadow-lg' },
                { key: 'medium' as const, label: 'متوسط', emoji: '🟡', activeClass: 'bg-yellow-400 ring-4 ring-yellow-200 scale-110 shadow-lg' },
                { key: 'hard' as const, label: 'متقدم', emoji: '🔴', activeClass: 'bg-red-400 ring-4 ring-red-200 scale-110 shadow-lg' },
              ]).map((lvl) => {
                const isActive = data?.currentStoryLevel === lvl.key;
                return (
                  <div key={lvl.key}
                    className={`flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all duration-500 ${
                      isActive ? lvl.activeClass : 'bg-white/20'
                    }`}>
                    <span className="text-xl">{lvl.emoji}</span>
                    <span className={`text-xs font-bold ${isActive ? 'text-white' : 'text-white/60'}`}>{lvl.label}</span>
                    {isActive && <span className="text-xs text-white/90">♥ أنت هنا</span>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Customize Avatar Button */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-purple-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${appearance.themeGradient} flex items-center justify-center text-2xl ${appearance.frameClass} overflow-hidden`}>
                {(child as any)?.avatarUrl ? (
                  <img src={(child as any).avatarUrl} alt={child.name} className="w-full h-full object-cover" />
                ) : (
                  appearance.avatarOverride ?? child.avatarEmoji
                )}
              </div>
              <div>
                <p className="font-bold text-sm text-foreground">مظهر بطاقتي</p>
                <p className="text-xs text-muted-foreground">
                  {appearance.hasCustomization ? '✨ مخصص' : 'افتراضي - خصّص من المتجر!'}
                </p>
              </div>
            </div>
            <button
              onClick={() => navigate('/shop')}
              className="flex items-center gap-1.5 bg-purple-600 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-purple-700 transition-colors"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              تخصيص
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-3xl p-5 shadow-sm text-center">
            <div className="text-4xl mb-2">📖</div>
            <div className="text-3xl font-bold text-primary">{data?.completedStories ?? 0}</div>
            <div className="text-xs text-muted-foreground mt-1">قصة مقروءة</div>
          </div>
          <div className="bg-white rounded-3xl p-5 shadow-sm text-center">
            <div className="text-4xl mb-2">🎮</div>
            <div className="text-3xl font-bold text-secondary">{data?.completedActivities ?? 0}</div>
            <div className="text-xs text-muted-foreground mt-1">نشاط مكتمل</div>
          </div>
          <div className="bg-white rounded-3xl p-5 shadow-sm text-center">
            <div className="text-4xl mb-2">⭐</div>
            <div className="text-3xl font-bold text-yellow-500">{child.totalPoints}</div>
            <div className="text-xs text-muted-foreground mt-1">نقطة مجموعة</div>
          </div>
          <div className="bg-white rounded-3xl p-5 shadow-sm text-center">
            <div className="text-4xl mb-2">🏆</div>
            <div className="text-3xl font-bold text-purple-500">{earnedAchievements.length}</div>
            <div className="text-xs text-muted-foreground mt-1">إنجاز محقق</div>
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-3xl p-5 shadow-sm">
          <h3 className="font-bold text-foreground text-lg mb-4 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            الإنجازات والشارات
          </h3>
          {allAchievements.length > 0 ? (
            <div className="grid grid-cols-4 gap-3">
              {allAchievements.map((ach) => {
                const isEarned = earnedAchievements.some((e) => e.achievementId === ach.id);
                return (
                  <div
                    key={ach.id}
                    className={`text-center p-3 rounded-2xl transition-all ${
                      isEarned
                        ? "bg-primary/10 border-2 border-primary/30"
                        : "bg-muted/50 opacity-40 grayscale"
                    }`}
                    title={ach.description || ach.title}
                  >
                    <div className={`text-3xl mb-1 ${isEarned ? "" : ""}`}>{ach.emoji}</div>
                    <div className="text-xs font-bold text-foreground line-clamp-2">{ach.title}</div>
                    {isEarned && (
                      <div className="text-xs text-primary mt-1">✓ محقق</div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-4xl mb-2">🎯</div>
              <p className="text-muted-foreground text-sm">ابدأ القراءة لتحصل على إنجازات!</p>
            </div>
          )}
        </div>

        {/* Daily Challenge Card */}
        <DailyChallengeCard childId={child.id} />

        {/* Adventures Progress */}
        <div className="bg-white rounded-3xl p-5 shadow-sm">
          <h3 className="font-bold text-foreground text-lg mb-4 flex items-center gap-2">
            <Map className="h-5 w-5 text-indigo-500" />
            مغامرات القصة 🧩
          </h3>
          <AdventuresProgress childId={child.id} />
        </div>

        {/* Shop CTA */}
        <button
          onClick={() => navigate("/shop")}
          className="w-full bg-gradient-to-r from-pink-400 to-rose-500 rounded-3xl p-4 text-white flex items-center gap-4 shadow-md hover:shadow-lg transition-all"
        >
          <div className="bg-white/20 rounded-2xl p-3">
            <ShoppingBag className="w-8 h-8 text-white" />
          </div>
          <div className="text-right flex-1">
            <p className="font-bold text-lg">متجر المكافآت 🛒</p>
            <p className="text-white/80 text-sm">لديك {child.totalPoints} نقطة — استبدلها بجوائز رائعة!</p>
          </div>
          <span className="text-2xl">→</span>
        </button>

        {/* قسم ردود الفعل التعبيرية من المعلمة */}
        {(myReactions as any[]).length > 0 && (() => {
          const reactions = myReactions as any[];
          const unseenCount = reactions.filter((rx: any) => !rx.seenByChild).length;
          // تجميع الردود حسب التسجيل
          const byRecording: Record<string, { title: string; storyTitle: string; pageNumber: number | null; reactions: any[] }> = {};
          reactions.forEach((rx: any) => {
            const key = String(rx.recordingId);
            if (!byRecording[key]) {
              byRecording[key] = {
                title: rx.recordingTitle || 'تسجيل',
                storyTitle: rx.storyTitle || '',
                pageNumber: rx.pageNumber ?? null,
                reactions: [],
              };
            }
            byRecording[key].reactions.push(rx);
          });
          return (
            <div className="bg-white rounded-3xl p-5 shadow-sm border-2 border-yellow-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-foreground text-lg flex items-center gap-2">
                  <span className="text-2xl">💌</span>
                  رسائل المعلمة
                  {unseenCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold rounded-full px-2 py-0.5">{unseenCount} جديد</span>
                  )}
                </h3>
                {unseenCount > 0 && (
                  <button
                    onClick={() => {
                      const ids = reactions.filter((rx: any) => !rx.seenByChild).map((rx: any) => rx.id);
                      markReactionsSeenMutation.mutate({ reactionIds: ids }, { onSuccess: () => refetchReactions() });
                    }}
                    className="text-xs text-yellow-600 underline hover:text-yellow-800"
                  >تعليم الكل كمقروء</button>
                )}
              </div>
              <div className="space-y-3">
                {Object.entries(byRecording).map(([recId, rec]) => (
                  <div key={recId} className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-2xl p-4 border border-yellow-100">
                    {/* معلومات التسجيل */}
                    <div className="flex items-start gap-2 mb-3">
                      <span className="text-xl mt-0.5">🎤</span>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-sm text-gray-800 truncate">{rec.title}</p>
                        {rec.storyTitle && (
                          <p className="text-xs text-gray-500 flex items-center gap-1">
                            <span>📖</span>
                            {rec.storyTitle}
                            {rec.pageNumber && <span className="text-gray-400">· صفحة {rec.pageNumber}</span>}
                          </p>
                        )}
                      </div>
                    </div>
                    {/* الردود التعبيرية */}
                    <div className="flex flex-wrap gap-2">
                      {rec.reactions.map((rx: any) => (
                        <div
                          key={rx.id}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-bold border-2 transition-all ${
                            !rx.seenByChild
                              ? 'bg-yellow-200 border-yellow-400 shadow-md animate-pulse'
                              : 'bg-white border-yellow-200 text-gray-700'
                          }`}
                        >
                          <span className="text-xl">{rx.emoji}</span>
                          <span className={!rx.seenByChild ? 'text-yellow-800' : 'text-gray-600'}>{rx.label}</span>
                        </div>
                      ))}
                    </div>
                    {/* تاريخ آخر رد */}
                    <p className="text-xs text-gray-400 mt-2 text-left">
                      {new Date(rec.reactions[0].createdAt).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long' })}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        {/* بطاقة تسجيلاتي */}
        <button
          onClick={() => navigate('/my-recordings')}
          className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-3xl p-4 text-white flex items-center gap-4 shadow-md hover:shadow-lg transition-all"
        >
          <div className="bg-white/20 rounded-2xl p-3">
            <span className="text-3xl">🎤</span>
          </div>
          <div className="text-right flex-1">
            <p className="font-bold text-lg">تسجيلاتي 🎤</p>
            <p className="text-white/80 text-sm">سجّل صوتك وأنت تقرأ القصص!</p>
          </div>
          <span className="text-2xl">→</span>
        </button>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <Button
            onClick={() => navigate("/home")}
            className="h-14 rounded-2xl font-bold text-base gap-2"
          >
            <BookOpen className="h-5 w-5" />
            اقرأ قصة
          </Button>
          <Button
            onClick={() => navigate("/adventures")}
            variant="outline"
            className="h-14 rounded-2xl font-bold text-base gap-2 border-2 border-indigo-400 text-indigo-600 hover:bg-indigo-50"
          >
            <Map className="h-5 w-5" />
            مغامرة جديدة
          </Button>
        </div>
      </main>

      {/* نافذة تغيير الصورة الشخصية */}
      {showAvatarModal && (
        <div
          className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 p-4"
          onClick={() => { setShowAvatarModal(false); setAvatarPreview(null); setAvatarFile(null); }}
        >
          <div
            className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl"
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* رأس النافذة */}
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-gray-800">تغيير صورتك 📸</h2>
              <button
                onClick={() => { setShowAvatarModal(false); setAvatarPreview(null); setAvatarFile(null); }}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200"
              >
                <X className="w-4 h-4 text-gray-600" />
              </button>
            </div>

            {/* معاينة الصورة */}
            <div className="flex flex-col items-center gap-4 mb-5">
              <div className="w-32 h-32 rounded-full overflow-hidden bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center border-4 border-purple-300 shadow-lg">
                {avatarPreview ? (
                  <img src={avatarPreview} alt="معاينة" className="w-full h-full object-cover" />
                ) : (child as any)?.avatarUrl ? (
                  <img src={(child as any).avatarUrl} alt={child.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-6xl">{child.avatarEmoji}</span>
                )}
              </div>
              <p className="text-sm text-gray-500 text-center">
                {avatarPreview ? "هذه ستكون صورتك الجديدة" : "صورتك الحالية"}
              </p>
            </div>

            {/* زر اختيار الصورة */}
            <input
              ref={avatarInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleAvatarFileChange}
            />
            <button
              onClick={() => avatarInputRef.current?.click()}
              className="w-full py-3 rounded-2xl border-2 border-dashed border-purple-300 text-purple-600 font-bold flex items-center justify-center gap-2 hover:bg-purple-50 transition-colors mb-3"
            >
              <Upload className="w-5 h-5" />
              {avatarPreview ? "اختر صورة أخرى" : "اختر صورة من جهازك"}
            </button>

            {/* أزرار الحفظ والإلغاء */}
            {avatarPreview && (
              <Button
                onClick={handleAvatarUpload}
                disabled={uploadingAvatar}
                className="w-full h-12 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold text-base"
              >
                {uploadingAvatar ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    جاري الحفظ...
                  </span>
                ) : (
                  "✅ احفظ الصورة الجديدة"
                )}
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
