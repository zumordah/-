import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { School, User, Mail, Lock, Phone, FileText, CheckCircle, ArrowRight } from "lucide-react";

export default function SchoolRegister() {
  const [, navigate] = useLocation();
  const [submitted, setSubmitted] = useState(false);

  const [form, setForm] = useState({
    schoolName: "",
    adminName: "",
    adminEmail: "",
    password: "",
    confirmPassword: "",
    phone: "",
    notes: "",
  });

  const registerMutation = trpc.schools.requestRegistration.useMutation();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.schoolName.trim()) { toast.error("يرجى إدخال اسم المدرسة"); return; }
    if (!form.adminName.trim()) { toast.error("يرجى إدخال اسم المديرة"); return; }
    if (!form.adminEmail.trim()) { toast.error("يرجى إدخال البريد الإلكتروني"); return; }
    if (form.password.length < 6) { toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل"); return; }
    if (form.password !== form.confirmPassword) { toast.error("كلمة المرور وتأكيدها غير متطابقتين"); return; }

    try {
      await registerMutation.mutateAsync({
        schoolName: form.schoolName,
        adminName: form.adminName,
        adminEmail: form.adminEmail,
        password: form.password,
        phone: form.phone || undefined,
        notes: form.notes || undefined,
      });
      setSubmitted(true);
    } catch (err: any) {
      if (err?.message?.includes("CONFLICT") || err?.message?.includes("مسبق")) {
        toast.error("يوجد طلب تسجيل مسبق بهذا البريد الإلكتروني");
      } else {
        toast.error("حدث خطأ، يرجى المحاولة مرة أخرى");
      }
    }
  };

  if (submitted) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        }}
      >
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">تم إرسال طلبك!</h2>
          <p className="text-gray-600 mb-6 leading-relaxed">
            تم استلام طلب تسجيل <strong>{form.schoolName}</strong> بنجاح.
            سيتم مراجعة الطلب من قِبل الإدارة وإشعارك بالقبول أو الرفض على البريد الإلكتروني.
          </p>
          <div className="bg-blue-50 rounded-xl p-4 mb-6 text-right">
            <p className="text-sm text-blue-700 font-medium">بعد الموافقة يمكنك الدخول بـ:</p>
            <p className="text-sm text-blue-600 mt-1">البريد: <strong>{form.adminEmail}</strong></p>
            <p className="text-sm text-blue-600">كلمة المرور: التي اخترتها في هذا النموذج</p>
          </div>
          <Button
            onClick={() => navigate("/")}
            className="w-full rounded-xl bg-purple-600 hover:bg-purple-700 text-white"
          >
            <ArrowRight className="w-4 h-4 ml-2" />
            العودة للصفحة الرئيسية
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      }}
    >
      {/* خلفية ثابتة */}
      <div
        className="fixed inset-0 -z-10"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1600&q=80')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.15,
        }}
      />

      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-lg w-full" dir="rtl">
        {/* الهيدر */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <School className="w-8 h-8 text-purple-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">تسجيل مدرسة جديدة</h1>
          <p className="text-gray-500 text-sm mt-1">أرسل طلب الانضمام لمنصة قصة وفكرة</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* اسم المدرسة */}
          <div>
            <Label className="text-gray-700 font-medium flex items-center gap-2 mb-1">
              <School className="w-4 h-4 text-purple-500" />
              اسم المدرسة / الروضة
            </Label>
            <Input
              name="schoolName"
              value={form.schoolName}
              onChange={handleChange}
              placeholder="مثال: روضة الورود"
              className="rounded-xl border-2 focus:border-purple-400 h-11"
              required
            />
          </div>

          {/* اسم المديرة */}
          <div>
            <Label className="text-gray-700 font-medium flex items-center gap-2 mb-1">
              <User className="w-4 h-4 text-purple-500" />
              اسم المديرة / المسؤولة
            </Label>
            <Input
              name="adminName"
              value={form.adminName}
              onChange={handleChange}
              placeholder="مثال: زمردة عبد العزيز"
              className="rounded-xl border-2 focus:border-purple-400 h-11"
              required
            />
          </div>

          {/* البريد الإلكتروني */}
          <div>
            <Label className="text-gray-700 font-medium flex items-center gap-2 mb-1">
              <Mail className="w-4 h-4 text-purple-500" />
              البريد الإلكتروني
            </Label>
            <Input
              name="adminEmail"
              type="email"
              value={form.adminEmail}
              onChange={handleChange}
              placeholder="example@hotmail.com"
              className="rounded-xl border-2 focus:border-purple-400 h-11"
              dir="ltr"
              required
            />
          </div>

          {/* كلمة المرور */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-gray-700 font-medium flex items-center gap-2 mb-1">
                <Lock className="w-4 h-4 text-purple-500" />
                كلمة المرور
              </Label>
              <Input
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                placeholder="6 أحرف على الأقل"
                className="rounded-xl border-2 focus:border-purple-400 h-11"
                dir="ltr"
                required
              />
            </div>
            <div>
              <Label className="text-gray-700 font-medium mb-1 block">تأكيد كلمة المرور</Label>
              <Input
                name="confirmPassword"
                type="password"
                value={form.confirmPassword}
                onChange={handleChange}
                placeholder="أعد كتابة كلمة المرور"
                className={`rounded-xl border-2 h-11 ${
                  form.confirmPassword && form.password !== form.confirmPassword
                    ? "border-red-400 focus:border-red-400"
                    : "focus:border-purple-400"
                }`}
                dir="ltr"
                required
              />
            </div>
          </div>
          {form.confirmPassword && form.password !== form.confirmPassword && (
            <p className="text-red-500 text-xs -mt-2">كلمة المرور وتأكيدها غير متطابقتين</p>
          )}

          {/* رقم الهاتف (اختياري) */}
          <div>
            <Label className="text-gray-700 font-medium flex items-center gap-2 mb-1">
              <Phone className="w-4 h-4 text-purple-500" />
              رقم الهاتف <span className="text-gray-400 font-normal text-xs">(اختياري)</span>
            </Label>
            <Input
              name="phone"
              value={form.phone}
              onChange={handleChange}
              placeholder="05xxxxxxxx"
              className="rounded-xl border-2 focus:border-purple-400 h-11"
              dir="ltr"
            />
          </div>

          {/* ملاحظات (اختياري) */}
          <div>
            <Label className="text-gray-700 font-medium flex items-center gap-2 mb-1">
              <FileText className="w-4 h-4 text-purple-500" />
              ملاحظات إضافية <span className="text-gray-400 font-normal text-xs">(اختياري)</span>
            </Label>
            <Textarea
              name="notes"
              value={form.notes}
              onChange={handleChange}
              placeholder="أي معلومات إضافية تودّ إضافتها..."
              className="rounded-xl border-2 focus:border-purple-400 resize-none"
              rows={3}
            />
          </div>

          {/* زر الإرسال */}
          <Button
            type="submit"
            disabled={registerMutation.isPending}
            className="w-full h-12 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-base font-bold mt-2"
          >
            {registerMutation.isPending ? "جاري الإرسال..." : "إرسال طلب التسجيل"}
          </Button>

          {/* رابط العودة */}
          <button
            type="button"
            onClick={() => navigate("/")}
            className="w-full text-center text-sm text-gray-500 hover:text-purple-600 transition-colors mt-1"
          >
            العودة لصفحة الدخول
          </button>
        </form>
      </div>
    </div>
  );
}
