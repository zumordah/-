import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { Lock, Star, CheckCircle, Map, ArrowLeft, Sparkles, Trophy } from "lucide-react";
import { toAr } from "@/lib/arabicNumerals";
import { getCharacterById, getDefaultCharacter } from "@/data/charactersData";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

type Adventure = {
  id: number;
  title: string;
  description: string | null;
  emoji: string | null;
  level: string;
  pointsReward: number;
  totalEndings: number;
  orderIndex: number | null;
  isLocked?: boolean;
  lockCost?: number;
};

type Progress = {
  adventureId: number;
  isCompleted: boolean;
  endingsDiscovered: string[] | null;
  pointsEarned: number | null;
  attempts: number | null;
};

// ألوان المحطات حسب المستوى
const LEVEL_COLORS: Record<string, { bg: string; border: string; text: string; glow: string; path: string }> = {
  easy: {
    bg: "bg-emerald-400",
    border: "border-emerald-500",
    text: "text-emerald-700",
    glow: "shadow-emerald-300",
    path: "#10b981",
  },
  medium: {
    bg: "bg-amber-400",
    border: "border-amber-500",
    text: "text-amber-700",
    glow: "shadow-amber-300",
    path: "#f59e0b",
  },
  hard: {
    bg: "bg-rose-400",
    border: "border-rose-500",
    text: "text-rose-700",
    glow: "shadow-rose-300",
    path: "#f43f5e",
  },
};

// مواضع المحطات على الخريطة (مسار متعرج)
function getStationPosition(index: number): { left: string; marginTop: string } {
  const positions = [
    { left: "10%", marginTop: "0px" },
    { left: "35%", marginTop: "-20px" },
    { left: "60%", marginTop: "-10px" },
    { left: "80%", marginTop: "10px" },
    { left: "55%", marginTop: "30px" },
    { left: "30%", marginTop: "20px" },
    { left: "10%", marginTop: "10px" },
    { left: "35%", marginTop: "-15px" },
    { left: "65%", marginTop: "-5px" },
    { left: "85%", marginTop: "15px" },
  ];
  return positions[index % positions.length];
}

export default function AdventureMap() {
  const [, navigate] = useLocation();
  const { child } = useChild();
  const [selectedAdventure, setSelectedAdventure] = useState<Adventure | null>(null);
  const [charWalking, setCharWalking] = useState(false);

  const { data: adventures = [], isLoading } = trpc.adventures.list.useQuery({});
  const { data: myProgress = [] } = trpc.adventures.getChildProgress.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: unlockedAdvIds = [] } = trpc.adventures.getUnlockedAdventureIds.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: companionData } = trpc.companion.getMyCompanion.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id, staleTime: 60000 }
  );

  const characterId = (companionData as any)?.characterId ?? 'sami';
  const character = getCharacterById(characterId) ?? getDefaultCharacter();

  const unlockedAdvSet = new Set(unlockedAdvIds as number[]);
  const progressMap: Record<number, Progress> = {};
  (myProgress as Progress[]).forEach((p) => { progressMap[p.adventureId] = p; });

  const sortedAdventures = [...(adventures as Adventure[])].sort(
    (a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0)
  );

  const totalCompleted = (myProgress as Progress[]).filter((p) => p.isCompleted).length;
  const totalEndingsFound = (myProgress as Progress[]).reduce(
    (sum, p) => sum + ((p.endingsDiscovered as string[] | null)?.length ?? 0), 0
  );

  const isAdventureAccessible = (adv: Adventure) => {
    if (!adv.isLocked) return true;
    return unlockedAdvSet.has(adv.id);
  };

  const isAdventureCompleted = (adv: Adventure) => progressMap[adv.id]?.isCompleted === true;

  // تحديد المحطة التالية (أول محطة غير مكتملة)
  const nextAdventureIndex = sortedAdventures.findIndex(
    (adv) => isAdventureAccessible(adv) && !isAdventureCompleted(adv)
  );

  // حساب موضع الشخصية على الخريطة
  const charPosition = nextAdventureIndex >= 0
    ? (() => {
        const idx = nextAdventureIndex;
        const pos = getStationPosition(idx);
        const row = Math.floor(idx / 5);
        const topOffset = row * 200 + 60;
        return { left: pos.left, top: topOffset };
      })()
    : { left: '50%', top: Math.ceil(sortedAdventures.length / 5) * 200 + 20 };

  // تأثير المشي عند تحميل الصفحة أو تغيير الموضع
  useEffect(() => {
    if (sortedAdventures.length === 0) return;
    setCharWalking(true);
    const t = setTimeout(() => setCharWalking(false), 1400);
    return () => clearTimeout(t);
  }, [nextAdventureIndex, sortedAdventures.length]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-300 via-emerald-200 to-amber-100 pb-20 overflow-x-hidden" dir="rtl">
      {/* ─── Header ─────────────────────────────────────────────── */}
      <div className="sticky top-0 z-20 bg-white/90 backdrop-blur-sm shadow-sm">
        <div className="px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="flex-shrink-0">
            <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
          </button>
          <button
            onClick={() => navigate("/adventures")}
            className="flex items-center gap-1 text-xs text-purple-600 bg-purple-50 border border-purple-200 px-2 py-1.5 rounded-full hover:bg-purple-100 transition-colors"
          >
            <ArrowLeft className="w-3 h-3" />
            المغامرات
          </button>
          <div className="flex-1" />
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-yellow-50 border border-yellow-200 px-2 py-1 rounded-full">
              <Trophy className="w-3.5 h-3.5 text-yellow-500" />
              <span className="text-xs font-bold text-yellow-700">{toAr(totalCompleted)} مكتملة</span>
            </div>
            <div className="flex items-center gap-1 bg-purple-50 border border-purple-200 px-2 py-1 rounded-full">
              <Star className="w-3.5 h-3.5 text-purple-500" />
              <span className="text-xs font-bold text-purple-700">{toAr(totalEndingsFound)} نهاية</span>
            </div>
          </div>
        </div>
      </div>

      {/* ─── عنوان الخريطة ─────────────────────────────────────── */}
      <div className="text-center pt-6 pb-2 px-4">
        <div className="inline-flex items-center gap-2 bg-white/80 rounded-2xl px-4 py-2 shadow-md">
          <Map className="w-5 h-5 text-indigo-600" />
          <h1 className="text-lg font-black text-indigo-800">خريطة المغامرات 🗺️</h1>
        </div>
        <p className="text-sm text-emerald-700 mt-2 font-medium">
          {nextAdventureIndex >= 0
            ? `المحطة التالية: ${sortedAdventures[nextAdventureIndex]?.title}`
            : "أكملت جميع المغامرات! 🏆"}
        </p>
      </div>

      {/* ─── شريط التقدم العام ─────────────────────────────────── */}
      <div className="mx-4 mt-3 mb-4 bg-white/70 rounded-2xl p-3 shadow-sm">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-bold text-gray-600">التقدم الكلي</span>
          <span className="text-xs font-bold text-indigo-600">
            {toAr(totalCompleted)} / {toAr(sortedAdventures.length)}
          </span>
        </div>
        <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-400 to-purple-500 rounded-full transition-all duration-700"
            style={{ width: `${sortedAdventures.length > 0 ? (totalCompleted / sortedAdventures.length) * 100 : 0}%` }}
          />
        </div>
      </div>

      {/* ─── الخريطة ─────────────────────────────────────────────── */}
      {isLoading ? (
        <div className="flex justify-center items-center py-20">
          <div className="w-12 h-12 border-4 border-indigo-400 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="relative px-4">
          {/* مسار الخريطة - خط متعرج خلفي مع تلوين التقدم */}
          {(() => {
            const totalH = Math.ceil(sortedAdventures.length / 5) * 200 + 100;
            const pathD = "M 40 60 Q 200 40 360 80 Q 200 120 40 160 Q 200 200 360 240 Q 200 280 40 320 Q 200 360 360 400 Q 200 440 40 480";
            // حساب نسبة التقدم لتحديد طول المسار الملوّن
            const progressRatio = sortedAdventures.length > 0 ? totalCompleted / sortedAdventures.length : 0;
            const totalPathLen = 800; // تقريبي
            const completedLen = progressRatio * totalPathLen;
            return (
              <svg
                className="absolute inset-0 w-full pointer-events-none"
                style={{ height: `${totalH}px` }}
                viewBox={`0 0 400 ${totalH}`}
                preserveAspectRatio="none"
              >
                {/* مسار خلفي رمادي */}
                <path d={pathD} fill="none" stroke="#e5e7eb" strokeWidth="20" strokeLinecap="round" strokeLinejoin="round" />
                {/* مسار التقدم المكتمل - أخضر */}
                <path
                  d={pathD}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="20"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray={`${completedLen} ${totalPathLen}`}
                  strokeDashoffset="0"
                  style={{ transition: 'stroke-dasharray 1s ease' }}
                />
                {/* خط متقطع فوق المسار */}
                <path d={pathD} fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="12 8" opacity="0.5" />
              </svg>
            );
          })()}

          {/* محطات المغامرات */}
          <div
            className="relative"
            style={{ minHeight: `${Math.ceil(sortedAdventures.length / 5) * 200 + 100}px` }}
          >
            {sortedAdventures.map((adv, index) => {
              const accessible = isAdventureAccessible(adv);
              const completed = isAdventureCompleted(adv);
              const isNext = index === nextAdventureIndex;
              const progress = progressMap[adv.id];
              const colors = LEVEL_COLORS[adv.level] ?? LEVEL_COLORS.easy;
              const pos = getStationPosition(index);

              // حساب الموضع العمودي
              const row = Math.floor(index / 5);
              const topOffset = row * 200 + 60;

              return (
                <div
                  key={adv.id}
                  className="absolute"
                  style={{
                    left: pos.left,
                    top: `${topOffset}px`,
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  {/* نبضة للمحطة التالية */}
                  {isNext && (
                    <div className="absolute inset-0 rounded-full bg-yellow-300 animate-ping opacity-60 scale-150" />
                  )}

                  {/* زر المحطة */}
                  <button
                    onClick={() => accessible ? setSelectedAdventure(adv) : null}
                    className={`relative w-16 h-16 rounded-full border-4 flex items-center justify-center text-2xl transition-all duration-200 shadow-lg
                      ${completed
                        ? `${colors.bg} ${colors.border} shadow-lg ${colors.glow} scale-100`
                        : accessible
                        ? `bg-white ${colors.border} hover:scale-110 active:scale-95 ${isNext ? "ring-4 ring-yellow-300 ring-offset-2" : ""}`
                        : "bg-gray-200 border-gray-300 opacity-60 cursor-not-allowed"
                      }`}
                  >
                    {completed ? (
                      <CheckCircle className="w-7 h-7 text-white" />
                    ) : !accessible ? (
                      <Lock className="w-6 h-6 text-gray-400" />
                    ) : (
                      <span>{adv.emoji ?? "⭐"}</span>
                    )}

                    {/* رقم المحطة */}
                    <span className="absolute -top-2 -right-2 w-5 h-5 bg-white border-2 border-gray-300 rounded-full text-[10px] font-black text-gray-600 flex items-center justify-center">
                      {toAr(index + 1)}
                    </span>

                    {/* نجوم الإنجاز */}
                    {completed && progress?.endingsDiscovered && (
                      <div className="absolute -bottom-2 flex gap-0.5">
                        {Array.from({ length: Math.min((progress.endingsDiscovered as string[]).length, 3) }).map((_, i) => (
                          <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        ))}
                      </div>
                    )}
                  </button>

                  {/* اسم المحطة */}
                  <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-white/80 shadow-sm
                      ${completed ? colors.text : accessible ? "text-gray-700" : "text-gray-400"}`}>
                      {adv.title.length > 8 ? adv.title.slice(0, 8) + "…" : adv.title}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* ─── الشخصية المرافقة تتحرك على الخريطة ─── */}
            {child && sortedAdventures.length > 0 && (
              <div
                className="absolute z-10 pointer-events-none"
                style={{
                  left: charPosition.left,
                  top: `${charPosition.top - 55}px`,
                  transform: 'translate(-50%, -50%)',
                  transition: 'left 1.2s cubic-bezier(0.34,1.56,0.64,1), top 1.2s cubic-bezier(0.34,1.56,0.64,1)',
                }}
              >
                {/* فقاعة حوار */}
                <div
                  className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-white rounded-xl px-2 py-0.5 text-[10px] font-bold shadow-md border"
                  style={{ borderColor: character.color, color: character.color }}
                >
                  {nextAdventureIndex >= 0 ? 'هنا التالي! 👆' : '🏆 أكملنا!'}
                </div>
                <img
                  src={character.imageUrl}
                  alt={character.name}
                  className="w-12 h-12 object-contain"
                  style={{
                    filter: `drop-shadow(0 0 6px ${character.color})`,
                    animation: charWalking
                      ? 'charWalk 0.35s ease-in-out infinite alternate'
                      : 'charBob 2s ease-in-out infinite',
                  }}
                />
                <style>{`
                  @keyframes charWalk {
                    0%   { transform: translateY(0) rotate(-8deg) scaleX(1); }
                    100% { transform: translateY(-6px) rotate(8deg) scaleX(-1); }
                  }
                  @keyframes charBob {
                    0%, 100% { transform: translateY(0) scale(1); }
                    50%       { transform: translateY(-5px) scale(1.05); }
                  }
                `}</style>
              </div>
            )}

            {/* نهاية المسار - كنز */}
            <div
              className="absolute"
              style={{
                left: "50%",
                top: `${Math.ceil(sortedAdventures.length / 5) * 200 + 20}px`,
                transform: "translate(-50%, -50%)",
              }}
            >
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 border-4 border-yellow-600 flex items-center justify-center text-3xl shadow-xl shadow-yellow-300">
                {totalCompleted === sortedAdventures.length ? "🏆" : "🎁"}
              </div>
              <p className="text-center text-xs font-bold text-amber-700 mt-2">الكنز الكبير!</p>
            </div>
          </div>
        </div>
      )}

      {/* ─── نافذة تفاصيل المغامرة ─────────────────────────────── */}
      {selectedAdventure && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm"
          onClick={() => setSelectedAdventure(null)}
        >
          <div
            className="w-full max-w-md bg-white rounded-t-3xl p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* إيموجي المغامرة */}
            <div className="text-center mb-4">
              <div className="text-6xl mb-2">{selectedAdventure.emoji ?? "⭐"}</div>
              <h2 className="text-xl font-black text-gray-800">{selectedAdventure.title}</h2>
              {selectedAdventure.description && (
                <p className="text-sm text-gray-500 mt-1">{selectedAdventure.description}</p>
              )}
            </div>

            {/* إحصائيات */}
            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="text-center bg-purple-50 rounded-2xl p-3">
                <div className="text-lg font-black text-purple-700">
                  {toAr(selectedAdventure.pointsReward)}
                </div>
                <div className="text-xs text-purple-500">نقطة</div>
              </div>
              <div className="text-center bg-blue-50 rounded-2xl p-3">
                <div className="text-lg font-black text-blue-700">
                  {toAr(selectedAdventure.totalEndings)}
                </div>
                <div className="text-xs text-blue-500">نهاية</div>
              </div>
              <div className="text-center bg-emerald-50 rounded-2xl p-3">
                <div className="text-lg font-black text-emerald-700">
                  {isAdventureCompleted(selectedAdventure) ? "✅" : "⏳"}
                </div>
                <div className="text-xs text-emerald-500">
                  {isAdventureCompleted(selectedAdventure) ? "مكتملة" : "لم تبدأ"}
                </div>
              </div>
            </div>

            {/* زر البدء */}
            <button
              onClick={() => {
                setSelectedAdventure(null);
                navigate(`/adventure/${selectedAdventure.id}`);
              }}
              className="w-full py-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-2xl font-black text-lg hover:from-indigo-600 hover:to-purple-700 active:scale-95 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5" />
              {isAdventureCompleted(selectedAdventure) ? "العب مرة أخرى 🔄" : "ابدأ المغامرة! 🚀"}
            </button>

            <button
              onClick={() => setSelectedAdventure(null)}
              className="w-full mt-2 py-2 text-gray-400 text-sm hover:text-gray-600 transition-colors"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
