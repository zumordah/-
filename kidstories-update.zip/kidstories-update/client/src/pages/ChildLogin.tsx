import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { BookOpen, Sparkles, ArrowLeft, Shield, Camera, X, School } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

const AVATARS = ["🧒", "👦", "👧", "🧑", "👶", "🦊", "🐼", "🦁", "🐸", "🦋"];
const AGE_GROUPS = [
  { value: "4-6", label: "٤ - ٦ سنوات", emoji: "🌱" },
  { value: "6-8", label: "٦ - ٨ سنوات", emoji: "🌟" },
  { value: "8-10", label: "٨ - ١٠ سنوات", emoji: "🚀" },
];

const BG_ELEMENTS = [
  { emoji: "⭐", top: "8%", right: "8%", size: "text-5xl", delay: "0s", duration: "3s" },
  { emoji: "🌙", top: "15%", left: "12%", size: "text-4xl", delay: "1s", duration: "4s" },
  { emoji: "✨", top: "30%", right: "5%", size: "text-3xl", delay: "2s", duration: "3.5s" },
  { emoji: "🌈", bottom: "15%", left: "8%", size: "text-4xl", delay: "0.5s", duration: "4s" },
  { emoji: "📚", top: "45%", left: "4%", size: "text-3xl", delay: "1.5s", duration: "3s" },
  { emoji: "🎯", top: "20%", right: "4%", size: "text-3xl", delay: "2.5s", duration: "3.5s" },
  { emoji: "👧", bottom: "30%", right: "6%", size: "text-4xl", delay: "0.8s", duration: "4.5s" },
  { emoji: "👦", top: "60%", left: "6%", size: "text-4xl", delay: "1.8s", duration: "3.8s" },
  { emoji: "📖", bottom: "45%", right: "10%", size: "text-3xl", delay: "0.3s", duration: "4s" },
  { emoji: "🏆", top: "75%", right: "15%", size: "text-3xl", delay: "2.2s", duration: "3.2s" },
  { emoji: "🌟", bottom: "60%", left: "15%", size: "text-2xl", delay: "1.2s", duration: "5s" },
  { emoji: "🎓", top: "85%", left: "20%", size: "text-3xl", delay: "0.7s", duration: "3.7s" },
  { emoji: "💡", top: "5%", left: "40%", size: "text-2xl", delay: "1.7s", duration: "4.2s" },
  { emoji: "🌺", bottom: "8%", right: "35%", size: "text-3xl", delay: "2.7s", duration: "3.3s" },
  { emoji: "🦋", top: "50%", right: "20%", size: "text-2xl", delay: "3s", duration: "5s" },
  { emoji: "🎨", bottom: "25%", left: "25%", size: "text-2xl", delay: "1.3s", duration: "4.7s" },
];

export default function ChildLogin() {
  const [, navigate] = useLocation();
  const { setChild } = useChild();
  const [step, setStep] = useState<"welcome" | "register" | "login">("welcome");
  const [regStep, setRegStep] = useState<1 | 2>(1);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [ageGroup, setAgeGroup] = useState<"4-6" | "6-8" | "8-10" | "">("");
  const [selectedAvatar, setSelectedAvatar] = useState("🧒");
  const [gender, setGender] = useState<"boy" | "girl" | "">("" );
  const [isKindergarten, setIsKindergarten] = useState<boolean | null>(null);
  const [classroom, setClassroom] = useState("");
  const [selectedSchoolId, setSelectedSchoolId] = useState<number | null>(null);
  const [referralSource, setReferralSource] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminRememberMe, setAdminRememberMe] = useState(false);
  const [childRememberMe, setChildRememberMe] = useState(false);
  const [isAdminLoading, setIsAdminLoading] = useState(false);

  // حالة رفع الصورة
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const registerMutation = trpc.children.register.useMutation();
  const loginMutation = trpc.children.login.useMutation();
  const uploadAvatarMutation = trpc.children.uploadAvatar.useMutation();
  const { data: publicSchools } = trpc.schools.listPublic.useQuery();
  const { data: schoolClassrooms } = trpc.schools.getClassrooms.useQuery(
    { schoolId: selectedSchoolId! },
    { enabled: !!selectedSchoolId }
  );

  const adminLoginMutation = trpc.admin.login.useMutation();
  const ADMIN_EMAIL = "shmo5_20-9@hotmail.com";
  const handleAdminLogin = async () => {
    if (!adminEmail.trim()) { toast.error("يرجى إدخال البريد الإلكتروني"); return; }
    if (!adminPassword.trim()) { toast.error("يرجى إدخال كلمة المرور"); return; }
    setIsAdminLoading(true);
    try {
      const result = await adminLoginMutation.mutateAsync({ email: adminEmail.trim().toLowerCase(), password: adminPassword.trim() });
      const sessionData = {
        email: result.email,
        name: result.name,
        role: result.role,
        schoolId: result.schoolId ?? null,
        school: result.school ?? null,
        adminToken: result.adminToken ?? null,
        loginTime: Date.now()
      };
      // تحديد مدة الجلسة بناءً على تذكرني
      const sessionWithExpiry = { ...sessionData, rememberMe: adminRememberMe };
      localStorage.setItem("adminSession", JSON.stringify(sessionWithExpiry));
      toast.success("مرحباً بك في لوحة التحكم!");
      if (result.role === "school_admin") {
        navigate("/school-admin");
      } else {
        navigate("/admin");
      }
    } catch (err: any) {
      toast.error("بيانات الدخول غير صحيحة");
    } finally { setIsAdminLoading(false); }
  };

  // معالجة اختيار الصورة
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("حجم الصورة كبير جداً (الحد الأقصى 5 ميغابايت)");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setPhotoPreview(result);
      setPhotoBase64(result);
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setPhotoPreview(null);
    setPhotoBase64(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleRegisterStep1 = () => {
    const nameParts = name.trim().split(/\s+/);
    if (nameParts.length < 3) { toast.error("يرجى إدخال الاسم الثلاثي كاملاً"); return; }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast.error("يرجى إدخال بريد إلكتروني صحيح"); return; }
    if (!password.trim() || password.length < 6) { toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل"); return; }
    if (password !== confirmPassword) { toast.error("كلمة المرور وتأكيدها غير متطابقتين"); return; }
    if (!ageGroup) { toast.error("يرجى اختيار الفئة العمرية"); return; }
    if (!gender) { toast.error("يرجى اختيار الجنس"); return; }
    setRegStep(2);
  };

  const handleRegister = async () => {
    if (isKindergarten === null) { toast.error("يرجى الإجابة على السؤال"); return; }
    if (isKindergarten && !selectedSchoolId) { toast.error("يرجى اختيار المدرسة"); return; }
    if (isKindergarten && !classroom) { toast.error("يرجى اختيار الفصل"); return; }
    if (!isKindergarten && !referralSource) { toast.error("يرجى اختيار كيف عرفت عنا"); return; }
    setIsLoading(true);
    try {
      const result = await registerMutation.mutateAsync({
        name: name.trim(), email: email.trim().toLowerCase(),
        ageGroup: ageGroup as "4-6" | "6-8" | "8-10", avatarEmoji: selectedAvatar,
        isKindergartenStudent: isKindergarten,
        classroom: isKindergarten ? (classroom as any) : undefined,
        schoolId: isKindergarten ? (selectedSchoolId ?? undefined) : undefined,
        referralSource: !isKindergarten ? (referralSource as any) : undefined,
        gender: (gender || "boy") as "boy" | "girl",
        password: password || undefined,
      });

      // رفع الصورة إذا اختار الطفل صورة
      if (photoBase64 && result.child?.id) {
        setIsUploadingPhoto(true);
        try {
          toast.info("جارٍ معالجة صورتك...");
          const uploadResult = await uploadAvatarMutation.mutateAsync({
            childId: result.child.id,
            base64: photoBase64,
            contentType: "image/jpeg",
          });
          // تحديث الطفل بالـ avatarUrl الجديد
          const childWithAvatar = { ...result.child, avatarUrl: uploadResult.url };
          setChild(childWithAvatar as any);
        } catch (uploadErr) {
          console.error("Photo upload failed:", uploadErr);
          // إذا فشل رفع الصورة، نكمل التسجيل بدونها
          setChild(result.child as any);
        } finally {
          setIsUploadingPhoto(false);
        }
      } else {
        setChild(result.child as any);
      }

      toast.success(result.isNew ? `مرحباً ${result.child.name}! تم إنشاء حسابك بنجاح` : `أهلاً بعودتك ${result.child.name}!`);
      navigate("/home");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ، يرجى المحاولة مرة أخرى");
    } finally { setIsLoading(false); }
  };

  const handleLogin = async () => {
    if (!email.trim()) { toast.error("يرجى إدخال بريدك الإلكتروني"); return; }
    setIsLoading(true);
    try {
      const child = await loginMutation.mutateAsync({ email: email.trim().toLowerCase(), password: loginPassword || undefined });
      setChild(child as any, childRememberMe);
      toast.success(`أهلاً بعودتك ${child.name}!`);
      navigate("/home");
    } catch (error: any) {
      toast.error("لم نجد حسابك. هل أنت مسجل؟");
    } finally { setIsLoading(false); }
  };

  const BG_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/qissa_wa_fikra_frame_bg_af365322.jpg";

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden"
      dir="rtl"
      style={{
        minHeight: "100dvh",
        width: "100%",
      }}
    >
      {/* طبقة خلفية ثابتة تعمل على جميع الأجهزة بما فيها الجوال */}
      <div
        className="fixed inset-0 -z-10"
        style={{
          backgroundImage: `url(${BG_URL})`,
          backgroundSize: "cover",
          backgroundPosition: "center top",
          backgroundRepeat: "no-repeat",
        }}
      />
      {/* طبقة شفافة خفيفة لتحسين قراءة البطاقة */}
      <div className="absolute inset-0 bg-black/10 pointer-events-none" />

      {/* الشعار - يعيد للصفحة الرئيسية */}
      <div className="absolute top-4 right-4 z-20">
        <button onClick={() => navigate("/home")} className="block">
          <img src={LOGO_URL} alt="قصة وفكرة" className="w-20 h-20 object-contain drop-shadow-lg" style={{ filter: "drop-shadow(0 2px 8px rgba(0,0,0,0.15))" }} />
        </button>
      </div>

      <div className="w-full max-w-md relative z-10">
        {step === "welcome" && (
          <div className="bg-white/20 backdrop-blur-md rounded-3xl shadow-2xl overflow-hidden border border-white/30">
            <div className="bg-white/30 backdrop-blur-sm p-8 text-center border-b border-white/20">
              <div className="text-7xl mb-4 animate-float">📚</div>
              <h1 className="text-3xl font-bold mb-1 font-kids" style={{color:'#4a1a6b', textShadow:'0 2px 8px rgba(255,255,255,0.8)'}}>قصة وفكرة</h1>
              <p className="text-base font-bold mb-2" style={{color:'#6b21a8', textShadow:'0 1px 4px rgba(255,255,255,0.7)'}}>عالم القصص التفاعلية</p>
              <p className="text-sm font-semibold" style={{color:'#7c3aed', textShadow:'0 1px 4px rgba(255,255,255,0.7)'}}>مغامرات لا تنتهي تنتظرك!</p>
            </div>
            <div className="p-8 space-y-4">
              <div className="grid grid-cols-3 gap-3 mb-6">
                {["📖 قصص رائعة", "🎮 ألعاب ممتعة", "🏆 إنجازات"].map((item) => (
                  <div key={item} className="bg-white/70 backdrop-blur-sm rounded-2xl p-3 text-center text-sm font-bold" style={{color:'#4a1a6b'}}>{item}</div>
                ))}
              </div>
              <Button onClick={() => setStep("register")} className="w-full h-14 text-lg rounded-2xl bg-primary hover:bg-primary/90 font-bold shadow-lg">
                <Sparkles className="ml-2 h-5 w-5" /> أنا جديد - سجّل حسابي
              </Button>
              <Button onClick={() => setStep("login")} variant="outline" className="w-full h-14 text-lg rounded-2xl border-2 font-bold shadow-lg bg-white/70 hover:bg-white/90" style={{borderColor:'#7c3aed', color:'#4a1a6b'}}>
                <BookOpen className="ml-2 h-5 w-5" /> لديّ حساب - ادخل
              </Button>
            </div>
          </div>
        )}

        {step === "register" && (
          <div className="bg-white/20 backdrop-blur-md rounded-3xl shadow-2xl overflow-hidden border border-white/30">
            <div className="bg-white/30 backdrop-blur-sm p-6 text-center border-b border-white/20">
              <h2 className="text-2xl font-bold text-white font-kids drop-shadow-md">{regStep === 1 ? "أنشئ حسابك!" : "سؤالان سريعان"}</h2>
              <p className="text-white/90 mt-1 drop-shadow-sm">خطوة {regStep} من 2</p>
            </div>
            {regStep === 1 && (
              <div className="p-6 space-y-5 bg-white/10">
                {/* خانة رفع الصورة الشخصية */}
                <div>
                  <Label className="text-sm font-bold text-white drop-shadow-sm mb-2 block">📸 ارفع صورتك (اختياري)</Label>
                  <div className="flex items-center gap-4">
                    {/* معاينة الصورة أو زر الرفع */}
                    {photoPreview ? (
                      <div className="relative">
                        <img
                          src={photoPreview}
                          alt="صورتك"
                          className="w-20 h-20 rounded-full object-cover border-4 border-primary shadow-lg"
                        />
                        <button
                          onClick={handleRemovePhoto}
                          className="absolute -top-1 -left-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center shadow-md hover:bg-red-600 transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="w-20 h-20 rounded-full border-4 border-dashed border-white/60 bg-white/20 hover:bg-white/30 flex flex-col items-center justify-center gap-1 transition-all hover:scale-105"
                      >
                        <Camera className="w-6 h-6 text-white" />
                        <span className="text-xs text-white font-bold">رفع</span>
                      </button>
                    )}
                    <div className="flex-1">
                      {photoPreview ? (
                        <div className="space-y-1">
                          <p className="text-sm text-white font-bold">✅ تم اختيار الصورة</p>
                          <p className="text-xs text-white/80">سيتم قص الخلفية تلقائياً</p>
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            className="text-xs text-white/70 underline hover:text-white"
                          >
                            تغيير الصورة
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <p className="text-sm text-white font-bold">ارفع صورة وجهك</p>
                          <p className="text-xs text-white/80">ستظهر كأفاتار شخصي لك</p>
                          <p className="text-xs text-white/60">الحد الأقصى: 5 ميغابايت</p>
                        </div>
                      )}
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handlePhotoSelect}
                  />
                </div>

                {/* اختيار الأفاتار (إذا لم يرفع صورة) */}
                {!photoPreview && (
                  <div>
                    <Label className="text-sm font-bold text-white drop-shadow-sm mb-2 block">أو اختر صورتك من هنا</Label>
                    <div className="grid grid-cols-5 gap-2">
                      {AVATARS.map((avatar) => (
                        <button key={avatar} onClick={() => setSelectedAvatar(avatar)}
                          className={`text-3xl p-2 rounded-xl transition-all ${selectedAvatar === avatar ? "bg-primary/20 ring-2 ring-primary scale-110" : "bg-muted hover:bg-muted/80"}`}>
                          {avatar}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="name" className="text-sm font-bold text-white drop-shadow-sm mb-2 block">الاسم الثلاثي</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="الاسم الأول والثاني والثالث..." className="h-12 rounded-xl text-base border-2 focus:border-primary" />
                  <p className="text-xs text-muted-foreground mt-1">مثال: محمد علي الأحمدي</p>
                </div>
                <div>
                  <Label htmlFor="email" className="text-sm font-bold text-white drop-shadow-sm mb-2 block">البريد الإلكتروني</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="example@email.com" className="h-12 rounded-xl text-base border-2 focus:border-primary" dir="ltr" />
                </div>
                <div>
                  <Label htmlFor="reg-password" className="text-sm font-bold text-white drop-shadow-sm mb-2 block">🔒 كلمة المرور</Label>
                  <Input id="reg-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="6 أحرف على الأقل" className="h-12 rounded-xl text-base border-2 focus:border-primary" dir="ltr" />
                </div>
                <div>
                  <Label htmlFor="reg-confirm-password" className="text-sm font-bold text-white drop-shadow-sm mb-2 block">🔐 تأكيد كلمة المرور</Label>
                  <Input id="reg-confirm-password" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="أعد كتابة كلمة المرور" className="h-12 rounded-xl text-base border-2 focus:border-primary" dir="ltr" />
                </div>
                <div>
                  <Label className="text-sm font-bold text-white drop-shadow-sm mb-2 block">أنت...</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => setGender("boy")}
                      className={`p-4 rounded-2xl text-center transition-all border-2 flex flex-col items-center gap-1 ${
                        gender === "boy" ? "border-blue-500 bg-blue-50 scale-105" : "border-border hover:border-blue-300"
                      }`}>
                      <span className="text-4xl">👦</span>
                      <span className="text-sm font-bold text-foreground">ولد</span>
                    </button>
                    <button onClick={() => setGender("girl")}
                      className={`p-4 rounded-2xl text-center transition-all border-2 flex flex-col items-center gap-1 ${
                        gender === "girl" ? "border-pink-500 bg-pink-50 scale-105" : "border-border hover:border-pink-300"
                      }`}>
                      <span className="text-4xl">👧</span>
                      <span className="text-sm font-bold text-foreground">بنت</span>
                    </button>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-bold text-white drop-shadow-sm mb-2 block">كم عمرك؟</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {AGE_GROUPS.map((group) => (
                      <button key={group.value} onClick={() => setAgeGroup(group.value as any)}
                        className={`p-3 rounded-xl text-center transition-all border-2 ${ageGroup === group.value ? "border-primary bg-primary/10 scale-105" : "border-border hover:border-primary/50"}`}>
                        <div className="text-2xl mb-1">{group.emoji}</div>
                        <div className="text-xs font-bold text-foreground">{group.label}</div>
                      </button>
                    ))}
                  </div>
                </div>
                <Button onClick={handleRegisterStep1} className="w-full h-12 text-base rounded-xl bg-primary hover:bg-primary/90 font-bold">التالي</Button>
                <button onClick={() => setStep("welcome")} className="w-full text-sm text-muted-foreground hover:text-primary flex items-center justify-center gap-1">
                  <ArrowLeft className="h-4 w-4" /> رجوع
                </button>
              </div>
            )}
            {regStep === 2 && (
              <div className="p-6 space-y-5">
                <div>
                  <Label className="text-sm font-bold text-foreground mb-3 block text-center">هل أنت ملتحق في إحدى مدارسنا؟</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {[{ value: true, label: "نعم", desc: "أنا طالب في مدرسة" }, { value: false, label: "لا", desc: "لست ملتحقاً" }].map((opt) => (
                      <button key={String(opt.value)} onClick={() => { setIsKindergarten(opt.value); setClassroom(""); setReferralSource(""); setSelectedSchoolId(null); }}
                        className={`p-4 rounded-2xl text-center transition-all border-2 ${isKindergarten === opt.value ? "border-primary bg-primary/10 scale-105" : "border-border hover:border-primary/50"}`}>
                        <div className="text-2xl mb-1">{opt.label}</div>
                        <div className="text-xs text-muted-foreground">{opt.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
                {isKindergarten === true && (
                  <div className="space-y-3">
                    <div>
                      <Label className="text-sm font-bold text-foreground mb-2 block text-center">🏫 اختر مدرستك</Label>
                      <div className="grid grid-cols-1 gap-2 max-h-36 overflow-y-auto">
                        {!(publicSchools ?? []).length ? (
                          <p className="text-center text-muted-foreground text-xs py-2">لا توجد مدارس مسجلة حالياً</p>
                        ) : (publicSchools ?? []).map((school: any) => (
                          <button key={school.id} onClick={() => { setSelectedSchoolId(school.id); setClassroom(""); }}
                            className={`p-3 rounded-xl text-center text-sm font-bold transition-all border-2 ${selectedSchoolId === school.id ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}>
                            {school.name}
                          </button>
                        ))}
                      </div>
                    </div>
                    {selectedSchoolId && (
                      <div>
                        <Label className="text-sm font-bold text-foreground mb-2 block text-center">🎓 في أي فصل تدرس؟</Label>
                        <div className="grid grid-cols-2 gap-2">
                          {!(schoolClassrooms ?? []).length ? (
                            <p className="text-center text-muted-foreground text-xs py-2 col-span-2">لا توجد فصول مضافة بعد</p>
                          ) : (schoolClassrooms ?? []).map((cls: any) => (
                            <button key={cls.id} onClick={() => setClassroom(cls.name)}
                              className={`p-3 rounded-xl text-center text-sm font-bold transition-all border-2 ${classroom === cls.name ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}>
                              {cls.name}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
                {isKindergarten === false && (
                  <div>
                    <Label className="text-sm font-bold text-foreground mb-3 block text-center">من أين عرفت عنا؟</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[{ value: "الأهل", emoji: "👨‍👩‍👧" }, { value: "الأصدقاء", emoji: "👫" }, { value: "العمل", emoji: "🏢" }, { value: "مواقع التواصل", emoji: "📱" }].map((src) => (
                        <button key={src.value} onClick={() => setReferralSource(src.value)}
                          className={`p-3 rounded-xl text-center text-sm font-bold transition-all border-2 ${referralSource === src.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}>
                          <div className="text-xl mb-1">{src.emoji}</div>{src.value}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <Button onClick={handleRegister} disabled={isLoading || isUploadingPhoto} className="w-full h-12 text-base rounded-xl bg-primary hover:bg-primary/90 font-bold">
                  {isUploadingPhoto ? "جارٍ معالجة صورتك..." : isLoading ? "جارٍ التسجيل..." : "ابدأ المغامرة!"}
                </Button>
                <button onClick={() => setRegStep(1)} className="w-full text-sm text-muted-foreground hover:text-primary flex items-center justify-center gap-1">
                  <ArrowLeft className="h-4 w-4" /> رجوع
                </button>
              </div>
            )}
          </div>
        )}

        {step === "login" && (
          <div className="bg-white/20 backdrop-blur-md rounded-3xl shadow-2xl overflow-hidden border border-white/30">
            <div className="bg-white/30 backdrop-blur-sm p-6 text-center border-b border-white/20">
              <div className="text-5xl mb-2">👋</div>
              <h2 className="text-2xl font-bold text-white font-kids drop-shadow-md">أهلاً بعودتك!</h2>
              <p className="text-white/90 mt-1 drop-shadow-sm">ادخل بريدك وكلمة المرور</p>
            </div>
            <div className="p-6 space-y-5">
              <div>
                <Label htmlFor="login-email" className="text-sm font-bold text-white drop-shadow-sm mb-2 block">بريدك الإلكتروني</Label>
                <Input id="login-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="example@email.com"
                  className="h-12 rounded-xl text-base border-2 border-white/40 bg-white/80 focus:border-primary" dir="ltr" onKeyDown={(e) => e.key === "Enter" && handleLogin()} />
              </div>
              <div>
                <Label htmlFor="login-password" className="text-sm font-bold text-white drop-shadow-sm mb-2 block">🔒 كلمة المرور</Label>
                <Input id="login-password" type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} placeholder="أدخل كلمة المرور"
                  className="h-12 rounded-xl text-base border-2 border-white/40 bg-white/80 focus:border-primary" dir="ltr" onKeyDown={(e) => e.key === "Enter" && handleLogin()} />
              </div>
              {/* خيار تذكرني للمتعلم */}
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={childRememberMe}
                  onChange={(e) => setChildRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded accent-primary"
                />
                <span className="text-sm text-white/80">تذكرني لمدة 30 يوماً</span>
              </label>
              <Button onClick={handleLogin} disabled={isLoading} className="w-full h-12 text-base rounded-xl bg-primary hover:bg-primary/90 font-bold">
                {isLoading ? "جارٍ الدخول..." : "ادخل!"}
              </Button>
              <button onClick={() => setStep("welcome")} className="w-full text-sm text-muted-foreground hover:text-primary flex items-center justify-center gap-1">
                <ArrowLeft className="h-4 w-4" /> رجوع
              </button>
            </div>
          </div>
        )}
      </div>

      <footer className="w-full py-4 px-4 text-center mt-6 relative z-10">
        <div className="max-w-md mx-auto">
          <div className="bg-white/50 backdrop-blur-sm rounded-2xl px-5 py-3 border border-white/40 shadow-sm">
            <p className="text-xs font-semibold text-foreground/70 mb-1">جميع الحقوق محفوظة</p>
            <p className="text-sm font-bold text-primary/90">تصميم وتنفيذ: زمرده عبد العزيز السماعيل</p>
            <p className="text-xs text-foreground/60 mt-0.5">معلمة رياض أطفال - ماجستير تربية الطفولة المبكرة</p>
            <p className="text-xs mt-1.5">
              <span className="bg-yellow-300 text-yellow-900 font-bold px-3 py-0.5 rounded-full text-xs">روضة السعادة</span>
            </p>
            <a href="mailto:zumorda77@hotmail.com" className="text-xs text-primary/70 hover:text-primary underline">zumorda77@hotmail.com</a>
          </div>
          <div className="mt-3 flex items-center justify-center gap-3">
            <button
              onClick={() => setShowAdminLogin(!showAdminLogin)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium
                bg-white/40 backdrop-blur-sm border border-white/60 shadow-sm
                text-foreground/70 hover:bg-white/60 hover:text-foreground hover:shadow
                transition-all duration-200"
            >
              <Shield className="w-3.5 h-3.5" /> دخول الإدارة
            </button>
            <span className="text-foreground/30 text-xs">|</span>
            <button
              onClick={() => navigate("/school-register")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium
                bg-purple-100/60 backdrop-blur-sm border border-purple-200/70 shadow-sm
                text-purple-700 hover:bg-purple-200/70 hover:text-purple-900 hover:shadow
                transition-all duration-200"
            >
              <School className="w-3.5 h-3.5" /> تسجيل مدرسة جديدة
            </button>
          </div>
          {showAdminLogin && (
            <div className="mt-2 bg-white/80 backdrop-blur-sm rounded-2xl px-4 py-3 border border-white/60 shadow-md">
              <p className="text-xs font-bold text-foreground/70 mb-2">دخول لوحة التحكم</p>
              <Input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} placeholder="البريد الإلكتروني"
                className="h-9 rounded-xl text-xs border-2 focus:border-primary mb-2" dir="ltr" onKeyDown={(e) => e.key === "Enter" && handleAdminLogin()} />
              <Input type="password" value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)} placeholder="كلمة المرور"
                className="h-9 rounded-xl text-xs border-2 focus:border-primary mb-2" dir="ltr" onKeyDown={(e) => e.key === "Enter" && handleAdminLogin()} />
              {/* خيار تذكرني للأدمن */}
              <label className="flex items-center gap-2 cursor-pointer select-none mb-2">
                <input
                  type="checkbox"
                  checked={adminRememberMe}
                  onChange={(e) => setAdminRememberMe(e.target.checked)}
                  className="w-3.5 h-3.5 rounded accent-primary"
                />
                <span className="text-xs text-foreground/60">تذكرني لمدة 30 يوماً</span>
              </label>
              <Button onClick={handleAdminLogin} disabled={isAdminLoading} className="w-full h-8 text-xs rounded-xl bg-primary hover:bg-primary/90">
                {isAdminLoading ? "جارٍ التحقق..." : "دخول"}
              </Button>
            </div>
          )}
        </div>
      </footer>
    </div>
  );
}
