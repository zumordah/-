import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { BookOpen, CheckCircle, Play, Star, Trophy, Lock } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

type Level = "easy" | "medium" | "hard";

const LEVEL_CONFIG: Record<Level, {
  label: string; emoji: string;
  gradient: string; lightBg: string; border: string;
  textColor: string; progressColor: string;
}> = {
  easy: {
    label: "مبتدئ", emoji: "🟢",
    gradient: "from-emerald-400 to-green-500",
    lightBg: "bg-emerald-50", border: "border-emerald-200",
    textColor: "text-emerald-700", progressColor: "from-emerald-400 to-green-500",
  },
  medium: {
    label: "متوسط", emoji: "🟡",
    gradient: "from-amber-400 to-orange-500",
    lightBg: "bg-amber-50", border: "border-amber-200",
    textColor: "text-amber-700", progressColor: "from-amber-400 to-orange-500",
  },
  hard: {
    label: "متقدم", emoji: "🔴",
    gradient: "from-rose-400 to-red-600",
    lightBg: "bg-rose-50", border: "border-rose-200",
    textColor: "text-rose-700", progressColor: "from-rose-400 to-red-600",
  },
};

type Activity = { id: number; title: string; pointsReward: number; storyId: number };
type Story = {
  id: number; title: string; difficulty: string | null;
  firstPageImage?: string | null;
};

function LevelProgressBar({
  completed, total, gradient,
}: { completed: number; total: number; gradient: string }) {
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs text-gray-500">
        <span>تقدمك في هذا المستوى</span>
        <span className="font-bold text-gray-700">{completed} / {total} نشاط</span>
      </div>
      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${gradient} rounded-full transition-all duration-700`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex justify-between items-center">
        <span className="text-xs text-gray-400">{pct}% مكتمل</span>
        {completed === total && total > 0 && (
          <span className="text-xs font-bold text-yellow-600 flex items-center gap-1">
            <Trophy className="w-3 h-3" /> مستوى مكتمل!
          </span>
        )}
      </div>
    </div>
  );
}

export default function StoryActivities() {
  const [, navigate] = useLocation();
  const search = useSearch();
  const { child } = useChild();
  const urlLevel = new URLSearchParams(search).get('level') as Level | null;
  const [activeLevel, setActiveLevel] = useState<Level>(
    urlLevel && ['easy','medium','hard'].includes(urlLevel) ? urlLevel : 'easy'
  );

  const { data: stories, isLoading: storiesLoading } = trpc.stories.list.useQuery({});
  const { data: allActivities } = trpc.activities.listAll.useQuery({});
  const { data: myResults } = trpc.activities.getChildResults.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const completedActivityIds = new Set(
    (myResults ?? [])
      .filter((r: { isCompleted: boolean; activityId: number }) => r.isCompleted)
      .map((r: { isCompleted: boolean; activityId: number }) => r.activityId)
  );

  const storiesByLevel = (stories ?? []).filter((s: Story) => (s.difficulty ?? "easy") === activeLevel);

  const getStoryActivities = (storyId: number): Activity[] =>
    (allActivities ?? []).filter((a: Activity) => a.storyId === storyId);

  // حساب عدد الأنشطة المكتملة لكل مستوى
  const activitiesCountByLevel = (level: Level) => {
    const levelStories = (stories ?? []).filter((s: Story) => (s.difficulty ?? "easy") === level);
    const levelActivityIds = levelStories.flatMap((s: Story) =>
      getStoryActivities(s.id).map((a) => a.id)
    );
    const completedCount = levelActivityIds.filter((id) => completedActivityIds.has(id)).length;
    return { total: levelActivityIds.length, completed: completedCount };
  };

  // ─── نظام التقدم المتدرج ───────────────────────────────────────────────
  const easyStats = activitiesCountByLevel("easy");
  const mediumStats = activitiesCountByLevel("medium");
  const hardStats = activitiesCountByLevel("hard");

  const easyAllDone = easyStats.total > 0 && easyStats.completed >= easyStats.total;
  const mediumAllDone = mediumStats.total > 0 && mediumStats.completed >= mediumStats.total;

  const levelUnlocked: Record<Level, boolean> = {
    easy: true,
    medium: easyAllDone,
    hard: easyAllDone && mediumAllDone,
  };

  const currentLevelStats = activitiesCountByLevel(activeLevel);
  const cfg = LEVEL_CONFIG[activeLevel];

  // إجمالي الأنشطة المكتملة
  const totalCompleted = completedActivityIds.size;
  const totalActivities = (allActivities ?? []).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-indigo-50 to-blue-50 pb-20" dir="rtl">

      {/* ─── Header ─────────────────────────────────────────────── */}
      <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm shadow-sm">
        <div className="px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="flex-shrink-0">
            <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-purple-800">أنشطة القصص 📚</h1>
            <p className="text-xs text-purple-500">أكمل أنشطة كل مستوى لفتح المستوى التالي</p>
          </div>
          <button
            onClick={() => navigate("/activities")}
            className="flex items-center gap-1 text-xs text-purple-600 bg-purple-50 border border-purple-200 px-3 py-1.5 rounded-full hover:bg-purple-100 transition-colors flex-shrink-0"
          >
            ← مركز الأنشطة
          </button>
          {child && (
            <div className="flex items-center gap-1 bg-purple-50 border border-purple-200 px-3 py-1.5 rounded-full">
              <Trophy className="w-4 h-4 text-purple-500" />
              <span className="text-sm font-bold text-purple-700">{totalCompleted}</span>
              <span className="text-xs text-purple-400">/ {totalActivities}</span>
            </div>
          )}
        </div>

        {/* Level Tabs */}
        <div className="flex px-4 pb-3 gap-2">
          {(["easy", "medium", "hard"] as Level[]).map((lvl) => {
            const c = LEVEL_CONFIG[lvl];
            const isActive = activeLevel === lvl;
            const stats = activitiesCountByLevel(lvl);
            const storiesCount = (stories ?? []).filter((s: Story) => (s.difficulty ?? "easy") === lvl).length;
            const unlocked = levelUnlocked[lvl];
            return (
              <button
                key={lvl}
                onClick={() => { if (unlocked) setActiveLevel(lvl); }}
                className={`flex-1 py-2.5 px-2 rounded-xl text-sm font-bold transition-all border-2 relative ${
                  !unlocked
                    ? "bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed opacity-70"
                    : isActive
                    ? `bg-gradient-to-r ${c.gradient} text-white border-transparent shadow-md`
                    : `${c.lightBg} ${c.textColor} ${c.border} hover:shadow-sm`
                }`}
              >
                <div className="flex items-center justify-center gap-1">
                  {!unlocked && <Lock className="w-3 h-3" />}
                  {c.emoji} {c.label}
                </div>
                <div className={`text-xs font-normal mt-0.5 ${isActive ? "text-white/80" : unlocked ? "opacity-60" : "text-gray-400"}`}>
                  {!unlocked
                    ? lvl === "medium" ? "أكمل المبتدئ أولاً" : "أكمل المتوسط أولاً"
                    : `${storiesCount} قصة`
                  }
                </div>
                {unlocked && stats.completed === stats.total && stats.total > 0 && (
                  <span className="absolute -top-1 -left-1 w-4 h-4 bg-yellow-400 rounded-full flex items-center justify-center text-[9px]">✓</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 pt-4 space-y-4">
        {/* ─── Level Lock Notice ───────────────────────────────────────────── */}
        {!levelUnlocked[activeLevel] && (
          <div className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-2xl p-6 text-center">
            <Lock className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <h3 className="font-bold text-gray-500 text-base mb-1">
              {activeLevel === "medium" ? "مستوى المتوسط مقفل" : "مستوى المتقدم مقفل"}
            </h3>
            <p className="text-sm text-gray-400">
              {activeLevel === "medium"
                ? `أكمل جميع أنشطة مستوى المبتدئ أولاً (${easyStats.completed}/${easyStats.total} مكتمل)`
                : `أكمل جميع أنشطة مستوى المتوسط أولاً (${mediumStats.completed}/${mediumStats.total} مكتمل)`
              }
            </p>
            <button
              onClick={() => setActiveLevel(activeLevel === "medium" ? "easy" : "medium")}
              className="mt-4 bg-purple-100 text-purple-700 font-bold px-4 py-2 rounded-xl text-sm hover:bg-purple-200 transition-colors"
            >
              {activeLevel === "medium" ? "اذهب لمستوى المبتدئ" : "اذهب لمستوى المتوسط"}
            </button>
          </div>
        )}

        {/* ─── Level Progress Card ──────────────────────────────────── */}
        {levelUnlocked[activeLevel] && (
          <div className={`${cfg.lightBg} border ${cfg.border} rounded-2xl p-4`}>
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${cfg.gradient} flex items-center justify-center text-white text-sm`}>
              {cfg.emoji}
            </div>
            <div>
              <h2 className={`font-bold text-sm ${cfg.textColor}`}>مستوى {cfg.label}</h2>
              <p className="text-xs text-gray-500">
                {storiesByLevel.length} قصة • {currentLevelStats.total} نشاط
              </p>
            </div>
            {currentLevelStats.completed === currentLevelStats.total && currentLevelStats.total > 0 && (
              <div className="mr-auto flex items-center gap-1 bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-bold">
                <Trophy className="w-3 h-3" /> مكتمل!
              </div>
            )}
          </div>
          {child ? (
            <LevelProgressBar
              completed={currentLevelStats.completed}
              total={currentLevelStats.total}
              gradient={cfg.progressColor}
            />
          ) : (
            <p className="text-xs text-gray-400 text-center py-1">
              🔑 سجّل دخولك لتتبع تقدمك وكسب النقاط
            </p>
          )}
          {/* رسالة فتح المستوى التالي */}
          {currentLevelStats.completed === currentLevelStats.total && currentLevelStats.total > 0 && activeLevel !== "hard" && (
            <div className="mt-3 bg-gradient-to-r from-yellow-400 to-amber-500 rounded-xl p-3 text-white text-center">
              <p className="font-bold text-sm">🎉 رائع! أكملت مستوى {cfg.label}!</p>
              <p className="text-xs text-white/80 mt-0.5">
                {activeLevel === "easy" ? "مستوى المتوسط أصبح متاحاً الآن!" : "مستوى المتقدم أصبح متاحاً الآن!"}
              </p>
              <button
                onClick={() => setActiveLevel(activeLevel === "easy" ? "medium" : "hard")}
                className="mt-2 bg-white text-amber-600 font-bold px-4 py-1.5 rounded-xl text-xs hover:bg-amber-50 transition-colors"
              >
                انتقل للمستوى التالي ←
              </button>
            </div>
          )}
          {/* توضيح الارتباط بين الأنشطة والقصص */}
          <div className="mt-3 bg-white/60 rounded-xl p-2 border border-white/80">
            <p className="text-xs text-gray-500 text-center">
              📖 الأنشطة مرتبطة بقصص هذا المستوى — اقرأ القصة أولاً ثم أكمل نشاطها
            </p>
          </div>
          </div>
        )}
        {/* ─── Overall Progress (if logged in) ───────────────────────────────────── */}
        {levelUnlocked[activeLevel] && child && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              تقدمك الإجمالي في الأنشطة
            </h3>
            <div className="space-y-3">
              {(["easy", "medium", "hard"] as Level[]).map((lvl) => {
                const c = LEVEL_CONFIG[lvl];
                const stats = activitiesCountByLevel(lvl);
                return (
                  <div key={lvl} className="flex items-center gap-3">
                    <span className="text-sm w-14 font-medium text-gray-600">{c.emoji} {c.label}</span>
                    <div className="flex-1 h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${c.progressColor} rounded-full transition-all duration-700`}
                        style={{ width: `${stats.total > 0 ? (stats.completed / stats.total) * 100 : 0}%` }}
                      />
                    </div>
                    <span className="text-xs font-bold text-gray-600 w-10 text-left">{stats.completed}/{stats.total}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        {/* ─── Stories List ───────────────────────────────────────────────────── */}
        {levelUnlocked[activeLevel] && (<>{storiesLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl h-28 animate-pulse" />
          ))
        ) : storiesByLevel.length === 0 ? (
          <div className="text-center py-16 text-purple-400">
            <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="font-semibold">لا توجد قصص في هذا المستوى</p>
          </div>
        ) : (
          storiesByLevel.map((story: Story) => {
            const acts = getStoryActivities(story.id);
            const completedCount = acts.filter((a) => completedActivityIds.has(a.id)).length;
            const totalCount = acts.length;
            const actPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

            return (
              <div
                key={story.id}
                className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-shadow border border-gray-100"
              >
                {/* Story Header */}
                <div className={`bg-gradient-to-r ${cfg.gradient} p-3 flex items-center gap-3`}>
                  <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 border-2 border-white/40">
                    {story.firstPageImage ? (
                      <img src={story.firstPageImage} alt={story.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-white/30 flex items-center justify-center">
                        <BookOpen className="w-6 h-6 text-white" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 text-right">
                    <h3 className="font-bold text-white text-base leading-tight">{story.title}</h3>
                    <div className="flex items-center justify-end gap-2 mt-1">
                      <span className="text-white/80 text-xs">{cfg.emoji} {cfg.label}</span>
                      {totalCount > 0 && (
                        <span className="text-white/80 text-xs">• {completedCount}/{totalCount} نشاط</span>
                      )}
                    </div>
                  </div>
                  {totalCount > 0 && completedCount === totalCount && (
                    <CheckCircle className="w-7 h-7 text-white flex-shrink-0 drop-shadow" />
                  )}
                </div>

                {/* Activities */}
                <div className="p-3">
                  {totalCount === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-3">لا توجد أنشطة لهذه القصة بعد</p>
                  ) : (
                    <div className="space-y-2">
                      {/* Progress Bar per story */}
                      <div className="flex items-center gap-2 mb-3">
                        <div className="flex-1 bg-gray-100 rounded-full h-2.5 overflow-hidden">
                          <div
                            className={`bg-gradient-to-r ${cfg.gradient} h-2.5 rounded-full transition-all duration-700`}
                            style={{ width: `${actPct}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500 font-medium">{completedCount}/{totalCount}</span>
                      </div>

                      {acts.map((act: Activity) => {
                        const done = completedActivityIds.has(act.id);
                        return (
                          <button
                            key={act.id}
                            onClick={() => navigate(`/activity/${act.id}?level=${activeLevel}`)}
                            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all text-right border ${
                              done
                                ? "bg-green-50 border-green-200 hover:bg-green-100"
                                : `${cfg.lightBg} ${cfg.border} hover:opacity-90 active:scale-98`
                            }`}
                          >
                            {done ? (
                              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            ) : (
                              <Play className={`w-5 h-5 flex-shrink-0 ${cfg.textColor}`} />
                            )}
                            <div className="flex-1">
                              <p className={`text-sm font-semibold ${done ? "text-green-700" : cfg.textColor}`}>
                                {act.title}
                              </p>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                              <span className="text-xs text-gray-500 font-medium">{act.pointsReward}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}</>
        )}
      </div>
    </div>
  );
}
