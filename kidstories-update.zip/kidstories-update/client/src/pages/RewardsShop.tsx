import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { ShoppingBag, Star, Lock, CheckCircle, ArrowRight, Sparkles, Gift, Crown, Gamepad2 } from "lucide-react";
import UnlockCelebration from "@/components/UnlockCelebration";

type TabType = "avatar" | "avatar_frame" | "theme" | "locked_games" | "locked_adventures";

const TAB_LABELS: Record<TabType, string> = {
  avatar: "أفاتار",
  avatar_frame: "إطارات",
  theme: "ثيمات",
  locked_games: "ألعاب 🔒",
  locked_adventures: "مغامرات 🔒",
};

const TAB_ICONS: Record<TabType, string> = {
  avatar: "🎭",
  avatar_frame: "🖼️",
  theme: "🎨",
  locked_games: "🎮",
  locked_adventures: "⚔️",
};

// الإطارات: CSS classes لكل قيمة
const FRAME_STYLES: Record<string, string> = {
  "frame-star": "ring-4 ring-yellow-400 ring-offset-2",
  "frame-moon": "ring-4 ring-indigo-400 ring-offset-2",
  "frame-rainbow": "ring-4 ring-offset-2 ring-transparent outline outline-4 outline-offset-2",
  "frame-gold": "ring-4 ring-amber-500 ring-offset-2 shadow-lg shadow-amber-200",
  "frame-space": "ring-4 ring-purple-600 ring-offset-2 shadow-lg shadow-purple-300",
};

const FRAME_PREVIEW_COLORS: Record<string, string> = {
  "frame-star": "border-yellow-400",
  "frame-moon": "border-indigo-400",
  "frame-rainbow": "border-pink-400",
  "frame-gold": "border-amber-500",
  "frame-space": "border-purple-600",
};

export default function RewardsShop() {
  const [, navigate] = useLocation();
  const { child } = useChild();
  const [activeTab, setActiveTab] = useState<TabType>("avatar");
  const [buying, setBuying] = useState<number | null>(null);
  const [equipping, setEquipping] = useState<number | null>(null);
  const [unlockingGameId, setUnlockingGameId] = useState<number | null>(null);
  const [unlockingAdvId, setUnlockingAdvId] = useState<number | null>(null);
  const [previewItem, setPreviewItem] = useState<{ icon: string; value: string; type: string } | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" } | null>(null);
  const [celebration, setCelebration] = useState<{ show: boolean; name: string; emoji: string; type: "game" | "adventure" }>({ show: false, name: "", emoji: "", type: "game" });

  const { data: items = [] } = trpc.shop.getItems.useQuery();
  const { data: inventory = [], refetch: refetchInventory } = trpc.shop.getInventory.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: childData, refetch: refetchChild } = trpc.children.getById.useQuery(
    { id: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: lockedGames = [], refetch: refetchLockedGames } = trpc.games.getLockedGames.useQuery();
  const { data: unlockedGameIds = [], refetch: refetchUnlockedGames } = trpc.games.getUnlockedGameIds.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );
  const { data: lockedAdventures = [], refetch: refetchLockedAdvs } = trpc.adventures.getLockedAdventures.useQuery();
  const { data: unlockedAdvIds = [], refetch: refetchUnlockedAdvs } = trpc.adventures.getUnlockedAdventureIds.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const purchase = trpc.shop.purchase.useMutation({
    onSuccess: async () => {
      await refetchInventory();
      await refetchChild();
      showToast("تم الشراء بنجاح! 🎉", "success");
    },
    onError: (e) => showToast(e.message, "error"),
    onSettled: () => setBuying(null),
  });

  const equip = trpc.shop.equip.useMutation({
    onSuccess: async () => {
      await refetchInventory();
      await refetchChild();
      showToast("تم التجهيز! ✨", "success");
      setPreviewItem(null);
    },
    onError: (e) => showToast(e.message, "error"),
    onSettled: () => setEquipping(null),
  });

  const unlockAdventure = trpc.adventures.unlockAdventure.useMutation({
    onSuccess: async (result, variables) => {
      if (result.success) {
        await refetchLockedAdvs();
        await refetchUnlockedAdvs();
        await refetchChild();
        // إيجاد بيانات المغامرة لعرض الاحتفال
        const adv = lockedAdventures.find((a) => a.id === variables.adventureId);
        if (adv) {
          setCelebration({ show: true, name: adv.title, emoji: adv.emoji ?? "⚔️", type: "adventure" });
        } else {
          showToast(result.message, "success");
        }
      } else {
        showToast(result.message, "error");
      }
    },
    onError: (e) => showToast(e.message, "error"),
    onSettled: () => setUnlockingAdvId(null),
  });

  const unlockGame = trpc.games.unlockGame.useMutation({
    onSuccess: async (result, variables) => {
      if (result.success) {
        await refetchLockedGames();
        await refetchUnlockedGames();
        await refetchChild();
        // إيجاد بيانات اللعبة لعرض الاحتفال
        const game = lockedGames.find((g) => g.id === variables.gameId);
        if (game) {
          setCelebration({ show: true, name: game.title, emoji: game.emoji ?? "🎮", type: "game" });
        } else {
          showToast(result.message, "success");
        }
      } else {
        showToast(result.message, "error");
      }
    },
    onError: (e) => showToast(e.message, "error"),
    onSettled: () => setUnlockingGameId(null),
  });

  function showToast(msg: string, type: "success" | "error") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }

  const level = childData?.level ?? child?.level ?? 1;
  const points = childData?.totalPoints ?? child?.totalPoints ?? 0;
  const ownedIds = new Set(inventory.map((i) => i.shopItemId));
  const equippedIds = new Set(inventory.filter((i) => i.isEquipped).map((i) => i.shopItemId));
  const unlockedGameSet = new Set(unlockedGameIds);

  // الأفاتار والإطار المجهّز حالياً
  const equippedAvatar = inventory.find((i) => i.isEquipped && items.find((it) => it.id === i.shopItemId && it.type === "avatar"));
  const equippedFrame = inventory.find((i) => i.isEquipped && items.find((it) => it.id === i.shopItemId && it.type === "avatar_frame"));
  const equippedTheme = inventory.find((i) => i.isEquipped && items.find((it) => it.id === i.shopItemId && it.type === "theme"));

  const equippedAvatarItem = equippedAvatar ? items.find((it) => it.id === equippedAvatar.shopItemId) : null;
  const equippedFrameItem = equippedFrame ? items.find((it) => it.id === equippedFrame.shopItemId) : null;
  const equippedThemeItem = equippedTheme ? items.find((it) => it.id === equippedTheme.shopItemId) : null;

  const filteredItems = items.filter((item) => item.type === activeTab);

  // معاينة الأفاتار المخصص
  const previewEmoji = previewItem?.type === "avatar" ? previewItem.icon : (equippedAvatarItem?.icon ?? child?.avatarEmoji ?? "🐻");
  const previewFrame = previewItem?.type === "avatar_frame" ? previewItem.value : (equippedFrameItem?.value ?? "");
  const previewTheme = previewItem?.type === "theme" ? previewItem.value : (equippedThemeItem?.value ?? "from-violet-600 to-purple-700");

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50 pb-20" dir="rtl">
      {/* احتفال فتح لعبة/مغامرة */}
      <UnlockCelebration
        show={celebration.show}
        itemName={celebration.name}
        itemEmoji={celebration.emoji}
        itemType={celebration.type}
        onClose={() => setCelebration((prev) => ({ ...prev, show: false }))}
      />
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl shadow-lg font-bold text-sm transition-all ${
          toast.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"
        }`}>
          {toast.msg}
        </div>
      )}

      <div className="max-w-md mx-auto px-4 pt-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <button onClick={() => navigate("/home")} className="flex items-center gap-1 text-purple-600 text-sm font-medium">
            <ArrowRight className="w-4 h-4" /> الرئيسية
          </button>
          <div className="flex items-center gap-2 bg-white rounded-full px-3 py-1.5 shadow-sm border border-purple-100">
            <ShoppingBag className="w-4 h-4 text-purple-500" />
            <span className="text-xs font-bold text-purple-700">متجر المكافآت</span>
          </div>
        </div>

        {/* بطاقة الطفل مع المعاينة */}
        {child && (
          <div className={`bg-gradient-to-r ${previewTheme} rounded-3xl p-5 text-white shadow-lg transition-all duration-500`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {/* الأفاتار مع الإطار */}
                <div className={`w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-4xl transition-all duration-300 ${
                  previewFrame ? FRAME_STYLES[previewFrame] ?? "ring-4 ring-white/60 ring-offset-2" : ""
                }`}>
                  {previewEmoji}
                </div>
                <div>
                  <p className="font-bold text-lg">{child.name}</p>
                  <div className="flex items-center gap-2 text-white/80 text-sm">
                    <Crown className="w-3.5 h-3.5" />
                    <span>المستوى {level}</span>
                  </div>
                  {previewItem && (
                    <p className="text-xs text-white/70 mt-0.5">معاينة: {previewItem.icon}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1.5 bg-white/20 rounded-2xl px-3 py-2">
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                <span className="font-bold">{points}</span>
              </div>
            </div>
            {previewItem && (
              <p className="text-center text-xs text-white/70 mt-3">👆 معاينة مباشرة — اضغط "تجهيز" لتطبيقه</p>
            )}
          </div>
        )}

        {/* بطاقة متجر الشخصيات */}
        <button
          onClick={() => navigate('/shop/characters')}
          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl p-4 flex items-center gap-4 shadow-md hover:shadow-lg transition-all"
        >
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl">
            🧸
          </div>
          <div className="text-right flex-1">
            <p className="font-bold text-base">متجر الشخصيات المرافقة</p>
            <p className="text-xs text-white/80">اختر رفيقك في كل رحلة!</p>
          </div>
          <span className="text-white/80 text-xl">←</span>
        </button>

        {/* Tabs */}
        <div className="grid grid-cols-5 gap-1">
          {(["avatar", "avatar_frame", "theme", "locked_games", "locked_adventures"] as TabType[]).map((tab) => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); setPreviewItem(null); }}
              className={`py-2 rounded-xl text-[10px] font-bold transition-all flex flex-col items-center gap-0.5 ${
                activeTab === tab
                  ? "bg-purple-600 text-white shadow-md"
                  : "bg-white text-gray-500 border border-gray-100"
              }`}
            >
              <span className="text-sm">{TAB_ICONS[tab]}</span>
              {TAB_LABELS[tab]}
            </button>
          ))}
        </div>

        {/* ─── Locked Games Tab ─────────────────────────────────────── */}
        {activeTab === "locked_games" ? (
          <div className="space-y-3">
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 text-xs text-purple-700">
              <p className="font-bold mb-1">🔒 ألعاب مقفلة</p>
              <p>هذه الألعاب مقفلة في قسم الألعاب التعليمية. افتحها بنقاطك لتتمكن من اللعب!</p>
            </div>
            {lockedGames.length === 0 ? (
              <div className="text-center py-10 text-gray-400">
                <Gamepad2 className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p>لا توجد ألعاب مقفلة حالياً</p>
              </div>
            ) : (
              <>
                {child && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-2 text-xs text-amber-700 flex items-center gap-2">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    نقاطك الحالية: <span className="font-bold">{points}</span>
                  </div>
                )}
                {(lockedGames as { id: number; title: string; description: string | null; level: string; emoji: string | null; lockCost: number; type: string }[]).map((game) => {
                  const alreadyUnlocked = unlockedGameSet.has(game.id);
                  const canAfford = points >= game.lockCost;
                  const isUnlocking = unlockingGameId === game.id;
                  const levelLabel = game.level === "easy" ? "🟢 مبتدئ" : game.level === "medium" ? "🟡 متوسط" : "🔴 متقدم";
                  return (
                    <div
                      key={game.id}
                      className={`bg-white rounded-2xl p-4 border-2 shadow-sm ${
                        alreadyUnlocked ? "border-green-300 bg-green-50" : "border-dashed border-gray-200"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 ${
                          alreadyUnlocked ? "bg-green-100" : "bg-gray-100 grayscale"
                        }`}>
                          {game.emoji ?? "🎮"}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-gray-800 text-sm truncate">{game.title}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs text-gray-400">{levelLabel}</span>
                            {!alreadyUnlocked && (
                              <span className="flex items-center gap-0.5 text-xs font-bold text-amber-600">
                                <Star className="w-3 h-3 fill-amber-500" />
                                {game.lockCost} نقطة
                              </span>
                            )}
                          </div>
                        </div>
                        {alreadyUnlocked ? (
                          <div className="flex items-center gap-1 text-green-600 text-xs font-bold flex-shrink-0">
                            <CheckCircle className="w-4 h-4" /> مفتوح
                          </div>
                        ) : child ? (
                          <button
                            onClick={() => {
                              if (!canAfford) {
                                showToast(`تحتاج ${game.lockCost} نقطة`, "error");
                                return;
                              }
                              setUnlockingGameId(game.id);
                              unlockGame.mutate({ childId: child.id, gameId: game.id });
                            }}
                            disabled={isUnlocking || !canAfford}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex-shrink-0 ${
                              canAfford
                                ? "bg-amber-500 text-white hover:bg-amber-600"
                                : "bg-gray-100 text-gray-400 cursor-not-allowed"
                            }`}
                          >
                            {isUnlocking ? "..." : canAfford ? "🔓 افتح" : "نقاط غير كافية"}
                          </button>
                        ) : (
                          <div className="px-3 py-1.5 bg-gray-100 text-gray-400 rounded-xl text-xs font-bold flex-shrink-0">
                            سجّل دخولك
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>
        ) : activeTab === "locked_adventures" ? (
          /* ─── Locked Adventures Tab ───────────────────────────────────────── */
          <div className="space-y-3">
            <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-3 text-xs text-indigo-700">
              <p className="font-bold mb-1">⚔️ مغامرات مقفلة</p>
              <p>هذه المغامرات مقفلة في قسم المغامرات. افتحها بنقاطك لتعيش مغامرة جديدة!</p>
            </div>
            {lockedAdventures.length === 0 ? (
              <div className="text-center py-10 text-gray-400">
                <span className="text-4xl block mb-2">⚔️</span>
                <p>لا توجد مغامرات مقفلة حالياً</p>
              </div>
            ) : (
              <>
                {child && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-2 text-xs text-amber-700 flex items-center gap-2">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    نقاطك الحالية: <span className="font-bold">{points}</span>
                  </div>
                )}
                {(lockedAdventures as { id: number; title: string; emoji: string | null; level: string; lockCost: number }[]).map((adv) => {
                  const alreadyUnlocked = new Set(unlockedAdvIds).has(adv.id);
                  const canAfford = points >= adv.lockCost;
                  const isUnlocking = unlockingAdvId === adv.id;
                  const levelLabel = adv.level === "easy" ? "🟢 مبتدئ" : adv.level === "medium" ? "🟡 متوسط" : "🔴 متقدم";
                  return (
                    <div key={adv.id} className={`bg-white rounded-2xl p-4 border-2 shadow-sm ${
                      alreadyUnlocked ? "border-green-300 bg-green-50" : "border-dashed border-gray-200"
                    }`}>
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 ${
                          alreadyUnlocked ? "bg-green-100" : "bg-gray-100 grayscale"
                        }`}>{adv.emoji ?? "⚔️"}</div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-gray-800 text-sm truncate">{adv.title}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs text-gray-400">{levelLabel}</span>
                            {!alreadyUnlocked && (
                              <span className="flex items-center gap-0.5 text-xs font-bold text-amber-600">
                                <Star className="w-3 h-3 fill-amber-500" />
                                {adv.lockCost} نقطة
                              </span>
                            )}
                          </div>
                        </div>
                        {alreadyUnlocked ? (
                          <div className="flex items-center gap-1 text-green-600 text-xs font-bold flex-shrink-0">
                            <CheckCircle className="w-4 h-4" /> مفتوح
                          </div>
                        ) : child ? (
                          <button
                            onClick={() => {
                              if (!canAfford) { showToast(`تحتاج ${adv.lockCost} نقطة`, "error"); return; }
                              setUnlockingAdvId(adv.id);
                              unlockAdventure.mutate({ childId: child.id, adventureId: adv.id });
                            }}
                            disabled={isUnlocking || !canAfford}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex-shrink-0 ${
                              canAfford ? "bg-indigo-500 text-white hover:bg-indigo-600" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                            }`}
                          >
                            {isUnlocking ? "..." : canAfford ? "🔓 افتح" : "نقاط غير كافية"}
                          </button>
                        ) : (
                          <div className="px-3 py-1.5 bg-gray-100 text-gray-400 rounded-xl text-xs font-bold flex-shrink-0">سجّل دخولك</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>
        ) : (
          /* ─── Regular Items Grid ────────────────────────────────────────────── */
          <div className="grid grid-cols-2 gap-3">
            {filteredItems.length === 0 ? (
              <div className="col-span-2 text-center py-10 text-gray-400">
                <Gift className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p>لا توجد عناصر متاحة</p>
              </div>
            ) : (
              filteredItems.map((item) => {
                const owned = ownedIds.has(item.id);
                const equipped = equippedIds.has(item.id);
                const locked = level < item.levelRequired;
                const canAfford = points >= item.pointsCost;
                const isPreviewing = previewItem && previewItem.icon === item.icon && previewItem.value === item.value;

                return (
                  <div
                    key={item.id}
                    className={`bg-white rounded-2xl p-4 border-2 transition-all shadow-sm cursor-pointer ${
                      equipped
                        ? "border-purple-400 bg-purple-50"
                        : isPreviewing
                        ? "border-blue-400 bg-blue-50"
                        : owned
                        ? "border-green-300 bg-green-50"
                        : locked
                        ? "border-gray-100 opacity-60"
                        : "border-gray-100 hover:border-purple-200"
                    }`}
                    onClick={() => {
                      if (!locked && (owned || item.type === "avatar_frame" || item.type === "theme" || item.type === "avatar")) {
                        setPreviewItem({ icon: item.icon ?? "🎁", value: item.value, type: item.type });
                      }
                    }}
                  >
                    {/* Icon مع معاينة الإطار */}
                    {item.type === "avatar_frame" ? (
                      <div className="flex justify-center mb-2">
                        <div className={`w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-2xl border-4 ${FRAME_PREVIEW_COLORS[item.value] ?? "border-gray-300"}`}>
                          {child?.avatarEmoji ?? "🐻"}
                        </div>
                      </div>
                    ) : item.type === "theme" ? (
                      <div className={`w-full h-10 rounded-xl bg-gradient-to-r ${item.value} mb-2 flex items-center justify-center text-white text-xs font-bold`}>
                        {item.icon}
                      </div>
                    ) : (
                      <div className="text-4xl text-center mb-2">{item.icon}</div>
                    )}

                    {/* Name */}
                    <p className="font-bold text-gray-700 text-xs text-center mb-1">{item.name}</p>

                    {/* Status badges */}
                    {equipped && (
                      <div className="flex items-center justify-center gap-1 text-purple-600 text-xs font-bold mb-2">
                        <Sparkles className="w-3 h-3" /> مجهّز
                      </div>
                    )}
                    {isPreviewing && !equipped && (
                      <div className="flex items-center justify-center gap-1 text-blue-600 text-xs font-bold mb-2">
                        👁️ معاينة
                      </div>
                    )}
                    {owned && !equipped && !isPreviewing && (
                      <div className="flex items-center justify-center gap-1 text-green-600 text-xs font-bold mb-2">
                        <CheckCircle className="w-3 h-3" /> مملوك
                      </div>
                    )}
                    {locked && (
                      <div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-2">
                        <Lock className="w-3 h-3" /> المستوى {item.levelRequired}
                      </div>
                    )}
                    {!owned && !locked && !isPreviewing && (
                      <div className="flex items-center justify-center gap-1 text-amber-600 text-xs font-bold mb-2">
                        <Star className="w-3 h-3 fill-amber-500" />
                        {item.pointsCost === 0 ? "مجاني" : `${item.pointsCost} نقطة`}
                      </div>
                    )}

                    {/* Action button */}
                    {owned && !equipped && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!child) return;
                          setEquipping(item.id);
                          equip.mutate({ childId: child.id, shopItemId: item.id });
                        }}
                        disabled={equipping === item.id}
                        className="w-full py-1.5 bg-purple-100 text-purple-700 rounded-xl text-xs font-bold hover:bg-purple-200 transition-colors disabled:opacity-50"
                      >
                        {equipping === item.id ? "..." : "تجهيز ✨"}
                      </button>
                    )}
                    {!owned && !locked && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!child) return;
                          if (!canAfford && item.pointsCost > 0) {
                            showToast("نقاطك غير كافية", "error");
                            return;
                          }
                          setBuying(item.id);
                          purchase.mutate({ childId: child.id, shopItemId: item.id });
                        }}
                        disabled={buying === item.id || (!canAfford && item.pointsCost > 0)}
                        className="w-full py-1.5 bg-purple-600 text-white rounded-xl text-xs font-bold hover:bg-purple-700 transition-colors disabled:opacity-50"
                      >
                        {buying === item.id ? "..." : item.pointsCost === 0 ? "احصل عليه" : "شراء"}
                      </button>
                    )}
                    {locked && (
                      <div className="w-full py-1.5 bg-gray-100 text-gray-400 rounded-xl text-xs font-bold text-center">
                        مقفل
                      </div>
                    )}
                    {equipped && (
                      <div className="w-full py-1.5 bg-purple-600 text-white rounded-xl text-xs font-bold text-center">
                        ✓ مجهّز الآن
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Info note */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-xs text-amber-700">
          <p className="font-bold mb-1">💡 كيف تكسب نقاطاً؟</p>
          <p>اقرأ القصص، العب الألعاب، أكمل المغامرات، وأتمم تحديات اليوم لكسب نقاط وفتح مكافآت جديدة!</p>
        </div>

        {/* جدول النقاط */}
        <div className="bg-white/80 rounded-2xl p-4 border border-purple-100">
          <p className="font-bold text-sm text-purple-700 mb-3">📊 جدول النقاط المطلوبة</p>
          <div className="space-y-2 text-xs">
            {[
              { label: "أفاتارات", items: items.filter(i => i.type === "avatar"), color: "text-blue-600" },
              { label: "إطارات الأفاتار", items: items.filter(i => i.type === "avatar_frame"), color: "text-yellow-600" },
              { label: "ثيمات البطاقة", items: items.filter(i => i.type === "theme"), color: "text-green-600" },
            ].map(group => (
              <div key={group.label}>
                <p className={`font-bold ${group.color} mb-1`}>{group.label}:</p>
                <div className="flex flex-wrap gap-1">
                  {group.items.map(item => (
                    <span key={item.id} className={`px-2 py-0.5 rounded-full bg-gray-100 ${ownedIds.has(item.id) ? "line-through text-gray-400" : "text-gray-600"}`}>
                      {item.icon} {item.pointsCost === 0 ? "مجاني" : `${item.pointsCost}نق`}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
