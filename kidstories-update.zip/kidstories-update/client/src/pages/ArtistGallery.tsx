import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";

export default function ArtistGallery() {
  const [filterStory, setFilterStory] = useState<number>();
  const [filterSchool, setFilterSchool] = useState<string>();
  
  const featured = trpc.drawings.getFeatured.useQuery();
  const all = trpc.drawings.getAll.useQuery({ storyId: filterStory, schoolName: filterSchool });
  const likeMutation = trpc.drawings.like.useMutation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 text-purple-600">🎨 لوحة الفنان الصغير</h1>

        {/* أفضل الرسومات */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-pink-600">⭐ أفضل الرسومات</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {featured.data?.map((drawing: any) => (
              <Card key={drawing.id} className="overflow-hidden hover:shadow-lg transition">
                <img src={drawing.imageUrl} alt={drawing.childName} className="w-full h-48 object-cover" />
                <div className="p-4">
                  <p className="font-bold">{drawing.childName}</p>
                  <p className="text-sm text-gray-600">{drawing.storyTitle}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                    <span>{drawing.likesCount}</span>
                  </div>
                  <div className="flex gap-2 mt-2">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={i < (drawing.rating || 0) ? "text-yellow-500" : "text-gray-300"}>⭐</span>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* جميع الرسومات */}
        <section>
          <h2 className="text-2xl font-bold mb-4 text-purple-600">📚 الأرشيف</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {all.data?.map((drawing: any) => (
              <Card key={drawing.id} className="overflow-hidden hover:shadow-lg transition cursor-pointer group">
                <div className="relative">
                  <img src={drawing.imageUrl} alt={drawing.childName} className="w-full h-40 object-cover group-hover:opacity-75 transition" />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => likeMutation.mutate({ drawingId: drawing.id })}
                    className="absolute bottom-2 right-2 bg-white/80 hover:bg-white"
                  >
                    <Heart className="w-4 h-4" /> {drawing.likesCount}
                  </Button>
                </div>
                <div className="p-2 text-sm">
                  <p className="font-bold truncate">{drawing.childName}</p>
                  <p className="text-gray-600 truncate">{drawing.storyTitle}</p>
                </div>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
