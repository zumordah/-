import { useState, useRef } from 'react';
import { useChild } from '@/contexts/ChildContext';
import { trpc } from '@/lib/trpc';
import { Mic, Play, Pause, Trash2, ArrowRight, BookOpen, ChevronDown, ChevronUp, Award } from 'lucide-react';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

export default function MyRecordings() {
  const { child } = useChild();
  const [, navigate] = useLocation();
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [expandedStories, setExpandedStories] = useState<Set<string>>(new Set());
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const { data: groups = [], refetch } = trpc.recordings.getMyRecordingsGrouped.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const deleteMutation = trpc.recordings.deleteRecording.useMutation({
    onSuccess: () => { toast.success('تم حذف التسجيل'); refetch(); },
    onError: () => toast.error('حدث خطأ أثناء الحذف'),
  });

  const totalRecordings = groups.reduce((sum, g) => sum + g.recordings.length, 0);
  const isDistinguishedReader = totalRecordings >= 5;

  const handlePlay = (rec: { id: number; audioUrl: string }) => {
    if (playingId === rec.id) { audioRef.current?.pause(); setPlayingId(null); return; }
    audioRef.current?.pause();
    audioRef.current = new Audio(rec.audioUrl);
    audioRef.current.onended = () => setPlayingId(null);
    audioRef.current.play();
    setPlayingId(rec.id);
  };

  const handleDelete = (id: number) => {
    if (!child?.id) return;
    if (confirm('هل تريد حذف هذا التسجيل؟')) deleteMutation.mutate({ id, childId: child.id });
  };

  const toggleStory = (key: string) => {
    setExpandedStories(prev => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const formatDate = (date: Date) =>
    new Date(date).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric' });

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 p-4" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <button onClick={() => navigate('/dashboard')} className="p-2 rounded-full bg-white shadow text-purple-600 hover:bg-purple-50">
          <ArrowRight className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-purple-800">🎙️ تسجيلاتي</h1>
          <p className="text-sm text-gray-500">سجّل صوتك وأنت تقرأ القصص!</p>
        </div>
      </div>

      {/* إحصائيات + شارة */}
      <div className="bg-white rounded-2xl shadow-sm p-4 mb-5 flex items-center gap-3">
        <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
          <Mic className="w-6 h-6 text-purple-600" />
        </div>
        <div className="flex-1">
          <p className="font-bold text-gray-800">
            🎧 لديك <span className="text-purple-600">{totalRecordings}</span> تسجيل
          </p>
          <p className="text-xs text-gray-400">موزّعة على {groups.length} قصة</p>
        </div>
        {isDistinguishedReader && (
          <div className="flex flex-col items-center gap-1 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
            <Award className="w-5 h-5 text-amber-500" />
            <span className="text-xs font-bold text-amber-700">قارئ متميز</span>
          </div>
        )}
        {!isDistinguishedReader && totalRecordings > 0 && (
          <div className="text-xs text-gray-400 text-center">
            <span className="font-bold text-purple-500">{5 - totalRecordings}</span> تسجيل<br />للشارة 🏅
          </div>
        )}
      </div>

      {/* قائمة التسجيلات مجمّعة */}
      {groups.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center shadow-sm">
          <Mic className="w-12 h-12 text-purple-200 mx-auto mb-3" />
          <p className="text-gray-500 font-bold mb-1">لم تسجّل أي قصة بعد</p>
          <p className="text-gray-400 text-sm mb-4">ابدأ الآن من صفحات القصة!</p>
          <button
            onClick={() => navigate('/home')}
            className="px-4 py-2 bg-purple-500 text-white rounded-full text-sm font-bold hover:bg-purple-600"
          >
            👉 اذهب إلى القصص
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {groups.map((group) => {
            const key = group.storyId ? String(group.storyId) : 'other';
            const isExpanded = expandedStories.has(key) || groups.length === 1;
            return (
              <div key={key} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                {/* رأس القصة */}
                <button
                  onClick={() => toggleStory(key)}
                  className="w-full flex items-center gap-3 p-4 hover:bg-purple-50 transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="font-bold text-gray-800 text-sm">{group.storyTitle}</p>
                    <p className="text-xs text-gray-400">{group.recordings.length} تسجيل</p>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  )}
                </button>

                {/* تسجيلات القصة */}
                {isExpanded && (
                  <div className="border-t border-gray-100 divide-y divide-gray-50">
                    {group.recordings.map((rec) => (
                      <div key={rec.id} className="flex items-center gap-3 px-4 py-3">
                        {/* زر التشغيل */}
                        <button
                          onClick={() => handlePlay(rec)}
                          className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                            playingId === rec.id
                              ? 'bg-purple-600 text-white'
                              : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
                          }`}
                        >
                          {playingId === rec.id ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </button>

                        {/* معلومات التسجيل */}
                        <div className="flex-1 min-w-0">
                          {rec.pageNumber != null && (
                            <span className="inline-block text-xs bg-purple-100 text-purple-600 px-2 py-0.5 rounded-full font-bold mb-0.5">
                              صفحة {rec.pageNumber}
                            </span>
                          )}
                          <p className="text-xs text-gray-400">{formatDate(rec.createdAt)}</p>
                          {(rec as any).rating && (
                            <div className="mt-1">
                              <span className="text-amber-400 text-sm">{'★'.repeat((rec as any).rating)}<span className="text-gray-200">{'★'.repeat(5 - (rec as any).rating)}</span></span>
                              {(rec as any).ratingComment && (
                                <p className="text-xs text-purple-600 font-bold mt-0.5">"‏{(rec as any).ratingComment}‏"</p>
                              )}
                            </div>
                          )}
                        </div>

                        {/* زر الحذف */}
                        <button
                          onClick={() => handleDelete(rec.id)}
                          className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
