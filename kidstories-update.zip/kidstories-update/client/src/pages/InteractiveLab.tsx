import { useState } from "react";
import { useLocation } from "wouter";
import { useChild } from "@/contexts/ChildContext";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star, Trophy, CheckCircle } from "lucide-react";
import { INTERACTIVE_GAMES_CATEGORIES, memoryGames, sortingGames, sequencingGames, buildLogicGames, logicPuzzleGames, coloringGames, scienceGames } from "@/lib/interactiveGamesData";
import { MemoryMatchGame } from "@/components/games/MemoryMatchGame";
import { SortingGame } from "@/components/games/SortingGame";
import { SequencingGame } from "@/components/games/SequencingGame";
import { BuildLogicGame } from "@/components/games/BuildLogicGame";
import { LogicPuzzleGame } from "@/components/games/LogicPuzzleGame";
import { ColoringGame } from "@/components/games/ColoringGame";
import ScienceExperimentGame from "@/components/games/ScienceExperimentGame";
import { toast } from "sonner";
import { getCharacterById, getDefaultCharacter } from "@/data/charactersData";

type ViewState =
  | { type: "categories" }
  | { type: "games"; categoryId: string }
  | { type: "playing"; categoryId: string; gameIndex: number };

const POINTS_PER_GAME = 10;

export default function InteractiveLab() {
  const { child } = useChild();
  const [, navigate] = useLocation();
  const [view, setView] = useState<ViewState>({ type: "categories" });
  const [localCompleted, setLocalCompleted] = useState<Set<string>>(new Set());

  const { data: companionData } = trpc.companion.getMyCompanion.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id, staleTime: 60000 }
  );
  const characterId = (companionData as any)?.characterId ?? 'sami';
  const character = getCharacterById(characterId) ?? getDefaultCharacter();

  const { data: progressData = [], refetch: refetchProgress } = trpc.interactiveLab.getProgress.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id }
  );

  const saveProgress = trpc.interactiveLab.saveProgress.useMutation({
    onSuccess: (data) => {
      refetchProgress();
      if (data.pointsEarned > 0) {
        toast.success(`أحسنت! ربحت ${data.pointsEarned} نقطة!`, {
          icon: "⭐",
        });
      }
    },
  });

  const serverCompletedIds = new Set(
    progressData.filter((p) => p.isCompleted).map((p) => p.gameId)
  );
  const completedGameIds = new Set([...Array.from(serverCompletedIds), ...Array.from(localCompleted)]);

  const getGamesForCategory = (categoryId: string) => {
    switch (categoryId) {
      case "memory": return memoryGames;
      case "sorting": return sortingGames;
      case "sequencing": return sequencingGames;
      case "build_logic": return buildLogicGames;
      case "logic_puzzle": return logicPuzzleGames;
      case "coloring": return coloringGames;
      case "science": return scienceGames;
      default: return [];
    }
  };

  const handleGameComplete = (gameId: string, categoryId: string, score: number) => {
    const isFirstCompletion = !completedGameIds.has(gameId);
    const pointsEarned = isFirstCompletion ? POINTS_PER_GAME : 0;
    // Mark as completed locally immediately
    setLocalCompleted((prev) => new Set([...Array.from(prev), gameId]));
      saveProgress.mutate({
      childId: child?.id ?? 0,
      gameId,
      category: (categoryId === "science" ? "coloring" : categoryId) as "memory" | "sorting" | "sequencing" | "build_logic" | "logic_puzzle" | "coloring",
      score,
      isCompleted: true,
      pointsEarned,
    });
    // Auto-advance to next game after 1.8 seconds (disabled for science experiments - user controls navigation)
    if (view.type === "playing" && categoryId !== "science") {
      const games = getGamesForCategory(categoryId);
      if (view.gameIndex < games.length - 1) {
        setTimeout(() => {
          setView((prev) => prev.type === "playing" ? { ...prev, gameIndex: prev.gameIndex + 1 } : prev);
        }, 1800);
      }
    }
  };

  // ── PLAYING VIEW ──────────────────────────────────────────────────────────
  if (view.type === "playing") {
    const games = getGamesForCategory(view.categoryId);
    const game = games[view.gameIndex];
    const category = INTERACTIVE_GAMES_CATEGORIES.find((c) => c.id === view.categoryId);

    if (!game || !category) return null;

    const renderGame = () => {
      if (view.categoryId === "memory") {
        const g = memoryGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <MemoryMatchGame
            game={g}
            onComplete={(score) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      if (view.categoryId === "sorting") {
        const g = sortingGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <SortingGame
            game={g}
            onComplete={(score) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      if (view.categoryId === "sequencing") {
        const g = sequencingGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <SequencingGame
            game={g}
            onComplete={(score) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      if (view.categoryId === "build_logic") {
        const g = buildLogicGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <BuildLogicGame
            game={g}
            onComplete={(score) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      if (view.categoryId === "logic_puzzle") {
        const g = logicPuzzleGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <LogicPuzzleGame
            game={g}
            onComplete={(score) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      if (view.categoryId === "coloring") {
        const g = coloringGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <ColoringGame
            game={g}
            onComplete={(score) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      if (view.categoryId === "science") {
        const g = scienceGames.find((g) => g.id === game.id);
        if (!g) return null;
        return (
          <ScienceExperimentGame
            key={`science-${view.gameIndex}`}
            game={g}
            onComplete={(score: number) => handleGameComplete(g.id, view.categoryId, score)}
          />
        );
      }
      return null;
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4" dir="rtl">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setView({ type: "games", categoryId: view.categoryId })}
              className="gap-1"
            >
              <ArrowRight className="h-4 w-4" />
              رجوع
            </Button>
            <div>
              <h1 className="text-xl font-bold">{game.title}</h1>
              <p className="text-xs text-muted-foreground">{category.title}</p>
            </div>
            {completedGameIds.has(game.id) && (
              <div className="mr-auto flex items-center gap-1 text-green-600 text-sm font-medium">
                <CheckCircle className="h-4 w-4" />
                مكتملة
              </div>
            )}
          </div>

          {/* Game card - key forces remount when game changes */}
          <div key={`${view.categoryId}-${view.gameIndex}-${game.id}`} className="bg-white rounded-3xl shadow-lg p-6 relative">
            {/* الشخصية المرافقة في زاوية اللعبة */}
            {child && (
              <div className="absolute -top-5 left-4 z-10">
                <img
                  src={character.imageUrl}
                  alt={character.name}
                  className="w-12 h-12 object-contain"
                  style={{
                    filter: `drop-shadow(0 0 8px ${character.color})`,
                    animation: 'bounce 2.5s ease-in-out infinite',
                  }}
                />
              </div>
            )}
            {renderGame()}
          </div>

          {/* Navigation between games */}
          <div className="flex justify-between mt-4">
            {view.gameIndex > 0 && (
              <Button
                variant="outline"
                onClick={() => setView({ ...view, gameIndex: view.gameIndex - 1 })}
                className="gap-1"
              >
                <ArrowRight className="h-4 w-4" />
                اللعبة السابقة
              </Button>
            )}
            {view.gameIndex < games.length - 1 && (
              <Button
                onClick={() => setView({ ...view, gameIndex: view.gameIndex + 1 })}
                className="gap-1 mr-auto"
              >
                اللعبة التالية
                <ArrowRight className="h-4 w-4 rotate-180" />
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ── GAMES LIST VIEW ───────────────────────────────────────────────────────
  if (view.type === "games") {
    const category = INTERACTIVE_GAMES_CATEGORIES.find((c) => c.id === view.categoryId);
    const games = getGamesForCategory(view.categoryId);
    if (!category) return null;

    const completedCount = games.filter((g) => completedGameIds.has(g.id)).length;

    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4" dir="rtl">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setView({ type: "categories" })}
              className="gap-1"
            >
              <ArrowRight className="h-4 w-4" />
              رجوع
            </Button>
            <div>
              <h1 className="text-2xl font-bold">
                {category.emoji} {category.title}
              </h1>
              <p className="text-sm text-muted-foreground">{category.description}</p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">التقدم</span>
              <span className="text-sm text-primary font-bold">{completedCount}/{games.length}</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className={`h-2 rounded-full bg-gradient-to-r ${category.color} transition-all`}
                style={{ width: `${(completedCount / games.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Games grid */}
          <div className="grid grid-cols-1 gap-3">
            {games.map((game, index) => {
              const isCompleted = completedGameIds.has(game.id);
              const progressEntry = progressData.find((p) => p.gameId === game.id);

              return (
                <div
                  key={game.id}
                  className={`bg-white rounded-2xl p-4 shadow-sm border-2 cursor-pointer transition-all hover:scale-[1.02] ${isCompleted ? "border-green-300" : "border-border hover:border-primary/50"}`}
                  onClick={() => setView({ type: "playing", categoryId: view.categoryId, gameIndex: index })}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center text-2xl text-white shadow-sm`}>
                      {category.emoji}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-base">{game.title}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {isCompleted ? (
                          <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                            <CheckCircle className="h-3 w-3" />
                            مكتملة
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground">لم تلعب بعد</span>
                        )}
                        {progressEntry && (
                          <span className="text-xs text-amber-600 font-medium flex items-center gap-1">
                            <Star className="h-3 w-3" />
                            {progressEntry.score}%
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-primary font-medium bg-primary/10 px-2 py-1 rounded-full">
                      <Star className="h-3 w-3" />
                      {POINTS_PER_GAME} نقطة
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }
  // ── CATEGORIES VIEW (default) ─────────────────────────────────────────────────────
  const totalGames = INTERACTIVE_GAMES_CATEGORIES.reduce((sum, c) => sum + c.games.length, 0);
  const totalCompleted = progressData.filter((p) => p.isCompleted).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4" dir="rtl">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/activities")} className="gap-1 text-indigo-600">
            <ArrowRight className="h-4 w-4" />
            ← مركز الأنشطة
          </Button>
        </div>
        <div className="text-center mb-6 relative">
          <div className="text-5xl mb-2">🧠</div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            مختبر التعلم التفاعلي
          </h1>
          <p className="text-muted-foreground mt-1">اضغط على العناصر وصنّفها ورتّبها وطابقة!</p>
          {child && (
            <div className="absolute -top-2 left-0 flex items-center gap-2 bg-white/80 rounded-2xl px-3 py-2 shadow-sm border border-purple-100">
              <img
                src={character.imageUrl}
                alt={character.name}
                className="w-10 h-10 object-contain"
                style={{ filter: `drop-shadow(0 0 6px ${character.color})`, animation: 'bounce 2s infinite' }}
              />
              <div className="text-right">
                <p className="text-xs font-bold text-purple-700">{character.name}</p>
                <p className="text-xs text-gray-500">معك في كل لعبة!</p>
              </div>
            </div>
          )}
        </div>

        {/* Overall progress */}
        <div className="bg-white rounded-2xl p-4 mb-6 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
            <Trophy className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">إجمالي التقدم</p>
            <div className="flex items-center gap-2 mt-1">
              <div className="flex-1 bg-muted rounded-full h-2">
                <div
                  className="h-2 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all"
                  style={{ width: `${(totalCompleted / totalGames) * 100}%` }}
                />
              </div>
              <span className="text-sm font-bold text-primary">{totalCompleted}/{totalGames}</span>
            </div>
          </div>
        </div>

        {/* Categories grid */}
        <div className="grid grid-cols-1 gap-4">
          {INTERACTIVE_GAMES_CATEGORIES.map((category) => {
            const games = getGamesForCategory(category.id);
            const completedCount = games.filter((g) => completedGameIds.has(g.id)).length;
            const allCompleted = completedCount === games.length;

            return (
              <div
                key={category.id}
                className={`bg-white rounded-3xl p-5 shadow-sm border-2 cursor-pointer transition-all hover:scale-[1.02] hover:shadow-md ${allCompleted ? "border-green-300" : "border-border"}`}
                onClick={() => setView({ type: "games", categoryId: category.id })}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center text-3xl shadow-md`}>
                    {category.emoji}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg font-bold">{category.title}</h2>
                      {allCompleted && <CheckCircle className="h-4 w-4 text-green-500" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex-1 bg-muted rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full bg-gradient-to-r ${category.color} transition-all`}
                          style={{ width: `${(completedCount / games.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground font-medium">
                        {completedCount}/{games.length}
                      </span>
                    </div>
                  </div>
                  <div className="text-muted-foreground">
                    <ArrowRight className="h-5 w-5 rotate-180" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Info note */}
        <div className="mt-6 bg-blue-50 rounded-2xl p-4 text-center border border-blue-200">
          <p className="text-sm text-blue-700">
            كل لعبة تمنحك <strong>{POINTS_PER_GAME} نقاط</strong> عند إكمالها لأول مرة!
          </p>
        </div>
      </div>
    </div>
  );
}
