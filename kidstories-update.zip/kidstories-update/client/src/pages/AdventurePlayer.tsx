import { useState, useEffect, useCallback, useMemo } from "react";
import { useLocation, useParams, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { ArrowRight, Star, RefreshCw, Trophy, Sparkles, CheckCircle, Home, Volume2, VolumeX } from "lucide-react";
import { useAdventureSound } from "@/hooks/useAdventureSound";
import { useArabicTTS } from "@/hooks/useArabicTTS";
import { ConfettiEffect } from "@/components/ConfettiEffect";
import { FloatingPoints, useFloatingPoints } from "@/components/FloatingPoints";

// ─── Types ────────────────────────────────────────────────────────────────────
type ChoiceType = "safe" | "adventure" | "learning";

type Choice = {
  id: string;
  text: string;
  emoji: string;
  type: ChoiceType;
  points: number;
  nextNodeId: string;
};

type Node = {
  id: string;
  text: string;
  emoji: string;
  choices?: Choice[];
  isEnding?: boolean;
  endingKey?: string;
  endingType?: "good" | "great" | "learning" | "surprise" | "danger" | "bad";
  endingTitle?: string;
};

type AdventureData = {
  nodes: Node[];
  startNodeId: string;
};

// جميع الخيارات بنفس اللون - لا تلوين حسب النوع
const CHOICE_STYLES: Record<ChoiceType, { bg: string; border: string; text: string; badge: string; badgeBg: string; label: string }> = {
  safe: {
    bg: "bg-white hover:bg-purple-50",
    border: "border-purple-200",
    text: "text-gray-800",
    badge: "",
    badgeBg: "bg-purple-100 text-purple-700",
    label: "",
  },
  adventure: {
    bg: "bg-white hover:bg-purple-50",
    border: "border-purple-200",
    text: "text-gray-800",
    badge: "",
    badgeBg: "bg-purple-100 text-purple-700",
    label: "",
  },
  learning: {
    bg: "bg-white hover:bg-purple-50",
    border: "border-purple-200",
    text: "text-gray-800",
    badge: "",
    badgeBg: "bg-purple-100 text-purple-700",
    label: "",
  },
};

const ENDING_STYLES: Record<string, { bg: string; emoji: string; title: string }> = {
  good: { bg: "from-green-400 to-emerald-500", emoji: "🌟", title: "نهاية سعيدة!" },
  great: { bg: "from-yellow-400 to-orange-500", emoji: "🏆", title: "نهاية رائعة!" },
  learning: { bg: "from-blue-400 to-indigo-500", emoji: "📚", title: "تعلمت شيئاً مهماً!" },
  surprise: { bg: "from-purple-400 to-pink-500", emoji: "✨", title: "نهاية مفاجئة!" },
  danger: { bg: "from-red-500 to-rose-700", emoji: "⚠️", title: "عاقبة خطيرة!" },
  bad: { bg: "from-gray-500 to-slate-700", emoji: "😢", title: "نهاية حزينة!" },
};

// ─── Pulse animation for choice buttons ──────────────────────────────────────
const pulseKeyframes = `
@keyframes choicePulse {
  0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(139,92,246,0.4); }
  70% { transform: scale(1.02); box-shadow: 0 0 0 8px rgba(139,92,246,0); }
  100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(139,92,246,0); }
}
@keyframes shimmer {
  0% { background-position: -200% center; }
  100% { background-position: 200% center; }
}
@keyframes bounceIn {
  0% { transform: scale(0.3) translateY(20px); opacity: 0; }
  60% { transform: scale(1.1) translateY(-5px); opacity: 1; }
  80% { transform: scale(0.95) translateY(2px); }
  100% { transform: scale(1) translateY(0); opacity: 1; }
}
@keyframes slideInUp {
  from { transform: translateY(30px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}
@keyframes starSpin {
  0% { transform: rotate(0deg) scale(1); }
  50% { transform: rotate(180deg) scale(1.3); }
  100% { transform: rotate(360deg) scale(1); }
}
@keyframes newEndingGlow {
  0%, 100% { box-shadow: 0 0 20px rgba(255,215,0,0.5); }
  50% { box-shadow: 0 0 40px rgba(255,215,0,0.9), 0 0 60px rgba(255,165,0,0.5); }
}
`;

// ─── Component ────────────────────────────────────────────────────────────────
export default function AdventurePlayer() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const search = useSearch();
  const { child } = useChild();
  const adventureId = parseInt(params.id ?? "0");
  const fromChallenge = new URLSearchParams(search).get('from') === 'daily-challenge';
  const backPath = fromChallenge ? '/challenges' : '/adventures';

  const [currentNodeId, setCurrentNodeId] = useState<string | null>(null);
  const [choices, setChoices] = useState<string[]>([]);
  const [totalPoints, setTotalPoints] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [resultData, setResultData] = useState<{ pointsEarned: number; isNewEnding: boolean } | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [lastChoiceType, setLastChoiceType] = useState<ChoiceType | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [isNewEndingConfetti, setIsNewEndingConfetti] = useState(false);
  const [nodeEnterAnim, setNodeEnterAnim] = useState(false);

  const sound = useAdventureSound();
  const { items: floatingItems, showPoints, removeItem } = useFloatingPoints();
  const tts = useArabicTTS();

  const { data: adventure, isLoading } = trpc.adventures.getById.useQuery(
    { id: adventureId },
    { enabled: adventureId > 0 }
  );

  const completeMutation = trpc.adventures.complete.useMutation();

  const adventureData = adventure?.adventureData as AdventureData | undefined;
  const isEasyLevel = adventure?.level === "easy";

  useEffect(() => {
    if (adventureData?.startNodeId && !currentNodeId) {
      setCurrentNodeId(adventureData.startNodeId);
    }
  }, [adventureData, currentNodeId]);

  // Inject CSS animations
  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = pulseKeyframes;
    document.head.appendChild(style);
    return () => { document.head.removeChild(style); };
  }, []);

  // Trigger enter animation on node change
  useEffect(() => {
    if (currentNodeId) {
      setNodeEnterAnim(false);
      const t = setTimeout(() => setNodeEnterAnim(true), 50);
      return () => clearTimeout(t);
    }
  }, [currentNodeId]);

  const currentNode = adventureData?.nodes.find((n) => n.id === currentNodeId);

  // خلط الخيارات عشوائياً عند كل عقدة جديدة - حتى لا يكون الخيار الخطر دائماً آخر خيار
  const shuffledChoices = useMemo(() => {
    if (!currentNode?.choices) return [];
    return [...currentNode.choices].sort(() => Math.random() - 0.5);
  }, [currentNodeId]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleChoice = useCallback((choice: Choice) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setLastChoiceType(choice.type);
    setChoices((prev) => [...prev, choice.id]);
    setTotalPoints((prev) => prev + choice.points);

    // Play sound based on choice type
    if (choice.type === "safe") sound.playSafeChoice();
    else if (choice.type === "adventure") sound.playAdventureChoice();
    else sound.playLearningChoice();

    // Show floating points
    setTimeout(() => {
      sound.playPointsEarned(choice.points);
      showPoints(choice.points, window.innerWidth / 2 - 30, window.innerHeight * 0.35);
    }, 200);

    setTimeout(() => {
      setCurrentNodeId(choice.nextNodeId);
      setIsAnimating(false);
      setLastChoiceType(null);
    }, 500);
  }, [isAnimating, sound, showPoints]);

  const handleEnding = async () => {
    if (!currentNode?.isEnding || !currentNode.endingKey) return;
    const finalPoints = totalPoints + (adventure?.pointsReward ?? 50);

    // Play ending sound based on type
    const endType = currentNode.endingType ?? "good";
    if (endType === "great") sound.playGreatEnding();
    else if (endType === "learning") sound.playLearningEnding();
    else sound.playGoodEnding();

    try {
      let result: { pointsEarned: number; isNewEnding: boolean };

      if (child?.id) {
        result = await completeMutation.mutateAsync({
          childId: child.id,
          adventureId,
          endingKey: currentNode.endingKey,
          pointsEarned: finalPoints,
          choices,
        });
      } else {
        result = { pointsEarned: finalPoints, isNewEnding: true };
      }

      // Use result directly (no stale state)
      const isNew = result.isNewEnding;
      setResultData(result);

      if (isNew) {
        // Special new-ending celebration
        setTimeout(() => {
          sound.playNewEndingDiscovered();
          setIsNewEndingConfetti(true);
          setShowConfetti(true);
          showPoints(20, window.innerWidth / 2 - 40, window.innerHeight * 0.3, "نهاية جديدة!");
        }, 400);
        setTimeout(() => {
          showPoints(finalPoints, window.innerWidth / 2 - 30, window.innerHeight * 0.5);
        }, 900);
        // Show result screen AFTER confetti (keep confetti active on result screen)
        setTimeout(() => {
          setShowResult(true);
          // Keep confetti running on result screen for 3s more
          setTimeout(() => setShowConfetti(false), 3000);
        }, 2800);
      } else {
        // Normal ending celebration
        setTimeout(() => {
          setIsNewEndingConfetti(false);
          setShowConfetti(true);
          showPoints(finalPoints, window.innerWidth / 2 - 30, window.innerHeight * 0.45);
        }, 300);
        setTimeout(() => {
          setShowResult(true);
          setTimeout(() => setShowConfetti(false), 2000);
        }, 2000);
      }
    } catch {
      // On error, still show result without points
      setResultData({ pointsEarned: finalPoints, isNewEnding: false });
      setShowResult(true);
    }
  };

  const handleReplay = () => {
    sound.playReplay();
    setCurrentNodeId(adventureData?.startNodeId ?? null);
    setChoices([]);
    setTotalPoints(0);
    setShowResult(false);
    setResultData(null);
    setShowConfetti(false);
    setIsNewEndingConfetti(false);
  };

  // ─── Loading ────────────────────────────────────────────────────────────────
  if (isLoading || !currentNode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="text-5xl mb-4 animate-bounce">🧩</div>
          <p className="text-purple-600 font-bold">جاري تحميل المغامرة...</p>
        </div>
      </div>
    );
  }

  const endingStyle = ENDING_STYLES[currentNode.endingType ?? "good"];

  // ─── Result Screen ──────────────────────────────────────────────────────────
  if (showResult && resultData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex flex-col items-center justify-center p-6" dir="rtl">
        <ConfettiEffect active={showConfetti} isNewEnding={isNewEndingConfetti} duration={3000} />
        <FloatingPoints items={floatingItems} onRemove={removeItem} />

        <div
          className={`bg-gradient-to-br ${endingStyle.bg} rounded-3xl p-8 text-white text-center max-w-sm w-full shadow-2xl`}
          style={{
            animation: "bounceIn 0.8s cubic-bezier(0.36, 0.07, 0.19, 0.97) both",
            ...(resultData.isNewEnding ? { animation: "bounceIn 0.8s ease both, newEndingGlow 2s ease-in-out infinite" } : {}),
          }}
        >
          {/* New ending badge */}
          {resultData.isNewEnding && (
            <div
              className="bg-yellow-400 text-yellow-900 font-black text-sm px-4 py-1.5 rounded-full inline-flex items-center gap-1.5 mb-4"
              style={{ animation: "bounceIn 0.6s ease 0.3s both" }}
            >
              <Sparkles className="w-4 h-4" style={{ animation: "starSpin 1s linear infinite" }} />
              نهاية جديدة اكتشفتها! 🎉
            </div>
          )}

          <div className="text-6xl mb-4" style={{ animation: "bounceIn 0.6s ease 0.1s both" }}>
            {endingStyle.emoji}
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ animation: "slideInUp 0.5s ease 0.2s both" }}>
            {endingStyle.title}
          </h2>
          <p className="text-white/80 text-sm mb-6" style={{ animation: "slideInUp 0.5s ease 0.3s both" }}>
            {currentNode.endingTitle}
          </p>

          <div
            className="bg-white/20 rounded-2xl p-4 mb-6 space-y-3"
            style={{ animation: "slideInUp 0.5s ease 0.4s both" }}
          >
            <div className="flex items-center justify-between">
              <span className="text-white/80 text-sm">النقاط المكتسبة</span>
              <div className="flex items-center gap-1 font-bold text-lg">
                <Star className="w-5 h-5 fill-white" />
                +{resultData.pointsEarned}
              </div>
            </div>
            {resultData.isNewEnding && (
              <div className="flex items-center justify-between bg-yellow-400/20 rounded-xl p-2">
                <span className="text-white/90 text-sm font-bold">🎊 مكافأة نهاية جديدة!</span>
                <div className="flex items-center gap-1 font-bold text-yellow-200">
                  <Sparkles className="w-4 h-4" /> +20
                </div>
              </div>
            )}
          </div>

          <div className="space-y-3" style={{ animation: "slideInUp 0.5s ease 0.5s both" }}>
            <button
              onClick={handleReplay}
              className="w-full bg-white text-purple-700 font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:bg-white/90 transition-all active:scale-[0.97]"
            >
              <RefreshCw className="w-4 h-4" />
              جرّب طريقاً آخر 🔁
            </button>
            <button
              onClick={() => navigate(backPath)}
              className="w-full bg-white/20 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:bg-white/30 transition-all active:scale-[0.97]"
            >
              <ArrowRight className="w-4 h-4" />
              {fromChallenge ? 'العودة للتحديات' : 'مغامرة أخرى'}
            </button>
            <button
              onClick={() => navigate("/home")}
              className="w-full text-white/70 text-sm py-2 flex items-center justify-center gap-1"
            >
              <Home className="w-3.5 h-3.5" /> الرئيسية
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ─── Ending Node ────────────────────────────────────────────────────────────
  if (currentNode.isEnding) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 pb-20" dir="rtl">
        <ConfettiEffect active={showConfetti} isNewEnding={isNewEndingConfetti} duration={2500} />
        <FloatingPoints items={floatingItems} onRemove={removeItem} />

        <div className="px-4 pt-6 space-y-4">
          <button onClick={() => navigate(backPath)} className="flex items-center gap-2 text-purple-600 text-sm font-medium">
            <ArrowRight className="w-4 h-4" /> {fromChallenge ? 'العودة للتحديات' : 'العودة للمغامرات'}
          </button>

          <div
            className={`bg-gradient-to-br ${endingStyle.bg} rounded-3xl p-6 text-white text-center`}
            style={{ animation: nodeEnterAnim ? "bounceIn 0.6s ease both" : "none" }}
          >
            <div className="text-5xl mb-3">{currentNode.emoji}</div>
            <p className="text-lg font-semibold leading-relaxed">{currentNode.text}</p>
          </div>

          <div className="bg-white rounded-2xl p-4 flex items-center justify-between shadow-sm border border-gray-100">
            <span className="text-gray-600 font-medium">نقاطك حتى الآن</span>
            <div className="flex items-center gap-1 text-yellow-600 font-bold text-lg">
              <Star className="w-5 h-5 fill-yellow-500 text-yellow-500" />
              {totalPoints + (adventure?.pointsReward ?? 50)}
            </div>
          </div>

          <button
            onClick={handleEnding}
            disabled={completeMutation.isPending}
            className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all text-lg active:scale-[0.98]"
            style={{ animation: "choicePulse 2s ease-in-out infinite" }}
          >
            {completeMutation.isPending ? (
              <><RefreshCw className="w-5 h-5 animate-spin" /> جاري الحفظ...</>
            ) : (
              <><CheckCircle className="w-5 h-5" /> أكمل المغامرة! 🎉</>
            )}
          </button>
        </div>
      </div>
    );
  }

  // ─── Story Node with Choices ─────────────────────────────────────────────────
  const stepNumber = choices.length + 1;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-20" dir="rtl">
      <FloatingPoints items={floatingItems} onRemove={removeItem} />

      <div className="px-4 pt-4 space-y-4">

        {/* Header */}
        <div className="flex items-center justify-between">
          <button onClick={() => navigate(backPath)} className="flex items-center gap-1 text-purple-600 text-sm font-medium">
            <ArrowRight className="w-4 h-4" /> {fromChallenge ? 'التحديات' : 'العودة'}
          </button>
          <div className="flex items-center gap-2">
            <div className="bg-white border border-purple-200 rounded-full px-3 py-1 text-xs font-bold text-purple-700">
              خطوة {stepNumber}
            </div>
            <div
              className="flex items-center gap-1 bg-yellow-50 border border-yellow-200 rounded-full px-3 py-1"
              style={{ animation: lastChoiceType ? "choicePulse 0.4s ease" : "none" }}
            >
              <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
              <span className="text-xs font-bold text-yellow-700">{totalPoints}</span>
            </div>
          </div>
        </div>

        {/* Adventure title */}
        <div className="text-center">
          <h2 className="text-lg font-bold text-purple-800">{adventure?.title}</h2>
          <p className="text-xs text-purple-400">{adventure?.emoji} مغامرة تفاعلية</p>
        </div>

        {/* Story text */}
        <div
          className="bg-white rounded-3xl p-6 shadow-sm border border-purple-100"
          style={{
            animation: nodeEnterAnim ? "slideInUp 0.4s ease both" : "none",
            opacity: isAnimating ? 0 : 1,
            transform: isAnimating ? "scale(0.95)" : "scale(1)",
            transition: "opacity 0.3s ease, transform 0.3s ease",
          }}
        >
          <div className="text-center text-4xl mb-4">{currentNode.emoji}</div>
          <p className="text-gray-700 text-base leading-relaxed text-center font-medium">
            {currentNode.text}
          </p>
          {isEasyLevel && tts.isSupported && (
            <div className="flex justify-center mt-3">
              <button
                onClick={() => tts.speak(currentNode.text, `node-${currentNode.id}`)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-all ${
                  tts.speakingId === `node-${currentNode.id}`
                    ? "bg-purple-500 text-white shadow-md scale-105"
                    : "bg-purple-100 text-purple-700 hover:bg-purple-200"
                }`}
                title="استمع للقصة"
              >
                {tts.speakingId === `node-${currentNode.id}` ? (
                  <><VolumeX className="w-4 h-4" /> إيقاف</>
                ) : (
                  <><Volume2 className="w-4 h-4" /> استمع 🎧</>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Choices */}
        {shuffledChoices.length > 0 && (
          <div className="space-y-3">
            <p className="text-center text-sm font-bold text-purple-600">❓ ماذا تختار؟</p>
            {shuffledChoices.map((choice, idx) => {
              const style = CHOICE_STYLES[choice.type];
              const isSelected = lastChoiceType === choice.type && isAnimating;
              return (
                <button
                  key={choice.id}
                  onClick={() => handleChoice(choice)}
                  disabled={isAnimating}
                  className={`w-full ${style.bg} border-2 ${style.border} rounded-2xl p-4 text-right transition-all active:scale-[0.97] flex items-start gap-3`}
                  style={{
                    animation: nodeEnterAnim ? `slideInUp 0.4s ease ${idx * 0.08 + 0.1}s both` : "none",
                    transform: isSelected ? "scale(1.03)" : undefined,
                    boxShadow: isSelected ? "0 0 0 3px rgba(139,92,246,0.4)" : undefined,
                  }}
                >
                  <span className="text-2xl flex-shrink-0">{choice.emoji}</span>
                  <div className="flex-1">
                    <p className={`font-semibold ${style.text} text-sm leading-relaxed`}>{choice.text}</p>
                  </div>
                  {isEasyLevel && tts.isSupported && (
                    <button
                      onClick={(e) => { e.stopPropagation(); tts.speak(choice.text, `choice-${choice.id}`); }}
                      className={`flex-shrink-0 p-2 rounded-full transition-all ${
                        tts.speakingId === `choice-${choice.id}`
                          ? "bg-purple-500 text-white"
                          : "bg-purple-100 text-purple-600 hover:bg-purple-200"
                      }`}
                      title="استمع للخيار"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* Progress dots */}
        <div className="flex justify-center gap-2 pt-2">
          {Array.from({ length: Math.max(stepNumber, 3) }).map((_, i) => (
            <div
              key={i}
              className={`rounded-full transition-all duration-300 ${
                i < stepNumber
                  ? "bg-purple-500 w-3 h-3"
                  : "bg-purple-200 w-2 h-2"
              }`}
              style={i === stepNumber - 1 ? { animation: "choicePulse 1.5s ease-in-out infinite" } : undefined}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
