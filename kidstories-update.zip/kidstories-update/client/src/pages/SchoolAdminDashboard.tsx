import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LogOut, Download, Users, Trophy, BookOpen, Star, School, RefreshCw, FileSpreadsheet, Mail, UserCheck, UserX, TrendingUp, PieChart as PieIcon, Trash2, MoveRight, Printer, Mic, Play, Pause, ChevronDown, ChevronUp, Smile, MessageCircle } from "lucide-react";
import * as XLSX from "xlsx";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";

interface SchoolAdminSession {
  email: string;
  name: string;
  role: string;
  schoolId: number | null;
  school: { id: number; name: string; email: string } | null;
  loginTime: number;
  adminToken?: string;
}

// ─── SchoolRecordingsSection ──────────────────────────────────────────────────
function SchoolRecordingsSection({ schoolId, adminToken }: { schoolId: number; adminToken: string }) {
  const REACTIONS = [
    { emoji: '🌟', label: 'أحسنت' },
    { emoji: '👏', label: 'رائع' },
    { emoji: '❤️', label: 'ممتاز' },
    { emoji: '😊', label: 'جميل' },
    { emoji: '🎉', label: 'برافو' },
    { emoji: '👑', label: 'ملك القراءة' },
    { emoji: '🔥', label: 'رائع جداً' },
    { emoji: '💫', label: 'نجم متألق' },
  ];
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [filterChild, setFilterChild] = useState('');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const utils = trpc.useUtils();

  const headers = adminToken ? { 'x-admin-token': adminToken } : {};

  const { data: recordings = [], isLoading, refetch } = trpc.recordings.getSchoolRecordings.useQuery(
    { schoolId },
    { enabled: schoolId > 0 }
  );

  const addReactionMut = trpc.recordings.schoolAddReaction.useMutation({
    onSuccess: () => { utils.recordings.getSchoolRecordings.invalidate(); toast.success('تم إرسال رد الفعل!'); },
    onError: () => toast.error('فشل إرسال رد الفعل'),
  });

  const deleteReactionMut = trpc.recordings.schoolDeleteReaction.useMutation({
    onSuccess: () => { utils.recordings.getSchoolRecordings.invalidate(); },
    onError: () => toast.error('فشل حذف رد الفعل'),
  });

  const playAudio = useCallback((rec: any) => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
    if (playingId === rec.id) { setPlayingId(null); return; }
    const audio = new Audio(rec.audioUrl);
    audioRef.current = audio;
    audio.onended = () => setPlayingId(null);
    audio.onerror = () => { toast.error('تعذّر تشغيل التسجيل'); setPlayingId(null); };
    audio.play().then(() => setPlayingId(rec.id)).catch(() => toast.error('تعذّر تشغيل التسجيل'));
  }, [playingId]);

  const filtered = (recordings as any[]).filter(r =>
    !filterChild || r.childName?.includes(filterChild)
  );

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full" />
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <Mic className="w-5 h-5 text-purple-600" />
          تسجيلات الطلاب
          <Badge className="bg-purple-100 text-purple-700">{filtered.length}</Badge>
        </h2>
        <div className="flex gap-2">
          <Input
            placeholder="ابحث باسم الطالب..."
            value={filterChild}
            onChange={e => setFilterChild(e.target.value)}
            className="w-48 rounded-xl text-sm"
          />
          <Button variant="outline" size="sm" onClick={() => refetch()} className="gap-1">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <Mic className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>لا توجد تسجيلات بعد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((rec: any) => (
            <Card key={rec.id} className="bg-white border-0 shadow-md overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  {/* زر التشغيل */}
                  <button
                    onClick={() => playAudio(rec)}
                    className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
                      playingId === rec.id
                        ? 'bg-purple-600 text-white'
                        : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                    }`}
                  >
                    {playingId === rec.id ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  </button>

                  {/* معلومات التسجيل */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-gray-900">{rec.childName}</span>
                      {rec.storyTitle && (
                        <Badge className="bg-blue-100 text-blue-700 text-xs">{rec.storyTitle}</Badge>
                      )}
                      {rec.pageNumber && (
                        <Badge className="bg-gray-100 text-gray-600 text-xs">ص{rec.pageNumber}</Badge>
                      )}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {new Date(rec.createdAt).toLocaleDateString('ar-SA')} •
                      {rec.durationSeconds ? ` ${rec.durationSeconds}ث` : ''}
                    </div>
                    {/* ردود الفعل الموجودة */}
                    {rec.reactions?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {rec.reactions.map((rx: any) => (
                          <span
                            key={rx.id}
                            className="inline-flex items-center gap-1 bg-yellow-50 border border-yellow-200 rounded-full px-2 py-0.5 text-xs cursor-pointer hover:bg-red-50 hover:border-red-200 group"
                            title="اضغط للحذف"
                            onClick={() => deleteReactionMut.mutate({ reactionId: rx.id, schoolId })}
                          >
                            {rx.emoji} <span className="text-gray-600">{rx.label}</span>
                            <span className="text-red-400 opacity-0 group-hover:opacity-100">×</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* زر ردود الفعل */}
                  <button
                    onClick={() => setExpandedId(expandedId === rec.id ? null : rec.id)}
                    className="flex-shrink-0 p-2 rounded-xl bg-yellow-50 hover:bg-yellow-100 text-yellow-700 transition-colors"
                    title="إرسال رد فعل"
                  >
                    <Smile className="w-5 h-5" />
                  </button>
                </div>

                {/* لوحة ردود الفعل */}
                {expandedId === rec.id && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <p className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                      <MessageCircle className="w-3 h-3" />
                      أرسل رد فعل للطالب:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {REACTIONS.map(r => (
                        <button
                          key={r.emoji}
                          onClick={() => {
                            addReactionMut.mutate({ recordingId: rec.id, emoji: r.emoji, label: r.label, schoolId });
                            setExpandedId(null);
                          }}
                          disabled={addReactionMut.isPending}
                          className="flex items-center gap-1 bg-white border border-gray-200 rounded-full px-3 py-1.5 text-sm hover:bg-yellow-50 hover:border-yellow-300 transition-colors"
                        >
                          <span className="text-base">{r.emoji}</span>
                          <span className="text-gray-700">{r.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

export default function SchoolAdminDashboard() {
  const [, navigate] = useLocation();
  const [session, setSession] = useState<SchoolAdminSession | null>(null);
  const [isPrinting, setIsPrinting] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  // التحديد الجماعي للطلاب
  const [selectedStudentIds, setSelectedStudentIds] = useState<Set<number>>(new Set());
  const [showBulkTransferDialog, setShowBulkTransferDialog] = useState(false);
  const [bulkTargetClassroom, setBulkTargetClassroom] = useState<string>("");
  const [activeSection, setActiveSection] = useState<'stats' | 'recordings'>('stats');
  const [activeClassroomTab, setActiveClassroomTab] = useState<string>('all');
  const [playingAudio, setPlayingAudio] = useState<number | null>(null);
  const [expandedRecording, setExpandedRecording] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("adminSession");
    if (!stored) { navigate("/"); return; }
    try {
      const parsed = JSON.parse(stored) as SchoolAdminSession;
      const ONE_WEEK = 7 * 24 * 60 * 60 * 1000;
      const ONE_MONTH = 30 * 24 * 60 * 60 * 1000;
      const duration = (parsed as any).rememberMe ? ONE_MONTH : ONE_WEEK;
      if (Date.now() - parsed.loginTime > duration) {
        localStorage.removeItem("adminSession");
        navigate("/");
        return;
      }
      if (parsed.role !== "school_admin") {
        navigate("/admin");
        return;
      }
      setSession(parsed);
    } catch {
      navigate("/");
    }
  }, []);

  const schoolId = session?.schoolId ?? 0;
  const { data: stats, isLoading, refetch } = trpc.schools.getStats.useQuery(
    { schoolId },
    { enabled: !!schoolId }
  );
  const { data: subStats } = (trpc.email as any).schoolSubscriberStats.useQuery(
    { schoolId },
    { enabled: !!schoolId }
  );
  const subMonthly: any[] = subStats?.monthly ?? [];
  const subStatusDist: any[] = subStats?.statusDist ?? [];
  const subTotal = subStats?.total ?? 0;
  const subActive = subStats?.activeCount ?? 0;
  const subUnsub = subStats?.unsubCount ?? 0;

  const bulkDeleteMutation = (trpc.schools as any).bulkDeleteChildren.useMutation({
    onSuccess: (data: any) => {
      toast.success(`✅ تم حذف ${data.deleted} طالب بنجاح`);
      setSelectedStudentIds(new Set());
      refetch();
    },
    onError: () => toast.error("حدث خطأ أثناء الحذف"),
  });

  const bulkTransferMutation = (trpc.schools as any).bulkTransferClassroom.useMutation({
    onSuccess: (data: any) => {
      toast.success(`✅ تم نقل ${data.transferred} طالب إلى الفصل بنجاح`);
      setSelectedStudentIds(new Set());
      setShowBulkTransferDialog(false);
      setBulkTargetClassroom("");
      refetch();
    },
    onError: () => toast.error("حدث خطأ أثناء النقل"),
  });

  const RADIAN = Math.PI / 180;
  const renderPieLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }: any) => {
    if (percent < 0.05) return null;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    return (
      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={13} fontWeight="bold">
        {`${name} ${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  const handleLogout = () => {
    localStorage.removeItem("adminSession");
    toast.success("تم تسجيل الخروج");
    navigate("/");
  };

  const handlePrint = async () => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 300);
  };

  const handlePrintSelected = () => {
    const students = (stats as any)?.students ?? [];
    const selected = students.filter((s: any) => selectedStudentIds.has(s.id));
    if (!selected.length) { toast.error("لم تحدد أي طالب"); return; }
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    const rows = selected.map((s: any, i: number) => `
      <tr>
        <td>${i + 1}</td>
        <td>${s.avatarEmoji ?? "🧒"} ${s.name}</td>
        <td>${s.classroom ?? "غير محدد"}</td>
        <td>${s.ageGroup} سنة</td>
        <td>${s.totalPoints ?? 0} ⭐</td>
        <td>${s.storiesRead ?? 0}</td>
        <td>${s.gamesPlayed ?? 0}</td>
      </tr>`).join("");
    printWindow.document.write(`
      <html dir="rtl"><head><title>قائمة الطلاب المحددين</title>
      <style>body{font-family:Arial;} table{width:100%;border-collapse:collapse;} th,td{border:1px solid #ccc;padding:8px;text-align:right;} th{background:#f0f0f0;}</style>
      </head><body>
      <h2>${session?.school?.name ?? "المدرسة"} - قائمة الطلاب المحددين</h2>
      <p>التاريخ: ${new Date().toLocaleDateString("ar-SA")} | عدد الطلاب: ${selected.length}</p>
      <table><thead><tr><th>#</th><th>الاسم</th><th>الفصل</th><th>الفئة العمرية</th><th>النقاط</th><th>القصص</th><th>الألعاب</th></tr></thead>
      <tbody>${rows}</tbody></table>
      <script>window.print();window.close();</script>
      </body></html>`);
    printWindow.document.close();
  };

  if (!session) return null;

  const schoolName = session.school?.name ?? "مدرستي";
  const allStudents: any[] = (stats as any)?.students ?? [];
  const allClassrooms: string[] = Array.from(new Set(allStudents.map((s: any) => s.classroom).filter(Boolean))) as string[];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 print:hidden">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
              <School className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">{schoolName}</h1>
              <p className="text-sm text-gray-500">لوحة إحصائيات المدرسة</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600 hidden sm:block">مرحباً، {session.name}</span>
            <Button variant="outline" size="sm" onClick={() => refetch()} className="gap-2">
              <RefreshCw className="w-4 h-4" />
              تحديث
            </Button>
            <Button variant="outline" size="sm" onClick={handlePrint} className="gap-2">
              <Download className="w-4 h-4" />
              تصدير PDF
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 border-green-500 text-green-700 hover:bg-green-50"
              onClick={() => {
                const students = (stats as any)?.students;
                const classrooms = (stats as any)?.classrooms;
                if (!students?.length) { toast.error("لا يوجد طلاب لتصديرهم"); return; }
                const studentRows = students.map((s: any, idx: number) => ({
                  "#": idx + 1,
                  "اسم الطالب": s.name,
                  "الفصل": s.classroom ?? "غير محدد",
                  "الفئة العمرية": `${s.ageGroup} سنة`,
                  "النقاط": s.totalPoints ?? 0,
                  "القصص المقروءة": s.storiesRead ?? 0,
                  "الألعاب الملعوبة": s.gamesPlayed ?? 0,
                }));
                const ws1 = XLSX.utils.json_to_sheet(studentRows);
                ws1["!cols"] = [{ wch: 5 }, { wch: 25 }, { wch: 15 }, { wch: 15 }, { wch: 10 }, { wch: 15 }, { wch: 15 }];
                const classroomRows = classrooms?.length
                  ? classrooms.map((c: any) => ({
                      "اسم الفصل": c.classroom ?? "غير محدد",
                      "عدد الطلاب": c.studentCount,
                      "متوسط النقاط": Math.round(c.avgPoints ?? 0),
                      "مجموع النقاط": c.totalPoints ?? 0,
                      "أعلى نقاط": c.maxPoints ?? 0,
                      "أدنى نقاط": c.minPoints ?? 0,
                    }))
                  : [{ "ملاحظة": "لا توجد بيانات فصول متاحة" }];
                const ws2 = XLSX.utils.json_to_sheet(classroomRows);
                ws2["!cols"] = [{ wch: 20 }, { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 12 }, { wch: 12 }];
                const summaryRows = [{
                  "اسم المدرسة": schoolName,
                  "تاريخ التقرير": new Date().toLocaleDateString("ar-SA"),
                  "إجمالي الطلاب": students.length,
                  "عدد الفصول": classrooms?.length ?? 0,
                  "مجموع النقاط": students.reduce((a: number, s: any) => a + (s.totalPoints ?? 0), 0),
                  "متوسط النقاط": Math.round(students.reduce((a: number, s: any) => a + (s.totalPoints ?? 0), 0) / students.length),
                }];
                const ws3 = XLSX.utils.json_to_sheet(summaryRows);
                ws3["!cols"] = [{ wch: 25 }, { wch: 18 }, { wch: 15 }, { wch: 12 }, { wch: 15 }, { wch: 15 }];
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws1, "قائمة الطلاب");
                XLSX.utils.book_append_sheet(wb, ws2, "إحصائيات الفصول");
                XLSX.utils.book_append_sheet(wb, ws3, "ملخص عام");
                const date = new Date().toLocaleDateString("ar-SA").replace(/\//g, "-");
                XLSX.writeFile(wb, `تقرير_${schoolName}_${date}.xlsx`);
                toast.success(`✅ تم تصدير تقرير شامل (${students.length} طالب + إحصائيات الفصول)`);
              }}
            >
              <FileSpreadsheet className="w-4 h-4" />
              تصدير Excel
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2 text-red-600 hover:text-red-700 border-red-200">
              <LogOut className="w-4 h-4" />
              خروج
            </Button>
          </div>
        </div>
      </header>

      {/* Dialog النقل بين الفصول */}
      {showBulkTransferDialog && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-xl font-bold mb-4">🏫 نقل {selectedStudentIds.size} طالب إلى فصل آخر</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-bold mb-1 block">الفصل المستهدف</Label>
                {allClassrooms.length > 0 ? (
                  <Select value={bulkTargetClassroom} onValueChange={setBulkTargetClassroom}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="اختر فصلاً" />
                    </SelectTrigger>
                    <SelectContent>
                      {allClassrooms.map((cls) => (
                        <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input value={bulkTargetClassroom} onChange={(e) => setBulkTargetClassroom(e.target.value)}
                    placeholder="اكتب اسم الفصل (مثل: فصل أ)" className="rounded-xl" />
                )}
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <Button className="flex-1 rounded-xl" disabled={!bulkTargetClassroom || bulkTransferMutation.isPending}
                onClick={() => {
                  if (!bulkTargetClassroom.trim()) { toast.error("يرجى اختيار فصل"); return; }
                  bulkTransferMutation.mutate({
                    childIds: Array.from(selectedStudentIds) as number[],
                    schoolId,
                    classroom: bulkTargetClassroom,
                  });
                }}>
                {bulkTransferMutation.isPending ? "جاري النقل..." : "تأكيد النقل"}
              </Button>
              <Button variant="outline" className="rounded-xl" onClick={() => setShowBulkTransferDialog(false)}>إلغاء</Button>
            </div>
          </div>
        </div>
      )}

      {/* Print Header */}
      <div className="hidden print:block p-6 border-b">
        <h1 className="text-2xl font-bold text-center">{schoolName} - تقرير الإحصائيات</h1>
        <p className="text-center text-gray-500 mt-1">تاريخ التقرير: {new Date().toLocaleDateString("ar-SA")}</p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200 print:hidden">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1">
            <button
              onClick={() => setActiveSection('stats')}
              className={`px-6 py-3 text-sm font-semibold border-b-2 transition-colors ${
                activeSection === 'stats'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <TrendingUp className="w-4 h-4 inline ml-2" />
              الإحصائيات والتقارير
            </button>
            <button
              onClick={() => setActiveSection('recordings')}
              className={`px-6 py-3 text-sm font-semibold border-b-2 transition-colors ${
                activeSection === 'recordings'
                  ? 'border-purple-600 text-purple-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Mic className="w-4 h-4 inline ml-2" />
              تسجيلات الطلاب
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-8" ref={printRef}>
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full" />
          </div>
        ) : !stats ? (
          <div className="text-center py-20 text-gray-500">
            <School className="w-16 h-16 mx-auto mb-4 opacity-30" />
            <p className="text-lg">لا توجد بيانات متاحة</p>
          </div>
        ) : (
          <>
            {activeSection === 'recordings' ? (
              <SchoolRecordingsSection schoolId={schoolId} adminToken={session.adminToken ?? ''} />
            ) : (
            <>
            {/* Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <Card className="bg-white border-0 shadow-md">
                <CardContent className="p-5 text-center">
                  <Users className="w-8 h-8 text-indigo-600 mx-auto mb-2" />
                  <div className="text-3xl font-bold text-gray-900">{(stats as any).totalStudents ?? 0}</div>
                  <div className="text-sm text-gray-500 mt-1">إجمالي الطلاب</div>
                </CardContent>
              </Card>
              <Card className="bg-white border-0 shadow-md">
                <CardContent className="p-5 text-center">
                  <BookOpen className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <div className="text-3xl font-bold text-gray-900">{(stats as any).totalStoriesRead ?? 0}</div>
                  <div className="text-sm text-gray-500 mt-1">قصص مقروءة</div>
                </CardContent>
              </Card>
              <Card className="bg-white border-0 shadow-md">
                <CardContent className="p-5 text-center">
                  <Trophy className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                  <div className="text-3xl font-bold text-gray-900">{(stats as any).totalPoints ?? 0}</div>
                  <div className="text-sm text-gray-500 mt-1">مجموع النقاط</div>
                </CardContent>
              </Card>
              <Card className="bg-white border-0 shadow-md">
                <CardContent className="p-5 text-center">
                  <Star className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <div className="text-3xl font-bold text-gray-900">{(stats as any).avgPoints ?? 0}</div>
                  <div className="text-sm text-gray-500 mt-1">متوسط النقاط</div>
                </CardContent>
              </Card>
            </div>

            {/* Students Table - مع تبويبات الفصول */}
            {(() => {
              const classroomStats: any[] = (stats as any).classroomStats ?? [];
              const classroomNames: string[] = classroomStats.map((c: any) => c.name);
              const displayedStudents = activeClassroomTab === 'all'
                ? allStudents
                : allStudents.filter((s: any) => s.classroom === activeClassroomTab);
              return (
            <Card className="bg-white border-0 shadow-md">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
                    <Users className="w-5 h-5 text-indigo-600" />
                    قائمة الطلاب
                    {allStudents.length > 0 && (
                      <span className="text-sm font-normal text-gray-500">({displayedStudents.length} / {allStudents.length} طالب)</span>
                    )}
                  </CardTitle>
                  {/* أزرار التحديد الكلي */}
                  {displayedStudents.length > 0 && (
                    <div className="flex items-center gap-2 print:hidden">
                      <button
                        className="text-xs text-indigo-600 hover:underline"
                        onClick={() => setSelectedStudentIds(new Set(displayedStudents.map((s: any) => s.id)))}
                      >تحديد الكل</button>
                      <span className="text-gray-300">|</span>
                      <button
                        className="text-xs text-gray-500 hover:underline"
                        onClick={() => setSelectedStudentIds(new Set())}
                      >إلغاء الكل</button>
                    </div>
                  )}
                </div>
                {/* تبويبات الفصول */}
                {classroomNames.length > 0 && (
                  <div className="flex gap-2 flex-wrap mt-3 print:hidden">
                    <button
                      onClick={() => setActiveClassroomTab('all')}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                        activeClassroomTab === 'all'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      الكل ({allStudents.length})
                    </button>
                    {classroomNames.map((name: string) => {
                      const cls = classroomStats.find((c: any) => c.name === name);
                      return (
                        <button
                          key={name}
                          onClick={() => setActiveClassroomTab(name)}
                          className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                            activeClassroomTab === name
                              ? 'bg-indigo-600 text-white'
                              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                          }`}
                        >
                          {name} ({cls?.count ?? 0})
                        </button>
                      );
                    })}
                  </div>
                )}
              </CardHeader>
              <CardContent>
                {/* شريط الإجراءات الجماعية */}
                {selectedStudentIds.size > 0 && (
                  <div className="mb-4 p-3 bg-indigo-50 rounded-xl flex items-center justify-between flex-wrap gap-2 print:hidden">
                    <span className="text-sm font-semibold text-indigo-700">
                      ✅ تم تحديد {selectedStudentIds.size} طالب
                    </span>
                    <div className="flex gap-2 flex-wrap">
                      <Button size="sm" variant="outline" className="gap-1 text-blue-600 border-blue-300 hover:bg-blue-50 rounded-lg"
                        onClick={handlePrintSelected}>
                        <Printer className="w-4 h-4" />
                        طباعة
                      </Button>
                      <Button size="sm" variant="outline" className="gap-1 text-orange-600 border-orange-300 hover:bg-orange-50 rounded-lg"
                        onClick={() => setShowBulkTransferDialog(true)}>
                        <MoveRight className="w-4 h-4" />
                        نقل لفصل آخر
                      </Button>
                      <Button size="sm" variant="outline" className="gap-1 text-red-600 border-red-300 hover:bg-red-50 rounded-lg"
                        disabled={bulkDeleteMutation.isPending}
                        onClick={() => {
                          if (!confirm(`هل أنت متأكد من حذف ${selectedStudentIds.size} طالب؟ لا يمكن التراجع.`)) return;
                          bulkDeleteMutation.mutate({
                            childIds: Array.from(selectedStudentIds) as number[],
                            schoolId,
                          });
                        }}>
                        <Trash2 className="w-4 h-4" />
                        {bulkDeleteMutation.isPending ? "جاري الحذف..." : "حذف"}
                      </Button>
                    </div>
                  </div>
                )}

                {!allStudents.length ? (
                  <p className="text-center text-gray-400 py-8">لا يوجد طلاب مسجلون في هذه المدرسة بعد</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-50 text-gray-600">
                          <th className="py-3 px-4 rounded-r-lg print:hidden">
                            <input type="checkbox"
                              className="w-4 h-4 rounded cursor-pointer"
                              checked={selectedStudentIds.size === allStudents.length && allStudents.length > 0}
                              onChange={(e) => {
                                if (e.target.checked) setSelectedStudentIds(new Set(allStudents.map((s: any) => s.id)));
                                else setSelectedStudentIds(new Set());
                              }}
                            />
                          </th>
                          <th className="text-right py-3 px-4 font-semibold">#</th>
                          <th className="text-right py-3 px-4 font-semibold">اسم الطالب</th>
                          <th className="text-right py-3 px-4 font-semibold">الفصل</th>
                          <th className="text-right py-3 px-4 font-semibold">الفئة العمرية</th>
                          <th className="text-right py-3 px-4 font-semibold">النقاط</th>
                          <th className="text-right py-3 px-4 font-semibold">القصص</th>
                          <th className="text-right py-3 px-4 font-semibold rounded-l-lg">الألعاب</th>
                        </tr>
                      </thead>
                      <tbody>
                        {allStudents.map((student: any, idx: number) => (
                          <tr key={student.id}
                            className={`border-b border-gray-100 transition-colors cursor-pointer ${selectedStudentIds.has(student.id) ? 'bg-indigo-50' : 'hover:bg-gray-50'}`}
                            onClick={() => {
                              const next = new Set(selectedStudentIds);
                              if (next.has(student.id)) next.delete(student.id); else next.add(student.id);
                              setSelectedStudentIds(next);
                            }}
                          >
                            <td className="py-3 px-4 print:hidden" onClick={(e) => e.stopPropagation()}>
                              <input type="checkbox" className="w-4 h-4 rounded cursor-pointer"
                                checked={selectedStudentIds.has(student.id)}
                                onChange={(e) => {
                                  const next = new Set(selectedStudentIds);
                                  if (e.target.checked) next.add(student.id); else next.delete(student.id);
                                  setSelectedStudentIds(next);
                                }}
                              />
                            </td>
                            <td className="py-3 px-4 text-gray-400 font-mono">{idx + 1}</td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2">
                                <span className="text-xl">{student.avatarEmoji ?? "🧒"}</span>
                                <span className="font-medium text-gray-900">{student.name}</span>
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <Badge variant="outline" className="text-xs">
                                {student.classroom ?? "غير محدد"}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-gray-600">{student.ageGroup}</td>
                            <td className="py-3 px-4">
                              <span className="font-bold text-yellow-600">{student.totalPoints ?? 0} ⭐</span>
                            </td>
                            <td className="py-3 px-4 text-green-600 font-medium">{student.storiesRead ?? 0}</td>
                            <td className="py-3 px-4 text-indigo-600 font-medium">{student.gamesPlayed ?? 0}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
             </Card>
            ); })()
            }

            {/* Classroom Breakdown - إحصائيات مفصّلة لكل فصل */}
            {(stats as any).classroomStats?.length > 0 && (
              <Card className="bg-white border-0 shadow-md mt-6">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
                    <span>🏫</span>
                    إحصائيات الفصول
                    <span className="text-sm font-normal text-gray-500">({(stats as any).classroomStats.length} فصل)</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {(stats as any).classroomStats.map((cls: any) => (
                      <div key={cls.name} className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-5 border border-indigo-100">
                        {/* عنوان الفصل */}
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                              <span className="text-white text-sm font-bold">{cls.name?.charAt(0)}</span>
                            </div>
                            <span className="font-bold text-indigo-800 text-base">{cls.name}</span>
                          </div>
                          <span className="bg-indigo-600 text-white text-xs font-bold px-2 py-1 rounded-full">{cls.count} طالب</span>
                        </div>
                        {/* إحصائيات الفصل */}
                        <div className="grid grid-cols-3 gap-2 mb-3">
                          <div className="bg-white rounded-xl p-2 text-center">
                            <div className="text-lg font-bold text-indigo-600">{cls.avgPoints}</div>
                            <div className="text-xs text-gray-500">متوسط النقاط</div>
                          </div>
                          <div className="bg-white rounded-xl p-2 text-center">
                            <div className="text-lg font-bold text-green-600">{cls.storiesRead}</div>
                            <div className="text-xs text-gray-500">قصص مكتملة</div>
                          </div>
                          <div className="bg-white rounded-xl p-2 text-center">
                            <div className="text-lg font-bold text-orange-600">{cls.gamesPlayed}</div>
                            <div className="text-xs text-gray-500">ألعاب</div>
                          </div>
                        </div>
                        {/* أفضل طالب */}
                        {cls.topStudent && (
                          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-2 flex items-center gap-2">
                            <span className="text-lg">🏆</span>
                            <div>
                              <div className="text-xs text-yellow-700 font-semibold">أفضل طالب</div>
                              <div className="text-sm font-bold text-yellow-800">{cls.topStudent.name}</div>
                              <div className="text-xs text-yellow-600">{cls.topStudent.points} نقطة</div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Email Subscribers Section */}
            <Card className="bg-white border-0 shadow-md mt-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Mail className="w-5 h-5 text-indigo-600" />
                  إحصائيات المشتركين في البريد
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-indigo-50 rounded-xl p-4 text-center">
                    <Users className="w-5 h-5 mx-auto mb-1 text-indigo-600" />
                    <p className="text-2xl font-bold text-indigo-600">{subTotal}</p>
                    <p className="text-xs text-gray-500">إجمالي المشتركين</p>
                  </div>
                  <div className="bg-green-50 rounded-xl p-4 text-center">
                    <UserCheck className="w-5 h-5 mx-auto mb-1 text-green-600" />
                    <p className="text-2xl font-bold text-green-600">{subActive}</p>
                    <p className="text-xs text-gray-500">نشط</p>
                  </div>
                  <div className="bg-red-50 rounded-xl p-4 text-center">
                    <UserX className="w-5 h-5 mx-auto mb-1 text-red-500" />
                    <p className="text-2xl font-bold text-red-500">{subUnsub}</p>
                    <p className="text-xs text-gray-500">ملغى الاشتراك</p>
                  </div>
                </div>

                {subTotal === 0 ? (
                  <div className="text-center text-gray-400 py-8">
                    <Mail className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p>لا يوجد مشتركون مرتبطون بهذه المدرسة بعد</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    <div className="lg:col-span-2">
                      <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
                        <TrendingUp className="w-4 h-4 text-indigo-500" />
                        نمو المشتركين شهرياً
                      </p>
                      <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={subMonthly} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                          <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                          <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                          <Tooltip
                            contentStyle={{ borderRadius: 8, fontSize: 12 }}
                            formatter={(val: any, name: string) => [val, name === "subscribed" ? "اشتراك جديد" : "إلغاء"]}
                          />
                          <Legend formatter={(val) => val === "subscribed" ? "اشتراك جديد" : "إلغاء اشتراك"} wrapperStyle={{ fontSize: 11 }} />
                          <Bar dataKey="subscribed" fill="#10b981" radius={[4, 4, 0, 0]} name="subscribed" />
                          <Bar dataKey="unsubscribed" fill="#ef4444" radius={[4, 4, 0, 0]} name="unsubscribed" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
                        <PieIcon className="w-4 h-4 text-indigo-500" />
                        توزيع الحالات
                      </p>
                      <ResponsiveContainer width="100%" height={200}>
                        <PieChart>
                          <Pie data={subStatusDist} cx="50%" cy="50%" outerRadius={75} dataKey="value" labelLine={false} label={renderPieLabel}>
                            {subStatusDist.map((entry: any, i: number) => (
                              <Cell key={i} fill={entry.fill} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                          <Legend wrapperStyle={{ fontSize: 11 }} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            </>
            )}
          </>
        )}
      </main>

      <style>{`
        @media print {
          .print\\:hidden { display: none !important; }
          .print\\:block { display: block !important; }
          body { background: white; }
        }
      `}</style>
    </div>
  );
}
