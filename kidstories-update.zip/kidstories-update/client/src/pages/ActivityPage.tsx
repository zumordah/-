import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation, useParams, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { Button } from "@/components/ui/button";
import { Home, CheckCircle, XCircle, Star, Trophy, ArrowLeft, ChevronRight } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

// ─── مؤثرات صوتية بسيطة باستخدام Web Audio API ─────────────────────────────
function playSound(type: "correct" | "wrong" | "complete" | "click") {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === "correct") {
      // نغمة صاعدة للإجابة الصحيحة
      osc.frequency.setValueAtTime(523, ctx.currentTime);
      osc.frequency.setValueAtTime(659, ctx.currentTime + 0.1);
      osc.frequency.setValueAtTime(784, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.5);
    } else if (type === "wrong") {
      // نغمة هابطة للإجابة الخاطئة
      osc.frequency.setValueAtTime(400, ctx.currentTime);
      osc.frequency.setValueAtTime(300, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } else if (type === "complete") {
      // لحن احتفالي عند الإنهاء
      const notes = [523, 659, 784, 1047];
      notes.forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.setValueAtTime(0.25, ctx.currentTime + i * 0.12);
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.3);
        o.start(ctx.currentTime + i * 0.12);
        o.stop(ctx.currentTime + i * 0.12 + 0.3);
      });
      return;
    } else if (type === "click") {
      osc.frequency.value = 600;
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.1);
    }
  } catch {}
}

// ─── مكوّن النجوم المتطايرة ─────────────────────────────────────────────────
function StarBurst({ active }: { active: boolean }) {
  if (!active) return null;
  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={i}
          className="absolute text-2xl animate-ping"
          style={{
            top: `${20 + Math.random() * 60}%`,
            left: `${10 + Math.random() * 80}%`,
            animationDelay: `${i * 0.08}s`,
            animationDuration: "0.6s",
            opacity: 0,
          }}
        >
          {["⭐", "🌟", "✨", "💫"][i % 4]}
        </div>
      ))}
    </div>
  );
}

export default function ActivityPage() {
  const params = useParams<{ id: string }>();
  const activityId = parseInt(params.id || "0");
  const [, navigate] = useLocation();
  const search = useSearch();
  const { child } = useChild();
  const searchParams = new URLSearchParams(search);
  const fromChallenge = searchParams.get('from') === 'daily-challenge';
  const returnLevel = searchParams.get('level') ?? 'easy';
  const backPath = fromChallenge ? '/challenges' : `/activities/stories?level=${returnLevel}`;

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [pointsEarned, setPointsEarned] = useState(0);
  const [newAchievements, setNewAchievements] = useState<any[]>([]);
  const [showStars, setShowStars] = useState(false);
  const [answerAnim, setAnswerAnim] = useState<"correct" | "wrong" | null>(null);
  const [cardAnim, setCardAnim] = useState(false);

  const { data, isLoading } = trpc.activities.getWithQuestions.useQuery({ id: activityId });
  const submitMutation = trpc.activities.submitResult.useMutation();
  const utils = trpc.useUtils();

  if (!child) { navigate("/"); return null; }

  const activity = data?.activity;
  const questions = data?.questions || [];
  const currentQ = questions[currentQuestion];

  const getOptions = (q: typeof currentQ): string[] => {
    if (!q) return [];
    try {
      if (typeof q.options === "string") return JSON.parse(q.options);
      if (Array.isArray(q.options)) return q.options;
    } catch {}
    return [];
  };

  const handleAnswer = (answerIndex: string) => {
    if (isAnswered) return;
    playSound("click");
    setSelectedAnswer(answerIndex);
    setIsAnswered(true);

    const isCorrect = answerIndex === currentQ?.correctAnswer;
    if (isCorrect) {
      setScore((s) => s + 1);
      setAnswerAnim("correct");
      setShowStars(true);
      playSound("correct");
      setTimeout(() => setShowStars(false), 800);
    } else {
      setAnswerAnim("wrong");
      playSound("wrong");
    }
    setTimeout(() => setAnswerAnim(null), 600);
  };

  const handleNext = async () => {
    playSound("click");
    if (currentQuestion + 1 < questions.length) {
      setCardAnim(true);
      setTimeout(() => {
        setCurrentQuestion((q) => q + 1);
        setSelectedAnswer(null);
        setIsAnswered(false);
        setCardAnim(false);
      }, 250);
    } else {
      const finalScore = score;
      const isCompleted = true;
      try {
        const result = await submitMutation.mutateAsync({
          childId: child.id,
          activityId,
          score: finalScore,
          maxScore: questions.length,
          isCompleted,
        });
        setPointsEarned(result.pointsEarned);
        setNewAchievements(result.newAchievements || []);
        utils.children.getById.invalidate({ id: child.id });
        playSound("complete");
      } catch {}
      setShowResult(true);
    }
  };

  const percentage = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;

  const getResultEmoji = () => {
    if (percentage >= 80) return "🏆";
    if (percentage >= 60) return "⭐";
    if (percentage >= 40) return "👍";
    return "💪";
  };

  const getResultMessage = () => {
    if (percentage >= 80) return "ممتاز! أنت نجم حقيقي!";
    if (percentage >= 60) return "جيد جداً! استمر!";
    if (percentage >= 40) return "جيد! يمكنك التحسن!";
    return "حاول مرة أخرى، أنت قادر!";
  };

  const getResultBg = () => {
    if (percentage >= 80) return "from-yellow-400 via-orange-400 to-red-400";
    if (percentage >= 60) return "from-purple-500 via-indigo-500 to-blue-500";
    if (percentage >= 40) return "from-green-400 via-teal-400 to-cyan-400";
    return "from-gray-400 via-slate-400 to-zinc-400";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 via-indigo-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="text-7xl mb-4 animate-bounce">🎮</div>
          <p className="text-purple-600 font-bold text-lg">جاري تحميل النشاط...</p>
        </div>
      </div>
    );
  }

  if (!activity || questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <p className="text-muted-foreground">لم نجد هذا النشاط</p>
          <Button onClick={() => navigate("/home")} className="mt-4">العودة</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-indigo-50 to-blue-100 flex flex-col" dir="rtl">
      <StarBurst active={showStars} />

      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm border-b border-purple-100 sticky top-0 z-40 shadow-sm">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-1">
            <button onClick={() => navigate("/home")} className="flex-shrink-0">
              <img src={LOGO_URL} alt="قصة وفكرة" className="w-8 h-8 object-contain" />
            </button>
            <Button variant="ghost" size="sm" onClick={() => navigate(backPath)} className="gap-1 rounded-xl text-purple-700 hover:bg-purple-50">
              <ChevronRight className="h-4 w-4" />
              <span className="hidden sm:inline">{fromChallenge ? 'التحديات' : 'الأنشطة'}</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/home")} className="gap-1 rounded-xl text-gray-500 hover:bg-gray-50">
              <Home className="h-4 w-4" />
              <span className="hidden sm:inline">المكتبة</span>
            </Button>
          </div>
          <h1 className="font-bold text-purple-800 text-sm truncate max-w-[200px]">{activity.title}</h1>
          <div className="flex items-center gap-1 bg-yellow-50 border border-yellow-200 px-3 py-1 rounded-full">
            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
            <span className="text-xs font-bold text-yellow-700">{activity.pointsReward} نقطة</span>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-6 max-w-2xl mx-auto px-4">
        {!showResult ? (
          <>
            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-purple-700">
                  سؤال {currentQuestion + 1} من {questions.length}
                </span>
                <span className="text-sm font-bold text-green-600">
                  ✅ {score} صحيح
                </span>
              </div>
              <div className="h-4 bg-white/70 rounded-full overflow-hidden shadow-inner border border-purple-100">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full transition-all duration-700 relative"
                  style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                >
                  <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
                </div>
              </div>
              {/* Dots indicator */}
              <div className="flex justify-center gap-1.5 mt-2">
                {questions.map((_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      i < currentQuestion
                        ? "bg-green-500 scale-110"
                        : i === currentQuestion
                        ? "bg-purple-500 scale-125"
                        : "bg-gray-200"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Question Card */}
            <div
              className={`bg-white rounded-3xl shadow-xl overflow-hidden mb-6 transition-all duration-250 ${
                cardAnim ? "opacity-0 translate-x-4" : "opacity-100 translate-x-0"
              } ${answerAnim === "correct" ? "ring-4 ring-green-400" : answerAnim === "wrong" ? "ring-4 ring-red-400" : ""}`}
            >
              {/* Question Header */}
              <div className="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
                <div className="text-4xl mb-3 text-center relative z-10">
                  {answerAnim === "correct" ? "🎉" : answerAnim === "wrong" ? "😅" : "❓"}
                </div>
                <p className="text-white text-lg font-bold text-center leading-relaxed relative z-10">
                  {currentQ?.questionText}
                </p>
              </div>

              {/* Options */}
              <div className="p-5 space-y-3">
                {getOptions(currentQ).map((option, idx) => {
                  const idxStr = String(idx);
                  const isSelected = selectedAnswer === idxStr;
                  const isCorrect = currentQ?.correctAnswer === idxStr;
                  const letters = ["أ", "ب", "ج", "د"];

                  let btnClass = "w-full p-4 rounded-2xl text-right font-medium transition-all border-2 flex items-center gap-3 ";
                  let letterClass = "w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 transition-all ";

                  if (!isAnswered) {
                    btnClass += "border-purple-100 hover:border-purple-400 hover:bg-purple-50 text-gray-700 hover:shadow-md hover:scale-[1.01]";
                    letterClass += "bg-purple-100 text-purple-700";
                  } else if (isCorrect) {
                    btnClass += "border-green-400 bg-green-50 text-green-800 shadow-md";
                    letterClass += "bg-green-500 text-white";
                  } else if (isSelected && !isCorrect) {
                    btnClass += "border-red-400 bg-red-50 text-red-800 shadow-md";
                    letterClass += "bg-red-500 text-white";
                  } else {
                    btnClass += "border-gray-100 bg-gray-50 text-gray-400";
                    letterClass += "bg-gray-200 text-gray-500";
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleAnswer(idxStr)}
                      className={btnClass}
                      disabled={isAnswered}
                    >
                      <span className={letterClass}>{letters[idx]}</span>
                      <span className="flex-1">{option}</span>
                      {isAnswered && isCorrect && (
                        <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0 animate-bounce" />
                      )}
                      {isAnswered && isSelected && !isCorrect && (
                        <XCircle className="h-6 w-6 text-red-500 flex-shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation */}
              {isAnswered && currentQ?.explanation && (
                <div className="mx-5 mb-5 bg-blue-50 border border-blue-200 rounded-2xl p-4">
                  <p className="text-sm text-blue-700 leading-relaxed">
                    <span className="font-bold text-base">💡 </span>
                    {currentQ.explanation}
                  </p>
                </div>
              )}
            </div>

            {/* Next Button */}
            {isAnswered && (
              <Button
                onClick={handleNext}
                className="w-full h-14 text-lg rounded-2xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]"
              >
                {currentQuestion + 1 < questions.length ? (
                  <>
                    السؤال التالي
                    <ArrowLeft className="mr-2 h-5 w-5" />
                  </>
                ) : (
                  <>
                    <Trophy className="ml-2 h-5 w-5" />
                    اعرض نتيجتي 🎊
                  </>
                )}
              </Button>
            )}
          </>
        ) : (
          /* Result Screen */
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden text-center">
            <div className={`bg-gradient-to-br ${getResultBg()} p-8 relative overflow-hidden`}>
              <div className="absolute inset-0 bg-black/10" />
              <div className="relative z-10">
                <div className="text-8xl mb-4 animate-bounce">{getResultEmoji()}</div>
                <h2 className="text-2xl font-bold text-white" style={{ fontFamily: "Tajawal, sans-serif" }}>
                  {getResultMessage()}
                </h2>
                <p className="text-white/80 text-sm mt-1">
                  {activity.title}
                </p>
              </div>
              {/* Decorative circles */}
              <div className="absolute top-4 right-4 w-16 h-16 bg-white/10 rounded-full" />
              <div className="absolute bottom-4 left-4 w-12 h-12 bg-white/10 rounded-full" />
            </div>

            <div className="p-8">
              {/* Score Circle */}
              <div className="w-36 h-36 mx-auto mb-6 relative">
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                  <circle cx="50" cy="50" r="40" fill="none" stroke="#f0f0f0" strokeWidth="10" />
                  <circle
                    cx="50" cy="50" r="40" fill="none"
                    stroke={percentage >= 80 ? "#f59e0b" : percentage >= 60 ? "#7c3aed" : percentage >= 40 ? "#10b981" : "#6b7280"}
                    strokeWidth="10"
                    strokeDasharray={`${(percentage / 100) * 251.2} 251.2`}
                    strokeLinecap="round"
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-4xl font-bold text-gray-800">{score}</span>
                  <span className="text-xs text-gray-400">من {questions.length}</span>
                </div>
              </div>

              <p className="text-gray-600 mb-2 text-base">
                أجبت على <span className="font-bold text-purple-600 text-lg">{score}</span> من <span className="font-bold text-gray-800">{questions.length}</span> أسئلة بشكل صحيح
              </p>
              <p className="text-2xl font-bold text-gray-800 mb-6">{percentage}%</p>

              {pointsEarned > 0 && (
                <div className="bg-yellow-50 border-2 border-yellow-300 rounded-2xl p-4 mb-4 flex items-center justify-center gap-3">
                  <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
                  <span className="font-bold text-yellow-700 text-lg">+{pointsEarned} نقطة مكتسبة!</span>
                  <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
                </div>
              )}

              {newAchievements.length > 0 && (
                <div className="mb-6 bg-purple-50 rounded-2xl p-4">
                  <p className="text-sm font-bold text-purple-700 mb-3">🏆 إنجازات جديدة!</p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {newAchievements.map((ach: any) => (
                      <div key={ach.key} className="bg-white border-2 border-purple-200 rounded-xl px-3 py-2 text-center shadow-sm">
                        <div className="text-2xl">{ach.emoji}</div>
                        <div className="text-xs font-bold text-purple-700 mt-1">{ach.title}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-3">
                <Button onClick={() => navigate(backPath)} className="w-full rounded-2xl h-12 font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-md">
                  <ChevronRight className="ml-2 h-4 w-4" />
                  {fromChallenge ? 'العودة للتحديات' : 'العودة للأنشطة'}
                </Button>
                <Button onClick={() => navigate("/home")} variant="outline" className="w-full rounded-2xl h-12 font-bold border-2 border-purple-200 text-purple-700 hover:bg-purple-50">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للمكتبة
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setCurrentQuestion(0);
                    setSelectedAnswer(null);
                    setIsAnswered(false);
                    setScore(0);
                    setShowResult(false);
                    setPointsEarned(0);
                    setNewAchievements([]);
                    playSound("click");
                  }}
                  className="w-full rounded-2xl h-12 font-bold border-2 border-gray-200 text-gray-600 hover:bg-gray-50"
                >
                  حاول مرة أخرى 🔄
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
