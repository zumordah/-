import { useState, useCallback, useEffect, useRef } from "react";
import { useLocation, useParams, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { useChild } from "@/contexts/ChildContext";
import { ArrowLeft, CheckCircle, Star, Trophy, XCircle, RefreshCw, Gamepad2, ChevronRight, ChevronLeft } from "lucide-react";
import { useEncouragementVoice } from "@/hooks/useEncouragementVoice";
import { toAr, arabicizeText } from "@/lib/arabicNumerals";
import CompareSymbolsGame from "@/components/games/CompareSymbolsGame";
import { useMemo } from "react";
import { getCharacterById, getDefaultCharacter } from "@/data/charactersData";

// ─── Shuffle Helper ───────────────────────────────────────────────────────────
// يخلط الخيارات عشوائياً ويعيد تعيين index الإجابة الصحيحة
function shuffleRound(round: Round): Round {
  if (!round.options || round.options.length === 0) return round;
  // دعم correctIndex (من بيانات قاعدة البيانات) وcorrect (من بيانات الكود)
  const correctIdx = (round as any).correctIndex ?? round.correct;
  const correctValue = round.options[correctIdx];
  const shuffled = [...round.options].sort(() => Math.random() - 0.5);
  const newCorrectIdx = shuffled.indexOf(correctValue);
  return { ...round, options: shuffled, correct: newCorrectIdx };
}

function shuffleRounds(rounds: Round[]): Round[] {
  return rounds.map(shuffleRound);
}

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663258701044/csLtKFqK5UD3dkHEUgWEBs/logo_kids_new_76ed5022.png";

// ─── Sound Engine (Web Audio API - no external files) ─────────────────────────
function createAudioContext(): AudioContext | null {
  try {
    return new (window.AudioContext || (window as any).webkitAudioContext)();
  } catch {
    return null;
  }
}

function playCorrectSound() {
  const ctx = createAudioContext();
  if (!ctx) return;
  const times = [0, 0.12, 0.24];
  const freqs = [523.25, 659.25, 783.99]; // C5, E5, G5 (major chord arpeggio)
  times.forEach((t, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.value = freqs[i];
    gain.gain.setValueAtTime(0.3, ctx.currentTime + t);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.3);
    osc.start(ctx.currentTime + t);
    osc.stop(ctx.currentTime + t + 0.35);
  });
}

function playWrongSound() {
  const ctx = createAudioContext();
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(220, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.3);
  gain.gain.setValueAtTime(0.2, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.4);
}

// ─── Confetti Burst ───────────────────────────────────────────────────────────
function ConfettiBurst({ active }: { active: boolean }) {
  if (!active) return null;
  const pieces = Array.from({ length: 18 });
  const colors = ["#f59e0b", "#10b981", "#6366f1", "#ec4899", "#3b82f6", "#f97316"];
  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {pieces.map((_, i) => {
        const color = colors[i % colors.length];
        const left = `${10 + (i * 5) % 80}%`;
        const delay = `${(i * 0.05).toFixed(2)}s`;
        const size = 8 + (i % 4) * 4;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              top: "-20px",
              left,
              width: size,
              height: size,
              background: color,
              borderRadius: i % 3 === 0 ? "50%" : "2px",
              animation: `confettiFall 1.2s ease-in ${delay} forwards`,
              transform: `rotate(${i * 20}deg)`,
            }}
          />
        );
      })}
    </div>
  );
}

// ─── Types ────────────────────────────────────────────────────────────────────
interface Round {
  question?: string;
  letter?: string;
  emoji?: string;
  image?: string; // URL for image-based games
  count?: number;
  options: (string | number)[];
  correct: number;
  hint?: string;
  word?: string;
  missing?: string;
  letters?: string[];
}

interface ClassificationItem {
  name: string;
  correct: number;
}

interface GameData {
  instructions: string;
  rounds?: Round[];
  questions?: Round[];
  items?: (string | ClassificationItem)[];
  correctOrder?: number[];
  categories?: string[];
  shuffleItems?: boolean;
}

// ─── Correct Answer Banner ──────────────────────────────────────────────────
// يظهر عند الإجابة الخاطئة ويوضح الإجابة الصحيحة
function CorrectAnswerBanner({ show, answer }: { show: boolean; answer: string | number }) {
  if (!show) return null;
  return (
    <div className="mt-3 p-3 bg-amber-50 border-2 border-amber-300 rounded-2xl text-center animate-fade-in">
      <p className="text-amber-700 font-bold text-base">
        💡 الإجابة الصحيحة: <span className="text-green-700 text-lg">{String(answer)}</span>
      </p>
    </div>
  );
}

// ─── Feedback Overlay ─────────────────────────────────────────────────────────
function FeedbackOverlay({ result }: { result: "correct" | "wrong" | null }) {
  if (!result) return null;
  return (
    <div
      className={`absolute inset-0 flex items-center justify-center rounded-3xl z-10 pointer-events-none
        ${result === "correct" ? "bg-green-400/20 animate-pulse-once" : "bg-red-400/20 animate-shake"}`}
    >
      <div className={`text-7xl animate-bounce-once`}>
        {result === "correct" ? "✅" : "❌"}
      </div>
    </div>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function LetterMatchGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    const delay = isCorrect ? 1100 : 2500; // وقت أطول عند الخطأ لعرض الإجابة الصحيحة
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, delay);
  };

  const round = rounds[current];
  if (!round) return null;

  // هل الخيارات جمل طويلة (أكثر من 8 أحرف)؟
  const isLongOptions = round.options.some(o => String(o).length > 8);

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        {/* إذا كانت جملة تكوين: أظهر السؤال كعنوان كبير بدون حرف */}
        {isLongOptions ? (
          <div className={`text-lg font-bold text-purple-700 bg-purple-50 rounded-3xl py-5 px-4 mb-2 shadow-inner leading-relaxed transition-all duration-300 ${feedback === "correct" ? "scale-105" : feedback === "wrong" ? "animate-shake-inline" : ""}`}>
            {round.emoji && <span className="text-3xl ml-2">{round.emoji}</span>}
            {round.question}
          </div>
        ) : (
          <>
            <div className={`text-8xl font-bold text-purple-700 bg-purple-50 rounded-3xl py-8 mb-4 shadow-inner transition-all duration-300 ${feedback === "correct" ? "scale-110" : feedback === "wrong" ? "animate-shake-inline" : ""}`}>
              {round.letter ?? round.emoji}
            </div>
            <p className="text-lg font-semibold text-gray-700">{round.question}</p>
          </>
        )}
        {round.hint && <p className="text-sm text-gray-400 mt-1">{round.hint}</p>}
      </div>
      <div className={`grid gap-3 ${isLongOptions ? 'grid-cols-1' : 'grid-cols-2'}`}>
        {round.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(i)}
            className={`p-4 rounded-2xl font-bold transition-all duration-200 text-right ${isLongOptions ? 'text-base' : 'text-xl'} ${
              selected === null
                ? "bg-white border-2 border-gray-200 hover:border-purple-400 hover:bg-purple-50 active:scale-95"
                : i === round.correct
                ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                : selected === i
                ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                : "bg-white border-2 border-gray-200 opacity-50"
            }`}
          >
            {arabicizeText(opt)}
          </button>
        ))}
      </div>
      <CorrectAnswerBanner show={feedback === "wrong"} answer={arabicizeText(round.options[round.correct])} />
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function CountObjectsGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    const delay = isCorrect ? 1100 : 2500;
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, delay);
  };

  const round = rounds[current];
  if (!round) return null;

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        <p className="text-lg font-semibold text-gray-700 mb-2">{round.question}</p>
        <div className={`text-5xl bg-yellow-50 rounded-3xl py-8 px-4 flex flex-wrap justify-center gap-2 shadow-inner transition-all ${feedback === "correct" ? "scale-105" : ""}`}>
          {Array.from({ length: round.count ?? 0 }).map((_, i) => (
            <span key={i}>{round.emoji}</span>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {round.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(i)}
            className={`p-4 rounded-2xl text-2xl font-bold transition-all duration-200 ${
              selected === null
                ? "bg-white border-2 border-gray-200 hover:border-yellow-400 hover:bg-yellow-50 active:scale-95"
                : i === round.correct
                ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                : selected === i
                ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                : "bg-white border-2 border-gray-200 opacity-50"
            }`}
          >
            {arabicizeText(opt)}
          </button>
        ))}
      </div>
      <CorrectAnswerBanner show={feedback === "wrong"} answer={arabicizeText(round.options[round.correct])} />
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-yellow-600 bg-yellow-50 hover:bg-yellow-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-yellow-600 bg-yellow-50 hover:bg-yellow-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
function ImageMatchGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? data.questions ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    const delay = isCorrect ? 1100 : 2500;
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, delay);
  };

  const round = rounds[current];
  if (!round) return null;

  // هل الخيارات أعلام (emoji)؟
  // الأعلام تبدأ بـ regional indicator letters (U+1F1E0–U+1F1FF)
  const isFlagGame = (round.options as string[]).every(opt => {
    const cp = opt.codePointAt(0);
    return cp !== undefined && cp >= 0x1F1E0 && cp <= 0x1F1FF;
  });

  // استخراج بيانات الصورة للألعاب غير الأعلام
  const displayEmoji = !isFlagGame ? (round.emoji || (round.image && !round.image.startsWith('http') ? round.image : null)) : null;
  const displayImage = !isFlagGame ? (round.image && round.image.startsWith('http') ? round.image : null) : null;

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        {displayImage && (
          <div className={`rounded-3xl overflow-hidden shadow-lg mb-3 transition-all ${feedback === "correct" ? "scale-105 ring-4 ring-green-400" : feedback === "wrong" ? "ring-4 ring-red-300" : ""}`}>
            <img src={displayImage} alt={round.question ?? "صورة"} className="w-full h-52 object-cover" loading="lazy" />
          </div>
        )}
        {displayEmoji && (
          <div className={`text-9xl bg-blue-50 rounded-3xl py-8 mb-3 shadow-inner flex items-center justify-center transition-all ${feedback === "correct" ? "scale-110 ring-4 ring-green-400" : feedback === "wrong" ? "ring-4 ring-red-300" : ""}`}>
            {displayEmoji}
          </div>
        )}
        <p className="text-xl font-bold text-gray-800 bg-blue-50 rounded-2xl py-4 px-3 shadow-inner">{round.question ?? "ما هذا؟"}</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {(round.options as string[]).map((opt, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(i)}
            className={`rounded-2xl transition-all duration-200 ${
              isFlagGame ? 'p-3 text-7xl flex items-center justify-center h-24' : 'p-4 text-base font-bold'
            } ${
              selected === null
                ? "bg-white border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50 active:scale-95"
                : i === round.correct
                ? "bg-green-100 border-2 border-green-400 scale-105"
                : selected === i
                ? "bg-red-100 border-2 border-red-400 animate-shake-inline"
                : "bg-white border-2 border-gray-200 opacity-50"
            }`}
          >
            {isFlagGame ? opt : arabicizeText(opt)}
          </button>
        ))}
      </div>
      <CorrectAnswerBanner show={feedback === "wrong"} answer={arabicizeText(round.options[round.correct])} />
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-blue-600 bg-blue-50 hover:bg-blue-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-blue-600 bg-blue-50 hover:bg-blue-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
function ClassificationGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const categories = data.categories ?? [];
  // خلط الأدوات عشوائياً إذا كان shuffleItems = true
  const items = useMemo(() => {
    const raw = (data.items ?? []) as ClassificationItem[];
    if (data.shuffleItems) return [...raw].sort(() => Math.random() - 0.5);
    return raw;
  }, [data]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  const handleClassify = (catIdx: number) => {
    if (selected !== null) return;
    setSelected(catIdx);
    const isCorrect = catIdx === items[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    const delay = isCorrect ? 1100 : 2500;
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    setTimeout(() => {
      if (current + 1 >= items.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, delay);
  };

  const item = items[current];
  if (!item) return null;

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        <div className={`text-5xl bg-teal-50 rounded-3xl py-8 shadow-inner font-bold transition-all ${feedback === "correct" ? "scale-110" : feedback === "wrong" ? "animate-shake-inline" : ""}`}>{item.name}</div>
        <p className="text-base text-gray-500 mt-3">في أي مجموعة ينتمي؟</p>
        <p className="text-xs text-gray-400 font-semibold">السؤال {toAr(current + 1)} من {toAr(items.length)}</p>
      </div>
      <div className="space-y-3">
        {categories.map((cat, i) => (
          <button
            key={i}
            onClick={() => handleClassify(i)}
            className={`w-full p-4 rounded-2xl text-base font-bold transition-all duration-200 ${
              selected === null
                ? "bg-white border-2 border-gray-200 hover:border-teal-400 hover:bg-teal-50 active:scale-95"
                : i === item.correct
                ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                : selected === i
                ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                : "bg-white border-2 border-gray-200 opacity-50"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>
      <CorrectAnswerBanner show={feedback === "wrong"} answer={categories[items[current]?.correct ?? 0] ?? ""} />
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-teal-600 bg-teal-50 hover:bg-teal-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(items.length)}</span>
        <button
          onClick={() => { if (current < items.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === items.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-teal-600 bg-teal-50 hover:bg-teal-100 active:scale-95'
          }`}
        >
          {current === items.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function MissingLetterGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    const delay = isCorrect ? 1100 : 2500;
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, delay);
  };

  const round = rounds[current];
  if (!round) return null;

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        {(round as any).emoji && !round.letter && (
          <div className="text-6xl mb-3">{(round as any).emoji}</div>
        )}
        <div className={`text-xl font-bold bg-orange-50 rounded-3xl py-6 px-4 shadow-inner text-orange-700 transition-all leading-loose ${feedback === "correct" ? "scale-105" : feedback === "wrong" ? "animate-shake-inline" : ""}`}>
          {arabicizeText(round.letter ?? round.question ?? round.word?.replace("_", "___"))}
        </div>
        {round.hint && <p className="text-gray-500 mt-3 text-sm">💡 {round.hint}</p>}
      </div>
      <div className="grid grid-cols-2 gap-3">
        {(round.options as string[]).map((opt, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(i)}
            className={`p-4 rounded-2xl text-xl font-bold transition-all duration-200 ${
              selected === null
                ? "bg-white border-2 border-gray-200 hover:border-orange-400 hover:bg-orange-50 active:scale-95"
                : i === round.correct
                ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                : selected === i
                ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                : "bg-white border-2 border-gray-200 opacity-50"
            }`}
          >
            {arabicizeText(opt)}
          </button>
        ))}
      </div>
      <CorrectAnswerBanner show={feedback === "wrong"} answer={arabicizeText(round.options[round.correct])} />
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-orange-600 bg-orange-50 hover:bg-orange-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-orange-600 bg-orange-50 hover:bg-orange-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
function WordBuildGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  // إذا كانت البيانات تستخدم options (اختيار حرف) نستخدم نمط الاختيار
  const hasOptions = !!(data.rounds?.[0]?.options);

  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [arranged, setArranged] = useState<string[]>([]);
  const [remaining, setRemaining] = useState<string[]>([]);
  const [showResult, setShowResult] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  useEffect(() => {
    if (!hasOptions && rounds[current]) {
      const shuffled = [...(rounds[current].letters ?? [])].sort(() => Math.random() - 0.5);
      setRemaining(shuffled);
      setArranged([]);
      setShowResult(null);
    }
    setSelected(null);
    setFeedback(null);
  }, [current, hasOptions]);

  // ─── نمط الاختيار (الكلمة المخفية) ───
  const handleOptionAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
      }
    }, 1100);
  };

  // ─── نمط ترتيب الحروف ───
  const addLetter = (letter: string, idx: number) => {
    if (showResult) return;
    setArranged((a) => [...a, letter]);
    setRemaining((r) => r.filter((_, i) => i !== idx));
  };

  const removeLetter = (idx: number) => {
    if (showResult) return;
    const letter = arranged[idx];
    setArranged((a) => a.filter((_, i) => i !== idx));
    setRemaining((r) => [...r, letter]);
  };

  const checkAnswer = () => {
    const attempt = arranged.join("");
    const target = rounds[current].word ?? "";
    const correct = attempt === target;
    setShowResult(correct ? "correct" : "wrong");
    if (correct) {
      playCorrectSound();
      setShowConfetti(true);
      setScore((s) => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
    } else {
      playWrongSound();
    }
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (correct ? 1 : 0));
      } else {
        setCurrent((c) => c + 1);
      }
    }, 1500);
  };

  const round = rounds[current];
  if (!round) return null;

  // ─── عرض نمط الاختيار ───
  if (hasOptions) {
    return (
      <div className="space-y-6 relative">
        <FeedbackOverlay result={feedback} />
        <ConfettiBurst active={showConfetti} />
        <div className="text-center">
          <div className={`text-3xl font-black bg-purple-50 rounded-3xl py-8 px-4 shadow-inner text-purple-700 tracking-widest transition-all ${feedback === "correct" ? "scale-105" : feedback === "wrong" ? "animate-shake-inline" : ""}`}>
            {arabicizeText(round.letter ?? round.word ?? "")}
          </div>
          {round.hint && <p className="text-gray-500 mt-3 text-sm">💡 {round.hint}</p>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          {(round.options as string[]).map((opt, i) => (
            <button
              key={i}
              onClick={() => handleOptionAnswer(i)}
              className={`p-4 rounded-2xl text-2xl font-bold transition-all duration-200 ${
                selected === null
                  ? "bg-white border-2 border-gray-200 hover:border-purple-400 hover:bg-purple-50 active:scale-95"
                  : i === round.correct
                  ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                  : selected === i
                  ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                  : "bg-white border-2 border-gray-200 opacity-50"
              }`}
            >
              {arabicizeText(opt)}
            </button>
          ))}
        </div>
        {/* شريط التنقل بين الأسئلة */}
        <div className="flex items-center justify-between mt-2">
          <button
            onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
            disabled={current === 0}
            className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
              current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
            }`}
          >
            <ChevronRight className="w-4 h-4" />
            السابق
          </button>
          <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
          <button
            onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
            className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
              current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
            }`}
          >
            {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // ─── عرض نمط ترتيب الحروف ───
  return (
    <div className="space-y-5 relative">
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        <p className="text-gray-500 text-sm">{round.hint}</p>
        <p className="text-base font-semibold text-gray-700 mt-1">رتّب الحروف لتكوين الكلمة</p>
      </div>
      <div className={`min-h-16 bg-purple-50 rounded-2xl p-3 flex flex-wrap gap-2 justify-center items-center border-2 border-dashed transition-all ${
        showResult === "correct" ? "border-green-400 bg-green-50" : showResult === "wrong" ? "border-red-400 bg-red-50 animate-shake-inline" : "border-purple-200"
      }`}>
        {arranged.length === 0 ? (
          <span className="text-gray-300 text-sm">انقر على الحروف لترتيبها هنا</span>
        ) : (
          arranged.map((l, i) => (
            <button
              key={i}
              onClick={() => removeLetter(i)}
              className="w-10 h-10 bg-purple-500 text-white rounded-xl font-bold text-lg hover:bg-purple-600 active:scale-90 transition-all"
            >
              {l}
            </button>
          ))
        )}
      </div>
      <div className="flex flex-wrap gap-2 justify-center">
        {remaining.map((l, i) => (
          <button
            key={i}
            onClick={() => addLetter(l, i)}
            className="w-12 h-12 bg-white border-2 border-gray-200 rounded-xl font-bold text-xl hover:border-purple-400 hover:bg-purple-50 active:scale-90 transition-all"
          >
            {l}
          </button>
        ))}
      </div>
      {arranged.length > 0 && remaining.length === 0 && !showResult && (
        <button
          onClick={checkAnswer}
          className="w-full py-3 bg-purple-600 text-white rounded-2xl font-bold text-lg hover:bg-purple-700 active:scale-95 transition-all"
        >
          تحقق ✓
        </button>
      )}
      {showResult && (
        <div className={`text-center p-4 rounded-2xl font-bold text-lg transition-all ${
          showResult === "correct" ? "bg-green-100 text-green-700 scale-105" : "bg-red-100 text-red-700"
        }`}>
          {showResult === "correct" ? "✅ أحسنت! إجابة صحيحة 🎉" : `❌ الإجابة الصحيحة: ${round.word}`}
        </div>
      )}
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setArranged([]); setRemaining([...(rounds[current - 1]?.letters ?? [])].sort(() => Math.random() - 0.5)); setShowResult(null); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function NumberOrderGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const originalItems = data.items as string[] ?? [];
  const [items, setItems] = useState(() => [...originalItems].sort(() => Math.random() - 0.5));
  const [selected, setSelected] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleSelect = (idx: number) => {
    if (checked) return;
    if (selected === null) {
      setSelected(idx);
    } else {
      const newItems = [...items];
      [newItems[selected], newItems[idx]] = [newItems[idx], newItems[selected]];
      setItems(newItems);
      setSelected(null);
    }
  };

  const checkOrder = () => {
    const correct = data.correctOrder ?? [];
    const isRight = correct.every((origIdx, pos) => items[pos] === originalItems[origIdx]);
    setIsCorrect(isRight);
    setChecked(true);
    if (isRight) {
      playCorrectSound();
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 1200);
    } else {
      playWrongSound();
    }
    setTimeout(() => onComplete(isRight ? 1 : 0), 1500);
  };

  return (
    <div className="space-y-5 relative">
      <ConfettiBurst active={showConfetti} />
      <p className="text-center text-gray-600 font-semibold">{data.instructions}</p>
      <p className="text-center text-xs text-gray-400">انقر على عنصرين لتبديل مكانيهما</p>
      <div className="flex flex-wrap gap-3 justify-center">
        {items.map((item, i) => (
          <button
            key={i}
            onClick={() => handleSelect(i)}
            className={`w-14 h-14 rounded-2xl text-2xl font-bold transition-all duration-200 ${
              checked
                ? isCorrect
                  ? "bg-green-100 border-2 border-green-400 scale-105"
                  : "bg-red-100 border-2 border-red-400 animate-shake-inline"
                : selected === i
                ? "bg-purple-500 text-white border-2 border-purple-600 scale-110"
                : "bg-white border-2 border-gray-200 hover:border-purple-300 active:scale-90"
            }`}
          >
            {item}
          </button>
        ))}
      </div>
      {!checked && (
        <button
          onClick={checkOrder}
          className="w-full py-3 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 active:scale-95 transition-all"
        >
          تحقق من الترتيب ✓
        </button>
      )}
      {checked && (
        <div className={`text-center p-4 rounded-2xl font-bold text-lg ${
          isCorrect ? "bg-green-100 text-green-700 scale-105" : "bg-red-100 text-red-700"
        }`}>
          {isCorrect ? "✅ ترتيب صحيح! أحسنت! 🎉" : "❌ الترتيب غير صحيح، حاول مرة أخرى"}
        </div>
      )}
    </div>
  );
}

// ─── Memory Game (NEW) ───────────────────────────────────────────────────────────────────
function MemoryGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [phase, setPhase] = useState<"show" | "hide" | "answer">("show");
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  useEffect(() => {
    if (phase === "show") {
      setCountdown(5);
      const timer = setInterval(() => {
        setCountdown(c => {
          if (c <= 1) {
            clearInterval(timer);
            setPhase("hide");
            setTimeout(() => setPhase("answer"), 500);
            return 0;
          }
          return c - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [phase, current]);

  const handleAnswer = (idx: number) => {
    if (selected !== null || phase !== "answer") return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore(s => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent(c => c + 1);
        setSelected(null);
        setFeedback(null);
        setPhase("show");
      }
    }, 1200);
  };

  const round = rounds[current];
  if (!round) return null;

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        <p className="text-lg font-semibold text-gray-700 mb-2">{round.question}</p>
        {phase === "show" && (
          <div className="space-y-3">
            <div className="text-6xl bg-yellow-50 rounded-3xl py-8 shadow-inner animate-pulse">
              {round.emoji}
            </div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold text-xl animate-bounce">
                {toAr(countdown)}
              </div>
              <p className="text-sm text-purple-600 font-semibold">احفظ الترتيب!</p>
            </div>
          </div>
        )}
        {phase === "hide" && (
          <div className="text-6xl bg-gray-100 rounded-3xl py-8 shadow-inner">
            ❓❓❓❓
          </div>
        )}
        {phase === "answer" && (
          <div className="text-4xl bg-gray-100 rounded-3xl py-6 shadow-inner text-gray-400">
            🔒 ما هو الترتيب الصحيح؟
          </div>
        )}
      </div>
      {phase === "answer" && (
        <div className="grid grid-cols-1 gap-3">
          {(round.options as string[]).map((opt, i) => (
            <button
              key={i}
              onClick={() => handleAnswer(i)}
              className={`p-4 rounded-2xl text-2xl font-bold transition-all duration-200 ${
                selected === null
                  ? "bg-white border-2 border-gray-200 hover:border-purple-400 hover:bg-purple-50 active:scale-95"
                  : i === round.correct
                  ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                  : selected === i
                  ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                  : "bg-white border-2 border-gray-200 opacity-50"
              }`}
            >
              {arabicizeText(opt)}
            </button>
          ))}
        </div>
      )}
      {phase === "answer" && <CorrectAnswerBanner show={feedback === "wrong"} answer={arabicizeText(round.options[round.correct])} />}
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); setPhase('show'); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); setPhase('show'); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// ─── Math Game (NEW) ─────────────────────────────────────────────────────────────────────
function MathGame({ data, onComplete }: { data: GameData; onComplete: (score: number) => void }) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const rounds = useMemo(() => shuffleRounds(data.rounds ?? []), [data]);
  const { encourageCorrect, encourageWrong } = useEncouragementVoice();

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const isCorrect = idx === rounds[current].correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) {
      playCorrectSound();
      setShowConfetti(true);
      setScore(s => s + 1);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => encourageCorrect(), 400);
    } else {
      playWrongSound();
      setTimeout(() => encourageWrong(), 400);
    }
    const delay = isCorrect ? 1100 : 2500;
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent(c => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, delay);
  };

  const round = rounds[current];
  if (!round) return null;

  return (
    <div className="space-y-6 relative">
      <FeedbackOverlay result={feedback} />
      <ConfettiBurst active={showConfetti} />
      <div className="text-center">
        {round.letter && (
          <div className={`text-3xl font-bold bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl py-6 px-4 shadow-inner text-indigo-700 mb-3 transition-all ${
            feedback === "correct" ? "scale-105" : feedback === "wrong" ? "animate-shake-inline" : ""
          }`}>
            {round.letter}
          </div>
        )}
        {!round.letter && (
          <div className={`text-5xl font-bold bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl py-10 shadow-inner text-indigo-700 transition-all ${
            feedback === "correct" ? "scale-105" : feedback === "wrong" ? "animate-shake-inline" : ""
          }`}>
            {arabicizeText(round.question)}
          </div>
        )}
        {round.letter && (
          <p className="text-lg font-semibold text-gray-700 mt-2">{arabicizeText(round.question)}</p>
        )}
      </div>
      <div className="grid grid-cols-2 gap-3">
        {round.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(i)}
            className={`p-5 rounded-2xl text-3xl font-bold transition-all duration-200 ${
              selected === null
                ? "bg-white border-2 border-gray-200 hover:border-indigo-400 hover:bg-indigo-50 active:scale-95"
                : i === round.correct
                ? "bg-green-100 border-2 border-green-400 text-green-700 scale-105"
                : selected === i
                ? "bg-red-100 border-2 border-red-400 text-red-700 animate-shake-inline"
                : "bg-white border-2 border-gray-200 opacity-50"
            }`}
          >
            {arabicizeText(opt)}
          </button>
        ))}
      </div>
      <CorrectAnswerBanner show={feedback === "wrong"} answer={arabicizeText(round.options[round.correct])} />
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); setShowConfetti(false); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); setShowConfetti(false); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// ─── Completion Screen ──────────────────────────────────────────────────────────────────────
function CompletionScreen({
  score,
  maxScore,
  pointsEarned,
  onRetry,
  onBack,
  isGuest,
  fromChallenge,
  childId,
}: {
  score: number;
  maxScore: number;
  pointsEarned: number;
  onRetry: () => void;
  onBack: () => void;
  isGuest?: boolean;
  fromChallenge?: boolean;
  childId?: number;
}) {
  const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
  const stars = percentage >= 80 ? 3 : percentage >= 50 ? 2 : 1;
  const [showConfetti] = useState(percentage >= 80);
  const isWin = percentage >= 50;
  const firedRef = useRef(false);
  const [charVisible, setCharVisible] = useState(false);
  const [charClapping, setCharClapping] = useState(false);

  // جلب بيانات الشخصية المرافقة
  const { data: companionData } = trpc.companion.getMyCompanion.useQuery(
    { childId: childId ?? 0 },
    { enabled: !!childId, staleTime: 60000 }
  );
  const characterId = companionData?.characterId ?? 'sami';
  const character = getCharacterById(characterId) ?? getDefaultCharacter();

  // تفعيل الشخصية المرافقة العائمة عند ظهور النتيجة
  useEffect(() => {
    if (firedRef.current) return;
    firedRef.current = true;
    const type = isWin ? 'celebration' : 'encouragement';
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('companion-trigger', { detail: { type } }));
    }, 400);
    // إظهار الشخصية في شاشة النتيجة بعد تأخير بسيط
    setTimeout(() => setCharVisible(true), 300);
    if (isWin) setTimeout(() => setCharClapping(true), 600);
  }, [isWin]);

  // رسائل الشخصية المرافقة في نهاية اللعبة
  const companionMessages = isWin
    ? character.celebrations
    : character.encouragements;
  const companionMsg = companionMessages[Math.floor(Math.random() * companionMessages.length)];

  // أنيميشن CSS مدمجة
  const resultStyles = `
    @keyframes resultPopIn {
      0%   { transform: scale(0.3) rotate(-10deg); opacity: 0; }
      50%  { transform: scale(1.25) rotate(5deg); opacity: 1; }
      70%  { transform: scale(0.95) rotate(-2deg); }
      85%  { transform: scale(1.08) rotate(1deg); }
      100% { transform: scale(1) rotate(0deg); opacity: 1; }
    }
    @keyframes charSlideIn {
      0%   { transform: translateY(60px) scale(0.5); opacity: 0; }
      60%  { transform: translateY(-10px) scale(1.15); opacity: 1; }
      80%  { transform: translateY(4px) scale(0.97); }
      100% { transform: translateY(0) scale(1); opacity: 1; }
    }
    @keyframes charClapBig {
      0%, 100% { transform: scale(1) rotate(0deg); }
      20%  { transform: scale(1.4) rotate(-8deg) translateY(-8px); }
      40%  { transform: scale(1.35) rotate(6deg) translateY(-12px); }
      60%  { transform: scale(1.4) rotate(-5deg) translateY(-8px); }
      80%  { transform: scale(1.2) rotate(3deg) translateY(-4px); }
    }
    @keyframes starSpinResult {
      0%   { transform: scale(0) rotate(0deg); opacity: 0; }
      50%  { transform: scale(1.3) rotate(180deg); opacity: 1; }
      100% { transform: scale(1) rotate(360deg); opacity: 1; }
    }
    .result-pop-in { animation: resultPopIn 0.7s cubic-bezier(0.34,1.56,0.64,1) forwards; }
    .char-slide-in { animation: charSlideIn 0.6s cubic-bezier(0.34,1.56,0.64,1) forwards; }
    .char-clap-big { animation: charClapBig 0.5s ease-in-out infinite; }
    .star-spin-result { animation: starSpinResult 0.5s ease-out forwards; }
  `;

  return (
    <div className="text-center space-y-5 py-4 relative" dir="rtl">
      <style>{resultStyles}</style>
      <ConfettiBurst active={showConfetti} />

      {/* الشخصية المرافقة تظهر بحجم كبير متحرك */}
      {charVisible && (
        <div className="flex flex-col items-center gap-1 mb-2">
          <div className={`relative ${charClapping ? 'char-clap-big' : 'char-slide-in'}`}>
            {/* تصفيق جانبي */}
            {charClapping && (
              <>
                <span className="absolute -right-10 top-1/3 text-3xl" style={{ animation: 'charClapBig 0.4s ease-in-out infinite', animationDelay: '0.1s', display: 'inline-block' }}>👏</span>
                <span className="absolute -left-10 top-1/3 text-3xl" style={{ animation: 'charClapBig 0.4s ease-in-out infinite', animationDelay: '0.25s', display: 'inline-block' }}>👏</span>
                <span className="absolute left-1/2 -translate-x-1/2 -top-6 text-2xl" style={{ animation: 'starSpinResult 0.6s ease-out infinite', display: 'inline-block' }}>🎉</span>
              </>
            )}
            <img
              src={character.imageUrl}
              alt={character.name}
              className="w-28 h-28 object-contain"
              style={{
                filter: isWin
                  ? `drop-shadow(0 0 16px ${character.color}) drop-shadow(0 0 8px ${character.color})`
                  : 'drop-shadow(0 3px 8px rgba(0,0,0,0.2))',
              }}
            />
          </div>
          <span
            className="text-xs font-bold px-3 py-1 rounded-full text-white shadow-sm"
            style={{ backgroundColor: character.color }}
          >
            {character.name}
          </span>
        </div>
      )}

      {/* إيموجي النتيجة بتكبير متحرك */}
      <div className="result-pop-in" style={{ animationDelay: '0.1s' }}>
        <div className="text-7xl mb-2">{percentage >= 80 ? "🏆" : percentage >= 50 ? "🌟" : "💪"}</div>
        <h2 className="text-2xl font-bold text-gray-800">
          {percentage >= 80 ? "أحسنت! رائع! 🎉" : percentage >= 50 ? "جيد جداً! 😊" : "حاول مرة أخرى! 💪"}
        </h2>
      </div>

      {/* النجوم بتأخير */}
      <div className="flex justify-center gap-2">
        {Array.from({ length: 3 }).map((_, i) => (
          <Star
            key={i}
            className={`w-10 h-10 transition-all duration-500 ${i < stars ? "text-yellow-400 fill-yellow-400" : "text-gray-200 fill-gray-200"}`}
            style={{
              animation: i < stars ? `starSpinResult 0.5s ease-out ${i * 0.15}s forwards` : 'none',
              opacity: i < stars ? 1 : 0.3,
            }}
          />
        ))}
      </div>

      {/* رسالة الشخصية المرافقة */}
      <div className={`rounded-2xl p-4 border-2 flex items-center gap-3 ${isWin ? 'bg-yellow-50 border-yellow-300' : 'bg-blue-50 border-blue-300'}`}>
        <p className="text-sm font-bold text-gray-800 text-right flex-1">{companionMsg}</p>
      </div>
      <div className="bg-gray-50 rounded-2xl p-4 space-y-2">
        <p className="text-gray-600">
          إجاباتك الصحيحة: <span className="font-bold text-green-600">{toAr(score)}</span> من {toAr(maxScore)}
        </p>
        <p className="text-gray-600">
          النقاط المكتسبة: <span className="font-bold text-yellow-600">+{toAr(pointsEarned)} نقطة</span>
        </p>
      </div>
      {isGuest && (
        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-3 text-sm text-purple-700">
          💡 سجّل دخولك لحفظ نقاطك وتتبع تقدمك!
        </div>
      )}
      <div className="flex gap-3">
        <button
          onClick={onRetry}
          className="flex-1 flex items-center justify-center gap-2 py-3 bg-gray-100 text-gray-700 rounded-2xl font-bold hover:bg-gray-200 active:scale-95 transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          حاول مجدداً
        </button>
        <button
          onClick={onBack}
          className="flex-1 flex items-center justify-center gap-2 py-3 bg-green-600 text-white rounded-2xl font-bold hover:bg-green-700 active:scale-95 transition-all"
        >
          <CheckCircle className="w-4 h-4" />
          {fromChallenge ? 'العودة للتحديات' : 'العودة للألعاب'}
        </button>
      </div>
    </div>
  );
}

// ─── Main GamePlayer ──────────────────────────────────────────────────────────
export default function GamePlayer() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const search = useSearch();
  const { child } = useChild();
  const gameId = parseInt(params.id ?? "0");
  // قراءة المستوى من query string باستخدام useSearch الصحيح
  const searchParams = new URLSearchParams(search);
  const returnLevel = searchParams.get('level') ?? 'easy';
  const fromChallenge = searchParams.get('from') === 'daily-challenge';
  const backPath = fromChallenge ? '/challenges' : `/activities/games?level=${returnLevel}`;

  const [gameKey, setGameKey] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [finalScore, setFinalScore] = useState(0);
  const [finalMax, setFinalMax] = useState(0);
  const [pointsEarned, setPointsEarned] = useState(0);

  const { data: game, isLoading } = trpc.games.getById.useQuery({ id: gameId });
  const saveProgress = trpc.games.saveProgress.useMutation();
  const { encourageCompletion } = useEncouragementVoice();

  const handleComplete = (score: number) => {
    if (!game) return;
    const maxScore = (game.gameData as GameData).rounds?.length
      ?? (game.gameData as GameData).questions?.length
      ?? (game.gameData as GameData).items?.length
      ?? 1;
    const percentage = maxScore > 0 ? score / maxScore : 0;
    const earned = Math.round(game.pointsReward * percentage);

    setFinalScore(score);
    setFinalMax(maxScore);
    setPointsEarned(earned);
    setCompleted(true);
    setTimeout(() => {
      if (percentage >= 0.5) encourageCompletion();
      else window.dispatchEvent(new CustomEvent('companion-trigger', { detail: { type: 'encouragement' } }));
    }, 600);
    // حفظ التقدم فقط للمستخدمين المسجلينن
    if (child) {
      saveProgress.mutate({
        childId: child.id,
        gameId: game.id,
        score,
        maxScore,
        isCompleted: percentage >= 0.5,
        pointsEarned: earned,
      });
    }
  };

  const handleRetry = () => {
    setCompleted(false);
    setGameKey((k) => k + 1);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-gray-500">جارٍ تحميل اللعبة...</p>
        </div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <XCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
          <p className="text-gray-600">اللعبة غير موجودة</p>
          <button onClick={() => navigate(backPath)} className="mt-4 text-purple-600 font-semibold">
            العودة للألعاب
          </button>
        </div>
      </div>
    );
  }

  const gameData = game.gameData as GameData;

  const renderGame = () => {
    switch (game.type) {
      case "letter_match":
        return <LetterMatchGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "count_objects":
        return <CountObjectsGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "image_match":
        return <ImageMatchGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "classification":
        return <ClassificationGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "missing_letter":
        return <MissingLetterGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "word_build":
        return <WordBuildGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "number_order":
        return <NumberOrderGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "memory_game":
        return <MemoryGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "math_addition":
      case "math_subtraction":
        return <MathGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "letter_sound":
        return <LetterMatchGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      case "compare_symbols":
        return <CompareSymbolsGame key={gameKey} data={gameData} onComplete={handleComplete} />;
      default:
        return <p className="text-center text-gray-400">نوع اللعبة غير مدعوم</p>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-4 pb-20" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <button onClick={() => navigate("/home")} className="flex-shrink-0">
          <img src={LOGO_URL} alt="قصة وفكرة" className="w-10 h-10 object-contain" />
        </button>
        <div className="flex-1">
          <h1 className="text-lg font-bold text-gray-800">{game.emoji} {game.title}</h1>
          <p className="text-xs text-gray-500">{gameData.instructions}</p>
        </div>
        <div className="flex items-center gap-1 bg-yellow-100 px-3 py-1 rounded-full">
          <Trophy className="w-4 h-4 text-yellow-600" />
          <span className="text-sm font-bold text-yellow-700">{toAr(game.pointsReward)}</span>
        </div>
      </div>
      {/* Back Button */}
      <button
        onClick={() => navigate(backPath)}
        className="flex items-center gap-2 mb-4 px-4 py-2 bg-white rounded-2xl shadow-sm border border-purple-100 text-purple-700 font-semibold text-sm hover:bg-purple-50 active:scale-95 transition-all"
      >
        <Gamepad2 className="w-4 h-4" />
        <span>{fromChallenge ? 'العودة للتحديات' : 'العودة للألعاب'}</span>
        <ArrowLeft className="w-4 h-4" />
      </button>

      {/* Game Card */}
      <div className="bg-white rounded-3xl shadow-md p-5 relative overflow-hidden">
        {completed ? (
          <CompletionScreen
            score={finalScore}
            maxScore={finalMax}
            pointsEarned={pointsEarned}
            onRetry={handleRetry}
            onBack={() => navigate(backPath)}
            isGuest={!child}
            fromChallenge={fromChallenge}
            childId={child?.id}
          />
        ) : (
          renderGame()
        )}
      </div>
    </div>
  );
}
