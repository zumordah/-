import React, { createContext, useContext, useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export interface ChildSession {
  id: number;
  name: string;
  email: string;
  ageGroup: "4-6" | "6-8" | "8-10";
  avatarEmoji: string;
  avatarUrl?: string | null;
  totalPoints: number;
  level: number;
  readingStreak: number;
  isKindergartenStudent?: boolean | null;
  classroom?: string | null;
  gender?: "boy" | "girl" | null;
}

interface ChildContextType {
  child: ChildSession | null;
  setChild: (child: ChildSession | null, rememberMe?: boolean) => void;
  logout: () => void;
  isLoading: boolean;
}

const ChildContext = createContext<ChildContextType>({
  child: null,
  setChild: () => {},
  logout: () => {},
  isLoading: true,
});

const CHILD_STORAGE_KEY = "kidstories_child_session";
const SESSION_DURATION_7D = 7 * 24 * 60 * 60 * 1000;   // 7 days (عادي)
const SESSION_DURATION_30D = 30 * 24 * 60 * 60 * 1000; // 30 days (تذكرني)

export function ChildProvider({ children }: { children: React.ReactNode }) {
  const [child, setChildState] = useState<ChildSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [storedId, setStoredId] = useState<number | null>(null);

  // Try to restore session from localStorage with 7-day expiry check
  useEffect(() => {
    const stored = localStorage.getItem(CHILD_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as { id: number; loginAt?: number; rememberMe?: boolean };
        const loginAt = parsed.loginAt ?? 0;
        const rememberMe = parsed.rememberMe ?? false;
        const duration = rememberMe ? SESSION_DURATION_30D : SESSION_DURATION_7D;
        const now = Date.now();
        if (now - loginAt > duration) {
          // Session expired
          localStorage.removeItem(CHILD_STORAGE_KEY);
          setIsLoading(false);
        } else {
          setStoredId(parsed.id);
        }
      } catch {
        localStorage.removeItem(CHILD_STORAGE_KEY);
        setIsLoading(false);
      }
    } else {
      setIsLoading(false);
    }
  }, []);

  // Fetch fresh data from DB if we have a stored ID
  const { data: freshChild, isError } = trpc.children.getById.useQuery(
    { id: storedId! },
    { enabled: storedId !== null, retry: false }
  );

  useEffect(() => {
    if (freshChild && storedId !== null) {
      setChildState(freshChild as ChildSession);
      setIsLoading(false);
    } else if (isError && storedId !== null) {
      localStorage.removeItem(CHILD_STORAGE_KEY);
      setStoredId(null);
      setIsLoading(false);
    } else if (storedId === null) {
      setIsLoading(false);
    }
  }, [freshChild, storedId, isError]);

  const setChild = (newChild: ChildSession | null, rememberMe = false) => {
    setChildState(newChild);
    if (newChild) {
      localStorage.setItem(
        CHILD_STORAGE_KEY,
        JSON.stringify({ id: newChild.id, loginAt: Date.now(), rememberMe })
      );
    } else {
      localStorage.removeItem(CHILD_STORAGE_KEY);
    }
  };

  const logout = () => {
    // إطلاق حدث الوداع للشخصية قبل تسجيل الخروج
    window.dispatchEvent(new CustomEvent('companion-trigger', { detail: { type: 'farewell' } }));
    // تأخير بسيط لإتاحة الوقت لعرض الرسالة
    setTimeout(() => {
      setChildState(null);
      localStorage.removeItem(CHILD_STORAGE_KEY);
      setStoredId(null);
    }, 2000);
  };

  return (
    <ChildContext.Provider value={{ child, setChild, logout, isLoading }}>
      {children}
    </ChildContext.Provider>
  );
}

export function useChild() {
  return useContext(ChildContext);
}
