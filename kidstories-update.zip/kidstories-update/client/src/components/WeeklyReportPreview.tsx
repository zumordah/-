/**
 * WeeklyReportPreview
 * مكوّن لعرض نص التقرير الأسبوعي لمدرسة محددة في لوحة الأدمن
 */
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function WeeklyReportPreview() {
  const [selectedSchoolId, setSelectedSchoolId] = useState<number | null>(null);
  const [runLog, setRunLog] = useState<string[]>([]);
  const [showLog, setShowLog] = useState(false);
  const [customNote, setCustomNote] = useState("");
  const [showNoteEditor, setShowNoteEditor] = useState(false);

  const { data: schools } = trpc.schools.listPublic.useQuery();
  const { data: preview, isLoading: previewLoading } = trpc.email.previewReport.useQuery(
    { schoolId: selectedSchoolId! },
    { enabled: !!selectedSchoolId }
  );

  const runAllMut = trpc.email.runWeeklyReports.useMutation({
    onSuccess: (data) => {
      setRunLog(data.log);
      setShowLog(true);
      toast.success(`✅ تم إرسال التقارير — نجح: ${data.sent} | فشل: ${data.failed} | المجموع: ${data.total}`);
    },
    onError: () => {
      toast.error("❌ فشل في تشغيل التقارير");
    },
  });

  const sendOneMut = trpc.schools.sendWeeklyReport.useMutation({
    onSuccess: (data) => {
      if (data.success) toast.success(data.message);
      else toast.error(data.message);
    },
  });

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">📊 التقارير الأسبوعية</h2>
          <p className="text-sm text-gray-500 mt-1">
            تُرسَل تلقائياً كل <strong>إثنين الساعة 8:00 صباحاً</strong>
          </p>
        </div>
        <Button
          onClick={() => runAllMut.mutate()}
          disabled={runAllMut.isPending}
          className="gap-2"
          style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
        >
          {runAllMut.isPending ? "⏳ جارٍ الإرسال..." : "📧 إرسال للجميع الآن"}
        </Button>
      </div>

      {/* معلومات الجدولة */}
      <Card className="border-indigo-200 bg-indigo-50">
        <CardContent className="pt-4 pb-4">
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-indigo-600 font-bold">⏰ الجدولة:</span>
              <Badge variant="secondary">كل إثنين — 8:00 صباحاً</Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-indigo-600 font-bold">📬 المرسَل إليهم:</span>
              <span className="text-gray-600">مديرو المدارس المسجلون</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-indigo-600 font-bold">🔕 إلغاء الاشتراك:</span>
              <span className="text-gray-600">رابط في تذييل كل إيميل</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* معاينة نص التقرير */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">🔍 معاينة نص التقرير وإرساله</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* اختيار المدرسة وأزرار الإرسال */}
          <div className="flex flex-wrap gap-3 items-center">
            <Select
              onValueChange={(v) => setSelectedSchoolId(Number(v))}
              value={selectedSchoolId?.toString() || ""}
            >
              <SelectTrigger className="w-64">
                <SelectValue placeholder="اختر مدرسة للمعاينة..." />
              </SelectTrigger>
              <SelectContent>
                {schools?.map((s: any) => (
                  <SelectItem key={s.id} value={s.id.toString()}>
                    🏫 {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {selectedSchoolId && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowNoteEditor(!showNoteEditor)}
                  className={showNoteEditor ? "border-amber-400 text-amber-700 bg-amber-50" : ""}
                >
                  {customNote ? "✏️ تعديل الملاحظة" : "📝 إضافة ملاحظة"}
                </Button>
                <Button
                  size="sm"
                  onClick={() => sendOneMut.mutate({ schoolId: selectedSchoolId, customNote: customNote || undefined })}
                  disabled={sendOneMut.isPending}
                  style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
                >
                  {sendOneMut.isPending ? "⏳ جارٍ الإرسال..." : "📤 إرسال لهذه المدرسة"}
                </Button>
              </>
            )}
          </div>

          {/* حقل الملاحظات الإضافية */}
          {showNoteEditor && selectedSchoolId && (
            <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">📝</span>
                <p className="font-bold text-amber-800 text-sm">ملاحظة إضافية من الإدارة</p>
                <span className="text-xs text-amber-600">(ستظهر في التقرير قبل زر "عرض التقرير الكامل")</span>
              </div>
              <Textarea
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="اكتب هنا أي ملاحظات أو توجيهات تريد إضافتها للتقرير...&#10;مثال: نشكر جهود المعلمات في هذا الأسبوع، ونتمنى لطلابنا مزيداً من التقدم."
                className="min-h-[120px] text-sm border-amber-200 focus:border-amber-400 bg-white resize-y"
                dir="rtl"
              />
              <div className="flex items-center gap-2">
                {customNote && (
                  <Button variant="ghost" size="sm" onClick={() => setCustomNote("")} className="text-red-500 hover:text-red-700 text-xs">
                    🗑️ حذف الملاحظة
                  </Button>
                )}
                <Button size="sm" variant="outline" onClick={() => setShowNoteEditor(false)} className="text-xs mr-auto">
                  إغلاق ✕
                </Button>
              </div>
              {customNote && (
                <div className="bg-white border border-amber-200 rounded-lg p-3">
                  <p className="text-xs text-amber-700 font-bold mb-1">معاينة الملاحظة:</p>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{customNote}</p>
                </div>
              )}
            </div>
          )}

          {previewLoading && (
            <div className="text-center py-8 text-gray-400">⏳ جارٍ تحميل التقرير...</div>
          )}

          {preview && (
            <div className="space-y-4">
              {/* إحصائيات سريعة */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: "إجمالي الطلاب", value: preview.stats.totalStudents, icon: "👥" },
                  { label: "نشطون هذا الأسبوع", value: preview.stats.activeStudents, icon: "⚡" },
                  { label: "متوسط النقاط", value: preview.stats.avgScore, icon: "⭐" },
                  { label: "الشارات", value: preview.stats.totalBadges, icon: "🏅" },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-3 text-center border border-indigo-100"
                  >
                    <div className="text-2xl font-bold text-indigo-600">{stat.value}</div>
                    <div className="text-xs text-gray-500 mt-1">{stat.icon} {stat.label}</div>
                  </div>
                ))}
              </div>

              {/* نص التقرير الكامل */}
              <div>
                <p className="text-sm font-semibold text-gray-600 mb-2">📄 نص التقرير كما سيصل للمدير:</p>
                <pre
                  className="bg-gray-900 text-green-400 p-4 rounded-xl text-sm overflow-auto whitespace-pre-wrap font-mono leading-relaxed border border-gray-700"
                  style={{ direction: "rtl", textAlign: "right", maxHeight: "400px" }}
                >
                  {preview.text}
                </pre>
              </div>
            </div>
          )}

          {!selectedSchoolId && !previewLoading && (
            <div className="text-center py-8 text-gray-400 text-sm">
              اختر مدرسة من القائمة أعلاه لمعاينة نص التقرير
            </div>
          )}
        </CardContent>
      </Card>

      {/* سجل آخر إرسال */}
      {showLog && runLog.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">📋 سجل آخر إرسال</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setShowLog(false)}>✕</Button>
            </div>
          </CardHeader>
          <CardContent>
            <pre
              className="bg-gray-900 text-gray-300 p-4 rounded-xl text-xs overflow-auto whitespace-pre-wrap font-mono"
              style={{ maxHeight: "250px" }}
            >
              {runLog.join("\n")}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
