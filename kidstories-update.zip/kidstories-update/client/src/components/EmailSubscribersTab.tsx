import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Mail, Search, Download, Users, UserCheck, UserX, RefreshCw, TrendingUp, PieChart as PieIcon, CalendarRange, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";

type FilterType = "all" | "active" | "unsubscribed";

const RADIAN = Math.PI / 180;
const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }: any) => {
  if (percent < 0.05) return null;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={13} fontWeight="bold">
      {`${name} ${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

export default function EmailSubscribersTab() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 15;

  // فلتر التاريخ
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const isDateFiltered = !!(dateFrom || dateTo);

  const { data: subscribers = [], isLoading, refetch } = (trpc.email as any).listAll.useQuery();
  const { data: stats } = (trpc.email as any).subscriberStats.useQuery();

  // تطبيق فلتر التاريخ على بيانات الرسوم البيانية
  const monthly: any[] = useMemo(() => {
    const all: any[] = stats?.monthly ?? [];
    if (!dateFrom && !dateTo) return all;
    return all.filter((row: any) => {
      // row.month هو label مثل "أبر 25"، نستخدم index بدلاً من ذلك
      return true; // سيتم الفلترة بالمقارنة مع subscribedAt في الجدول
    });
  }, [stats, dateFrom, dateTo]);

  // إعادة حساب إحصائيات الرسوم البيانية بناءً على فلتر التاريخ
  const filteredStats = useMemo(() => {
    const all: any[] = subscribers as any[];
    const from = dateFrom ? new Date(dateFrom).getTime() : null;
    const to = dateTo ? new Date(dateTo + "T23:59:59").getTime() : null;

    const inRange = (ts: any) => {
      if (!ts) return false;
      const t = new Date(ts).getTime();
      if (from && t < from) return false;
      if (to && t > to) return false;
      return true;
    };

    if (!from && !to) {
      return {
        monthly: stats?.monthly ?? [],
        statusDist: stats?.statusDist ?? [],
        total: stats?.total ?? all.length,
        activeCount: stats?.activeCount ?? all.filter((s: any) => s.isSubscribed).length,
        unsubCount: stats?.unsubCount ?? all.filter((s: any) => !s.isSubscribed).length,
      };
    }

    // فلترة المشتركين حسب التاريخ
    const rangeSubscribers = all.filter((s: any) => inRange(s.subscribedAt));
    const activeCount = rangeSubscribers.filter((s: any) => s.isSubscribed).length;
    const unsubCount = rangeSubscribers.filter((s: any) => !s.isSubscribed).length;
    const total = rangeSubscribers.length;

    // إعادة بناء النمو الشهري
    const monthMap: Record<string, { month: string; subscribed: number; unsubscribed: number }> = {};
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("ar-SA", { month: "short", year: "2-digit" });
      monthMap[key] = { month: label, subscribed: 0, unsubscribed: 0 };
    }
    for (const s of all) {
      if (s.subscribedAt && inRange(s.subscribedAt)) {
        const d = new Date(s.subscribedAt);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        if (monthMap[key]) monthMap[key].subscribed++;
      }
      if (s.unsubscribedAt && inRange(s.unsubscribedAt)) {
        const d = new Date(s.unsubscribedAt);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        if (monthMap[key]) monthMap[key].unsubscribed++;
      }
    }

    return {
      monthly: Object.values(monthMap),
      statusDist: [
        { name: "نشط", value: activeCount, fill: "#10b981" },
        { name: "ملغى", value: unsubCount, fill: "#ef4444" },
      ],
      total,
      activeCount,
      unsubCount,
    };
  }, [subscribers, stats, dateFrom, dateTo]);

  // فلترة الجدول
  const filtered = useMemo(() => {
    let list = subscribers as any[];
    const from = dateFrom ? new Date(dateFrom).getTime() : null;
    const to = dateTo ? new Date(dateTo + "T23:59:59").getTime() : null;
    if (from || to) {
      list = list.filter((s: any) => {
        if (!s.subscribedAt) return false;
        const t = new Date(s.subscribedAt).getTime();
        if (from && t < from) return false;
        if (to && t > to) return false;
        return true;
      });
    }
    if (filter === "active") list = list.filter((s: any) => s.isSubscribed);
    if (filter === "unsubscribed") list = list.filter((s: any) => !s.isSubscribed);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((s: any) =>
        (s.email || "").toLowerCase().includes(q) ||
        (s.childName || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [subscribers, filter, search, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleResetDate = () => { setDateFrom(""); setDateTo(""); setPage(1); };

  // تصدير Excel
  const handleExportExcel = async () => {
    try {
      const XLSX = await import("xlsx");
      const rows = filtered.map((s: any) => ({
        "الاسم": s.childName || "—",
        "البريد الإلكتروني": s.email,
        "الحالة": s.isSubscribed ? "نشط" : "ملغى",
        "تاريخ الاشتراك": s.subscribedAt ? new Date(s.subscribedAt).toLocaleDateString("ar-SA") : "—",
        "تاريخ الإلغاء": s.unsubscribedAt ? new Date(s.unsubscribedAt).toLocaleDateString("ar-SA") : "—",
      }));
      const ws = XLSX.utils.json_to_sheet(rows);
      ws["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 10 }, { wch: 18 }, { wch: 18 }];
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "المشتركون");
      const date = new Date().toLocaleDateString("ar-SA").replace(/\//g, "-");
      XLSX.writeFile(wb, `مشتركو_البريد_${date}.xlsx`);
      toast.success("✅ تم تصدير قائمة المشتركين");
    } catch (e) {
      toast.error("حدث خطأ أثناء التصدير");
    }
  };

  return (
    <div className="space-y-6 p-4 md:p-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Mail className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold">المشتركون في البريد</h2>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="gap-1" onClick={() => refetch()}>
            <RefreshCw className="w-3.5 h-3.5" />
            تحديث
          </Button>
          <Button
            size="sm"
            className="gap-1 bg-green-600 hover:bg-green-700 text-white"
            onClick={handleExportExcel}
            disabled={filtered.length === 0}
          >
            <Download className="w-3.5 h-3.5" />
            تصدير Excel
          </Button>
        </div>
      </div>

      {/* Date Filter */}
      <Card className={`border-2 ${isDateFiltered ? "border-primary/50 bg-primary/5" : "border-border/30"}`}>
        <CardContent className="pt-4 pb-3">
          <div className="flex flex-wrap gap-3 items-end">
            <CalendarRange className="w-4 h-4 text-primary mt-1 shrink-0" />
            <div className="flex flex-col gap-1">
              <Label className="text-xs font-semibold text-muted-foreground">من تاريخ</Label>
              <Input
                type="date"
                value={dateFrom}
                onChange={e => { setDateFrom(e.target.value); setPage(1); }}
                className="h-8 text-sm w-40"
                dir="ltr"
              />
            </div>
            <div className="flex flex-col gap-1">
              <Label className="text-xs font-semibold text-muted-foreground">إلى تاريخ</Label>
              <Input
                type="date"
                value={dateTo}
                onChange={e => { setDateTo(e.target.value); setPage(1); }}
                className="h-8 text-sm w-40"
                dir="ltr"
              />
            </div>
            {isDateFiltered && (
              <Button variant="outline" size="sm" className="gap-1 h-8 text-xs" onClick={handleResetDate}>
                <RotateCcw className="w-3 h-3" />
                إعادة تعيين
              </Button>
            )}
            {isDateFiltered && (
              <Badge className="bg-primary/10 text-primary border-primary/30 text-xs">
                فلتر نشط
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="border-2 border-primary/20">
          <CardContent className="pt-4 text-center">
            <Users className="w-5 h-5 mx-auto mb-1 text-primary" />
            <p className="text-2xl font-bold text-primary">{filteredStats.total}</p>
            <p className="text-xs text-muted-foreground">إجمالي المشتركين</p>
          </CardContent>
        </Card>
        <Card className="border-2 border-green-200">
          <CardContent className="pt-4 text-center">
            <UserCheck className="w-5 h-5 mx-auto mb-1 text-green-600" />
            <p className="text-2xl font-bold text-green-600">{filteredStats.activeCount}</p>
            <p className="text-xs text-muted-foreground">نشط</p>
          </CardContent>
        </Card>
        <Card className="border-2 border-red-200">
          <CardContent className="pt-4 text-center">
            <UserX className="w-5 h-5 mx-auto mb-1 text-red-500" />
            <p className="text-2xl font-bold text-red-500">{filteredStats.unsubCount}</p>
            <p className="text-xs text-muted-foreground">ملغى الاشتراك</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              نمو المشتركين شهرياً
              {isDateFiltered && <Badge className="text-xs bg-primary/10 text-primary border-primary/30">مُفلتر</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredStats.monthly.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">لا توجد بيانات</div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={filteredStats.monthly} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ borderRadius: 8, fontSize: 12 }}
                    formatter={(val: any, name: string) => [val, name === "subscribed" ? "اشتراك جديد" : "إلغاء"]}
                    labelFormatter={(l) => `الشهر: ${l}`}
                  />
                  <Legend formatter={(val) => val === "subscribed" ? "اشتراك جديد" : "إلغاء اشتراك"} wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="subscribed" fill="#10b981" radius={[4, 4, 0, 0]} name="subscribed" />
                  <Bar dataKey="unsubscribed" fill="#ef4444" radius={[4, 4, 0, 0]} name="unsubscribed" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-primary" />
              توزيع الحالات
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredStats.total === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">لا توجد بيانات</div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={filteredStats.statusDist} cx="50%" cy="50%" outerRadius={85} dataKey="value" labelLine={false} label={renderCustomLabel}>
                    {filteredStats.statusDist.map((entry: any, i: number) => (
                      <Cell key={i} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} formatter={(val: any, name: string) => [val, name]} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالاسم أو البريد..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            className="pr-9 h-9 text-sm"
          />
        </div>
        {(["all", "active", "unsubscribed"] as FilterType[]).map(f => (
          <Button key={f} variant={filter === f ? "default" : "outline"} size="sm" onClick={() => { setFilter(f); setPage(1); }}>
            {f === "all" ? "الكل" : f === "active" ? "نشط" : "ملغى"}
          </Button>
        ))}
        <span className="text-xs text-muted-foreground mr-auto">{filtered.length} نتيجة</span>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <Mail className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p>لا توجد نتائج</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="text-right py-3 px-4 font-semibold text-muted-foreground">#</th>
                  <th className="text-right py-3 px-4 font-semibold text-muted-foreground">الاسم</th>
                  <th className="text-right py-3 px-4 font-semibold text-muted-foreground">البريد الإلكتروني</th>
                  <th className="text-right py-3 px-4 font-semibold text-muted-foreground">الحالة</th>
                  <th className="text-right py-3 px-4 font-semibold text-muted-foreground">تاريخ الاشتراك</th>
                  <th className="text-right py-3 px-4 font-semibold text-muted-foreground">تاريخ الإلغاء</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((s: any, i: number) => (
                  <tr key={s.id} className="border-b last:border-0 hover:bg-muted/20 transition-colors">
                    <td className="py-3 px-4 text-muted-foreground">{(page - 1) * PAGE_SIZE + i + 1}</td>
                    <td className="py-3 px-4 font-medium">{s.childName || <span className="text-muted-foreground">—</span>}</td>
                    <td className="py-3 px-4 text-muted-foreground" dir="ltr">{s.email}</td>
                    <td className="py-3 px-4">
                      {s.isSubscribed
                        ? <Badge className="bg-green-100 text-green-700 border-green-200">نشط</Badge>
                        : <Badge variant="outline" className="text-red-500 border-red-200">ملغى</Badge>
                      }
                    </td>
                    <td className="py-3 px-4 text-muted-foreground text-xs">
                      {s.subscribedAt ? new Date(s.subscribedAt).toLocaleDateString("ar-SA") : "—"}
                    </td>
                    <td className="py-3 px-4 text-muted-foreground text-xs">
                      {s.unsubscribedAt ? new Date(s.unsubscribedAt).toLocaleDateString("ar-SA") : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>السابق</Button>
          <span className="text-sm text-muted-foreground">صفحة {page} من {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>التالي</Button>
        </div>
      )}
    </div>
  );
}
