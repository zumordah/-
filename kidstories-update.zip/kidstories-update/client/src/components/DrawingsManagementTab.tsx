import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function DrawingsManagementTab() {
  const { data: drawings, refetch } = trpc.drawings.adminGetAll.useQuery();
  const reviewMutation = trpc.drawings.adminReview.useMutation();
  const setFeaturedMutation = trpc.drawings.adminSetFeatured.useMutation();
  const [selectedRating, setSelectedRating] = useState<Record<number, number>>({});

  const handleApprove = async (drawingId: number) => {
    await reviewMutation.mutateAsync({
      drawingId,
      approved: true,
      rating: selectedRating[drawingId] || 0,
    });
    refetch();
  };

  const handleReject = async (drawingId: number) => {
    await reviewMutation.mutateAsync({
      drawingId,
      approved: false,
    });
    refetch();
  };

  const handleSetFeatured = async (drawingId: number, isFeatured: boolean) => {
    await setFeaturedMutation.mutateAsync({ drawingId, isFeatured });
    refetch();
  };

  return (
    <div className="space-y-4">
      {drawings?.map((drawing) => (
        <Card key={drawing.id} className="p-4">
          <div className="flex gap-4">
            <img src={drawing.imageUrl} alt="drawing" className="w-32 h-32 object-cover rounded" />
            <div className="flex-1">
              <p className="font-bold">{drawing.childName}</p>
              <p className="text-sm text-gray-600">{drawing.storyTitle}</p>
              <p className="text-sm">المدرسة: {drawing.schoolName}</p>
              <Badge className={drawing.status === "pending" ? "bg-yellow-500" : drawing.status === "approved" ? "bg-green-500" : "bg-red-500"}>
                {drawing.status === "pending" ? "قيد المراجعة" : drawing.status === "approved" ? "معتمدة" : "مرفوضة"}
              </Badge>

              {drawing.status === "pending" && (
                <div className="mt-3 space-y-2">
                  <div>
                    <label className="text-sm">التقييم (1-5):</label>
                    <select
                      value={selectedRating[drawing.id] || 0}
                      onChange={(e) => setSelectedRating({ ...selectedRating, [drawing.id]: parseInt(e.target.value) })}
                      className="border rounded px-2 py-1 text-sm"
                    >
                      <option value={0}>بدون تقييم</option>
                      {[1, 2, 3, 4, 5].map((r) => (
                        <option key={r} value={r}>{r} نجوم</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleApprove(drawing.id)} className="bg-green-500">اعتماد</Button>
                    <Button size="sm" onClick={() => handleReject(drawing.id)} className="bg-red-500">رفض</Button>
                  </div>
                </div>
              )}

              {drawing.status === "approved" && (
                <Button
                  size="sm"
                  onClick={() => handleSetFeatured(drawing.id, !drawing.isFeatured)}
                  className={drawing.isFeatured ? "bg-purple-500" : "bg-gray-400"}
                >
                  {drawing.isFeatured ? "إلغاء التمييز" : "تعيين كأفضل"}
                </Button>
              )}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
