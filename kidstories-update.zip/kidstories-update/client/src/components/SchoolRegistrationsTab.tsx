import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { CheckCircle, XCircle, Clock, School, Mail, Phone, FileText, User, Calendar } from "lucide-react";

const STATUS_MAP: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending: { label: "قيد المراجعة", color: "bg-yellow-100 text-yellow-700 border-yellow-300", icon: <Clock className="w-3.5 h-3.5" /> },
  approved: { label: "تمت الموافقة", color: "bg-green-100 text-green-700 border-green-300", icon: <CheckCircle className="w-3.5 h-3.5" /> },
  rejected: { label: "مرفوض", color: "bg-red-100 text-red-700 border-red-300", icon: <XCircle className="w-3.5 h-3.5" /> },
};

export default function SchoolRegistrationsTab() {
  const { data: registrations = [], refetch, isLoading } = trpc.schools.listRegistrations.useQuery();
  const approveMutation = trpc.schools.approveRegistration.useMutation();
  const rejectMutation = trpc.schools.rejectRegistration.useMutation();

  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "approved" | "rejected">("all");

  const filtered = filterStatus === "all"
    ? registrations
    : registrations.filter((r: any) => r.status === filterStatus);

  const pendingCount = registrations.filter((r: any) => r.status === "pending").length;

  const handleApprove = async (id: number, schoolName: string) => {
    if (!confirm(`هل تريد الموافقة على طلب تسجيل "${schoolName}"؟\nسيتم إنشاء حساب المدرسة فوراً.`)) return;
    try {
      await approveMutation.mutateAsync({ id });
      toast.success(`تمت الموافقة على "${schoolName}" وإنشاء حسابها ✅`);
      refetch();
    } catch {
      toast.error("حدث خطأ أثناء الموافقة");
    }
  };

  const handleReject = async (id: number) => {
    try {
      await rejectMutation.mutateAsync({ id, reason: rejectReason || undefined });
      toast.success("تم رفض الطلب");
      setRejectingId(null);
      setRejectReason("");
      refetch();
    } catch {
      toast.error("حدث خطأ أثناء الرفض");
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-5" dir="rtl">
      {/* الهيدر */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
            <School className="w-5 h-5 text-purple-500" />
            طلبات تسجيل المدارس
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            {registrations.length} طلب إجمالي
            {pendingCount > 0 && (
              <span className="mr-2 text-yellow-600 font-semibold">• {pendingCount} في انتظار المراجعة</span>
            )}
          </p>
        </div>
        {/* فلتر الحالة */}
        <div className="flex gap-2 flex-wrap">
          {(["all", "pending", "approved", "rejected"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                filterStatus === s
                  ? "bg-purple-600 text-white border-purple-600"
                  : "bg-white text-gray-600 border-gray-200 hover:border-purple-300"
              }`}
            >
              {s === "all" ? "الكل" : STATUS_MAP[s]?.label}
              {s === "pending" && pendingCount > 0 && (
                <span className="mr-1.5 bg-yellow-400 text-yellow-900 rounded-full px-1.5 py-0.5 text-xs font-bold">
                  {pendingCount}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* المحتوى */}
      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">جاري التحميل...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <School className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>{filterStatus === "all" ? "لا توجد طلبات تسجيل حتى الآن" : "لا توجد طلبات بهذه الحالة"}</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filtered.map((reg: any) => {
            const statusInfo = STATUS_MAP[reg.status] ?? STATUS_MAP.pending;
            return (
              <div
                key={reg.id}
                className={`bg-white rounded-2xl border-2 p-5 shadow-sm transition-all ${
                  reg.status === "pending" ? "border-yellow-200 hover:border-yellow-300" : "border-gray-100"
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                  {/* المعلومات */}
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base font-bold text-gray-800">{reg.schoolName}</h3>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${statusInfo.color}`}>
                        {statusInfo.icon}
                        {statusInfo.label}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-sm text-gray-600">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                        <span>{reg.adminName}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                        <span dir="ltr" className="text-xs">{reg.adminEmail}</span>
                      </div>
                      {reg.phone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-green-400 flex-shrink-0" />
                          <span dir="ltr">{reg.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                        <span className="text-xs text-gray-400">
                          {new Date(reg.createdAt).toLocaleDateString("ar-SA", { year: "numeric", month: "short", day: "numeric" })}
                        </span>
                      </div>
                    </div>

                    {reg.notes && (
                      <div className="flex items-start gap-1.5 text-sm text-gray-500 bg-gray-50 rounded-lg p-2.5 mt-1">
                        <FileText className="w-3.5 h-3.5 text-gray-400 flex-shrink-0 mt-0.5" />
                        <span>{reg.notes}</span>
                      </div>
                    )}

                    {reg.status === "rejected" && reg.rejectionReason && (
                      <div className="flex items-start gap-1.5 text-sm text-red-600 bg-red-50 rounded-lg p-2.5 mt-1">
                        <XCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                        <span>سبب الرفض: {reg.rejectionReason}</span>
                      </div>
                    )}
                  </div>

                  {/* الأزرار */}
                  {reg.status === "pending" && (
                    <div className="flex flex-col gap-2 min-w-[120px]">
                      <Button
                        size="sm"
                        onClick={() => handleApprove(reg.id, reg.schoolName)}
                        disabled={approveMutation.isPending}
                        className="bg-green-600 hover:bg-green-700 text-white rounded-xl gap-1.5 text-xs"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        موافقة
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => { setRejectingId(reg.id); setRejectReason(""); }}
                        className="border-red-300 text-red-600 hover:bg-red-50 rounded-xl gap-1.5 text-xs"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        رفض
                      </Button>
                    </div>
                  )}
                </div>

                {/* نافذة الرفض المضمّنة */}
                {rejectingId === reg.id && (
                  <div className="mt-4 pt-4 border-t border-red-100 space-y-3">
                    <p className="text-sm font-medium text-red-700">سبب الرفض (اختياري):</p>
                    <textarea
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                      placeholder="أدخل سبب الرفض إن وجد..."
                      className="w-full border border-red-200 rounded-xl p-3 text-sm resize-none focus:outline-none focus:border-red-400"
                      rows={2}
                    />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleReject(reg.id)}
                        disabled={rejectMutation.isPending}
                        className="bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs"
                      >
                        تأكيد الرفض
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setRejectingId(null)}
                        className="rounded-xl text-xs"
                      >
                        إلغاء
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
