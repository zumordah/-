import { useState, useCallback, useMemo } from "react";
import { RotateCcw, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toAr, arabicizeText } from "@/lib/arabicNumerals";

function playCorrectTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = "sine"; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.3, ctx.currentTime + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.3);
      osc.start(ctx.currentTime + i * 0.12);
      osc.stop(ctx.currentTime + i * 0.12 + 0.35);
    });
  } catch {}
}
function playWrongTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.4);
  } catch {}
}

export interface LogicPuzzleGameData {
  id: string;
  title: string;
  description: string;
  /** نوع اللعبة المنطقية */
  type: "pattern_complete" | "odd_one_out" | "what_comes_next" | "find_rule";
  questions: {
    id: string;
    prompt: string;
    items: { emoji: string; label: string }[];
    options: { emoji: string; label: string }[];
    correctIndex: number;
    explanation: string;
  }[];
}

// ─── خلط الخيارات عشوائياً مع تحديث correctIndex ───────────────────────────
function shuffleOptions(question: LogicPuzzleGameData["questions"][number]) {
  const correctOption = question.options[question.correctIndex];
  const shuffled = [...question.options].sort(() => Math.random() - 0.5);
  const newCorrectIndex = shuffled.findIndex(
    (opt) => opt.emoji === correctOption.emoji && opt.label === correctOption.label
  );
  return { shuffledOptions: shuffled, newCorrectIndex };
}

interface Props {
  game: LogicPuzzleGameData;
  onComplete: (score: number) => void;
}

export function LogicPuzzleGame({ game, onComplete }: Props) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [shake, setShake] = useState<number | null>(null);
  const [done, setDone] = useState(false);

  // خلط الخيارات مرة واحدة عند تحميل اللعبة — كل سؤال له خيارات مخلوطة مختلفة
  const shuffledQuestions = useMemo(() => {
    return game.questions.map((q) => {
      const { shuffledOptions, newCorrectIndex } = shuffleOptions(q);
      return { ...q, options: shuffledOptions, correctIndex: newCorrectIndex };
    });
  }, [game]);

  const question = shuffledQuestions[currentQ];

  const handleSelect = useCallback((idx: number) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === question.correctIndex) {
      playCorrectTone();
      setCorrect((c) => c + 1);
    } else {
      playWrongTone();
      setShake(idx);
      setTimeout(() => setShake(null), 500);
    }
    setTimeout(() => {
      if (currentQ < shuffledQuestions.length - 1) {
        setCurrentQ((q) => q + 1);
        setSelected(null);
        setAnswered(false);
      } else {
        setDone(true);
        const score = Math.round(((correct + (idx === question.correctIndex ? 1 : 0)) / shuffledQuestions.length) * 100);
        onComplete(score);
      }
    }, 1400);
  }, [answered, question, currentQ, shuffledQuestions.length, correct, onComplete]);

  const reset = () => {
    setCurrentQ(0);
    setSelected(null);
    setAnswered(false);
    setCorrect(0);
    setDone(false);
  };

  if (done) {
    const score = Math.round((correct / shuffledQuestions.length) * 100);
    return (
      <div className="text-center py-8">
        <div className="text-6xl mb-4">{score >= 70 ? "🏆" : "🌟"}</div>
        <h3 className="text-2xl font-bold text-foreground mb-2">
          {score >= 70 ? "ممتاز! عقلك ذكي جداً!" : "أحسنت! استمر في التدرب!"}
        </h3>
        <p className="text-muted-foreground mb-4">
          أجبت على {toAr(correct)} من {toAr(shuffledQuestions.length)} أسئلة بشكل صحيح
        </p>
        <div className="text-4xl font-bold text-primary mb-6">{toAr(score)}%</div>
        <Button onClick={reset} variant="outline" className="gap-2 rounded-2xl">
          <RotateCcw className="h-4 w-4" />
          العب مجدداً
        </Button>
      </div>
    );
  }

  return (
    <div dir="rtl">
      {/* Progress */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-muted-foreground">سؤال {toAr(currentQ + 1)} من {toAr(shuffledQuestions.length)}</span>
        <div className="flex gap-1">
          {shuffledQuestions.map((_, i) => (
            <div
              key={i}
              className={`h-2 w-6 rounded-full transition-colors ${
                i < currentQ ? "bg-green-400" : i === currentQ ? "bg-primary" : "bg-muted"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Prompt */}
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-4 mb-4 text-center">
        <p className="text-base font-bold text-foreground mb-3">{arabicizeText(question.prompt)}</p>
        {/* Pattern items */}
        <div className="flex justify-center gap-2 flex-wrap">
          {question.items.map((item, i) => (
            <div key={i} className="flex flex-col items-center bg-white rounded-xl p-2 shadow-sm min-w-[52px]">
              <span className="text-3xl">{item.emoji}</span>
              <span className="text-xs text-muted-foreground mt-1">{item.label}</span>
            </div>
          ))}
          {/* Question mark slot */}
          <div className="flex flex-col items-center bg-yellow-100 border-2 border-dashed border-yellow-400 rounded-xl p-2 shadow-sm min-w-[52px]">
            <span className="text-3xl">❓</span>
            <span className="text-xs text-yellow-600 mt-1">؟</span>
          </div>
        </div>
      </div>

      {/* Options */}
      <div className="grid grid-cols-2 gap-3">
        {question.options.map((opt, i) => {
          const isCorrect = i === question.correctIndex;
          const isSelected = selected === i;
          let cls = "flex flex-col items-center p-4 rounded-2xl border-2 cursor-pointer transition-all ";
          if (answered) {
            if (isCorrect) cls += "border-green-400 bg-green-50 scale-105";
            else if (isSelected) cls += "border-red-400 bg-red-50";
            else cls += "border-border bg-muted/30 opacity-60";
          } else {
            cls += "border-border bg-white hover:border-primary hover:bg-primary/5 hover:scale-105";
          }
          if (shake === i) cls += " animate-shake";

          return (
            <button key={i} className={cls} onClick={() => handleSelect(i)}>
              <span className="text-4xl mb-1">{opt.emoji}</span>
              <span className="text-sm font-bold text-foreground">{arabicizeText(opt.label)}</span>
              {answered && isCorrect && <CheckCircle className="h-4 w-4 text-green-500 mt-1" />}
            </button>
          );
        })}
      </div>

      {/* Explanation */}
      {answered && (
        <div className={`mt-4 p-3 rounded-2xl text-sm font-medium ${
          selected === question.correctIndex ? "bg-green-50 text-green-700" : "bg-orange-50 text-orange-700"
        }`}>
          {selected === question.correctIndex ? "✅ " : "💡 "}
          {question.explanation}
        </div>
      )}
    </div>
  );
}
