import { useState } from "react";
import { RotateCcw, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toAr } from "@/lib/arabicNumerals";

// تأثيرات صوتية عبر Web Audio API
function playCorrectTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = "sine"; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.3, ctx.currentTime + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.3);
      osc.start(ctx.currentTime + i * 0.12);
      osc.stop(ctx.currentTime + i * 0.12 + 0.35);
    });
  } catch {}
}
function playWrongTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.4);
  } catch {}
}

export interface BuildLogicGameData {
  id: string;
  title: string;
  description: string;
  type: "match_function" | "complete_pattern" | "count_build";
  pairs: { id: string; left: { emoji: string; label: string }; right: { emoji: string; label: string } }[];
}

interface Props {
  game: BuildLogicGameData;
  onComplete: (score: number) => void;
}

// نظام النقر: اضغط على عنصر أيسر ثم اضغط على ما يناسبه في الأيمن
export function BuildLogicGame({ game, onComplete }: Props) {
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [connections, setConnections] = useState<Record<string, string>>({}); // leftId -> rightId
  const [completed, setCompleted] = useState(false);
  const [correctPairs, setCorrectPairs] = useState<Set<string>>(new Set());
  const [shakePair, setShakePair] = useState<string | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);

  const [shuffledRight] = useState(() =>
    [...game.pairs].sort(() => Math.random() - 0.5)
  );

  const handleLeftClick = (leftId: string) => {
    if (correctPairs.has(leftId)) return; // مربوط بشكل صحيح
    setSelectedLeft(selectedLeft === leftId ? null : leftId);
  };

  const handleRightClick = (rightId: string) => {
    if (!selectedLeft) return;
    // تحقق من الصحة
    const pair = game.pairs.find((p) => p.id === selectedLeft);
    const isCorrect = pair?.id === rightId;
    const newConnections = { ...connections, [selectedLeft]: rightId };
    setConnections(newConnections);

    if (isCorrect) {
      playCorrectTone();
      const newCorrect = new Set(correctPairs);
      newCorrect.add(selectedLeft);
      setCorrectPairs(newCorrect);
      setSelectedLeft(null);
      if (newCorrect.size === game.pairs.length) {
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 1800);
        setCompleted(true);
        setTimeout(() => onComplete(100), 800);
      }
    } else {
      playWrongTone();
      setShakePair(selectedLeft);
      setTimeout(() => {
        setShakePair(null);
        const next = { ...newConnections };
        delete next[selectedLeft!];
        setConnections(next);
        setSelectedLeft(null);
      }, 900);
    }
  };

  const handleReset = () => {
    setSelectedLeft(null);
    setConnections({});
    setCompleted(false);
    setCorrectPairs(new Set());
    setShakePair(null);
    setShowConfetti(false);
  };

  const getLeftStyle = (leftId: string) => {
    if (correctPairs.has(leftId)) return "border-green-500 bg-green-50 opacity-70 cursor-default";
    if (shakePair === leftId) return "border-red-400 bg-red-50 animate-shake-inline";
    if (selectedLeft === leftId) return "border-purple-500 bg-purple-100 scale-105 shadow-md ring-2 ring-purple-300";
    return "border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50 hover:scale-105 cursor-pointer";
  };

  const getRightStyle = (rightId: string) => {
    const matchedLeftId = Object.keys(connections).find((k) => connections[k] === rightId);
    if (matchedLeftId && correctPairs.has(matchedLeftId)) return "border-green-500 bg-green-50 cursor-default";
    if (matchedLeftId && shakePair === matchedLeftId) return "border-red-400 bg-red-50 animate-shake-inline";
    if (selectedLeft) return "border-dashed border-purple-300 bg-purple-50/50 hover:border-purple-500 hover:bg-purple-100 hover:scale-105 cursor-pointer";
    return "border-dashed border-gray-300 bg-gray-50";
  };

  if (completed) {
    return (
      <div className="flex flex-col items-center justify-center py-10 gap-4" dir="rtl">
        {showConfetti && (
          <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} style={{
                position: "absolute", top: "-20px",
                left: `${5 + (i * 5) % 90}%`,
                width: 10, height: 10,
                background: ["#f59e0b","#10b981","#6366f1","#ec4899","#3b82f6"][i % 5],
                borderRadius: i % 2 === 0 ? "50%" : "2px",
                animation: `confettiFall 1.5s ease-in ${(i * 0.06).toFixed(2)}s forwards`,
              }} />
            ))}
          </div>
        )}
        <div className="text-6xl animate-bounce">🏆</div>
        <h3 className="text-2xl font-bold text-green-600">عبقري! ربطت كل شيء بشكل صحيح!</h3>
        <Button onClick={handleReset} variant="outline" className="gap-2">
          <RotateCcw className="h-4 w-4" /> العب مرة أخرى
        </Button>
      </div>
    );
  }

  return (
    <div className="select-none" dir="rtl">
      <div className="text-center mb-4">
        <p className="text-sm text-gray-500">{game.description}</p>
        <div className="mt-2 bg-purple-50 border border-purple-200 rounded-xl px-3 py-2">
          <p className="text-xs text-purple-700 font-medium">
            👆 اضغط على عنصر من العمود الأيسر ثم اضغط على ما يناسبه في العمود الأيمن
          </p>
        </div>
        <p className="text-xs text-green-600 font-medium mt-2">
          ✅ صحيح: {toAr(correctPairs.size)} / {toAr(game.pairs.length)}
        </p>
      </div>

      {selectedLeft && (
        <div className="mb-3 bg-purple-100 border border-purple-300 rounded-xl p-2 text-center">
          <p className="text-xs text-purple-700 font-bold">
            اخترت: {game.pairs.find(p => p.id === selectedLeft)?.left.emoji} {game.pairs.find(p => p.id === selectedLeft)?.left.label} — الآن اضغط على ما يناسبه ←
          </p>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        {/* العمود الأيسر - اضغط للاختيار */}
        <div className="space-y-2">
          <p className="text-xs text-center font-bold text-purple-600 mb-2">اضغط للاختيار 👆</p>
          {game.pairs.map((pair) => (
            <button
              key={pair.id}
              onClick={() => handleLeftClick(pair.id)}
              disabled={correctPairs.has(pair.id)}
              className={`w-full flex items-center gap-2 p-3 rounded-2xl border-2 transition-all duration-200 text-right ${getLeftStyle(pair.id)}`}
            >
              <span className="text-2xl">{pair.left.emoji}</span>
              <span className="text-sm font-medium">{pair.left.label}</span>
              {correctPairs.has(pair.id) && <CheckCircle className="h-4 w-4 text-green-500 mr-auto" />}
            </button>
          ))}
        </div>

        {/* العمود الأيمن - اضغط للمطابقة */}
        <div className="space-y-2">
          <p className="text-xs text-center font-bold text-orange-600 mb-2">اضغط للمطابقة 👇</p>
          {shuffledRight.map((pair) => {
            const matchedLeftId = Object.keys(connections).find((k) => connections[k] === pair.id);
            const isMatched = matchedLeftId ? correctPairs.has(matchedLeftId) : false;
            return (
              <button
                key={pair.id}
                onClick={() => handleRightClick(pair.id)}
                disabled={isMatched}
                className={`w-full flex items-center gap-2 p-3 rounded-2xl border-2 transition-all duration-200 text-right min-h-[56px] ${getRightStyle(pair.id)}`}
              >
                <span className="text-2xl">{pair.right.emoji}</span>
                <span className="text-sm font-medium">{pair.right.label}</span>
                {isMatched && <CheckCircle className="h-4 w-4 text-green-500 mr-auto" />}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-4 flex justify-center">
        <Button onClick={handleReset} variant="ghost" size="sm" className="gap-1 text-muted-foreground">
          <RotateCcw className="h-3 w-3" /> إعادة
        </Button>
      </div>
    </div>
  );
}
