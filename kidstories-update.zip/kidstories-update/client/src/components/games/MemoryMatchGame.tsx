import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RotateCcw, Eye, EyeOff, CheckCircle } from "lucide-react";
import { toAr } from "@/lib/arabicNumerals";

// ─── Types ────────────────────────────────────────────────────────────────────
export interface MemoryCard {
  id: string;
  emoji: string;
  label: string;
}

export interface MemoryMatchData {
  id: string;
  title: string;
  description?: string;
  leftItems?: MemoryCard[];
  rightItems?: MemoryCard[];
  cards?: MemoryCard[];
}

interface Props {
  game: MemoryMatchData;
  onComplete: (score: number) => void;
}

// ─── Confetti ─────────────────────────────────────────────────────────────────
function MiniConfetti({ active }: { active: boolean }) {
  if (!active) return null;
  const colors = ["#f59e0b", "#10b981", "#6366f1", "#ec4899", "#3b82f6", "#f97316"];
  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {Array.from({ length: 24 }).map((_, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            top: "-20px",
            left: `${4 + (i * 4) % 92}%`,
            width: 8 + (i % 5) * 3,
            height: 8 + (i % 5) * 3,
            background: colors[i % colors.length],
            borderRadius: i % 3 === 0 ? "50%" : "2px",
            animation: `confettiFall 1.5s ease-in ${(i * 0.05).toFixed(2)}s forwards`,
            transform: `rotate(${i * 15}deg)`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export function MemoryMatchGame({ game, onComplete }: Props) {
  const rawCards: MemoryCard[] = game.cards ?? game.leftItems ?? [];

  type Phase = "memorize" | "countdown" | "play" | "done";
  const [phase, setPhase] = useState<Phase>("memorize");
  const [countdown, setCountdown] = useState(4);
  const [row2] = useState<MemoryCard[]>(() =>
    [...rawCards].sort(() => Math.random() - 0.5)
  );
  const [selected, setSelected] = useState<Record<number, number>>({});
  const [activeRow2, setActiveRow2] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<Record<number, "correct" | "wrong">>({});
  const [showConfetti, setShowConfetti] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [shakeRow2, setShakeRow2] = useState<number | null>(null);

  // ── Countdown ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (phase !== "countdown") return;
    if (countdown <= 0) { setPhase("play"); return; }
    const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, countdown]);

  const startGame = () => { setPhase("countdown"); setCountdown(4); };

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handleRow2Click = (r2Idx: number) => {
    if (phase !== "play") return;
    if (feedback[r2Idx] === "correct") return;
    setActiveRow2(r2Idx);
  };

  const handleRow1Click = useCallback(
    (r1Idx: number) => {
      if (phase !== "play" || activeRow2 === null) return;
      if (feedback[activeRow2] === "correct") return;

      setAttempts((a) => a + 1);
      const r2Card = row2[activeRow2];
      const r1Card = rawCards[r1Idx];
      const isCorrect = r2Card.id === r1Card.id;

      setSelected((prev) => ({ ...prev, [activeRow2]: r1Idx }));
      setFeedback((prev) => ({ ...prev, [activeRow2]: isCorrect ? "correct" : "wrong" }));
      setActiveRow2(null);

      if (!isCorrect) {
        setShakeRow2(activeRow2);
        setTimeout(() => {
          setShakeRow2(null);
          setFeedback((prev) => {
            const next = { ...prev };
            if (next[activeRow2] === "wrong") delete next[activeRow2];
            return next;
          });
          setSelected((prev) => {
            const next = { ...prev };
            delete next[activeRow2];
            return next;
          });
        }, 900);
      } else {
        const newCorrectCount = Object.values({ ...feedback, [activeRow2]: "correct" }).filter(
          (v) => v === "correct"
        ).length;
        if (newCorrectCount === rawCards.length) {
          setPhase("done");
          setShowConfetti(true);
          setTimeout(() => setShowConfetti(false), 1800);
          const score = Math.max(20, Math.round(100 - (attempts / rawCards.length) * 8));
          setTimeout(() => onComplete(score), 900);
        }
      }
    },
    [phase, activeRow2, row2, rawCards, feedback, attempts, onComplete]
  );

  const handleReset = () => {
    setPhase("memorize");
    setCountdown(4);
    setSelected({});
    setActiveRow2(null);
    setFeedback({});
    setShowConfetti(false);
    setAttempts(0);
    setShakeRow2(null);
  };

  const correctCount = Object.values(feedback).filter((v) => v === "correct").length;

  // ── MEMORIZE ──────────────────────────────────────────────────────────────
  if (phase === "memorize") {
    return (
      <div className="select-none" dir="rtl">
        <div className="text-center mb-5">
          <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 px-4 py-2 rounded-full text-sm font-bold mb-3">
            <Eye className="w-4 h-4" /> مرحلة الحفظ
          </div>
          <h3 className="text-base font-bold text-gray-700 mb-1">احفظ مكان كل بطاقة في الصف الأول!</h3>
          <p className="text-xs text-gray-500">بعد الضغط على "ابدأ" ستظهر البطاقات لثوانٍ ثم تختفي</p>
        </div>
        <div className="mb-4">
          <p className="text-xs font-bold text-center text-purple-600 mb-2">الصف الأول (احفظ الترتيب)</p>
          <div className="flex gap-2 justify-center flex-wrap">
            {rawCards.map((card, idx) => (
              <div key={card.id} className="flex flex-col items-center gap-1 bg-purple-50 border-2 border-purple-200 rounded-2xl p-2 min-w-[60px]">
                <span className="text-xs text-purple-400 font-bold">{toAr(idx + 1)}</span>
                <span className="text-3xl">{card.emoji}</span>
                <span className="text-[10px] font-medium text-purple-700 text-center leading-tight">{card.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="mb-5">
          <p className="text-xs font-bold text-center text-orange-600 mb-2">الصف الثاني (مختلط - ستطابق هنا)</p>
          <div className="flex gap-2 justify-center flex-wrap">
            {row2.map((card) => (
              <div key={card.id} className="flex flex-col items-center gap-1 bg-orange-50 border-2 border-orange-200 rounded-2xl p-2 min-w-[60px]">
                <span className="text-3xl">{card.emoji}</span>
                <span className="text-[10px] font-medium text-orange-700 text-center leading-tight">{card.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="text-center">
          <Button onClick={startGame} className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-2xl text-base font-bold gap-2">
            <Eye className="w-5 h-5" /> ابدأ الحفظ!
          </Button>
        </div>
      </div>
    );
  }

  // ── COUNTDOWN ─────────────────────────────────────────────────────────────
  if (phase === "countdown") {
    return (
      <div className="select-none" dir="rtl">
        <div className="text-center mb-4">
          <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-bold mb-3">
            <Eye className="w-4 h-4" /> احفظ الترتيب!
          </div>
          <div className="text-6xl font-black text-purple-700 animate-bounce mb-2">{toAr(countdown)}</div>
          <p className="text-sm text-gray-500">ستختفي البطاقات بعد {toAr(countdown)} ثانية</p>
        </div>
        <div className="mb-4">
          <p className="text-xs font-bold text-center text-purple-600 mb-2">الصف الأول</p>
          <div className="flex gap-2 justify-center flex-wrap">
            {rawCards.map((card, idx) => (
              <div key={card.id} className="flex flex-col items-center gap-1 bg-purple-100 border-2 border-purple-400 rounded-2xl p-2 min-w-[60px] shadow-md">
                <span className="text-xs text-purple-400 font-bold">{toAr(idx + 1)}</span>
                <span className="text-3xl">{card.emoji}</span>
                <span className="text-[10px] font-medium text-purple-700 text-center">{card.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="mb-4">
          <p className="text-xs font-bold text-center text-orange-600 mb-2">الصف الثاني (مختلط)</p>
          <div className="flex gap-2 justify-center flex-wrap">
            {row2.map((card) => (
              <div key={card.id} className="flex flex-col items-center gap-1 bg-orange-50 border-2 border-orange-200 rounded-2xl p-2 min-w-[60px]">
                <span className="text-3xl">{card.emoji}</span>
                <span className="text-[10px] font-medium text-orange-700 text-center">{card.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── DONE ──────────────────────────────────────────────────────────────────
  if (phase === "done") {
    return (
      <div className="flex flex-col items-center justify-center py-8 gap-4 select-none" dir="rtl">
        <MiniConfetti active={showConfetti} />
        <div className="text-7xl animate-bounce">🏆</div>
        <h3 className="text-2xl font-bold text-green-600">ذاكرة قوية! 🎉</h3>
        <p className="text-sm text-gray-500">طابقت {toAr(rawCards.length)} بطاقة بـ {toAr(attempts)} محاولة</p>
        <Button onClick={handleReset} variant="outline" className="gap-2 mt-2">
          <RotateCcw className="h-4 w-4" /> العب مرة أخرى
        </Button>
      </div>
    );
  }

  // ── PLAY ──────────────────────────────────────────────────────────────────
  return (
    <div className="select-none" dir="rtl">
      <MiniConfetti active={showConfetti} />
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 bg-green-50 border border-green-200 px-3 py-1.5 rounded-full">
          <CheckCircle className="w-4 h-4 text-green-500" />
          <span className="text-sm font-bold text-green-700">{toAr(correctCount)} / {toAr(rawCards.length)}</span>
        </div>
        <div className="flex items-center gap-2 bg-orange-50 border border-orange-200 px-3 py-1.5 rounded-full">
          <span className="text-xs text-orange-600">محاولات: {toAr(attempts)}</span>
        </div>
        <Button onClick={handleReset} variant="ghost" size="sm">
          <RotateCcw className="h-3 w-3" />
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4 text-center">
        <p className="text-xs text-blue-700 font-medium">
          <EyeOff className="w-3 h-3 inline ml-1" />
          اضغط على بطاقة في الصف الثاني ثم اختر مكانها في الصف الأول
        </p>
      </div>

      {/* Row 1 - hidden */}
      <div className="mb-5">
        <p className="text-xs font-bold text-center text-purple-600 mb-2">الصف الأول (مخفي)</p>
        <div className="flex gap-2 justify-center flex-wrap">
          {rawCards.map((card, idx) => {
            const matchedR2Idx = Object.entries(selected).find(
              ([r2i, r1i]) => Number(r1i) === idx && feedback[Number(r2i)] === "correct"
            )?.[0];
            const isMatched = matchedR2Idx !== undefined;
            const canClick = activeRow2 !== null && !isMatched;
            return (
              <button
                key={card.id}
                onClick={() => handleRow1Click(idx)}
                disabled={!canClick}
                className={`flex flex-col items-center gap-1 rounded-2xl p-2 min-w-[60px] border-2 transition-all duration-200 ${
                  isMatched
                    ? "bg-green-100 border-green-400 scale-105"
                    : canClick
                    ? "bg-white border-purple-400 hover:bg-purple-50 hover:scale-105 cursor-pointer shadow-md"
                    : "bg-gray-100 border-gray-200 cursor-not-allowed opacity-60"
                }`}
              >
                {isMatched ? (
                  <>
                    <span className="text-3xl">{card.emoji}</span>
                    <span className="text-[10px] font-medium text-green-700 text-center">{card.label}</span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </>
                ) : (
                  <>
                    <span className="text-3xl">❓</span>
                    <span className="text-xs font-bold text-gray-400">{toAr(idx + 1)}</span>
                  </>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Row 2 - shuffled */}
      <div className="mb-4">
        <p className="text-xs font-bold text-center text-orange-600 mb-2">الصف الثاني (اضغط لاختيار)</p>
        <div className="flex gap-2 justify-center flex-wrap">
          {row2.map((card, r2Idx) => {
            const fb = feedback[r2Idx];
            const isActive = activeRow2 === r2Idx;
            const isShaking = shakeRow2 === r2Idx;
            return (
              <button
                key={card.id}
                onClick={() => handleRow2Click(r2Idx)}
                disabled={fb === "correct"}
                className={`flex flex-col items-center gap-1 rounded-2xl p-2 min-w-[60px] border-2 transition-all duration-200 ${
                  fb === "correct"
                    ? "bg-green-100 border-green-400 opacity-60 cursor-not-allowed"
                    : fb === "wrong" || isShaking
                    ? "bg-red-100 border-red-400 animate-shake-inline"
                    : isActive
                    ? "bg-purple-200 border-purple-500 scale-110 shadow-lg"
                    : "bg-orange-50 border-orange-200 hover:bg-orange-100 hover:scale-105 cursor-pointer"
                }`}
              >
                <span className="text-3xl">{card.emoji}</span>
                <span className="text-[10px] font-medium text-center text-gray-700">{card.label}</span>
                {fb === "correct" && <CheckCircle className="w-4 h-4 text-green-500" />}
                {(fb === "wrong" || isShaking) && <span className="text-xs text-red-500 font-bold">✗</span>}
              </button>
            );
          })}
        </div>
      </div>

      {activeRow2 !== null && (
        <div className="bg-purple-100 border border-purple-300 rounded-xl p-2 text-center">
          <p className="text-xs text-purple-700 font-bold">
            اخترت: {row2[activeRow2].emoji} {row2[activeRow2].label} — الآن اضغط على مكانها في الصف الأول ↑
          </p>
        </div>
      )}
    </div>
  );
}
