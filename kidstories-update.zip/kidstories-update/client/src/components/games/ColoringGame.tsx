import { useState, useCallback } from "react";
import { RotateCcw, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toAr } from "@/lib/arabicNumerals";

function playCorrectTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = "sine"; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.3, ctx.currentTime + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.3);
      osc.start(ctx.currentTime + i * 0.12);
      osc.stop(ctx.currentTime + i * 0.12 + 0.35);
    });
  } catch {}
}
function playWrongTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.4);
  } catch {}
}

export interface ColoringGameData {
  id: string;
  title: string;
  description: string;
  /** نوع لعبة التلوين */
  type: "color_by_number" | "color_by_name" | "match_color" | "color_pattern";
  rounds: {
    id: string;
    prompt: string;
    /** الشيء المراد تلوينه */
    subject: { emoji: string; label: string };
    /** الألوان المتاحة */
    colorOptions: { name: string; hex: string; emoji: string }[];
    /** الإجابة الصحيحة (اسم اللون) */
    correctColor: string;
    explanation: string;
  }[];
}

interface Props {
  game: ColoringGameData;
  onComplete: (score: number) => void;
}

export function ColoringGame({ game, onComplete }: Props) {
  const [currentRound, setCurrentRound] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [done, setDone] = useState(false);
  const [shake, setShake] = useState<string | null>(null);
  const [paintedColor, setPaintedColor] = useState<string | null>(null);

  const round = game.rounds[currentRound];

  const handleSelectColor = useCallback((colorName: string, colorHex: string) => {
    if (answered) return;
    setSelected(colorName);
    setAnswered(true);
    setPaintedColor(colorHex);

    const isCorrect = colorName === round.correctColor;
    if (isCorrect) {
      playCorrectTone();
      setCorrect((c) => c + 1);
    } else {
      playWrongTone();
      setShake(colorName);
      setTimeout(() => setShake(null), 500);
    }

    setTimeout(() => {
      if (currentRound < game.rounds.length - 1) {
        setCurrentRound((r) => r + 1);
        setSelected(null);
        setAnswered(false);
        setPaintedColor(null);
      } else {
        setDone(true);
        const score = Math.round(((correct + (isCorrect ? 1 : 0)) / game.rounds.length) * 100);
        onComplete(score);
      }
    }, 1500);
  }, [answered, round, currentRound, game.rounds.length, correct, onComplete]);

  const reset = () => {
    setCurrentRound(0);
    setSelected(null);
    setAnswered(false);
    setCorrect(0);
    setDone(false);
    setPaintedColor(null);
  };

  if (done) {
    const score = Math.round((correct / game.rounds.length) * 100);
    return (
      <div className="text-center py-8">
        <div className="text-6xl mb-4">{score >= 70 ? "🎨" : "🖌️"}</div>
        <h3 className="text-2xl font-bold text-foreground mb-2">
          {score >= 70 ? "رائع! أنت فنان موهوب!" : "جميل! تدرب أكثر على الألوان!"}
        </h3>
        <p className="text-muted-foreground mb-4">
          أجبت على {toAr(correct)} من {toAr(game.rounds.length)} بشكل صحيح
        </p>
        <div className="text-4xl font-bold text-primary mb-6">{score}%</div>
        <Button onClick={reset} variant="outline" className="gap-2 rounded-2xl">
          <RotateCcw className="h-4 w-4" />
          العب مجدداً
        </Button>
      </div>
    );
  }

  return (
    <div dir="rtl">
      {/* Progress */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-muted-foreground">جولة {currentRound + 1} من {game.rounds.length}</span>
        <div className="flex gap-1">
          {game.rounds.map((_, i) => (
            <div
              key={i}
              className={`h-2 w-6 rounded-full transition-colors ${
                i < currentRound ? "bg-green-400" : i === currentRound ? "bg-primary" : "bg-muted"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Subject to color */}
      <div className="text-center mb-6">
        <p className="text-base font-bold text-foreground mb-4">{round.prompt}</p>
        <div
          className="inline-flex flex-col items-center justify-center w-36 h-36 rounded-3xl border-4 border-dashed border-border shadow-lg transition-all duration-500 mx-auto"
          style={{ backgroundColor: paintedColor || "#f9fafb", borderColor: paintedColor ? paintedColor : undefined }}
        >
          <span className="text-6xl">{round.subject.emoji}</span>
          <span className="text-sm font-bold text-gray-700 mt-1">{round.subject.label}</span>
        </div>
        {!answered && (
          <p className="text-xs text-muted-foreground mt-2">اختر اللون المناسب من الأسفل</p>
        )}
      </div>

      {/* Color palette */}
      <div className="grid grid-cols-3 gap-3">
        {round.colorOptions.map((color) => {
          const isCorrect = color.name === round.correctColor;
          const isSelected = selected === color.name;
          let cls = "flex flex-col items-center p-3 rounded-2xl border-2 cursor-pointer transition-all ";
          if (answered) {
            if (isCorrect) cls += "border-green-400 bg-green-50 scale-105";
            else if (isSelected) cls += "border-red-400 bg-red-50";
            else cls += "border-border bg-muted/30 opacity-50";
          } else {
            cls += "border-border bg-white hover:scale-105 hover:shadow-md";
          }
          if (shake === color.name) cls += " animate-shake";

          return (
            <button
              key={color.name}
              className={cls}
              onClick={() => handleSelectColor(color.name, color.hex)}
            >
              <div
                className="w-10 h-10 rounded-full border-2 border-white shadow-md mb-1"
                style={{ backgroundColor: color.hex }}
              />
              <span className="text-lg">{color.emoji}</span>
              <span className="text-xs font-bold text-foreground mt-0.5">{color.name}</span>
              {answered && isCorrect && <CheckCircle className="h-3 w-3 text-green-500 mt-0.5" />}
            </button>
          );
        })}
      </div>

      {/* Explanation */}
      {answered && (
        <div className={`mt-4 p-3 rounded-2xl text-sm font-medium ${
          selected === round.correctColor ? "bg-green-50 text-green-700" : "bg-orange-50 text-orange-700"
        }`}>
          {selected === round.correctColor ? "✅ " : "💡 "}
          {round.explanation}
        </div>
      )}
    </div>
  );
}
