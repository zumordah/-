import { useState } from "react";
import { RotateCcw, CheckCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

// تأثيرات صوتية
function playCorrectTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = "sine"; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.3, ctx.currentTime + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.3);
      osc.start(ctx.currentTime + i * 0.12); osc.stop(ctx.currentTime + i * 0.12 + 0.35);
    });
  } catch {}
}
function playWrongTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.4);
  } catch {}
}

export interface SequencingGameData {
  id: string;
  title: string;
  description: string;
  items: { id: string; emoji: string; label: string; correctOrder: number }[];
}

interface Props {
  game: SequencingGameData;
  onComplete: (score: number) => void;
}

// نظام النقر: اضغط على عنصر من البنك ثم اضغط على خانة في الترتيب
export function SequencingGame({ game, onComplete }: Props) {
  const totalSlots = game.items.length;

  const [slots, setSlots] = useState<(string | null)[]>(() => Array(totalSlots).fill(null));
  const [bankItems] = useState(() => [...game.items].sort(() => Math.random() - 0.5));
  const [selectedFromBank, setSelectedFromBank] = useState<string | null>(null);
  const [completed, setCompleted] = useState(false);
  const [checked, setChecked] = useState(false);
  const [wrongSlots, setWrongSlots] = useState<Set<number>>(new Set());
  const [showConfetti, setShowConfetti] = useState(false);

  const placedIds = new Set(slots.filter(Boolean) as string[]);

  const handleBankClick = (itemId: string) => {
    if (placedIds.has(itemId)) return;
    setSelectedFromBank(selectedFromBank === itemId ? null : itemId);
    setChecked(false);
  };

  const handleSlotClick = (slotIndex: number) => {
    if (!selectedFromBank) {
      if (slots[slotIndex]) {
        const newSlots = [...slots];
        newSlots[slotIndex] = null;
        setSlots(newSlots);
        setChecked(false);
      }
      return;
    }
    const newSlots = [...slots];
    const prevSlot = newSlots.findIndex(s => s === selectedFromBank);
    if (prevSlot !== -1) newSlots[prevSlot] = null;
    newSlots[slotIndex] = selectedFromBank;
    setSlots(newSlots);
    setSelectedFromBank(null);
    setChecked(false);
  };

  const handleCheck = () => {
    if (slots.some(s => s === null)) return;
    setChecked(true);
    const wrong = new Set<number>();
    let allCorrect = true;
    slots.forEach((itemId, index) => {
      const item = game.items.find(i => i.id === itemId);
      if (item?.correctOrder !== index + 1) {
        wrong.add(index);
        allCorrect = false;
      }
    });
    setWrongSlots(wrong);
    if (allCorrect) {
      playCorrectTone();
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 1800);
      setCompleted(true);
      setTimeout(() => onComplete(100), 800);
    } else {
      playWrongTone();
    }
  };

  const handleReset = () => {
    setSlots(Array(totalSlots).fill(null));
    setSelectedFromBank(null);
    setCompleted(false);
    setChecked(false);
    setWrongSlots(new Set());
    setShowConfetti(false);
  };

  const getSlotStyle = (slotIndex: number) => {
    const itemId = slots[slotIndex];
    if (!itemId) {
      if (selectedFromBank) return "border-dashed border-purple-400 bg-purple-50 hover:border-purple-600 hover:bg-purple-100 cursor-pointer";
      return "border-dashed border-gray-300 bg-gray-50";
    }
    if (checked && wrongSlots.has(slotIndex)) return "border-red-400 bg-red-50 animate-shake-inline";
    if (checked && !wrongSlots.has(slotIndex)) return "border-green-500 bg-green-50";
    return "border-blue-400 bg-blue-50";
  };

  if (completed) {
    return (
      <div className="flex flex-col items-center justify-center py-10 gap-4" dir="rtl">
        {showConfetti && (
          <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} style={{
                position: "absolute", top: "-20px",
                left: `${5 + (i * 5) % 90}%`,
                width: 10, height: 10,
                background: ["#f59e0b","#10b981","#6366f1","#ec4899","#3b82f6"][i % 5],
                borderRadius: i % 2 === 0 ? "50%" : "2px",
                animation: `confettiFall 1.5s ease-in ${(i * 0.06).toFixed(2)}s forwards`,
              }} />
            ))}
          </div>
        )}
        <div className="text-6xl animate-bounce">⭐</div>
        <h3 className="text-2xl font-bold text-green-600">ممتاز! رتّبت كل شيء بشكل صحيح!</h3>
        <Button onClick={handleReset} variant="outline" className="gap-2">
          <RotateCcw className="h-4 w-4" /> العب مرة أخرى
        </Button>
      </div>
    );
  }

  return (
    <div className="select-none" dir="rtl">
      <div className="text-center mb-4">
        <p className="text-sm text-gray-500">{game.description}</p>
        <div className="mt-2 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2">
          <p className="text-xs text-blue-700 font-medium">
            👆 اضغط على عنصر من الأسفل ثم اضغط على الخانة المناسبة في الترتيب
          </p>
        </div>
      </div>

      {/* خانات الترتيب */}
      <div className="flex gap-2 items-center justify-center flex-wrap mb-6">
        {slots.map((itemId, index) => {
          const item = game.items.find(i => i.id === itemId);
          return (
            <div key={index} className="flex items-center gap-1">
              <button
                onClick={() => handleSlotClick(index)}
                className={`flex flex-col items-center justify-center gap-1 p-2 rounded-2xl border-2 transition-all duration-200 min-w-[64px] min-h-[80px] ${getSlotStyle(index)}`}
              >
                <span className="text-xs font-bold text-gray-400 bg-gray-100 rounded-full w-5 h-5 flex items-center justify-center">{index + 1}</span>
                {item ? (
                  <>
                    <span className="text-3xl">{item.emoji}</span>
                    <span className="text-xs font-medium text-center leading-tight">{item.label}</span>
                    {checked && !wrongSlots.has(index) && <CheckCircle className="h-3 w-3 text-green-500" />}
                  </>
                ) : (
                  <span className="text-2xl text-gray-300">?</span>
                )}
              </button>
              {index < totalSlots - 1 && (
                <ArrowLeft className="h-4 w-4 text-gray-300 flex-shrink-0" />
              )}
            </div>
          );
        })}
      </div>

      {/* بنك العناصر */}
      <div className="bg-gray-50 rounded-2xl p-3 mb-4">
        <p className="text-xs text-center text-gray-500 font-medium mb-2">العناصر — اضغط لاختيار</p>
        <div className="flex gap-2 flex-wrap justify-center">
          {bankItems.map((item) => {
            const isPlaced = placedIds.has(item.id);
            const isSelected = selectedFromBank === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleBankClick(item.id)}
                disabled={isPlaced}
                className={`flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all duration-200 min-w-[60px] ${
                  isPlaced
                    ? "opacity-30 cursor-default border-gray-200 bg-white"
                    : isSelected
                    ? "border-purple-500 bg-purple-100 scale-110 shadow-md ring-2 ring-purple-300"
                    : "border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50 hover:scale-105 cursor-pointer"
                }`}
              >
                <span className="text-2xl">{item.emoji}</span>
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {selectedFromBank && (
        <div className="mb-3 bg-purple-100 border border-purple-300 rounded-xl p-2 text-center">
          <p className="text-xs text-purple-700 font-bold">
            اخترت: {game.items.find(i => i.id === selectedFromBank)?.emoji} {game.items.find(i => i.id === selectedFromBank)?.label} — اضغط على الخانة المناسبة ↑
          </p>
        </div>
      )}

      {checked && wrongSlots.size > 0 && (
        <div className="mb-3 bg-orange-50 border border-orange-200 rounded-xl p-2 text-center">
          <p className="text-sm text-orange-600 font-medium">الترتيب غير صحيح في بعض الخانات! حاول مرة أخرى 🔄</p>
        </div>
      )}

      <div className="flex gap-2 justify-center">
        <Button
          onClick={handleCheck}
          disabled={slots.some(s => s === null)}
          className="gap-2"
        >
          <CheckCircle className="h-4 w-4" /> تحقق من الترتيب
        </Button>
        <Button onClick={handleReset} variant="ghost" size="sm" className="gap-1 text-muted-foreground">
          <RotateCcw className="h-3 w-3" /> إعادة
        </Button>
      </div>
    </div>
  );
}
