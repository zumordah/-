import { useState } from "react";
import { RotateCcw, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

// تأثيرات صوتية
function playCorrectTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = "sine"; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.3, ctx.currentTime + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.3);
      osc.start(ctx.currentTime + i * 0.12); osc.stop(ctx.currentTime + i * 0.12 + 0.35);
    });
  } catch {}
}
function playWrongTone() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.4);
  } catch {}
}

export interface SortingGameData {
  id: string;
  title: string;
  categories: { id: string; label: string; emoji: string; color: string }[];
  items: { id: string; emoji: string; label: string; correctCategoryId: string }[];
}

interface Props {
  game: SortingGameData;
  onComplete: (score: number) => void;
}

// نظام النقر: اضغط على عنصر ثم اضغط على الفئة المناسبة
export function SortingGame({ game, onComplete }: Props) {
  const [placements, setPlacements] = useState<Record<string, string>>({}); // itemId -> categoryId
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [completed, setCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [checked, setChecked] = useState(false);
  const [wrongItems, setWrongItems] = useState<Set<string>>(new Set());
  const [showConfetti, setShowConfetti] = useState(false);

  const unplacedItems = game.items.filter((item) => !placements[item.id]);

  const handleItemClick = (itemId: string) => {
    setSelectedItem(selectedItem === itemId ? null : itemId);
    setChecked(false);
  };

  const handleCategoryClick = (categoryId: string) => {
    if (!selectedItem) return;
    const newPlacements = { ...placements, [selectedItem]: categoryId };
    setPlacements(newPlacements);
    setSelectedItem(null);
    setChecked(false);
  };

  const handlePlacedItemClick = (itemId: string) => {
    // إزالة العنصر من الفئة وإعادته للبنك
    const newPlacements = { ...placements };
    delete newPlacements[itemId];
    setPlacements(newPlacements);
    setChecked(false);
  };

  const handleCheck = () => {
    setChecked(true);
    const wrong = new Set<string>();
    let correct = 0;
    game.items.forEach((item) => {
      if (placements[item.id] === item.correctCategoryId) {
        correct++;
      } else {
        wrong.add(item.id);
      }
    });
    setWrongItems(wrong);
    const total = game.items.length;
    const finalScore = Math.round((correct / total) * 100);
    setScore(finalScore);
    if (correct === total) {
      playCorrectTone();
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 1800);
      setCompleted(true);
      setTimeout(() => onComplete(finalScore), 800);
    } else {
      playWrongTone();
    }
  };

  const handleReset = () => {
    setPlacements({});
    setSelectedItem(null);
    setCompleted(false);
    setScore(0);
    setChecked(false);
    setWrongItems(new Set());
    setShowConfetti(false);
  };

  const getItemStyle = (itemId: string) => {
    if (!checked) return "bg-white border-gray-200";
    const item = game.items.find((i) => i.id === itemId);
    if (!item) return "bg-white border-gray-200";
    return placements[itemId] === item.correctCategoryId
      ? "bg-green-50 border-green-500"
      : "bg-red-50 border-red-400 animate-shake-inline";
  };

  if (completed) {
    return (
      <div className="flex flex-col items-center justify-center py-10 gap-4" dir="rtl">
        {showConfetti && (
          <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} style={{
                position: "absolute", top: "-20px",
                left: `${5 + (i * 5) % 90}%`,
                width: 10, height: 10,
                background: ["#f59e0b","#10b981","#6366f1","#ec4899","#3b82f6"][i % 5],
                borderRadius: i % 2 === 0 ? "50%" : "2px",
                animation: `confettiFall 1.5s ease-in ${(i * 0.06).toFixed(2)}s forwards`,
              }} />
            ))}
          </div>
        )}
        <div className="text-6xl animate-bounce">🎉</div>
        <h3 className="text-2xl font-bold text-green-600">رائع! صنّفت كل شيء بشكل صحيح!</h3>
        <p className="text-lg text-muted-foreground">النتيجة: {score} نقطة</p>
        <Button onClick={handleReset} variant="outline" className="gap-2">
          <RotateCcw className="h-4 w-4" /> العب مرة أخرى
        </Button>
      </div>
    );
  }

  return (
    <div className="select-none" dir="rtl">
      <div className="text-center mb-3">
        <div className="bg-blue-50 border border-blue-200 rounded-xl px-3 py-2">
          <p className="text-xs text-blue-700 font-medium">
            👆 اضغط على عنصر ثم اضغط على المجموعة المناسبة لوضعه فيها
          </p>
        </div>
      </div>

      {/* بنك العناصر */}
      <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-2xl min-h-[60px] mb-4 border-2 border-dashed border-gray-300">
        {unplacedItems.length === 0 ? (
          <p className="text-xs text-gray-400 m-auto">تم وضع جميع العناصر ✅</p>
        ) : (
          unplacedItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`flex items-center gap-1 px-3 py-2 rounded-xl border-2 transition-all duration-200 ${
                selectedItem === item.id
                  ? "border-purple-500 bg-purple-100 scale-110 shadow-md ring-2 ring-purple-300"
                  : "border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50 hover:scale-105 cursor-pointer"
              }`}
            >
              <span className="text-xl">{item.emoji}</span>
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))
        )}
      </div>

      {selectedItem && (
        <div className="mb-3 bg-purple-100 border border-purple-300 rounded-xl p-2 text-center">
          <p className="text-xs text-purple-700 font-bold">
            اخترت: {game.items.find(i => i.id === selectedItem)?.emoji} {game.items.find(i => i.id === selectedItem)?.label} — اضغط على المجموعة المناسبة ↓
          </p>
        </div>
      )}

      {/* فئات التصنيف */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {game.categories.map((cat) => {
          const itemsInCat = game.items.filter((item) => placements[item.id] === cat.id);
          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              disabled={!selectedItem}
              className={`rounded-2xl p-3 border-2 min-h-[90px] text-right transition-all duration-200 ${
                selectedItem
                  ? `${cat.color} border-solid hover:scale-105 hover:shadow-md cursor-pointer ring-2 ring-transparent hover:ring-purple-400`
                  : `${cat.color} border-dashed cursor-default`
              }`}
            >
              <p className="text-sm font-bold text-center mb-2">
                {cat.emoji} {cat.label}
              </p>
              <div className="flex flex-wrap gap-1 justify-center">
                {itemsInCat.map((item) => (
                  <button
                    key={item.id}
                    onClick={(e) => { e.stopPropagation(); handlePlacedItemClick(item.id); }}
                    className={`flex items-center gap-1 px-2 py-1 rounded-xl border-2 text-xs transition-all hover:opacity-70 ${getItemStyle(item.id)}`}
                    title="اضغط لإزالة العنصر"
                  >
                    <span>{item.emoji}</span>
                    <span>{item.label}</span>
                    {checked && placements[item.id] === item.correctCategoryId && (
                      <CheckCircle className="h-3 w-3 text-green-500" />
                    )}
                  </button>
                ))}
              </div>
            </button>
          );
        })}
      </div>

      {checked && wrongItems.size > 0 && (
        <div className="mb-3 bg-orange-50 border border-orange-200 rounded-xl p-2 text-center">
          <p className="text-sm text-orange-600 font-medium">بعض العناصر في المكان الخطأ! حاول مرة أخرى 🔄</p>
        </div>
      )}

      <div className="flex gap-2 justify-center">
        {Object.keys(placements).length === game.items.length && (
          <Button onClick={handleCheck} className="gap-2">
            <CheckCircle className="h-4 w-4" /> تحقق من الإجابات
          </Button>
        )}
        <Button onClick={handleReset} variant="ghost" size="sm" className="gap-1 text-muted-foreground">
          <RotateCcw className="h-3 w-3" /> إعادة
        </Button>
      </div>
    </div>
  );
}
