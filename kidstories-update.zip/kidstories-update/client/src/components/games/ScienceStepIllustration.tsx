import type { ReactElement } from 'react';

/**
 * ScienceStepIllustration
 * صور SVG مبسطة توضيحية لخطوات التجارب العلمية
 * كل صورة تشرح الخطوة بشكل مرئي واضح للأطفال
 */

interface Props {
  experimentId: string;
  stepId: string;
  className?: string;
}

// ── صور SVG مبسطة لكل خطوة ──────────────────────────────────────────────────

const illustrations: Record<string, Record<string, ReactElement>> = {

  // ─── الطفو والغرق ───────────────────────────────────────────────────────────
  "sci-water-float": {
    s1: ( // احضر وعاء وأضف ماء
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* وعاء */}
        <rect x="20" y="45" width="80" height="45" rx="6" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2.5"/>
        {/* ماء */}
        <rect x="22" y="55" width="76" height="33" rx="4" fill="#bfdbfe" opacity="0.8"/>
        {/* موجات الماء */}
        <path d="M30 62 Q45 58 60 62 Q75 66 90 62" stroke="#60a5fa" strokeWidth="2" fill="none"/>
        {/* يد تصب ماء */}
        <ellipse cx="60" cy="30" rx="12" ry="8" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M60 38 L60 48" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round"/>
        {/* قطرات ماء */}
        <circle cx="55" cy="44" r="2" fill="#60a5fa"/>
        <circle cx="65" cy="46" r="2" fill="#60a5fa"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">أضف الماء</text>
      </svg>
    ),
    s2: ( // ضع الأشياء في الماء
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* وعاء بماء */}
        <rect x="15" y="40" width="90" height="50" rx="6" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="17" y="50" width="86" height="38" rx="4" fill="#bfdbfe" opacity="0.8"/>
        {/* كرة طافية */}
        <circle cx="40" cy="52" r="10" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="40" y="56" textAnchor="middle" fontSize="8" fill="#92400e">🏀</text>
        {/* حجر غارق */}
        <ellipse cx="80" cy="78" rx="9" ry="7" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        {/* سهم للأسفل */}
        <path d="M80 60 L80 70" stroke="#374151" strokeWidth="2" strokeLinecap="round"/>
        <path d="M76 67 L80 72 L84 67" stroke="#374151" strokeWidth="2" fill="none"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">ضع الأشياء</text>
      </svg>
    ),
    s3: ( // لاحظ ماذا يطفو
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* وعاء */}
        <rect x="10" y="38" width="100" height="52" rx="6" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="12" y="48" width="96" height="40" rx="4" fill="#bfdbfe" opacity="0.8"/>
        {/* أشياء طافية */}
        <circle cx="35" cy="50" r="8" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <rect x="55" y="44" width="14" height="10" rx="2" fill="#86efac" stroke="#22c55e" strokeWidth="2"/>
        {/* أشياء غارقة */}
        <ellipse cx="85" cy="78" rx="8" ry="6" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        {/* عين تراقب */}
        <ellipse cx="60" cy="18" rx="14" ry="10" fill="white" stroke="#6366f1" strokeWidth="2"/>
        <circle cx="60" cy="18" r="5" fill="#6366f1"/>
        <circle cx="62" cy="16" r="2" fill="white"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">لاحظ وراقب</text>
      </svg>
    ),
    s4: ( // صنّف الأشياء
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مجموعة طافية */}
        <rect x="5" y="15" width="50" height="40" rx="8" fill="#dcfce7" stroke="#22c55e" strokeWidth="2"/>
        <text x="30" y="28" textAnchor="middle" fontSize="8" fill="#166534" fontWeight="bold">يطفو ⬆️</text>
        <circle cx="20" cy="42" r="7" fill="#fbbf24"/>
        <rect x="32" y="36" width="12" height="9" rx="2" fill="#86efac"/>
        {/* مجموعة غارقة */}
        <rect x="65" y="15" width="50" height="40" rx="8" fill="#fee2e2" stroke="#ef4444" strokeWidth="2"/>
        <text x="90" y="28" textAnchor="middle" fontSize="8" fill="#991b1b" fontWeight="bold">يغرق ⬇️</text>
        <ellipse cx="80" cy="42" rx="8" ry="6" fill="#6b7280"/>
        <rect x="92" y="36" width="10" height="10" rx="2" fill="#9ca3af"/>
        {/* سهم تصنيف */}
        <path d="M60 60 L60 75" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">صنّف الأشياء</text>
      </svg>
    ),
    s5: ( // اكتب نتائجك
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ورقة */}
        <rect x="25" y="10" width="70" height="75" rx="6" fill="white" stroke="#d1d5db" strokeWidth="2"/>
        {/* خطوط الكتابة */}
        <line x1="35" y1="28" x2="85" y2="28" stroke="#e5e7eb" strokeWidth="1.5"/>
        <line x1="35" y1="38" x2="85" y2="38" stroke="#e5e7eb" strokeWidth="1.5"/>
        <line x1="35" y1="48" x2="85" y2="48" stroke="#e5e7eb" strokeWidth="1.5"/>
        <line x1="35" y1="58" x2="85" y2="58" stroke="#e5e7eb" strokeWidth="1.5"/>
        {/* ✓ و ✗ */}
        <text x="38" y="37" fontSize="10" fill="#22c55e">✓ يطفو</text>
        <text x="38" y="47" fontSize="10" fill="#ef4444">✗ يغرق</text>
        {/* قلم */}
        <rect x="75" y="55" width="6" height="22" rx="2" fill="#fbbf24" stroke="#f59e0b" strokeWidth="1.5" transform="rotate(-20 78 66)"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">سجّل النتائج</text>
      </svg>
    ),
  },

  // ─── نمو النباتات ────────────────────────────────────────────────────────────
  "sci-plant-growth": {
    s1: ( // احضر بذرة ووعاء
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* وعاء */}
        <path d="M35 55 L25 90 L95 90 L85 55 Z" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <rect x="28" y="50" width="64" height="10" rx="4" fill="#b45309" stroke="#92400e" strokeWidth="2"/>
        {/* تربة */}
        <ellipse cx="60" cy="60" rx="28" ry="8" fill="#78350f"/>
        {/* بذرة */}
        <ellipse cx="60" cy="52" rx="8" ry="5" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="60" y="55" textAnchor="middle" fontSize="7" fill="#92400e">بذرة</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#166534" fontWeight="bold">احضر البذرة</text>
      </svg>
    ),
    s2: ( // ضع التربة وازرع
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* وعاء */}
        <path d="M30 52 L22 88 L98 88 L90 52 Z" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <rect x="24" y="47" width="72" height="10" rx="4" fill="#b45309" stroke="#92400e" strokeWidth="2"/>
        {/* تربة */}
        <ellipse cx="60" cy="57" rx="32" ry="10" fill="#78350f"/>
        {/* يد تزرع */}
        <ellipse cx="60" cy="30" rx="10" ry="7" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M55 36 L55 48" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M65 36 L65 48" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#166534" fontWeight="bold">ازرع البذرة</text>
      </svg>
    ),
    s3: ( // اسقِ النبتة
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* وعاء */}
        <path d="M30 55 L22 90 L98 90 L90 55 Z" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <rect x="24" y="50" width="72" height="10" rx="4" fill="#b45309" stroke="#92400e" strokeWidth="2"/>
        {/* تربة */}
        <ellipse cx="60" cy="60" rx="32" ry="10" fill="#78350f"/>
        {/* نبتة صغيرة */}
        <path d="M60 60 L60 42" stroke="#22c55e" strokeWidth="3" strokeLinecap="round"/>
        <ellipse cx="52" cy="46" rx="8" ry="5" fill="#86efac" transform="rotate(-30 52 46)"/>
        <ellipse cx="68" cy="44" rx="8" ry="5" fill="#86efac" transform="rotate(30 68 44)"/>
        {/* إبريق ري */}
        <ellipse cx="90" cy="25" rx="12" ry="9" fill="#60a5fa" stroke="#3b82f6" strokeWidth="2"/>
        <path d="M78 25 L70 35" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round"/>
        {/* قطرات */}
        <circle cx="65" cy="38" r="2" fill="#60a5fa"/>
        <circle cx="60" cy="42" r="2" fill="#60a5fa"/>
        <circle cx="70" cy="40" r="2" fill="#60a5fa"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#166534" fontWeight="bold">اسقِ النبتة</text>
      </svg>
    ),
    s4: ( // ضع في الشمس
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* شمس */}
        <circle cx="25" cy="22" r="14" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        {/* أشعة */}
        {[0,45,90,135,180,225,270,315].map((angle, i) => (
          <line key={i}
            x1={25 + 16 * Math.cos(angle * Math.PI / 180)}
            y1={22 + 16 * Math.sin(angle * Math.PI / 180)}
            x2={25 + 22 * Math.cos(angle * Math.PI / 180)}
            y2={22 + 22 * Math.sin(angle * Math.PI / 180)}
            stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round"
          />
        ))}
        {/* وعاء */}
        <path d="M40 62 L33 90 L87 90 L80 62 Z" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <rect x="35" y="57" width="50" height="9" rx="4" fill="#b45309" stroke="#92400e" strokeWidth="2"/>
        {/* نبتة تنمو */}
        <path d="M60 62 L60 35" stroke="#22c55e" strokeWidth="3" strokeLinecap="round"/>
        <ellipse cx="50" cy="44" rx="10" ry="6" fill="#86efac" transform="rotate(-25 50 44)"/>
        <ellipse cx="70" cy="40" rx="10" ry="6" fill="#86efac" transform="rotate(25 70 40)"/>
        <ellipse cx="60" cy="32" rx="8" ry="5" fill="#4ade80"/>
        {/* سهم شمس للنبتة */}
        <path d="M38 28 L50 38" stroke="#fbbf24" strokeWidth="2" strokeDasharray="3 2"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#166534" fontWeight="bold">ضعها في الشمس</text>
      </svg>
    ),
    s5: ( // راقب النمو يومياً
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* 3 مراحل نمو */}
        {/* مرحلة 1 - صغيرة */}
        <path d="M20 80 L15 90 L35 90 L30 80 Z" fill="#d97706" stroke="#92400e" strokeWidth="1.5"/>
        <path d="M25 80 L25 70" stroke="#22c55e" strokeWidth="2" strokeLinecap="round"/>
        <ellipse cx="22" cy="72" rx="4" ry="3" fill="#86efac" transform="rotate(-20 22 72)"/>
        {/* مرحلة 2 - متوسطة */}
        <path d="M48" y="75" width="24" height="15" rx="3" fill="#d97706" stroke="#92400e" strokeWidth="1.5"/>
        <path d="M48 75 L43 90 L63 90 L58 75 Z" fill="#d97706" stroke="#92400e" strokeWidth="1.5"/>
        <path d="M53 75 L53 58" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round"/>
        <ellipse cx="47" cy="65" rx="7" ry="4" fill="#86efac" transform="rotate(-25 47 65)"/>
        <ellipse cx="59" cy="62" rx="7" ry="4" fill="#86efac" transform="rotate(25 59 62)"/>
        {/* مرحلة 3 - كبيرة */}
        <path d="M78 68 L73 90 L97 90 L92 68 Z" fill="#d97706" stroke="#92400e" strokeWidth="1.5"/>
        <path d="M85 68 L85 42" stroke="#22c55e" strokeWidth="3" strokeLinecap="round"/>
        <ellipse cx="76" cy="55" rx="10" ry="6" fill="#4ade80" transform="rotate(-25 76 55)"/>
        <ellipse cx="94" cy="50" rx="10" ry="6" fill="#4ade80" transform="rotate(25 94 50)"/>
        <ellipse cx="85" cy="38" rx="8" ry="5" fill="#16a34a"/>
        {/* سهم تقدم */}
        <path d="M37 82 L45 82" stroke="#6366f1" strokeWidth="2" strokeLinecap="round"/>
        <path d="M65 78 L73 78" stroke="#6366f1" strokeWidth="2" strokeLinecap="round"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#166534" fontWeight="bold">راقب النمو يومياً</text>
      </svg>
    ),
  },

  // ─── المغناطيس ──────────────────────────────────────────────────────────────
  "sci-magnet": {
    s1: ( // احضر مغناطيس وأشياء
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مغناطيس حدوة */}
        <path d="M35 20 Q35 55 50 60 Q60 65 70 60 Q85 55 85 20" fill="none" stroke="#ef4444" strokeWidth="8" strokeLinecap="round"/>
        <rect x="28" y="15" width="14" height="12" rx="3" fill="#ef4444"/>
        <rect x="78" y="15" width="14" height="12" rx="3" fill="#3b82f6"/>
        <text x="35" y="24" textAnchor="middle" fontSize="7" fill="white" fontWeight="bold">N</text>
        <text x="85" y="24" textAnchor="middle" fontSize="7" fill="white" fontWeight="bold">S</text>
        {/* أشياء متنوعة */}
        <rect x="20" y="75" width="12" height="12" rx="2" fill="#6b7280"/>
        <circle cx="50" cy="80" r="7" fill="#fbbf24"/>
        <rect x="65" y="73" width="8" height="14" rx="2" fill="#ef4444"/>
        <circle cx="90" cy="80" r="7" fill="#86efac"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر المغناطيس</text>
      </svg>
    ),
    s2: ( // اختبر الأشياء
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مغناطيس */}
        <path d="M45 10 Q45 35 55 40 Q60 43 65 40 Q75 35 75 10" fill="none" stroke="#ef4444" strokeWidth="7" strokeLinecap="round"/>
        <rect x="38" y="6" width="14" height="10" rx="3" fill="#ef4444"/>
        <rect x="68" y="6" width="14" height="10" rx="3" fill="#3b82f6"/>
        {/* مسمار يُجذب */}
        <rect x="55" y="42" width="6" height="20" rx="2" fill="#6b7280" stroke="#4b5563" strokeWidth="1.5"/>
        {/* سهم جذب */}
        <path d="M58 58 L58 46" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M54 50 L58 44 L62 50" stroke="#ef4444" strokeWidth="2" fill="none"/>
        {/* كرة خشب لا تُجذب */}
        <circle cx="90" cy="65" r="10" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <text x="90" y="69" textAnchor="middle" fontSize="8" fill="#92400e">✗</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اختبر الأشياء</text>
      </svg>
    ),
    s3: ( // صنّف المعادن
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مجموعة تُجذب */}
        <rect x="5" y="10" width="50" height="40" rx="8" fill="#fee2e2" stroke="#ef4444" strokeWidth="2"/>
        <text x="30" y="23" textAnchor="middle" fontSize="7" fill="#991b1b" fontWeight="bold">يُجذب 🔴</text>
        <rect x="12" y="28" width="10" height="15" rx="2" fill="#6b7280"/>
        <circle cx="32" cy="35" r="7" fill="#9ca3af"/>
        <rect x="42" y="28" width="8" height="15" rx="2" fill="#4b5563"/>
        {/* مجموعة لا تُجذب */}
        <rect x="65" y="10" width="50" height="40" rx="8" fill="#dcfce7" stroke="#22c55e" strokeWidth="2"/>
        <text x="90" y="23" textAnchor="middle" fontSize="7" fill="#166534" fontWeight="bold">لا يُجذب 🟢</text>
        <circle cx="75" cy="35" r="7" fill="#fbbf24"/>
        <rect x="87" y="28" width="10" height="15" rx="2" fill="#86efac"/>
        <circle cx="105" cy="35" r="7" fill="#93c5fd"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">صنّف المعادن</text>
      </svg>
    ),
    s4: ( // اكتشف القطبين
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مغناطيسان متقابلان */}
        {/* الأول */}
        <rect x="8" y="35" width="40" height="20" rx="5" fill="#ef4444" stroke="#dc2626" strokeWidth="2"/>
        <rect x="8" y="35" width="20" height="20" rx="5" fill="#ef4444"/>
        <rect x="28" y="35" width="20" height="20" rx="5" fill="#3b82f6"/>
        <text x="18" y="49" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">N</text>
        <text x="38" y="49" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">S</text>
        {/* الثاني */}
        <rect x="72" y="35" width="40" height="20" rx="5" fill="#3b82f6" stroke="#2563eb" strokeWidth="2"/>
        <rect x="72" y="35" width="20" height="20" rx="5" fill="#3b82f6"/>
        <rect x="92" y="35" width="20" height="20" rx="5" fill="#ef4444"/>
        <text x="82" y="49" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">N</text>
        <text x="102" y="49" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">S</text>
        {/* سهم تنافر */}
        <path d="M50 45 L70 45" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round"/>
        <path d="M55 40 L48 45 L55 50" fill="#f59e0b"/>
        <path d="M65 40 L72 45 L65 50" fill="#f59e0b"/>
        <text x="60" y="75" textAnchor="middle" fontSize="8" fill="#dc2626" fontWeight="bold">تنافر!</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اكتشف القطبين</text>
      </svg>
    ),
    s5: ( // سجّل نتائجك
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ورقة */}
        <rect x="20" y="8" width="80" height="78" rx="6" fill="white" stroke="#d1d5db" strokeWidth="2"/>
        <rect x="20" y="8" width="80" height="18" rx="6" fill="#fee2e2"/>
        <text x="60" y="21" textAnchor="middle" fontSize="8" fill="#991b1b" fontWeight="bold">نتائج المغناطيس</text>
        {/* صفوف النتائج */}
        <text x="30" y="38" fontSize="8" fill="#374151">🔩 مسمار</text>
        <text x="85" y="38" textAnchor="end" fontSize="8" fill="#22c55e">✓ يُجذب</text>
        <text x="30" y="50" fontSize="8" fill="#374151">🪵 خشب</text>
        <text x="85" y="50" textAnchor="end" fontSize="8" fill="#ef4444">✗ لا</text>
        <text x="30" y="62" fontSize="8" fill="#374151">🔑 مفتاح</text>
        <text x="85" y="62" textAnchor="end" fontSize="8" fill="#22c55e">✓ يُجذب</text>
        <text x="30" y="74" fontSize="8" fill="#374151">🧲 قلم</text>
        <text x="85" y="74" textAnchor="end" fontSize="8" fill="#ef4444">✗ لا</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">سجّل النتائج</text>
      </svg>
    ),
  },

  // ─── ضغط الهواء ─────────────────────────────────────────────────────────────
  "sci-air-pressure": {
    s1: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* كوب */}
        <path d="M30 30 L25 85 L95 85 L90 30 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="25" y="25" width="70" height="10" rx="4" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        {/* ماء */}
        <path d="M28 60 L27 83 L93 83 L92 60 Z" fill="#60a5fa" opacity="0.7"/>
        {/* بطاقة */}
        <rect x="22" y="83" width="76" height="10" rx="3" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <text x="60" y="91" textAnchor="middle" fontSize="7" fill="#92400e">بطاقة</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر الكوب</text>
      </svg>
    ),
    s2: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* كوب مملوء */}
        <path d="M30 25 L25 80 L95 80 L90 25 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="25" y="20" width="70" height="10" rx="4" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        <path d="M27 30 L26 78 L94 78 L93 30 Z" fill="#60a5fa" opacity="0.8"/>
        {/* موجات */}
        <path d="M35 45 Q50 41 65 45 Q80 49 90 45" stroke="white" strokeWidth="1.5" fill="none" opacity="0.6"/>
        {/* بطاقة توضع */}
        <rect x="22" y="78" width="76" height="10" rx="3" fill="#fde68a" stroke="#f59e0b" strokeWidth="2.5"/>
        {/* يد */}
        <ellipse cx="60" cy="95" rx="12" ry="7" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">املأ الكوب</text>
      </svg>
    ),
    s3: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* كوب مقلوب */}
        <path d="M30 75 L25 20 L95 20 L90 75 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="25" y="75" width="70" height="10" rx="4" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        {/* ماء داخل الكوب المقلوب */}
        <path d="M27 25 L26 72 L94 72 L93 25 Z" fill="#60a5fa" opacity="0.7"/>
        {/* بطاقة ملتصقة */}
        <rect x="22" y="78" width="76" height="10" rx="3" fill="#fde68a" stroke="#f59e0b" strokeWidth="2.5"/>
        {/* سهم قلب */}
        <path d="M60 90 L60 82" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اقلب الكوب</text>
      </svg>
    ),
    s4: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* كوب مقلوب والبطاقة لا تسقط */}
        <path d="M30 70 L25 15 L95 15 L90 70 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="25" y="70" width="70" height="10" rx="4" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        <path d="M27 20 L26 68 L94 68 L93 20 Z" fill="#60a5fa" opacity="0.7"/>
        {/* بطاقة ثابتة */}
        <rect x="22" y="78" width="76" height="10" rx="3" fill="#fde68a" stroke="#f59e0b" strokeWidth="3"/>
        {/* علامة تعجب */}
        <text x="60" y="95" textAnchor="middle" fontSize="12" fill="#f59e0b">!</text>
        {/* سهام ضغط الهواء */}
        <path d="M15 84 L22 84" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M98 84 L105 84" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">لماذا لا تسقط؟</text>
      </svg>
    ),
    s5: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* رسم توضيحي لضغط الهواء */}
        <circle cx="60" cy="45" r="35" fill="#eff6ff" stroke="#3b82f6" strokeWidth="2"/>
        {/* سهام الضغط من الخارج */}
        <path d="M20 45 L30 45" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round"/>
        <path d="M90 45 L100 45" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round"/>
        <path d="M60 10 L60 20" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round"/>
        <path d="M60 70 L60 80" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round"/>
        {/* رمز الهواء */}
        <text x="60" y="50" textAnchor="middle" fontSize="20">💨</text>
        <text x="60" y="30" textAnchor="middle" fontSize="7" fill="#1e40af" fontWeight="bold">ضغط الهواء</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اكتشف السبب!</text>
      </svg>
    ),
  },

  // ─── خلط الألوان ─────────────────────────────────────────────────────────────
  "sci-color-mixing": {
    s1: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* 3 كؤوس بألوان أساسية */}
        <path d="M10 30 L8 70 L38 70 L36 30 Z" fill="#fca5a5" stroke="#ef4444" strokeWidth="2"/>
        <path d="M8 35 L9 68 L37 68 L38 35 Z" fill="#ef4444" opacity="0.7"/>
        <path d="M45 30 L43 70 L73 70 L71 30 Z" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M43 35 L44 68 L72 68 L73 35 Z" fill="#fbbf24" opacity="0.7"/>
        <path d="M80 30 L78 70 L108 70 L106 30 Z" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        <path d="M78 35 L79 68 L107 68 L108 35 Z" fill="#60a5fa" opacity="0.7"/>
        <text x="22" y="80" textAnchor="middle" fontSize="8" fill="#ef4444" fontWeight="bold">أحمر</text>
        <text x="57" y="80" textAnchor="middle" fontSize="8" fill="#f59e0b" fontWeight="bold">أصفر</text>
        <text x="93" y="80" textAnchor="middle" fontSize="8" fill="#3b82f6" fontWeight="bold">أزرق</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر الألوان</text>
      </svg>
    ),
    s2: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* أحمر + أصفر = برتقالي */}
        <circle cx="30" cy="40" r="18" fill="#ef4444" opacity="0.8"/>
        <text x="30" y="44" textAnchor="middle" fontSize="14" fill="white" fontWeight="bold">+</text>
        <circle cx="65" cy="40" r="18" fill="#fbbf24" opacity="0.8"/>
        <text x="65" y="44" textAnchor="middle" fontSize="14" fill="white" fontWeight="bold">=</text>
        <circle cx="100" cy="40" r="18" fill="#f97316" stroke="#ea580c" strokeWidth="2"/>
        <text x="100" y="44" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">🟠</text>
        <text x="30" y="68" textAnchor="middle" fontSize="8" fill="#ef4444">أحمر</text>
        <text x="65" y="68" textAnchor="middle" fontSize="8" fill="#f59e0b">أصفر</text>
        <text x="100" y="68" textAnchor="middle" fontSize="8" fill="#ea580c" fontWeight="bold">برتقالي!</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">امزج الألوان</text>
      </svg>
    ),
    s3: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* أزرق + أصفر = أخضر */}
        <circle cx="30" cy="40" r="18" fill="#3b82f6" opacity="0.8"/>
        <text x="30" y="44" textAnchor="middle" fontSize="14" fill="white" fontWeight="bold">+</text>
        <circle cx="65" cy="40" r="18" fill="#fbbf24" opacity="0.8"/>
        <text x="65" y="44" textAnchor="middle" fontSize="14" fill="white" fontWeight="bold">=</text>
        <circle cx="100" cy="40" r="18" fill="#22c55e" stroke="#16a34a" strokeWidth="2"/>
        <text x="100" y="44" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">🟢</text>
        <text x="30" y="68" textAnchor="middle" fontSize="8" fill="#3b82f6">أزرق</text>
        <text x="65" y="68" textAnchor="middle" fontSize="8" fill="#f59e0b">أصفر</text>
        <text x="100" y="68" textAnchor="middle" fontSize="8" fill="#16a34a" fontWeight="bold">أخضر!</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">أزرق + أصفر</text>
      </svg>
    ),
    s4: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* أحمر + أزرق = بنفسجي */}
        <circle cx="30" cy="40" r="18" fill="#ef4444" opacity="0.8"/>
        <text x="30" y="44" textAnchor="middle" fontSize="14" fill="white" fontWeight="bold">+</text>
        <circle cx="65" cy="40" r="18" fill="#3b82f6" opacity="0.8"/>
        <text x="65" y="44" textAnchor="middle" fontSize="14" fill="white" fontWeight="bold">=</text>
        <circle cx="100" cy="40" r="18" fill="#a855f7" stroke="#9333ea" strokeWidth="2"/>
        <text x="100" y="44" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">🟣</text>
        <text x="30" y="68" textAnchor="middle" fontSize="8" fill="#ef4444">أحمر</text>
        <text x="65" y="68" textAnchor="middle" fontSize="8" fill="#3b82f6">أزرق</text>
        <text x="100" y="68" textAnchor="middle" fontSize="8" fill="#9333ea" fontWeight="bold">بنفسجي!</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">أحمر + أزرق</text>
      </svg>
    ),
    s5: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* دائرة الألوان */}
        <circle cx="60" cy="45" r="35" fill="none" stroke="#e5e7eb" strokeWidth="2"/>
        {/* قطاعات الألوان */}
        <path d="M60 45 L60 10 A35 35 0 0 1 90 75 Z" fill="#ef4444" opacity="0.8"/>
        <path d="M60 45 L90 75 A35 35 0 0 1 30 75 Z" fill="#fbbf24" opacity="0.8"/>
        <path d="M60 45 L30 75 A35 35 0 0 1 60 10 Z" fill="#3b82f6" opacity="0.8"/>
        {/* ألوان ثانوية */}
        <circle cx="78" cy="30" r="8" fill="#f97316" stroke="white" strokeWidth="1.5"/>
        <circle cx="40" cy="30" r="8" fill="#a855f7" stroke="white" strokeWidth="1.5"/>
        <circle cx="60" cy="78" r="8" fill="#22c55e" stroke="white" strokeWidth="1.5"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">عجلة الألوان!</text>
      </svg>
    ),
  },

  // ─── الصوت اهتزاز ────────────────────────────────────────────────────────────
  "sci-sound-vibration": {
    s1: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* طبل */}
        <ellipse cx="60" cy="50" rx="40" ry="15" fill="#fde68a" stroke="#f59e0b" strokeWidth="2.5"/>
        <rect x="20" y="50" width="80" height="20" rx="4" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <ellipse cx="60" cy="70" rx="40" ry="10" fill="#b45309" stroke="#92400e" strokeWidth="2"/>
        {/* حبوب أرز */}
        <circle cx="45" cy="46" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        <circle cx="60" cy="44" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        <circle cx="75" cy="46" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        {/* عصا طبل */}
        <rect x="85" y="25" width="5" height="30" rx="2.5" fill="#92400e" transform="rotate(20 87 40)"/>
        <circle cx="90" cy="24" r="5" fill="#6b7280"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر الطبل</text>
      </svg>
    ),
    s2: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* طبل مع أرز يقفز */}
        <ellipse cx="60" cy="55" rx="40" ry="15" fill="#fde68a" stroke="#f59e0b" strokeWidth="2.5"/>
        <rect x="20" y="55" width="80" height="20" rx="4" fill="#d97706" stroke="#92400e" strokeWidth="2"/>
        <ellipse cx="60" cy="75" rx="40" ry="10" fill="#b45309" stroke="#92400e" strokeWidth="2"/>
        {/* أرز يقفز */}
        <circle cx="40" cy="42" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        <circle cx="55" cy="38" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        <circle cx="70" cy="40" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        <circle cx="80" cy="36" r="3" fill="white" stroke="#d1d5db" strokeWidth="1"/>
        {/* سهام قفز */}
        <path d="M40 50 L40 44" stroke="#6366f1" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M55 50 L55 40" stroke="#6366f1" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M70 50 L70 42" stroke="#6366f1" strokeWidth="1.5" strokeLinecap="round"/>
        {/* عصا تضرب */}
        <rect x="82" y="28" width="5" height="30" rx="2.5" fill="#92400e" transform="rotate(30 84 43)"/>
        <circle cx="88" cy="26" r="5" fill="#6b7280"/>
        {/* موجات صوت */}
        <path d="M15 45 Q20 40 25 45 Q30 50 35 45" stroke="#f59e0b" strokeWidth="1.5" fill="none"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اضرب الطبل!</text>
      </svg>
    ),
    s3: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* كوبان وخيط */}
        {/* كوب أيسر */}
        <path d="M8 30 L5 65 L35 65 L32 30 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2"/>
        <rect x="5" y="25" width="30" height="8" rx="3" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        {/* كوب أيمن */}
        <path d="M88 30 L85 65 L115 65 L112 30 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2"/>
        <rect x="85" y="25" width="30" height="8" rx="3" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        {/* خيط مرخٍ */}
        <path d="M35 65 Q60 80 85 65" stroke="#f59e0b" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* ثقوب */}
        <circle cx="20" cy="63" r="3" fill="#1e40af"/>
        <circle cx="100" cy="63" r="3" fill="#1e40af"/>
        {/* إبرة */}
        <line x1="20" y1="55" x2="20" y2="68" stroke="#6b7280" strokeWidth="2" strokeLinecap="round"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اثقب وأدخل الخيط</text>
      </svg>
    ),
    s4: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* كوبان وخيط مشدود */}
        <path d="M5 28 L3 63 L33 63 L31 28 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2"/>
        <rect x="3" y="23" width="30" height="8" rx="3" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        <path d="M87 28 L85 63 L115 63 L113 28 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2"/>
        <rect x="85" y="23" width="30" height="8" rx="3" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        {/* خيط مشدود مع اهتزاز */}
        <path d="M33 50 Q45 46 60 50 Q75 54 87 50" stroke="#f59e0b" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* موجات اهتزاز على الخيط */}
        <path d="M38 50 Q42 44 46 50 Q50 56 54 50 Q58 44 62 50 Q66 56 70 50 Q74 44 78 50 Q82 56 86 50" stroke="#f97316" strokeWidth="1.5" fill="none" opacity="0.7"/>
        {/* شخص يتكلم */}
        <circle cx="15" cy="18" r="8" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M12 22 Q15 25 18 22" stroke="#92400e" strokeWidth="1.5" fill="none"/>
        {/* موجات صوت */}
        <path d="M24 15 Q28 10 24 5" stroke="#6366f1" strokeWidth="1.5" fill="none"/>
        <path d="M27 17 Q33 10 27 3" stroke="#6366f1" strokeWidth="1.5" fill="none"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">اشدد الخيط وتكلم</text>
      </svg>
    ),
    s5: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* شخص يتكلم وآخر يسمع */}
        {/* شخص يتكلم */}
        <circle cx="18" cy="25" r="12" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M14 30 Q18 34 22 30" stroke="#92400e" strokeWidth="1.5" fill="none"/>
        <path d="M10 37 L10 55" stroke="#6b7280" strokeWidth="3" strokeLinecap="round"/>
        <path d="M10 40 L5 48" stroke="#6b7280" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M10 40 L15 48" stroke="#6b7280" strokeWidth="2.5" strokeLinecap="round"/>
        {/* كوب */}
        <path d="M20 30 L18 50 L32 50 L30 30 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1.5"/>
        {/* خيط مشدود مع اهتزاز */}
        <path d="M32 40 Q60 35 88 40" stroke="#f59e0b" strokeWidth="2.5" fill="none"/>
        <path d="M35 40 Q40 35 45 40 Q50 45 55 40 Q60 35 65 40 Q70 45 75 40 Q80 35 85 40" stroke="#f97316" strokeWidth="1.5" fill="none" opacity="0.8"/>
        {/* كوب ثانٍ */}
        <path d="M88 30 L86 50 L100 50 L98 30 Z" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1.5"/>
        {/* شخص يسمع */}
        <circle cx="102" cy="25" r="12" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M98 30 Q102 34 106 30" stroke="#92400e" strokeWidth="1.5" fill="none"/>
        <path d="M110 37 L110 55" stroke="#6b7280" strokeWidth="3" strokeLinecap="round"/>
        {/* أذن */}
        <path d="M90 22 Q86 25 90 28" stroke="#92400e" strokeWidth="2" fill="none"/>
        {/* نجوم دهشة */}
        <text x="110" y="20" fontSize="10">⭐</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">استمع وتعجّب!</text>
      </svg>
    ),
  },

  // ─── الضوء والظل ─────────────────────────────────────────────────────────────
  "sci-light-shadow": {
    s1: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مصباح يدوي */}
        <rect x="45" y="10" width="30" height="20" rx="5" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <rect x="52" y="30" width="16" height="25" rx="3" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        <rect x="48" y="52" width="24" height="8" rx="3" fill="#4b5563"/>
        {/* أشعة ضوء */}
        <path d="M30 15 L45 18" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M25 25 L45 22" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M90 15 L75 18" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M95 25 L75 22" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round"/>
        {/* جسم */}
        <circle cx="60" cy="75" r="12" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر المصباح</text>
      </svg>
    ),
    s2: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* مصباح يضيء على جسم */}
        <circle cx="20" cy="20" r="12" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        {/* أشعة */}
        <path d="M30 20 L50 35" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" opacity="0.8"/>
        <path d="M28 28 L48 42" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" opacity="0.6"/>
        <path d="M32 14 L52 28" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" opacity="0.6"/>
        {/* جسم */}
        <circle cx="65" cy="40" r="15" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        {/* ظل */}
        <ellipse cx="85" cy="72" rx="20" ry="8" fill="#374151" opacity="0.6"/>
        <path d="M65 55 L75 65 L95 72 L75 72 Z" fill="#374151" opacity="0.5"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">وجّه الضوء</text>
      </svg>
    ),
    s3: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ظل قصير (ضوء من فوق) */}
        <circle cx="30" cy="15" r="8" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M30 23 L30 35" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round"/>
        <circle cx="30" cy="50" r="10" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        <ellipse cx="30" cy="65" rx="8" ry="4" fill="#374151" opacity="0.6"/>
        <text x="30" y="78" textAnchor="middle" fontSize="7" fill="#374151">قصير</text>
        {/* ظل طويل (ضوء من جانب) */}
        <circle cx="80" cy="40" r="8" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M88 40 L100 40" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round"/>
        <circle cx="90" cy="65" r="10" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        <ellipse cx="75" cy="68" rx="18" ry="5" fill="#374151" opacity="0.6"/>
        <text x="80" y="82" textAnchor="middle" fontSize="7" fill="#374151">طويل</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">قارن الظلال</text>
      </svg>
    ),
    s4: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* يد تحجب الضوء */}
        <circle cx="15" cy="30" r="12" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <path d="M25 25 L55 40" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" opacity="0.8"/>
        <path d="M25 30 L55 45" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" opacity="0.6"/>
        <path d="M25 35 L55 50" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" opacity="0.6"/>
        {/* يد */}
        <ellipse cx="55" cy="45" rx="12" ry="8" fill="#fde68a" stroke="#f59e0b" strokeWidth="2"/>
        {/* ظل اليد */}
        <ellipse cx="85" cy="65" rx="18" ry="7" fill="#374151" opacity="0.5"/>
        <path d="M55 52 L70 60 L100 65 L70 65 Z" fill="#374151" opacity="0.4"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احجب الضوء</text>
      </svg>
    ),
    s5: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* شمس + ظل الشجرة */}
        <circle cx="20" cy="18" r="12" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        {/* أشعة شمس */}
        {[0,45,90,135,180,225,270,315].map((a, i) => (
          <line key={i}
            x1={20 + 14 * Math.cos(a * Math.PI / 180)}
            y1={18 + 14 * Math.sin(a * Math.PI / 180)}
            x2={20 + 19 * Math.cos(a * Math.PI / 180)}
            y2={18 + 19 * Math.sin(a * Math.PI / 180)}
            stroke="#f59e0b" strokeWidth="2" strokeLinecap="round"
          />
        ))}
        {/* شجرة */}
        <rect x="57" y="55" width="6" height="30" fill="#92400e"/>
        <circle cx="60" cy="45" r="18" fill="#22c55e" stroke="#16a34a" strokeWidth="2"/>
        {/* ظل الشجرة */}
        <ellipse cx="80" cy="85" rx="25" ry="8" fill="#374151" opacity="0.4"/>
        <path d="M60 85 L85 80 L105 85 L85 88 Z" fill="#374151" opacity="0.3"/>
        {/* طفل في الظل */}
        <circle cx="85" cy="72" r="6" fill="#fde68a" stroke="#f59e0b" strokeWidth="1.5"/>
        <text x="85" y="76" textAnchor="middle" fontSize="8">😊</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">الظل في الطبيعة</text>
      </svg>
    ),
  },

  // ─── الحرارة والبرودة ────────────────────────────────────────────────────────
  "sci-heat-cold": {
    s1: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ثلج */}
        <rect x="10" y="25" width="45" height="55" rx="8" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2"/>
        <text x="32" y="58" textAnchor="middle" fontSize="28">🧊</text>
        <text x="32" y="78" textAnchor="middle" fontSize="8" fill="#1e40af" fontWeight="bold">ثلج</text>
        {/* شمس */}
        <circle cx="85" cy="45" r="20" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="85" y="50" textAnchor="middle" fontSize="14" fill="#92400e">☀️</text>
        <text x="85" y="78" textAnchor="middle" fontSize="8" fill="#92400e" fontWeight="bold">حرارة</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر الثلج</text>
      </svg>
    ),
    s2: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ثلج يذوب */}
        <rect x="30" y="20" width="60" height="40" rx="8" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="2"/>
        <text x="60" y="45" textAnchor="middle" fontSize="22">🧊</text>
        {/* شمس تسخّن */}
        <circle cx="95" cy="18" r="14" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="95" y="22" textAnchor="middle" fontSize="10">☀️</text>
        {/* قطرات ذوبان */}
        <path d="M40 60 L38 75" stroke="#60a5fa" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M55 60 L53 78" stroke="#60a5fa" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M70 60 L68 76" stroke="#60a5fa" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M80 60 L79 73" stroke="#60a5fa" strokeWidth="2.5" strokeLinecap="round"/>
        {/* ماء يتجمع */}
        <ellipse cx="60" cy="82" rx="30" ry="8" fill="#93c5fd" opacity="0.7"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">الثلج يذوب!</text>
      </svg>
    ),
    s3: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ماء يتبخر */}
        <ellipse cx="60" cy="75" rx="40" ry="15" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        <text x="60" y="80" textAnchor="middle" fontSize="8" fill="#1e40af">ماء</text>
        {/* شمس */}
        <circle cx="60" cy="20" r="14" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="60" y="24" textAnchor="middle" fontSize="10">☀️</text>
        {/* بخار يصعد */}
        <path d="M40 60 Q38 50 42 42" stroke="#93c5fd" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 2"/>
        <path d="M55 58 Q53 46 57 38" stroke="#93c5fd" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 2"/>
        <path d="M70 58 Q68 46 72 38" stroke="#93c5fd" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 2"/>
        <path d="M80 60 Q78 50 82 42" stroke="#93c5fd" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 2"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">الماء يتبخر</text>
      </svg>
    ),
    s4: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* ميزان حرارة */}
        <rect x="55" y="10" width="10" height="65" rx="5" fill="white" stroke="#d1d5db" strokeWidth="2"/>
        <rect x="57" y="45" width="6" height="28" rx="3" fill="#ef4444"/>
        <circle cx="60" cy="78" r="8" fill="#ef4444" stroke="#dc2626" strokeWidth="2"/>
        {/* درجات */}
        <line x1="65" y1="20" x2="70" y2="20" stroke="#6b7280" strokeWidth="1.5"/>
        <line x1="65" y1="30" x2="70" y2="30" stroke="#6b7280" strokeWidth="1.5"/>
        <line x1="65" y1="40" x2="70" y2="40" stroke="#6b7280" strokeWidth="1.5"/>
        <line x1="65" y1="50" x2="70" y2="50" stroke="#6b7280" strokeWidth="1.5"/>
        <line x1="65" y1="60" x2="70" y2="60" stroke="#6b7280" strokeWidth="1.5"/>
        {/* حار وبارد */}
        <text x="25" y="45" textAnchor="middle" fontSize="20">🔥</text>
        <text x="95" y="45" textAnchor="middle" fontSize="20">❄️</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">قِس الحرارة</text>
      </svg>
    ),
    s5: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* دورة الماء */}
        <text x="60" y="15" textAnchor="middle" fontSize="8" fill="#1e40af" fontWeight="bold">دورة الماء</text>
        {/* بحر */}
        <ellipse cx="60" cy="85" rx="50" ry="12" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2"/>
        {/* سحاب */}
        <ellipse cx="60" cy="35" rx="25" ry="12" fill="white" stroke="#d1d5db" strokeWidth="2"/>
        <ellipse cx="45" cy="38" rx="15" ry="10" fill="white" stroke="#d1d5db" strokeWidth="2"/>
        <ellipse cx="75" cy="38" rx="15" ry="10" fill="white" stroke="#d1d5db" strokeWidth="2"/>
        {/* مطر */}
        <path d="M48 50 L45 62" stroke="#60a5fa" strokeWidth="2" strokeLinecap="round"/>
        <path d="M60 50 L58 65" stroke="#60a5fa" strokeWidth="2" strokeLinecap="round"/>
        <path d="M72 50 L70 62" stroke="#60a5fa" strokeWidth="2" strokeLinecap="round"/>
        {/* بخار صاعد */}
        <path d="M30 73 Q28 60 32 50" stroke="#93c5fd" strokeWidth="2" strokeDasharray="3 2" strokeLinecap="round"/>
        <path d="M90 73 Q88 60 92 50" stroke="#93c5fd" strokeWidth="2" strokeDasharray="3 2" strokeLinecap="round"/>
        {/* شمس */}
        <circle cx="100" cy="20" r="10" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">دورة الماء الكاملة</text>
      </svg>
    ),
  },

  // ─── الطفو والغرق (نسخة 2) ──────────────────────────────────────────────────
  "sci-density": {
    s1: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="20" y="35" width="80" height="55" rx="6" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="22" y="45" width="76" height="43" rx="4" fill="#bfdbfe" opacity="0.8"/>
        <text x="60" y="72" textAnchor="middle" fontSize="20">🫙</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">احضر الوعاء</text>
      </svg>
    ),
    s2: (
      <svg viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="20" y="35" width="80" height="55" rx="6" fill="#93c5fd" stroke="#3b82f6" strokeWidth="2.5"/>
        <rect x="22" y="45" width="76" height="43" rx="4" fill="#bfdbfe" opacity="0.8"/>
        <circle cx="45" cy="52" r="10" fill="#fbbf24" stroke="#f59e0b" strokeWidth="2"/>
        <text x="45" y="56" textAnchor="middle" fontSize="8">طافٍ</text>
        <ellipse cx="80" cy="78" rx="10" ry="7" fill="#6b7280" stroke="#4b5563" strokeWidth="2"/>
        <text x="80" y="82" textAnchor="middle" fontSize="8" fill="white">غارق</text>
        <text x="60" y="98" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="bold">ضع الأشياء</text>
      </svg>
    ),
  },
};

// ── مكوّن رئيسي ──────────────────────────────────────────────────────────────
export default function ScienceStepIllustration({ experimentId, stepId, className = "" }: Props) {
  const expIllustrations = illustrations[experimentId];
  if (!expIllustrations) return null;

  const illustration = expIllustrations[stepId];
  if (!illustration) return null;

  return (
    <div className={`w-full flex items-center justify-center ${className}`}>
      <div className="w-32 h-28">
        {illustration}
      </div>
    </div>
  );
}
