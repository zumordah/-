import { useState, useMemo } from "react";
import { toAr } from "@/lib/arabicNumerals";
import { ChevronRight, ChevronLeft } from "lucide-react";

function playCorrectSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.setValueAtTime(523, ctx.currentTime);
    o.frequency.setValueAtTime(659, ctx.currentTime + 0.1);
    o.frequency.setValueAtTime(784, ctx.currentTime + 0.2);
    g.gain.setValueAtTime(0.3, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
    o.start(); o.stop(ctx.currentTime + 0.5);
  } catch {}
}

function playWrongSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.setValueAtTime(300, ctx.currentTime);
    o.frequency.setValueAtTime(200, ctx.currentTime + 0.15);
    g.gain.setValueAtTime(0.3, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
    o.start(); o.stop(ctx.currentTime + 0.4);
  } catch {}
}

interface CompareRound {
  emoji: string;
  leftCount: number;
  rightCount: number;
  leftLabel: string;
  rightLabel: string;
  correct: "left" | "right" | "equal";
}

// ─── خلط ترتيب الأزرار الثلاثة عشوائياً لكل سؤال ───────────────────────────
type ButtonDef = {
  key: "left" | "right" | "equal";
  icon: string;
  label: string;
};

function shuffleButtonOrder(): ButtonDef[] {
  const buttons: ButtonDef[] = [
    { key: "left",  icon: "⬅️", label: "الأيسر أكبر" },
    { key: "equal", icon: "=",  label: "متساويان"    },
    { key: "right", icon: "➡️", label: "الأيمن أكبر" },
  ];
  return [...buttons].sort(() => Math.random() - 0.5);
}

export default function CompareSymbolsGame({
  data,
  onComplete,
}: {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: any;
  onComplete: (score: number) => void;
}) {
  const rounds = useMemo(() => {
    if (data.rounds && data.rounds.length > 0) return data.rounds as CompareRound[];
    // بيانات افتراضية إذا لم تكن موجودة
    return [
      { emoji: "🍎", leftCount: 3, rightCount: 5, leftLabel: "تفاحات", rightLabel: "تفاحات", correct: "right" as const },
      { emoji: "🍊", leftCount: 7, rightCount: 4, leftLabel: "برتقالات", rightLabel: "برتقالات", correct: "left" as const },
      { emoji: "⭐", leftCount: 2, rightCount: 2, leftLabel: "نجوم", rightLabel: "نجوم", correct: "equal" as const },
      { emoji: "🐟", leftCount: 6, rightCount: 3, leftLabel: "أسماك", rightLabel: "أسماك", correct: "left" as const },
      { emoji: "🌸", leftCount: 4, rightCount: 8, leftLabel: "زهور", rightLabel: "زهور", correct: "right" as const },
      { emoji: "🍓", leftCount: 5, rightCount: 5, leftLabel: "فراولة", rightLabel: "فراولة", correct: "equal" as const },
      { emoji: "🦋", leftCount: 9, rightCount: 6, leftLabel: "فراشات", rightLabel: "فراشات", correct: "left" as const },
      { emoji: "🎈", leftCount: 3, rightCount: 7, leftLabel: "بالونات", rightLabel: "بالونات", correct: "right" as const },
    ];
  }, [data]);

  // ترتيب الأزرار مخلوط عشوائياً لكل سؤال — يُحسب مرة واحدة لجميع الأسئلة
  const buttonOrders = useMemo(() => rounds.map(() => shuffleButtonOrder()), [rounds]);

  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<"left" | "right" | "equal" | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);

  const round = rounds[current] as CompareRound;
  const currentButtons = buttonOrders[current] ?? shuffleButtonOrder();

  if (!round) return null;

  const handleAnswer = (choice: "left" | "right" | "equal") => {
    if (selected !== null) return;
    setSelected(choice);
    const isCorrect = choice === round.correct;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) {
      playCorrectSound();
      setScore(s => s + 1);
    } else {
      playWrongSound();
    }
    setTimeout(() => {
      if (current + 1 >= rounds.length) {
        onComplete(score + (isCorrect ? 1 : 0));
      } else {
        setCurrent(c => c + 1);
        setSelected(null);
        setFeedback(null);
      }
    }, 1200);
  };

  const renderSymbols = (emoji: string, count: number) => (
    <div className="flex flex-wrap justify-center gap-1 max-w-[140px]">
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} className="text-3xl">{emoji}</span>
      ))}
    </div>
  );

  const getBtnClass = (key: "left" | "right" | "equal") => {
    const base = "flex flex-col items-center justify-center p-4 rounded-3xl border-3 transition-all duration-200 font-bold text-lg ";
    if (selected === null) return base + "border-gray-200 bg-white hover:border-purple-400 hover:bg-purple-50 active:scale-95 cursor-pointer";
    if (key === round.correct) return base + "border-green-400 bg-green-100 scale-105 text-green-700";
    if (key === selected) return base + "border-red-400 bg-red-100 text-red-700 animate-shake-inline";
    return base + "border-gray-200 bg-gray-50 opacity-50";
  };

  return (
    <div className="space-y-6">
      {/* عداد الأسئلة */}
      <div className="text-center text-sm text-gray-400 font-semibold">
        السؤال {toAr(current + 1)} من {toAr(rounds.length)}
      </div>

      {/* السؤال */}
      <div className="text-center">
        <p className="text-xl font-bold text-gray-700 mb-4">أيهما أكبر؟</p>
      </div>

      {/* المقارنة */}
      <div className="flex items-center justify-center gap-4">
        {/* الجانب الأيسر */}
        <div className={`flex flex-col items-center gap-2 p-4 rounded-3xl border-2 transition-all ${
          selected === "left" && round.correct === "left" ? "border-green-400 bg-green-50" :
          selected === "left" && round.correct !== "left" ? "border-red-400 bg-red-50" :
          selected !== null && round.correct === "left" ? "border-green-400 bg-green-50" :
          "border-gray-200 bg-white"
        }`}>
          {renderSymbols(round.emoji, round.leftCount)}
          <span className="text-sm font-bold text-gray-600 mt-1">
            {toAr(round.leftCount)} {round.leftLabel}
          </span>
        </div>

        {/* علامة المقارنة */}
        <div className="text-4xl font-black text-gray-400">؟</div>

        {/* الجانب الأيمن */}
        <div className={`flex flex-col items-center gap-2 p-4 rounded-3xl border-2 transition-all ${
          selected === "right" && round.correct === "right" ? "border-green-400 bg-green-50" :
          selected === "right" && round.correct !== "right" ? "border-red-400 bg-red-50" :
          selected !== null && round.correct === "right" ? "border-green-400 bg-green-50" :
          "border-gray-200 bg-white"
        }`}>
          {renderSymbols(round.emoji, round.rightCount)}
          <span className="text-sm font-bold text-gray-600 mt-1">
            {toAr(round.rightCount)} {round.rightLabel}
          </span>
        </div>
      </div>

      {/* الأزرار — ترتيب عشوائي مختلف لكل سؤال */}
      <div className="grid grid-cols-3 gap-3">
        {currentButtons.map((btn) => (
          <button key={btn.key} className={getBtnClass(btn.key)} onClick={() => handleAnswer(btn.key)}>
            <span className="text-2xl">{btn.icon}</span>
            <span className="text-sm">{btn.label}</span>
          </button>
        ))}
      </div>

      {/* تغذية راجعة */}
      {feedback && (
        <div className={`text-center text-xl font-bold py-3 rounded-2xl ${
          feedback === "correct" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
        }`}>
          {feedback === "correct" ? "✅ أحسنت! إجابة صحيحة!" : `❌ الإجابة الصحيحة: ${round.correct === "left" ? "الأيسر أكبر" : round.correct === "right" ? "الأيمن أكبر" : "متساويان"}`}
        </div>
      )}
      {/* شريط التنقل بين الأسئلة */}
      <div className="flex items-center justify-between mt-2">
        <button
          onClick={() => { if (current > 0) { setCurrent(c => c - 1); setSelected(null); setFeedback(null); } }}
          disabled={current === 0}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === 0 ? 'text-gray-300 bg-gray-100 cursor-not-allowed' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </button>
        <span className="text-sm text-gray-400 font-semibold">{toAr(current + 1)} / {toAr(rounds.length)}</span>
        <button
          onClick={() => { if (current < rounds.length - 1) { setCurrent(c => c + 1); setSelected(null); setFeedback(null); } else { onComplete(score); } }}
          className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            current === rounds.length - 1 ? 'text-green-600 bg-green-50 hover:bg-green-100 active:scale-95' : 'text-purple-600 bg-purple-50 hover:bg-purple-100 active:scale-95'
          }`}
        >
          {current === rounds.length - 1 ? 'إنهاء' : 'التالي'}
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
