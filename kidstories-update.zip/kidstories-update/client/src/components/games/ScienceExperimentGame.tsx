import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { toAr, arabicizeText } from "@/lib/arabicNumerals";
import ScienceStepIllustration from "./ScienceStepIllustration";

export interface ScienceStep {
  id: string;
  instruction: string;
  emoji: string;
  animation?: string;
  audioText?: string;  // النص الصوتي للخطوة (قد يختلف عن النص المكتوب)
  audioUrl?: string;  // رابط ملف الصوت المولّد
}

export interface ScienceQuestion {
  id: string;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export interface ScienceExperimentGameData {
  id: string;
  title: string;
  description: string;
  type: "science_experiment";
  emoji: string;
  category: string;
  hypothesis: string;
  hypothesisOptions?: string[];
  materials: string[];
  steps: ScienceStep[];
  result: string;
  explanation: string;
  questions: ScienceQuestion[];
  videoUrl?: string;
}

interface Props {
  game: ScienceExperimentGameData;
  onComplete?: (score: number, maxScore: number) => void;
}

// التدفق الجديد:
// intro → hypothesis → steps → result → choice → (quiz_first | video_first)
// quiz_first: quiz → video_after_quiz → done
// video_first: video → quiz_after_video → done
type Phase =
  | "intro"
  | "hypothesis"
  | "steps"
  | "result"
  | "choice"          // شاشة الخيار: اختبر معلوماتك أو شاهد الفيديو
  | "quiz"            // الأسئلة (قبل أو بعد الفيديو)
  | "video"           // الفيديو
  | "quiz_after_video" // الأسئلة بعد الفيديو
  | "video_after_quiz" // الفيديو بعد الأسئلة
  | "done";

// ── Hook تشغيل الصوت البشري (MP3) ──
function useStepAudio() {
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // تشغيل ملف MP3 أو fallback لـ Web Speech
  const speak = useCallback((audioUrl: string | undefined, fallbackText: string, id: string) => {
    // إذا كان نفس الصوت يعمل → أوقفه
    if (speakingId === id) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        audioRef.current = null;
      }
      window.speechSynthesis?.cancel();
      setSpeakingId(null);
      return;
    }

    // أوقف أي صوت حالي
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    window.speechSynthesis?.cancel();

    if (audioUrl) {
      // ── تشغيل ملف MP3 البشري ──
      const audio = new Audio(audioUrl);
      audio.volume = 1;
      audio.onplay = () => setSpeakingId(id);
      audio.onended = () => { setSpeakingId(null); audioRef.current = null; };
      audio.onerror = () => { setSpeakingId(null); audioRef.current = null; };
      audioRef.current = audio;
      audio.play().catch(() => setSpeakingId(null));
    } else if (typeof window !== "undefined" && "speechSynthesis" in window) {
      // ── fallback: Web Speech API ──
      const utterance = new SpeechSynthesisUtterance(fallbackText);
      utterance.lang = "ar-SA";
      utterance.rate = 0.82;
      utterance.pitch = 1.05;
      utterance.volume = 1;
      const voices = window.speechSynthesis.getVoices();
      const arabicVoice =
        voices.find((v) => v.lang === "ar-SA" && v.localService) ||
        voices.find((v) => v.lang === "ar-SA") ||
        voices.find((v) => v.lang.startsWith("ar")) || null;
      if (arabicVoice) utterance.voice = arabicVoice;
      utterance.onstart = () => setSpeakingId(id);
      utterance.onend = () => setSpeakingId(null);
      utterance.onerror = () => setSpeakingId(null);
      window.speechSynthesis.speak(utterance);
    }
  }, [speakingId]);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    window.speechSynthesis?.cancel();
    setSpeakingId(null);
  }, []);

  return { speak, stop, speakingId, isSupported: true };
}

export default function ScienceExperimentGame({ game, onComplete }: Props) {
  const [phase, setPhase] = useState<Phase>("intro");
  const [currentStep, setCurrentStep] = useState(0);
  const [hypothesis, setHypothesis] = useState<string | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [finalScore, setFinalScore] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const tts = useStepAudio();

  const maxScore = game.questions.length;
  const hasVideo = !!game.videoUrl;

  // إعادة تشغيل الفيديو عند الانتقال لمرحلة الفيديو
  useEffect(() => {
    if ((phase === "video" || phase === "video_after_quiz") && videoRef.current) {
      videoRef.current.load();
    }
  }, [phase]);

  // إيقاف الصوت عند تغيير الخطوة أو المرحلة
  useEffect(() => {
    tts.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep, phase]);

  const handleAnswer = (idx: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(idx);
    setShowExplanation(true);
    const isCorrect = idx === game.questions[currentQ].correct;
    if (isCorrect) setScore(s => s + 1);
  };

  const nextQuestion = (currentPhase: "quiz" | "quiz_after_video") => {
    const isLastQ = currentQ + 1 >= game.questions.length;
    const currentScore = score + (selectedOption === game.questions[currentQ].correct ? 1 : 0);

    setSelectedOption(null);
    setShowExplanation(false);

    if (!isLastQ) {
      setCurrentQ(q => q + 1);
    } else {
      setFinalScore(currentScore);
      if (currentPhase === "quiz") {
        // بعد الأسئلة → شاهد الفيديو (إذا كان موجوداً)
        if (hasVideo) {
          setPhase("video_after_quiz");
        } else {
          setPhase("done");
          onComplete?.(currentScore, maxScore);
        }
      } else {
        // بعد الأسئلة (التي جاءت بعد الفيديو) → انتهى
        setPhase("done");
        onComplete?.(currentScore, maxScore);
      }
    }
  };

  const resetQuiz = () => {
    setCurrentQ(0);
    setScore(0);
    setSelectedOption(null);
    setShowExplanation(false);
  };

  const q = game.questions[currentQ];

  // ── مكوّن الأسئلة المشترك ──
  const renderQuiz = (quizPhase: "quiz" | "quiz_after_video") => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-bold text-muted-foreground">
          السؤال {toAr(currentQ + 1)} / {toAr(game.questions.length)}
        </span>
        <span className="text-sm font-bold text-green-600">النقاط: {toAr(score)}</span>
      </div>

      <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border-2 border-indigo-200 rounded-2xl p-5 text-center">
        <p className="text-lg font-bold text-indigo-900 leading-relaxed">{arabicizeText(q.question)}</p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {q.options.map((opt, i) => {
          let cls = "w-full p-4 rounded-2xl border-2 text-right font-medium transition-all ";
          if (selectedOption === null) {
            cls += "border-gray-200 hover:border-indigo-400 hover:bg-indigo-50 cursor-pointer";
          } else if (i === q.correct) {
            cls += "border-green-500 bg-green-50 text-green-800";
          } else if (i === selectedOption) {
            cls += "border-red-400 bg-red-50 text-red-700";
          } else {
            cls += "border-gray-200 bg-gray-50 opacity-60";
          }
          return (
            <button key={i} className={cls} onClick={() => handleAnswer(i)} disabled={selectedOption !== null}>
              {i === q.correct && selectedOption !== null ? "✅ " : i === selectedOption && selectedOption !== q.correct ? "❌ " : ""}
              {arabicizeText(opt)}
            </button>
          );
        })}
      </div>

      {showExplanation && (
        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4">
          <p className="text-yellow-800 text-sm leading-relaxed">💡 {q.explanation}</p>
        </div>
      )}

      {selectedOption !== null && (
        <Button
          onClick={() => nextQuestion(quizPhase)}
          className="w-full h-12 rounded-2xl font-bold"
        >
          {currentQ + 1 < game.questions.length
            ? "السؤال التالي →"
            : quizPhase === "quiz" && hasVideo
              ? "🎬 شاهد الفيديو الآن"
              : "🏆 انهِ التجربة"}
        </Button>
      )}
    </div>
  );

  // ── مكوّن الفيديو المشترك ──
  const renderVideo = (nextPhase: Phase, nextLabel: string) => (
    <div className="space-y-4 text-center">
      <div className="text-5xl mb-2">🎬</div>
      <h2 className="text-xl font-bold text-foreground">شاهد التجربة</h2>
      <p className="text-sm text-muted-foreground mb-3">شاهد الفيديو ثم {nextPhase === "quiz_after_video" ? "اختبر معلوماتك" : "انتهت التجربة"}</p>

      <div className="rounded-2xl overflow-hidden border-2 border-blue-200 shadow-md bg-black">
        <video
          ref={videoRef}
          src={game.videoUrl}
          controls
          playsInline
          preload="metadata"
          className="w-full"
          style={{ maxHeight: '280px' }}
          onError={(e) => {
            console.error("Video error:", e);
          }}
        >
          متصفحك لا يدعم تشغيل الفيديو
        </video>
      </div>

      <Button
        onClick={() => {
          if (nextPhase === "quiz_after_video") {
            resetQuiz();
          }
          setPhase(nextPhase);
        }}
        className="w-full h-12 rounded-2xl font-bold"
      >
        {nextLabel}
      </Button>
    </div>
  );

  const step = game.steps[currentStep];
  const stepAudioText = step?.audioText || step?.instruction || "";
  const stepAudioUrl = step?.audioUrl;
  const stepAudioId = `step-${game.id}-${step?.id}`;
  const isSpeakingStep = tts.speakingId === stepAudioId;

  return (
    <div className="w-full max-w-lg mx-auto space-y-4" dir="rtl">

      {/* المقدمة */}
      {phase === "intro" && (
        <div className="text-center space-y-4">
          <div className="text-7xl animate-bounce">{game.emoji}</div>
          <h2 className="text-2xl font-bold text-foreground">{game.title}</h2>
          <p className="text-muted-foreground text-sm">{game.description}</p>
          <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 text-right">
            <h3 className="font-bold text-blue-800 mb-2">🧪 المواد اللازمة:</h3>
            <div className="flex flex-wrap gap-2">
              {game.materials.map((m, i) => (
                <span key={i} className="bg-white border border-blue-200 rounded-xl px-3 py-1 text-sm text-blue-700">{m}</span>
              ))}
            </div>
          </div>
          <Button onClick={() => setPhase("hypothesis")} className="w-full h-12 rounded-2xl font-bold text-lg">
            🔬 ابدأ التجربة!
          </Button>
        </div>
      )}

      {/* التوقع */}
      {phase === "hypothesis" && (
        <div className="text-center space-y-4">
          <div className="text-5xl">🤔</div>
          <h2 className="text-xl font-bold text-foreground">ماذا تتوقع أن يحدث؟</h2>
          <p className="text-muted-foreground text-sm">{game.hypothesis}</p>
          <div className="grid grid-cols-1 gap-3">
            {(game.hypothesisOptions ?? ["سيحدث شيء رائع! 🎉", "لن يتغير شيء 😐", "لا أعرف، سأكتشف! 🔍"]).map((opt, i) => (
              <button
                key={i}
                onClick={() => { setHypothesis(opt); setPhase("steps"); setCurrentStep(0); }}
                className="w-full p-4 rounded-2xl border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50 text-right font-medium transition-all"
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* خطوات التجربة */}
      {phase === "steps" && step && (
        <div className="space-y-4">
          {/* شريط التقدم */}
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">الخطوة {toAr(currentStep + 1)} من {toAr(game.steps.length)}</span>
            <div className="flex gap-1">
              {game.steps.map((_, i) => (
                <div key={i} className={`h-2 w-6 rounded-full transition-all ${i <= currentStep ? "bg-blue-500" : "bg-gray-200"}`} />
              ))}
            </div>
          </div>

          {/* بطاقة الخطوة */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-3xl p-6 text-center space-y-4">
            {/* صورة SVG توضيحية أو رمز كبديل */}
            <ScienceStepIllustration
              experimentId={game.id}
              stepId={step.id}
              className="mb-2"
            />
            {/* الرمز النصي كبديل إذا لم تتوفر صورة */}
            {!['sci-water-float','sci-plant-growth','sci-magnet','sci-air-pressure','sci-color-mixing','sci-sound-vibration','sci-light-shadow','sci-heat-cold','sci-density'].includes(game.id) && (
              <div className="text-5xl leading-tight min-h-[3rem] flex items-center justify-center">
                {step.emoji}
              </div>
            )}
            <h3 className="text-lg font-bold text-blue-900">الخطوة {toAr(currentStep + 1)}</h3>
            <p className="text-blue-800 text-base leading-relaxed">{step.instruction}</p>

            {/* زر الاستماع */}
            {tts.isSupported && (
              <button
                onClick={() => tts.speak(stepAudioUrl, stepAudioText, stepAudioId)}
                className={`
                  inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium
                  border-2 transition-all duration-200
                  ${isSpeakingStep
                    ? "border-orange-400 bg-orange-50 text-orange-700 animate-pulse"
                    : "border-blue-300 bg-white text-blue-700 hover:border-blue-500 hover:bg-blue-50"
                  }
                `}
                title={isSpeakingStep ? "اضغط لإيقاف الصوت" : "اضغط للاستماع"}
              >
                {isSpeakingStep ? (
                  <>
                    <span className="text-base">⏹️</span>
                    <span>إيقاف الصوت</span>
                  </>
                ) : (
                  <>
                    <span className="text-base">🔊</span>
                    <span>استمع للخطوة</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* أزرار التنقل */}
          <div className="flex gap-3">
            {currentStep > 0 && (
              <Button variant="outline" onClick={() => setCurrentStep(s => s - 1)} className="flex-1 h-12 rounded-2xl border-2">
                ← السابقة
              </Button>
            )}
            {currentStep < game.steps.length - 1 ? (
              <Button onClick={() => setCurrentStep(s => s + 1)} className="flex-1 h-12 rounded-2xl font-bold">
                التالية →
              </Button>
            ) : (
              <Button onClick={() => setPhase("result")} className="flex-1 h-12 rounded-2xl font-bold bg-green-600 hover:bg-green-700">
                🎉 شاهد النتيجة!
              </Button>
            )}
          </div>
        </div>
      )}

      {/* النتيجة */}
      {phase === "result" && (
        <div className="text-center space-y-4">
          <div className="text-7xl animate-bounce">🎉</div>
          <h2 className="text-2xl font-bold text-foreground">ماذا حدث؟</h2>
          <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-4 text-right">
            <p className="text-green-800 font-medium text-base leading-relaxed">{game.result}</p>
          </div>
          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 text-right">
            <h3 className="font-bold text-yellow-800 mb-2">💡 لماذا حدث هذا؟</h3>
            <p className="text-yellow-700 text-sm leading-relaxed">{game.explanation}</p>
          </div>
          {hypothesis && (
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 text-right">
              <p className="text-purple-700 text-sm">توقعك كان: <span className="font-bold">{hypothesis}</span></p>
            </div>
          )}
          <Button onClick={() => setPhase("choice")} className="w-full h-12 rounded-2xl font-bold">
            التالي ←
          </Button>
        </div>
      )}

      {/* شاشة الخيار */}
      {phase === "choice" && (
        <div className="text-center space-y-5">
          <div className="text-5xl">🌟</div>
          <h2 className="text-xl font-bold text-foreground">ماذا تريد أن تفعل الآن؟</h2>
          <p className="text-muted-foreground text-sm">اختر ما تريد</p>

          <div className="grid grid-cols-1 gap-4">
            {/* اختبر معلوماتك */}
            <button
              onClick={() => { resetQuiz(); setPhase("quiz"); }}
              className="w-full p-5 rounded-2xl border-2 border-indigo-200 hover:border-indigo-500 hover:bg-indigo-50 transition-all text-right group"
            >
              <div className="flex items-center gap-4">
                <div className="text-4xl">📝</div>
                <div>
                  <p className="text-lg font-bold text-indigo-800 group-hover:text-indigo-900">اختبر معلوماتك</p>
                  <p className="text-sm text-indigo-500">أجب على الأسئلة واكسب نقاط</p>
                </div>
              </div>
            </button>

            {/* شاهد الفيديو */}
            {hasVideo && (
              <button
                onClick={() => setPhase("video")}
                className="w-full p-5 rounded-2xl border-2 border-blue-200 hover:border-blue-500 hover:bg-blue-50 transition-all text-right group"
              >
                <div className="flex items-center gap-4">
                  <div className="text-4xl">🎬</div>
                  <div>
                    <p className="text-lg font-bold text-blue-800 group-hover:text-blue-900">شاهد فيديو التجربة</p>
                    <p className="text-sm text-blue-500">شاهد التجربة ثم اختبر معلوماتك</p>
                  </div>
                </div>
              </button>
            )}
          </div>
        </div>
      )}

      {/* الأسئلة أولاً (ثم الفيديو) */}
      {phase === "quiz" && renderQuiz("quiz")}

      {/* الفيديو بعد الأسئلة */}
      {phase === "video_after_quiz" && renderVideo("done", "🏆 انهِ التجربة")}

      {/* الفيديو أولاً (ثم الأسئلة) */}
      {phase === "video" && renderVideo("quiz_after_video", "📝 اختبر معلوماتك الآن")}

      {/* الأسئلة بعد الفيديو */}
      {phase === "quiz_after_video" && renderQuiz("quiz_after_video")}

      {/* النهاية */}
      {phase === "done" && (
        <div className="text-center space-y-4">
          <div className="text-7xl">{finalScore === maxScore ? "🏆" : finalScore >= maxScore / 2 ? "⭐" : "🔬"}</div>
          <h2 className="text-2xl font-bold text-foreground">أحسنت العالم الصغير!</h2>
          <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-2xl p-5">
            <p className="text-3xl font-bold text-blue-700 mb-1">{toAr(finalScore)} / {toAr(maxScore)}</p>
            <p className="text-blue-600 text-sm">
              {finalScore === maxScore ? "إجابات صحيحة كاملة! عالم متميز! 🌟" :
               finalScore >= maxScore / 2 ? "أداء جيد! واصل الاستكشاف! 🔍" :
               "جرب مرة أخرى وستتحسن! 💪"}
            </p>
          </div>
          <Button
            onClick={() => {
              setPhase("intro");
              setCurrentStep(0);
              setCurrentQ(0);
              setScore(0);
              setFinalScore(0);
              setSelectedOption(null);
              setShowExplanation(false);
              setHypothesis(null);
            }}
            variant="outline"
            className="w-full h-12 rounded-2xl border-2 font-bold"
          >
            🔄 أعد التجربة
          </Button>
        </div>
      )}
    </div>
  );
}
