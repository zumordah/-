import { useChild } from "@/contexts/ChildContext";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Star } from "lucide-react";

// الصفحات التي لا تحتاج الشريط (صفحة تسجيل الدخول والأدمن)
const HIDDEN_PATHS = ["/", "/login", "/admin"];

// ارتفاع الشريط العلوي (يُستخدم لإضافة padding للصفحة)
export const TOP_BAR_HEIGHT = 53; // px

export default function ChildTopBar() {
  const { child } = useChild();
  const [location] = useLocation();
  const [, navigate] = useLocation();

  // جلب أحدث بيانات الطفل (النقاط قد تتغير)
  const { data: freshChild } = trpc.children.getById.useQuery(
    { id: child?.id ?? 0 },
    { enabled: !!child?.id, refetchInterval: 30000 }
  );

  // إخفاء الشريط في صفحات معينة
  if (!child) return null;
  if (HIDDEN_PATHS.includes(location)) return null;

  const displayPoints = freshChild?.totalPoints ?? child.totalPoints;
  const displayName = child.name;
  const displayAvatar = child.avatarEmoji ?? "🧒";
  const displayAvatarUrl = (freshChild as any)?.avatarUrl ?? (child as any)?.avatarUrl ?? null;

  return (
    <>
    {/* padding-top لمنع تداخل المحتوى مع الشريط */}
    <div style={{ height: TOP_BAR_HEIGHT }} />
    <div
      className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-purple-100 shadow-sm"
      dir="rtl"
    >
      <div className="flex items-center justify-between px-4 py-2 max-w-lg mx-auto">
        {/* الأفاتار والاسم */}
        <button
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-xl shadow-sm border-2 border-white overflow-hidden">
            {displayAvatarUrl ? (
              <img src={displayAvatarUrl} alt={displayName} className="w-full h-full object-cover" />
            ) : (
              displayAvatar
            )}
          </div>
          <span className="text-sm font-bold text-gray-800 max-w-[90px] truncate">
            {displayName}
          </span>
        </button>

        {/* النقاط */}
        <button
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-1.5 bg-yellow-50 border border-yellow-200 px-3 py-1.5 rounded-full hover:bg-yellow-100 transition-colors"
        >
          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
          <span className="text-sm font-bold text-yellow-700">{displayPoints}</span>
          <span className="text-xs text-yellow-500">نقطة</span>
        </button>
      </div>
    </div>
    </>
  );
}
