import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import {
  Download, TrendingUp, Users, BarChart2, PieChart as PieIcon,
  School, CalendarRange, RotateCcw, Eye, EyeOff, CheckSquare, Square, FileSpreadsheet,
} from "lucide-react";
import { toast } from "sonner";

const COLORS = [
  "#6366f1", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6",
  "#06b6d4", "#f97316", "#84cc16", "#ec4899", "#14b8a6",
  "#a855f7", "#0ea5e9", "#d97706", "#16a34a", "#dc2626",
];

// ─── Date Filter Bar ─────────────────────────────────────────────────────────
interface DateFilterBarProps {
  fromDate: string;
  toDate: string;
  onFromChange: (v: string) => void;
  onToChange: (v: string) => void;
  onReset: () => void;
  isCustom: boolean;
}

function DateFilterBar({ fromDate, toDate, onFromChange, onToChange, onReset, isCustom }: DateFilterBarProps) {
  return (
    <div className="flex flex-wrap items-end gap-3 p-3 bg-muted/40 rounded-lg border">
      <CalendarRange className="w-4 h-4 text-muted-foreground mt-6 shrink-0" />
      <div className="flex flex-col gap-1">
        <Label className="text-xs text-muted-foreground">من تاريخ</Label>
        <Input
          type="date"
          value={fromDate}
          onChange={e => onFromChange(e.target.value)}
          className="h-8 text-sm w-36"
        />
      </div>
      <div className="flex flex-col gap-1">
        <Label className="text-xs text-muted-foreground">إلى تاريخ</Label>
        <Input
          type="date"
          value={toDate}
          onChange={e => onToChange(e.target.value)}
          className="h-8 text-sm w-36"
        />
      </div>
      {isCustom && (
        <Button variant="outline" size="sm" onClick={onReset} className="gap-1 h-8">
          <RotateCcw className="w-3 h-3" />
          إعادة تعيين
        </Button>
      )}
      {isCustom && (
        <Badge variant="secondary" className="h-8 px-2 flex items-center">
          فلتر مخصص نشط
        </Badge>
      )}
    </div>
  );
}

// ─── School Visibility Toggle Panel ─────────────────────────────────────────
interface SchoolTogglePanelProps {
  schools: string[];
  visible: Set<string>;
  colors: string[];
  onToggle: (name: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
}

function SchoolTogglePanel({ schools, visible, colors, onToggle, onSelectAll, onDeselectAll }: SchoolTogglePanelProps) {
  const allSelected = visible.size === schools.length;
  const noneSelected = visible.size === 0;

  return (
    <div className="p-3 bg-muted/30 rounded-lg border space-y-2">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 text-sm font-medium text-foreground">
          <Eye className="w-4 h-4 text-primary" />
          <span>تحكم في عرض المدارس</span>
          <Badge variant="outline" className="text-xs px-1.5 py-0">
            {visible.size} / {schools.length}
          </Badge>
        </div>
        <div className="flex gap-1.5">
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs gap-1"
            onClick={onSelectAll}
            disabled={allSelected}
          >
            <CheckSquare className="w-3 h-3" />
            تحديد الكل
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs gap-1"
            onClick={onDeselectAll}
            disabled={noneSelected}
          >
            <Square className="w-3 h-3" />
            إلغاء الكل
          </Button>
        </div>
      </div>

      {/* School Chips */}
      <div className="flex flex-wrap gap-2">
        {schools.map((name, i) => {
          const isVisible = visible.has(name);
          const color = colors[i % colors.length];
          return (
            <button
              key={name}
              onClick={() => onToggle(name)}
              title={isVisible ? `إخفاء ${name}` : `إظهار ${name}`}
              className={`
                flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium
                border-2 transition-all duration-200 select-none
                ${isVisible
                  ? "text-white shadow-sm scale-100"
                  : "bg-muted text-muted-foreground border-muted-foreground/20 scale-95 opacity-50"
                }
              `}
              style={isVisible ? { backgroundColor: color, borderColor: color } : {}}
            >
              {isVisible
                ? <Eye className="w-3 h-3 shrink-0" />
                : <EyeOff className="w-3 h-3 shrink-0" />
              }
              <span className="max-w-[120px] truncate">{name}</span>
            </button>
          );
        })}
      </div>

      {noneSelected && (
        <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded px-2 py-1">
          ⚠️ لا توجد مدارس مُفعَّلة — اختر مدرسة واحدة على الأقل لعرض الرسم البياني.
        </p>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function UserGrowthCharts() {
  const chartsRef = useRef<HTMLDivElement>(null);
  const [view, setView] = useState<"weekly" | "monthly">("monthly");
  const [isExporting, setIsExporting] = useState(false);
  const [activeSection, setActiveSection] = useState<"users" | "schools">("users");

  // فلتر التاريخ
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const isCustomRange = !!(fromDate && toDate);
  const filterInput = isCustomRange ? { fromDate, toDate } : undefined;

  // حالة إظهار/إخفاء المدارس
  const [visibleSchools, setVisibleSchools] = useState<Set<string>>(new Set());
  const [schoolsInitialized, setSchoolsInitialized] = useState(false);

  // بيانات نمو المستخدمين
  const { data, isLoading } = (trpc.admin as any).userGrowthStats.useQuery(filterInput);

  // بيانات نمو المدارس
  const { data: schoolData, isLoading: schoolLoading } = (trpc.admin as any).schoolGrowthStats.useQuery(filterInput);

  const weekly: Array<{ week: string; count: number }> = data?.weekly ?? [];
  const monthly: Array<{ month: string; count: number }> = data?.monthly ?? [];
  const byAgeGroup: Array<{ name: string; value: number }> = data?.byAgeGroup ?? [];
  const byGender: Array<{ name: string; value: number }> = data?.byGender ?? [];

  const allSchoolNames: string[] = schoolData?.schools ?? [];
  const allSchoolChartData: Array<Record<string, string | number>> = schoolData?.data ?? [];

  // تهيئة visibleSchools عند أول تحميل للمدارس
  useEffect(() => {
    if (allSchoolNames.length > 0 && !schoolsInitialized) {
      setVisibleSchools(new Set(allSchoolNames));
      setSchoolsInitialized(true);
    }
  }, [allSchoolNames, schoolsInitialized]);

  // إعادة التهيئة عند تغيير الفلتر (قد تتغير المدارس)
  useEffect(() => {
    if (allSchoolNames.length > 0) {
      setVisibleSchools(prev => {
        // أضف المدارس الجديدة تلقائياً، احتفظ بحالة القديمة
        const next = new Set(prev);
        allSchoolNames.forEach(n => {
          if (!prev.has(n) && !schoolsInitialized) next.add(n);
          else if (!prev.has(n)) next.add(n); // مدرسة جديدة → أضفها مفعّلة
        });
        // احذف المدارس التي لم تعد موجودة
        prev.forEach(n => {
          if (!allSchoolNames.includes(n)) next.delete(n);
        });
        return next;
      });
    }
  }, [allSchoolNames.join(",")]); // eslint-disable-line react-hooks/exhaustive-deps

  // تصفية بيانات الرسوم البيانية حسب المدارس المُفعَّلة
  const visibleSchoolNames = allSchoolNames.filter(n => visibleSchools.has(n));
  const filteredChartData = allSchoolChartData.map(row => {
    const filtered: Record<string, string | number> = { month: row.month };
    visibleSchoolNames.forEach(n => { filtered[n] = row[n] ?? 0; });
    return filtered;
  });

  const cumulativeData = monthly.reduce<Array<{ month: string; count: number; cumulative: number }>>(
    (acc, item, i) => {
      const prev = i > 0 ? acc[i - 1].cumulative : 0;
      acc.push({ ...item, cumulative: prev + item.count });
      return acc;
    },
    []
  );

  const totalUsers = (data as any)?.totalCount ?? byAgeGroup.reduce((s: number, r: { name: string; value: number }) => s + r.value, 0);
  const currentMonthCount = monthly[monthly.length - 1]?.count ?? 0;
  const prevMonthCount = monthly[monthly.length - 2]?.count ?? 0;
  const growthPct = prevMonthCount > 0
    ? (((currentMonthCount - prevMonthCount) / prevMonthCount) * 100).toFixed(1)
    : "—";

  // إجمالي طلاب كل مدرسة (للبطاقات)
  const schoolTotals = allSchoolNames.map(name => ({
    name,
    total: allSchoolChartData.reduce((sum, row) => sum + (Number(row[name]) || 0), 0),
  }));

  const handleToggleSchool = (name: string) => {
    setVisibleSchools(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const handleSelectAll = () => setVisibleSchools(new Set(allSchoolNames));
  const handleDeselectAll = () => setVisibleSchools(new Set());

  const handleExportExcel = async () => {
    try {
      const XLSX = await import("xlsx");
      const wb = XLSX.utils.book_new();

      // ورقة 1: النمو الشهري
      const monthlyRows = (view === "monthly" ? monthly : weekly).map((r: any) => ({
        "الشهر / الأسبوع": r.month ?? r.week,
        "مستخدمون جدد": r.count,
      }));
      const ws1 = XLSX.utils.json_to_sheet(monthlyRows);
      XLSX.utils.book_append_sheet(wb, ws1, view === "monthly" ? "شهري" : "أسبوعي");

      // ورقة 2: توزيع الفئات العمرية
      if (byAgeGroup.length > 0) {
        const ageRows = byAgeGroup.map((r: any) => ({ "الفئة العمرية": r.name, "العدد": r.value }));
        const ws2 = XLSX.utils.json_to_sheet(ageRows);
        XLSX.utils.book_append_sheet(wb, ws2, "الفئات العمرية");
      }

      // ورقة 3: المدارس المُفعَّلة
      if (visibleSchoolNames.length > 0 && filteredChartData.length > 0) {
        const schoolRows = filteredChartData.map((row: any) => {
          const r: Record<string, any> = { "الشهر": row.month };
          visibleSchoolNames.forEach(n => { r[n] = row[n] ?? 0; });
          return r;
        });
        const ws3 = XLSX.utils.json_to_sheet(schoolRows);
        XLSX.utils.book_append_sheet(wb, ws3, "مقارنة المدارس");
      }

      const date = new Date().toLocaleDateString("ar-SA").replace(/\//g, "-");
      XLSX.writeFile(wb, `إحصائيات_النمو_${date}.xlsx`);
      toast.success("✅ تم تصدير Excel بنجاح");
    } catch (e) {
      toast.error("حدث خطأ أثناء تصدير Excel");
    }
  };

  const handleDownloadPDF = async () => {
    if (!chartsRef.current) return;
    setIsExporting(true);
    try {
      const html2canvas = (await import("html2canvas")).default;
      const { jsPDF } = await import("jspdf");

      const canvas = await html2canvas(chartsRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
      });

      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      const pageHeight = pdf.internal.pageSize.getHeight();
      if (pdfHeight <= pageHeight) {
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      } else {
        let yOffset = 0;
        let remaining = pdfHeight;
        while (remaining > 0) {
          const sliceHeight = Math.min(pageHeight, remaining);
          pdf.addImage(imgData, "PNG", 0, -yOffset, pdfWidth, pdfHeight);
          remaining -= sliceHeight;
          yOffset += sliceHeight;
          if (remaining > 0) pdf.addPage();
        }
      }

      const date = new Date().toLocaleDateString("ar-SA").replace(/\//g, "-");
      pdf.save(`إحصائيات_نمو_${date}.pdf`);
      toast.success("✅ تم تحميل التقرير PDF بنجاح");
    } catch (e) {
      toast.error("حدث خطأ أثناء تحميل PDF");
    } finally {
      setIsExporting(false);
    }
  };

  const handleResetFilter = () => {
    setFromDate("");
    setToDate("");
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p>جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold">إحصائيات نمو المستخدمين</h2>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant={view === "monthly" ? "default" : "outline"}
            size="sm"
            onClick={() => setView("monthly")}
          >
            شهري
          </Button>
          <Button
            variant={view === "weekly" ? "default" : "outline"}
            size="sm"
            onClick={() => setView("weekly")}
          >
            أسبوعي
          </Button>
          <Button
            onClick={handleExportExcel}
            className="gap-2 bg-green-600 hover:bg-green-700 text-white"
            size="sm"
          >
            <FileSpreadsheet className="w-4 h-4" />
            تصدير Excel
          </Button>
          <Button
            onClick={handleDownloadPDF}
            disabled={isExporting}
            className="gap-2 bg-red-600 hover:bg-red-700 text-white"
            size="sm"
          >
            <Download className="w-4 h-4" />
            {isExporting ? "جاري التصدير..." : "تحميل PDF"}
          </Button>
        </div>
      </div>

      {/* Date Filter */}
      <DateFilterBar
        fromDate={fromDate}
        toDate={toDate}
        onFromChange={setFromDate}
        onToChange={setToDate}
        onReset={handleResetFilter}
        isCustom={isCustomRange}
      />

      {/* Section Tabs */}
      <div className="flex gap-2 border-b pb-2">
        <button
          onClick={() => setActiveSection("users")}
          className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
            activeSection === "users"
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Users className="w-4 h-4" />
          نمو المستخدمين
        </button>
        <button
          onClick={() => setActiveSection("schools")}
          className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
            activeSection === "schools"
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <School className="w-4 h-4" />
          مقارنة المدارس
          {activeSection === "schools" && allSchoolNames.length > 0 && (
            <Badge variant="secondary" className="text-xs px-1.5 py-0 mr-1">
              {visibleSchools.size}/{allSchoolNames.length}
            </Badge>
          )}
        </button>
      </div>

      {/* Summary Cards (users section) */}
      {activeSection === "users" && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-4 text-center">
              <p className="text-3xl font-bold text-primary">{totalUsers}</p>
              <p className="text-sm text-muted-foreground mt-1">
                {isCustomRange ? "مستخدمون في الفترة" : "إجمالي المستخدمين"}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 text-center">
              <p className="text-3xl font-bold text-green-600">{currentMonthCount}</p>
              <p className="text-sm text-muted-foreground mt-1">
                {isCustomRange ? "آخر شهر في الفترة" : "مستخدمون هذا الشهر"}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 text-center">
              <p className={`text-3xl font-bold ${growthPct !== "—" && Number(growthPct) >= 0 ? "text-green-600" : "text-red-500"}`}>
                {growthPct !== "—" ? `${growthPct}%` : "—"}
              </p>
              <p className="text-sm text-muted-foreground mt-1">نمو مقارنة بالشهر الماضي</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 text-center">
              <p className="text-3xl font-bold text-purple-600">
                {byGender.find((g: { name: string; value: number }) => g.name === "بنات")?.value ?? 0}
              </p>
              <p className="text-sm text-muted-foreground mt-1">عدد البنات</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Charts area — captured for PDF */}
      <div ref={chartsRef} className="space-y-6 bg-white p-4 rounded-xl">

        {/* ─── Users Growth Section ─── */}
        {activeSection === "users" && (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <BarChart2 className="w-4 h-4" />
                  {view === "monthly"
                    ? `نمو المستخدمين الجدد شهرياً${isCustomRange ? " (فترة مخصصة)" : " (آخر 12 شهر)"}`
                    : `نمو المستخدمين الجدد أسبوعياً${isCustomRange ? " (فترة مخصصة)" : " (آخر 12 أسبوع)"}`}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  {view === "monthly" ? (
                    <BarChart data={monthly} margin={{ top: 5, right: 20, left: 0, bottom: 60 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} angle={-35} textAnchor="end" interval={0} />
                      <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                      <Tooltip
                        formatter={(v: number) => [`${v} مستخدم`, "مستخدمون جدد"]}
                        contentStyle={{ direction: "rtl", fontFamily: "inherit" }}
                      />
                      <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} name="مستخدمون جدد" />
                    </BarChart>
                  ) : (
                    <LineChart data={weekly} margin={{ top: 5, right: 20, left: 0, bottom: 60 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="week" tick={{ fontSize: 11 }} angle={-35} textAnchor="end" interval={0} />
                      <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                      <Tooltip
                        formatter={(v: number) => [`${v} مستخدم`, "مستخدمون جدد"]}
                        contentStyle={{ direction: "rtl", fontFamily: "inherit" }}
                      />
                      <Line
                        type="monotone" dataKey="count" stroke="#6366f1"
                        strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }}
                        name="مستخدمون جدد"
                      />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <PieIcon className="w-4 h-4" />
                    توزيع الفئات العمرية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {byAgeGroup.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">لا توجد بيانات بعد</p>
                  ) : (
                    <ResponsiveContainer width="100%" height={260}>
                      <PieChart>
                        <Pie
                          data={byAgeGroup} dataKey="value" nameKey="name"
                          cx="50%" cy="50%" outerRadius={90}
                          label={({ name, percent }: { name: string; percent: number }) =>
                            `${name} (${(percent * 100).toFixed(0)}%)`}
                          labelLine={true}
                        >
                          {byAgeGroup.map((_item: { name: string; value: number }, i: number) => (
                            <Cell key={i} fill={COLORS[i % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(v: number) => [`${v} مستخدم`]} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Users className="w-4 h-4" />
                    توزيع الجنس
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {byGender.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">لا توجد بيانات بعد</p>
                  ) : (
                    <ResponsiveContainer width="100%" height={260}>
                      <PieChart>
                        <Pie
                          data={byGender} dataKey="value" nameKey="name"
                          cx="50%" cy="50%" outerRadius={90}
                          label={({ name, percent }: { name: string; percent: number }) =>
                            `${name} (${(percent * 100).toFixed(0)}%)`}
                        >
                          <Cell fill="#6366f1" />
                          <Cell fill="#f59e0b" />
                        </Pie>
                        <Tooltip formatter={(v: number) => [`${v} مستخدم`]} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <TrendingUp className="w-4 h-4" />
                  النمو التراكمي للمستخدمين{isCustomRange ? " (فترة مخصصة)" : " (آخر 12 شهر)"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={cumulativeData} margin={{ top: 5, right: 20, left: 0, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} angle={-35} textAnchor="end" interval={0} />
                    <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                    <Tooltip
                      formatter={(v: number) => [`${v} مستخدم`]}
                      contentStyle={{ direction: "rtl", fontFamily: "inherit" }}
                    />
                    <Line
                      type="monotone" dataKey="cumulative" stroke="#10b981"
                      strokeWidth={2.5} dot={{ r: 3 }} name="إجمالي تراكمي"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </>
        )}

        {/* ─── Schools Comparison Section ─── */}
        {activeSection === "schools" && (
          <>
            {schoolLoading ? (
              <div className="flex items-center justify-center h-40 text-muted-foreground">
                <div className="text-center space-y-2">
                  <div className="w-6 h-6 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-sm">جاري تحميل بيانات المدارس...</p>
                </div>
              </div>
            ) : allSchoolNames.length === 0 ? (
              <Card>
                <CardContent className="py-16 text-center text-muted-foreground">
                  <School className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  <p>لا توجد مدارس مسجلة بعد</p>
                </CardContent>
              </Card>
            ) : (
              <>
                {/* School Visibility Toggle Panel */}
                <SchoolTogglePanel
                  schools={allSchoolNames}
                  visible={visibleSchools}
                  colors={COLORS}
                  onToggle={handleToggleSchool}
                  onSelectAll={handleSelectAll}
                  onDeselectAll={handleDeselectAll}
                />

                {/* Summary cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card className="border-2 border-primary/20">
                    <CardContent className="pt-4 text-center">
                      <p className="text-3xl font-bold text-primary">{allSchoolNames.length}</p>
                      <p className="text-sm text-muted-foreground mt-1">إجمالي المدارس</p>
                    </CardContent>
                  </Card>
                  {schoolTotals.slice(0, 3).map((s, i) => {
                    const isVis = visibleSchools.has(s.name);
                    return (
                      <Card
                        key={i}
                        className={`cursor-pointer transition-all duration-200 border-2 ${isVis ? "opacity-100" : "opacity-40"}`}
                        style={{ borderColor: isVis ? COLORS[i % COLORS.length] : undefined }}
                        onClick={() => handleToggleSchool(s.name)}
                        title={isVis ? `إخفاء ${s.name}` : `إظهار ${s.name}`}
                      >
                        <CardContent className="pt-4 text-center">
                          <p className="text-3xl font-bold" style={{ color: COLORS[i % COLORS.length] }}>
                            {s.total}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1 truncate px-1" title={s.name}>
                            {s.name}
                          </p>
                          <p className="text-xs mt-0.5">
                            {isVis
                              ? <span className="text-green-600">● ظاهر</span>
                              : <span className="text-muted-foreground">○ مخفي</span>
                            }
                          </p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {visibleSchools.size === 0 ? (
                  <Card>
                    <CardContent className="py-12 text-center text-muted-foreground">
                      <EyeOff className="w-10 h-10 mx-auto mb-3 opacity-40" />
                      <p className="font-medium">جميع المدارس مخفية</p>
                      <p className="text-sm mt-1">اختر مدرسة واحدة على الأقل من لوحة التحكم أعلاه</p>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-3 gap-1"
                        onClick={handleSelectAll}
                      >
                        <CheckSquare className="w-3 h-3" />
                        إظهار جميع المدارس
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    {/* Multi-line chart */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-base flex-wrap">
                          <School className="w-4 h-4 shrink-0" />
                          <span>مقارنة نمو الطلاب بين المدارس شهرياً</span>
                          {isCustomRange && <Badge variant="secondary" className="text-xs">فترة مخصصة</Badge>}
                          <Badge variant="outline" className="text-xs mr-auto">
                            {visibleSchoolNames.length} مدرسة مُعروضة
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={360}>
                          <LineChart
                            data={filteredChartData}
                            margin={{ top: 5, right: 20, left: 0, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                            <XAxis
                              dataKey="month"
                              tick={{ fontSize: 10 }}
                              angle={-35}
                              textAnchor="end"
                              interval={0}
                            />
                            <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                            <Tooltip
                              formatter={(v: number, name: string) => [`${v} طالب`, name]}
                              contentStyle={{ direction: "rtl", fontFamily: "inherit" }}
                            />
                            <Legend wrapperStyle={{ paddingTop: "10px" }} />
                            {visibleSchoolNames.map((name, i) => {
                              const colorIdx = allSchoolNames.indexOf(name);
                              return (
                                <Line
                                  key={name}
                                  type="monotone"
                                  dataKey={name}
                                  stroke={COLORS[colorIdx % COLORS.length]}
                                  strokeWidth={2}
                                  dot={{ r: 3 }}
                                  activeDot={{ r: 5 }}
                                />
                              );
                            })}
                          </LineChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    {/* Stacked bar chart */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-base">
                          <BarChart2 className="w-4 h-4" />
                          إجمالي الطلاب الجدد لكل مدرسة (مقارنة شاملة)
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart
                            data={filteredChartData}
                            margin={{ top: 5, right: 20, left: 0, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                            <XAxis
                              dataKey="month"
                              tick={{ fontSize: 10 }}
                              angle={-35}
                              textAnchor="end"
                              interval={0}
                            />
                            <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                            <Tooltip
                              formatter={(v: number, name: string) => [`${v} طالب`, name]}
                              contentStyle={{ direction: "rtl", fontFamily: "inherit" }}
                            />
                            <Legend wrapperStyle={{ paddingTop: "10px" }} />
                            {visibleSchoolNames.map((name, i) => {
                              const colorIdx = allSchoolNames.indexOf(name);
                              return (
                                <Bar
                                  key={name}
                                  dataKey={name}
                                  stackId="schools"
                                  fill={COLORS[colorIdx % COLORS.length]}
                                  name={name}
                                />
                              );
                            })}
                          </BarChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>
                  </>
                )}
              </>
            )}
          </>
        )}

      </div>
    </div>
  );
}
