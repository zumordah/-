import { useEffect, useState } from "react";

interface FloatingItem {
  id: number;
  points: number;
  x: number;
  y: number;
  label?: string;
}

interface FloatingPointsProps {
  items: FloatingItem[];
  onRemove: (id: number) => void;
}

export function FloatingPoints({ items, onRemove }: FloatingPointsProps) {
  return (
    <div className="fixed inset-0 pointer-events-none z-[9998]">
      {items.map((item) => (
        <FloatingPointItem key={item.id} item={item} onRemove={onRemove} />
      ))}
    </div>
  );
}

function FloatingPointItem({ item, onRemove }: { item: FloatingItem; onRemove: (id: number) => void }) {
  const [visible, setVisible] = useState(true);
  const [risen, setRisen] = useState(false);

  useEffect(() => {
    // Trigger rise animation
    const riseTimer = setTimeout(() => setRisen(true), 50);
    // Remove after animation
    const removeTimer = setTimeout(() => {
      setVisible(false);
      onRemove(item.id);
    }, 1400);

    return () => {
      clearTimeout(riseTimer);
      clearTimeout(removeTimer);
    };
  }, [item.id, onRemove]);

  if (!visible) return null;

  const isBonus = item.points >= 20;
  const isMedium = item.points >= 10;

  return (
    <div
      className="absolute select-none font-black"
      style={{
        left: item.x,
        top: item.y,
        transform: risen ? "translateY(-80px) scale(1.2)" : "translateY(0) scale(0.8)",
        opacity: risen ? 0 : 1,
        transition: "transform 1.2s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 1.2s ease-in",
        fontSize: isBonus ? "2rem" : isMedium ? "1.6rem" : "1.3rem",
        color: isBonus ? "#FFD700" : isMedium ? "#FF6B35" : "#4CAF50",
        textShadow: isBonus
          ? "0 0 10px rgba(255,215,0,0.8), 2px 2px 0 rgba(0,0,0,0.3)"
          : "2px 2px 0 rgba(0,0,0,0.2)",
        whiteSpace: "nowrap",
      }}
    >
      {isBonus && <span className="mr-1">🌟</span>}
      {isMedium && !isBonus && <span className="mr-1">⭐</span>}
      {!isMedium && <span className="mr-1">✨</span>}
      +{item.points}
      {item.label && <span className="text-sm font-bold mr-1"> {item.label}</span>}
    </div>
  );
}

// Hook to manage floating points
let nextId = 1;

export function useFloatingPoints() {
  const [items, setItems] = useState<FloatingItem[]>([]);

  const showPoints = (points: number, x?: number, y?: number, label?: string) => {
    const id = nextId++;
    // Default to center-ish of screen
    const px = x ?? window.innerWidth / 2 - 40;
    const py = y ?? window.innerHeight * 0.4;
    setItems((prev) => [...prev, { id, points, x: px, y: py, label }]);
  };

  const removeItem = (id: number) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  return { items, showPoints, removeItem };
}
