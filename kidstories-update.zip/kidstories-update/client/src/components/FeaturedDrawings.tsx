import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export function FeaturedDrawings() {
  const { data } = trpc.drawings.getFeatured.useQuery();

  if (!data || data.length === 0) return null;

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-purple-600">🎨 أفضل رسومات الأطفال</h2>
        <Link href="/artist-gallery" className="text-purple-600 hover:underline">عرض الكل →</Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {data.map((drawing: any) => (
          <Card key={drawing.id} className="overflow-hidden hover:shadow-lg transition">
            <img src={drawing.imageUrl} alt={drawing.childName} className="w-full h-40 object-cover" />
            <div className="p-3">
              <p className="font-bold text-sm">{drawing.childName}</p>
              <p className="text-xs text-gray-600">{drawing.storyTitle}</p>
              <div className="flex gap-1 mt-2">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className={i < (drawing.rating || 0) ? "text-yellow-500 text-xs" : "text-gray-300 text-xs"}>⭐</span>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}
