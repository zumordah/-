import { useState, useEffect, useCallback, useRef } from 'react';
import { useChild } from '@/contexts/ChildContext';
import { trpc } from '@/lib/trpc';
import { getCharacterById, getDefaultCharacter } from '@/data/charactersData';

// روابط الأصوات البشرية حسب الجنس والموقف
const SOUNDS = {
  boy: {
    welcome:  'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-welcome-boy_fb69ba85.wav',
    retry:    'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-retry-boy_3e58eb96.wav',
    win:      'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-win-boy_de90cf3d.wav',
    activity: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-activity-boy_d6958f7c.wav',
  },
  girl: {
    welcome:  'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-welcome-girl_afadca09.wav',
    retry:    'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-retry-girl_e532c88d.wav',
    win:      'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-win-girl_9e70bf3f.wav',
    activity: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/companion-activity-girl_4c3eb77f.wav',
  },
};

type CompanionState = 'idle' | 'welcome' | 'celebrate' | 'encourage' | 'activity' | 'farewell';

// رسائل احتياطية ثابتة في حال عدم وجود شخصية
const FALLBACK_MESSAGES: Record<CompanionState, string> = {
  idle: '',
  welcome:   'هلا! يلا نتعلم سوا! 🌟',
  celebrate: 'أحسنت! كنت عارف إنك تقدر! 🎉',
  encourage: 'ما عليك! حاول مرة ثانية، أنت تقدر! 💪',
  activity:  'هيا نجمع النقاط ونكون الأبطال! ⭐',
  farewell:  'مع السلامة! نشوفك بكرة! 👋',
};

// اختيار رسالة عشوائية من مصفوفة
function pickRandom(arr: string[]): string {
  return arr[Math.floor(Math.random() * arr.length)];
}

// CSS animations مدمجة في الكود
const COMPANION_STYLES = `
  @keyframes companionFloat {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    25%       { transform: translateY(-6px) rotate(-2deg); }
    75%       { transform: translateY(-3px) rotate(2deg); }
  }
  @keyframes companionBounce {
    0%, 100% { transform: translateY(0px) scale(1); }
    20%       { transform: translateY(-12px) scale(1.05); }
    40%       { transform: translateY(-6px) scale(0.97); }
    60%       { transform: translateY(-10px) scale(1.03); }
    80%       { transform: translateY(-4px) scale(0.99); }
  }
  @keyframes companionCelebrateBig {
    0%   { transform: scale(1) translateY(0); }
    10%  { transform: scale(1.5) translateY(-14px); }
    25%  { transform: scale(1.45) translateY(-10px); }
    40%  { transform: scale(1.5) translateY(-14px); }
    55%  { transform: scale(1.45) translateY(-10px); }
    70%  { transform: scale(1.5) translateY(-14px); }
    85%  { transform: scale(1.3) translateY(-6px); }
    100% { transform: scale(1) translateY(0); }
  }
  @keyframes clapHands {
    0%, 100% { transform: scale(1) rotate(0deg); }
    25%       { transform: scale(1.3) rotate(-15deg); }
    50%       { transform: scale(1.5) rotate(0deg); }
    75%       { transform: scale(1.3) rotate(15deg); }
  }
  .companion-celebrate-big { animation: companionCelebrateBig 0.8s ease-in-out infinite; }
  .clap-emoji { animation: clapHands 0.4s ease-in-out infinite; display: inline-block; }
  @keyframes companionShake {
    0%, 100% { transform: translateX(0) rotate(0deg); }
    15%       { transform: translateX(-4px) rotate(-3deg); }
    30%       { transform: translateX(4px) rotate(3deg); }
    45%       { transform: translateX(-3px) rotate(-2deg); }
    60%       { transform: translateX(3px) rotate(2deg); }
    75%       { transform: translateX(-2px) rotate(-1deg); }
  }
  @keyframes companionWave {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    20%       { transform: translateY(-8px) rotate(-5deg); }
    40%       { transform: translateY(-4px) rotate(5deg); }
    60%       { transform: translateY(-8px) rotate(-3deg); }
    80%       { transform: translateY(-2px) rotate(3deg); }
  }
  @keyframes scarfSway {
    0%, 100% { transform: rotate(0deg) skewX(0deg); }
    25%       { transform: rotate(8deg) skewX(3deg); }
    75%       { transform: rotate(-8deg) skewX(-3deg); }
  }
  @keyframes scarfSwayFast {
    0%, 100% { transform: rotate(0deg) skewX(0deg); }
    20%       { transform: rotate(15deg) skewX(5deg); }
    40%       { transform: rotate(-12deg) skewX(-4deg); }
    60%       { transform: rotate(10deg) skewX(3deg); }
    80%       { transform: rotate(-8deg) skewX(-2deg); }
  }
  @keyframes glowPulse {
    0%, 100% { filter: drop-shadow(0 0 4px var(--char-color)); }
    50%       { filter: drop-shadow(0 0 14px var(--char-color)) drop-shadow(0 0 6px rgba(255,255,255,0.8)); }
  }
  @keyframes starBurst {
    0%   { transform: scale(0) rotate(0deg); opacity: 1; }
    50%  { transform: scale(1.5) rotate(180deg); opacity: 0.8; }
    100% { transform: scale(0) rotate(360deg); opacity: 0; }
  }
  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes bubblePop {
    0%   { transform: scale(0.5); opacity: 0; }
    60%  { transform: scale(1.08); opacity: 1; }
    100% { transform: scale(1); opacity: 1; }
  }
  .companion-idle     { animation: companionFloat 3s ease-in-out infinite; }
  .companion-welcome  { animation: companionWave 0.8s ease-in-out infinite; }
  .companion-celebrate{ animation: companionCelebrateBig 0.8s ease-in-out infinite; }
  .companion-encourage{ animation: companionShake 0.5s ease-in-out 3; }
  .companion-activity { animation: companionBounce 0.7s ease-in-out infinite; }
  .companion-farewell { animation: companionWave 0.8s ease-in-out 4; }
  .scarf-idle         { animation: scarfSway 2.5s ease-in-out infinite; transform-origin: top center; }
  .scarf-active       { animation: scarfSwayFast 0.4s ease-in-out infinite; transform-origin: top center; }
  .companion-glow     { animation: glowPulse 1s ease-in-out infinite; }
  .bubble-pop         { animation: bubblePop 0.35s cubic-bezier(0.34,1.56,0.64,1) forwards; }
`;

interface CompanionCharacterProps {
  trigger?: 'celebration' | 'encouragement' | 'activity' | 'farewell' | null;
  onTriggerHandled?: () => void;
}

export default function CompanionCharacter({ trigger, onTriggerHandled }: CompanionCharacterProps) {
  const { child } = useChild();
  const [isVisible, setIsVisible] = useState(false);
  const [companionState, setCompanionState] = useState<CompanionState>('idle');
  const [isExpanded, setIsExpanded] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [starBursts, setStarBursts] = useState<number[]>([]);
  const [currentMessage, setCurrentMessage] = useState<string>('');

  const { data: companionData } = trpc.companion.getMyCompanion.useQuery(
    { childId: child?.id ?? 0 },
    { enabled: !!child?.id, staleTime: 60000 }
  );

  const characterId = companionData?.characterId ?? 'sami';
  const character = getCharacterById(characterId) ?? getDefaultCharacter();
  const gender = character.gender as 'boy' | 'girl';

  const playSound = useCallback((soundKey: keyof typeof SOUNDS.boy) => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    const url = SOUNDS[gender][soundKey];
    const audio = new Audio(url);
    audioRef.current = audio;
    audio.play().catch(() => {});
  }, [gender]);

  const triggerStarBurst = useCallback(() => {
    const id = Date.now();
    setStarBursts(prev => [...prev, id]);
    setTimeout(() => setStarBursts(prev => prev.filter(x => x !== id)), 1200);
  }, []);

  const getMessageForState = useCallback((state: CompanionState): string => {
    if (state === 'celebrate') return pickRandom(character.celebrations);
    if (state === 'encourage') return pickRandom(character.encouragements);
    if (state === 'welcome')   return pickRandom(character.greetings);
    if (state === 'activity')  return pickRandom(character.encouragements);
    if (state === 'farewell')  return pickRandom(character.farewells);
    return FALLBACK_MESSAGES[state];
  }, [character]);

  const showState = useCallback((state: CompanionState, soundKey: keyof typeof SOUNDS.boy, duration = 5500) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setCompanionState(state);
    setCurrentMessage(getMessageForState(state));
    setIsExpanded(true);
    playSound(soundKey);
    if (state === 'celebrate') {
      triggerStarBurst();
      setTimeout(triggerStarBurst, 400);
      setTimeout(triggerStarBurst, 800);
    }
    timerRef.current = setTimeout(() => {
      setIsExpanded(false);
      setCompanionState('idle');
    }, duration);
  }, [playSound, triggerStarBurst]);

  // الاستماع لأحداث الألعاب عبر CustomEvent
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.type === 'celebration') showState('celebrate', 'win', 5500);
      else if (detail?.type === 'encouragement') showState('encourage', 'retry', 5000);
      else if (detail?.type === 'activity') showState('activity', 'activity', 5000);
      else if (detail?.type === 'farewell') showState('farewell', 'welcome', 4000);
    };
    window.addEventListener('companion-trigger', handler);
    return () => window.removeEventListener('companion-trigger', handler);
  }, [showState]);

  // ترحيب عند الدخول
  useEffect(() => {
    if (child?.id) {
      const timer = setTimeout(() => {
        setIsVisible(true);
        showState('welcome', 'welcome', 6000);
      }, 1800);
      return () => clearTimeout(timer);
    }
  }, [child?.id, characterId]);

  // معالجة الـ triggers
  useEffect(() => {
    if (trigger === 'celebration') {
      showState('celebrate', 'win', 5500);
      onTriggerHandled?.();
    } else if (trigger === 'encouragement') {
      showState('encourage', 'retry', 5000);
      onTriggerHandled?.();
    } else if (trigger === 'activity') {
      showState('activity', 'activity', 5000);
      onTriggerHandled?.();
    } else if (trigger === 'farewell') {
      showState('farewell', 'welcome', 4000);
      onTriggerHandled?.();
    }
  }, [trigger]);

  const handleClick = () => {
    if (isExpanded) {
      setIsExpanded(false);
      setCompanionState('idle');
      if (audioRef.current) audioRef.current.pause();
    } else {
      showState('welcome', 'welcome', 5500);
    }
  };

  if (!child?.id || !isVisible) return null;

  const isActive = companionState !== 'idle';
  const bodyClass = `companion-${companionState}`;
  const scarfClass = isActive ? 'scarf-active' : 'scarf-idle';
  const glowClass = isActive ? 'companion-glow' : '';

  // ألوان الوشاح حسب الشخصية
  const scarfColor = character.color;
  const scarfColorLight = `${character.color}88`;

  return (
    <>
      <style>{COMPANION_STYLES}</style>
      <div
        className="fixed bottom-6 left-4 z-50 flex flex-col items-center gap-2"
        style={{ direction: 'ltr' }}
      >
        {/* نجوم الاحتفال */}
        {starBursts.map(id => (
          <div key={id} className="pointer-events-none absolute inset-0 flex items-center justify-center">
            {['⭐','🌟','✨','💫'].map((star, i) => (
              <span
                key={i}
                className="absolute text-xl"
                style={{
                  animation: `starBurst 1s ease-out ${i * 0.1}s forwards`,
                  top: `${20 + Math.sin(i * 90 * Math.PI / 180) * 40}px`,
                  left: `${20 + Math.cos(i * 90 * Math.PI / 180) * 40}px`,
                }}
              >
                {star}
              </span>
            ))}
          </div>
        ))}

        {/* فقاعة الكلام */}
        {isExpanded && companionState !== 'idle' && (
          <div
            className="bubble-pop relative max-w-[210px] rounded-2xl shadow-xl border-2 p-3 text-center"
            style={{
              borderColor: character.color,
              background: 'white',
              direction: 'rtl',
            }}
          >
            <p className="text-sm font-bold text-gray-800 leading-relaxed">
              {currentMessage || FALLBACK_MESSAGES[companionState]}
            </p>
            {/* ذيل الفقاعة */}
            <div
              className="absolute -bottom-3 left-7 w-0 h-0"
              style={{
                borderLeft: '8px solid transparent',
                borderRight: '8px solid transparent',
                borderTop: `12px solid ${character.color}`,
              }}
            />
          </div>
        )}

        {/* الشخصية */}
        <button
          onClick={handleClick}
          className="relative cursor-pointer select-none"
          title={`${character.name} - اضغط للتحدث`}
          style={{ background: 'none', border: 'none', padding: 0 }}
        >
          {/* حاوية الجسم مع الأنيميشن */}
          <div
            className={`relative ${bodyClass} ${glowClass}`}
            style={{ '--char-color': character.color } as React.CSSProperties}
          >
            {/* أيدي التصفيق عند الاحتفال - أكبر وأكثر حيوية */}
            {companionState === 'celebrate' && (
              <>
                <span className="clap-emoji absolute -left-8 top-1/3 -translate-y-1/2 text-3xl" style={{ animationDelay: '0s' }}>👏</span>
                <span className="clap-emoji absolute -right-8 top-1/3 -translate-y-1/2 text-3xl" style={{ animationDelay: '0.15s' }}>👏</span>
                <span className="clap-emoji absolute left-1/2 -translate-x-1/2 -top-8 text-2xl" style={{ animationDelay: '0.3s' }}>🎉</span>
              </>
            )}
            {/* صورة الشخصية - بدون خلفية بيضاء */}
            <img
              src={character.imageUrl}
              alt={character.name}
              className="w-20 h-20 object-contain"
              style={{
                filter: isActive
                  ? `drop-shadow(0 0 8px ${character.color}) drop-shadow(0 0 4px ${character.color})`
                  : 'drop-shadow(0 3px 6px rgba(0,0,0,0.22))',
                transition: 'filter 0.3s ease',
              }}
            />

            {/* الوشاح المتحرك - شريط ملوّن تحت الصورة */}
            <div
              className={`absolute -bottom-1 left-1/2 ${scarfClass}`}
              style={{
                width: '60%',
                height: '8px',
                marginLeft: '-30%',
                borderRadius: '4px',
                background: `linear-gradient(90deg, ${scarfColor}, ${scarfColorLight}, ${scarfColor})`,
                boxShadow: `0 2px 6px ${scarfColorLight}`,
              }}
            />

            {/* هالة الاحتفال */}
            {companionState === 'celebrate' && (
              <div
                className="absolute inset-0 rounded-full animate-ping opacity-25 pointer-events-none"
                style={{ backgroundColor: character.color }}
              />
            )}
          </div>

          {/* نقطة تنبيه */}
          {!isExpanded && (
            <span
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white text-xs font-bold animate-pulse"
              style={{ backgroundColor: character.color }}
            >
              !
            </span>
          )}
        </button>

        {/* اسم الشخصية */}
        <span
          className="text-xs font-bold px-2 py-0.5 rounded-full text-white shadow-sm"
          style={{ backgroundColor: character.color, direction: 'rtl' }}
        >
          {character.name}
        </span>
      </div>
    </>
  );
}

// Hook للتحكم في الشخصية من أي مكان
export function useCompanion() {
  const [trigger, setTrigger] = useState<'celebration' | 'encouragement' | 'activity' | 'farewell' | null>(null);

  const celebrate  = useCallback(() => setTrigger('celebration'),  []);
  const encourage  = useCallback(() => setTrigger('encouragement'), []);
  const goActivity = useCallback(() => setTrigger('activity'),      []);
  const sayFarewell = useCallback(() => setTrigger('farewell'),     []);

  const handleTriggerHandled = useCallback(() => setTrigger(null), []);

  return { trigger, celebrate, encourage, goActivity, sayFarewell, handleTriggerHandled };
}
