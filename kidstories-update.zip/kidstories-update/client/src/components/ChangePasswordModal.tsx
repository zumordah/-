/**
 * ChangePasswordModal
 * نافذة تغيير كلمة المرور للأدمن من داخل لوحة التحكم
 */
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Eye, EyeOff, Lock, X, CheckCircle } from "lucide-react";

interface ChangePasswordModalProps {
  onClose: () => void;
}

export default function ChangePasswordModal({ onClose }: ChangePasswordModalProps) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [success, setSuccess] = useState(false);

  // جلب إيميل الأدمن من الجلسة المحفوظة
  const adminEmail = (() => {
    try {
      const session = JSON.parse(localStorage.getItem("adminSession") || "{}");
      return session.email || "";
    } catch { return ""; }
  })();

  const changePasswordMut = trpc.admin.changePassword.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setSuccess(true);
      setTimeout(onClose, 2000);
    },
    onError: (err) => {
      toast.error(err.message || "حدث خطأ أثناء تغيير كلمة المرور");
    },
  });

  const handleSubmit = () => {
    if (!adminEmail) { toast.error("يرجى تسجيل الدخول أولاً"); return; }
    if (!currentPassword.trim()) { toast.error("يرجى إدخال كلمة المرور الحالية"); return; }
    if (newPassword.length < 6) { toast.error("كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل"); return; }
    if (newPassword !== confirmPassword) { toast.error("كلمة المرور الجديدة وتأكيدها غير متطابقتين"); return; }
    if (newPassword === currentPassword) { toast.error("كلمة المرور الجديدة يجب أن تختلف عن الحالية"); return; }
    changePasswordMut.mutate({ email: adminEmail, currentPassword, newPassword });
  };

  // قوة كلمة المرور
  const getStrength = (pwd: string) => {
    if (!pwd) return { level: 0, label: "", color: "" };
    let score = 0;
    if (pwd.length >= 6) score++;
    if (pwd.length >= 10) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;
    if (score <= 1) return { level: score, label: "ضعيفة", color: "bg-red-400" };
    if (score <= 3) return { level: score, label: "متوسطة", color: "bg-yellow-400" };
    return { level: score, label: "قوية", color: "bg-green-400" };
  };

  const strength = getStrength(newPassword);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(4px)" }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden" dir="rtl">
        {/* Header */}
        <div
          className="px-6 py-5 flex items-center justify-between text-white"
          style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-lg">تغيير كلمة المرور</h2>
              <p className="text-xs text-white/70">لوحة تحكم المؤسس</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          {success ? (
            <div className="text-center py-6">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-3" />
              <p className="text-lg font-bold text-gray-800">تم تغيير كلمة المرور بنجاح!</p>
              <p className="text-sm text-gray-500 mt-1">سيتم إغلاق هذه النافذة تلقائياً...</p>
            </div>
          ) : (
            <>
              {/* كلمة المرور الحالية */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور الحالية</label>
                <div className="relative">
                  <Input
                    type={showCurrent ? "text" : "password"}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="أدخل كلمة المرور الحالية"
                    className="h-11 rounded-xl border-2 pr-4 pl-10 text-sm"
                    dir="ltr"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrent(!showCurrent)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* كلمة المرور الجديدة */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور الجديدة</label>
                <div className="relative">
                  <Input
                    type={showNew ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="6 أحرف على الأقل"
                    className="h-11 rounded-xl border-2 pr-4 pl-10 text-sm"
                    dir="ltr"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNew(!showNew)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {/* مؤشر قوة كلمة المرور */}
                {newPassword && (
                  <div className="mt-2">
                    <div className="flex gap-1 mb-1">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div
                          key={i}
                          className={`h-1.5 flex-1 rounded-full transition-all ${i <= strength.level ? strength.color : "bg-gray-200"}`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-gray-500">قوة كلمة المرور: <span className="font-semibold">{strength.label}</span></p>
                  </div>
                )}
              </div>

              {/* تأكيد كلمة المرور */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">تأكيد كلمة المرور الجديدة</label>
                <div className="relative">
                  <Input
                    type={showConfirm ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="أعد إدخال كلمة المرور الجديدة"
                    className={`h-11 rounded-xl border-2 pr-4 pl-10 text-sm ${confirmPassword && confirmPassword !== newPassword ? "border-red-400" : confirmPassword && confirmPassword === newPassword ? "border-green-400" : ""}`}
                    dir="ltr"
                    onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {confirmPassword && confirmPassword !== newPassword && (
                  <p className="text-xs text-red-500 mt-1">كلمتا المرور غير متطابقتين</p>
                )}
              </div>

              {/* أزرار */}
              <div className="flex gap-3 pt-2">
                <Button
                  onClick={handleSubmit}
                  disabled={changePasswordMut.isPending}
                  className="flex-1 h-11 rounded-xl font-bold text-sm"
                  style={{ background: "linear-gradient(135deg, #6c63ff, #a855f7)" }}
                >
                  {changePasswordMut.isPending ? "⏳ جارٍ التغيير..." : "🔐 تغيير كلمة المرور"}
                </Button>
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="h-11 px-5 rounded-xl text-sm"
                >
                  إلغاء
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
