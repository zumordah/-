import { useState, useRef, useCallback } from 'react';
import { Mic, MicOff, Square, Play, Pause, Trash2, Save } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useChild } from '@/contexts/ChildContext';
import { toast } from 'sonner';

interface VoiceRecorderProps {
  storyId?: number;
  storyTitle?: string;
  onSaved?: () => void;
}

export default function VoiceRecorder({ storyId, storyTitle, onSaved }: VoiceRecorderProps) {
  const { child } = useChild();
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isSaving, setIsSaving] = useState(false);
  const [title, setTitle] = useState(storyTitle ? `تسجيل: ${storyTitle}` : 'تسجيلي الصوتي');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const saveRecordingMutation = trpc.recordings.saveRecording.useMutation({
    onSuccess: () => {
      toast.success('تم حفظ التسجيل بنجاح! 🎙️');
      setAudioBlob(null);
      setAudioUrl(null);
      setRecordingTime(0);
      onSaved?.();
    },
    onError: (err) => {
      toast.error(err.message || 'حدث خطأ أثناء الحفظ');
    },
    onSettled: () => setIsSaving(false),
  });

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      setRecordingTime(0);

      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          if (prev >= 120) { // حد أقصى 2 دقيقة
            stopRecording();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err) {
      toast.error('لا يمكن الوصول للميكروفون. تأكد من منح الإذن.');
    }
  }, []);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [isRecording]);

  const togglePlay = useCallback(() => {
    if (!audioUrl) return;
    if (!audioRef.current) {
      audioRef.current = new Audio(audioUrl);
      audioRef.current.onended = () => setIsPlaying(false);
      audioRef.current.ondurationchange = () => {
        setDuration(Math.round(audioRef.current?.duration ?? 0));
      };
    }
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play();
      setIsPlaying(true);
    }
  }, [audioUrl, isPlaying]);

  const discardRecording = () => {
    setAudioBlob(null);
    setAudioUrl(null);
    setRecordingTime(0);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setIsPlaying(false);
  };

  const saveRecording = async () => {
    if (!audioBlob || !child?.id) return;
    setIsSaving(true);

    try {
      // رفع الصوت إلى S3 عبر API
      const formData = new FormData();
      formData.append('file', audioBlob, `recording-${Date.now()}.webm`);
      formData.append('childId', String(child.id));

      const response = await fetch('/api/upload-recording', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('فشل رفع الملف');
      const { url, key } = await response.json();

      await saveRecordingMutation.mutateAsync({
        childId: child.id,
        title,
        audioUrl: url,
        audioKey: key,
        durationSeconds: recordingTime || duration,
        storyId,
      });
    } catch (err: any) {
      toast.error(err.message || 'حدث خطأ أثناء الحفظ');
      setIsSaving(false);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-md p-4 border border-purple-100" dir="rtl">
      <h3 className="font-bold text-purple-800 mb-3 flex items-center gap-2">
        <Mic className="w-4 h-4" />
        سجّل صوتك
      </h3>

      {/* حقل العنوان */}
      {audioBlob && (
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm mb-3 focus:outline-none focus:border-purple-400"
          placeholder="اسم التسجيل..."
        />
      )}

      {/* مؤقت التسجيل */}
      {isRecording && (
        <div className="flex items-center justify-center gap-2 mb-3">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
          <span className="text-red-600 font-bold text-lg">{formatTime(recordingTime)}</span>
          <span className="text-xs text-gray-400">/ 2:00</span>
        </div>
      )}

      {/* شريط التقدم */}
      {isRecording && (
        <div className="w-full bg-gray-100 rounded-full h-2 mb-3">
          <div
            className="bg-red-500 h-2 rounded-full transition-all"
            style={{ width: `${(recordingTime / 120) * 100}%` }}
          />
        </div>
      )}

      {/* أزرار التحكم */}
      <div className="flex items-center justify-center gap-3">
        {!isRecording && !audioBlob && (
          <button
            onClick={startRecording}
            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-md"
          >
            <Mic className="w-5 h-5" />
            ابدأ التسجيل
          </button>
        )}

        {isRecording && (
          <button
            onClick={stopRecording}
            className="flex items-center gap-2 bg-gray-700 hover:bg-gray-800 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-md"
          >
            <Square className="w-5 h-5" />
            إيقاف
          </button>
        )}

        {audioBlob && !isRecording && (
          <>
            <button
              onClick={togglePlay}
              className="flex items-center gap-2 bg-purple-500 hover:bg-purple-600 text-white px-4 py-2.5 rounded-xl font-bold transition-all"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              {isPlaying ? 'إيقاف' : 'تشغيل'}
            </button>

            <button
              onClick={discardRecording}
              className="flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2.5 rounded-xl font-bold transition-all"
            >
              <Trash2 className="w-4 h-4" />
              حذف
            </button>

            <button
              onClick={saveRecording}
              disabled={isSaving}
              className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2.5 rounded-xl font-bold transition-all disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'جاري الحفظ...' : 'حفظ'}
            </button>
          </>
        )}
      </div>

      {audioBlob && (
        <p className="text-center text-xs text-gray-400 mt-2">
          مدة التسجيل: {formatTime(recordingTime)}
        </p>
      )}
    </div>
  );
}
