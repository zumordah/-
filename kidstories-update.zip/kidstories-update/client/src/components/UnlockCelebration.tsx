import { useEffect, useRef } from "react";

interface UnlockCelebrationProps {
  show: boolean;
  itemName: string;
  itemEmoji?: string;
  itemType: "game" | "adventure";
  onClose: () => void;
}

// ألوان الـ confetti
const COLORS = ["#FFD700", "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD", "#98D8C8"];

function createConfettiPiece(canvas: HTMLCanvasElement) {
  return {
    x: Math.random() * canvas.width,
    y: -10,
    size: Math.random() * 8 + 4,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
    speedX: (Math.random() - 0.5) * 4,
    speedY: Math.random() * 3 + 2,
    rotation: Math.random() * 360,
    rotationSpeed: (Math.random() - 0.5) * 8,
    shape: Math.random() > 0.5 ? "rect" : "circle",
    opacity: 1,
  };
}

function playUnlockSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();

    // نغمة احتفالية صاعدة
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, i) => {
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.12);

      gainNode.gain.setValueAtTime(0, ctx.currentTime + i * 0.12);
      gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + i * 0.12 + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.4);

      oscillator.start(ctx.currentTime + i * 0.12);
      oscillator.stop(ctx.currentTime + i * 0.12 + 0.4);
    });

    // صوت "بريق" إضافي
    const shimmer = ctx.createOscillator();
    const shimmerGain = ctx.createGain();
    shimmer.connect(shimmerGain);
    shimmerGain.connect(ctx.destination);
    shimmer.type = "triangle";
    shimmer.frequency.setValueAtTime(1200, ctx.currentTime + 0.5);
    shimmer.frequency.exponentialRampToValueAtTime(2400, ctx.currentTime + 0.9);
    shimmerGain.gain.setValueAtTime(0.15, ctx.currentTime + 0.5);
    shimmerGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.0);
    shimmer.start(ctx.currentTime + 0.5);
    shimmer.stop(ctx.currentTime + 1.0);
  } catch (e) {
    // تجاهل أخطاء الصوت
  }
}

export default function UnlockCelebration({ show, itemName, itemEmoji, itemType, onClose }: UnlockCelebrationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const piecesRef = useRef<ReturnType<typeof createConfettiPiece>[]>([]);

  useEffect(() => {
    if (!show) return;

    // تشغيل الصوت
    playUnlockSound();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // إنشاء 120 قطعة confetti
    piecesRef.current = Array.from({ length: 120 }, () => createConfettiPiece(canvas));

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      piecesRef.current = piecesRef.current.filter((p) => p.opacity > 0.05);

      piecesRef.current.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        p.rotation += p.rotationSpeed;
        if (p.y > canvas.height * 0.7) {
          p.opacity -= 0.02;
        }

        ctx.save();
        ctx.globalAlpha = p.opacity;
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;

        if (p.shape === "rect") {
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      if (piecesRef.current.length > 0) {
        animFrameRef.current = requestAnimationFrame(animate);
      }
    };

    animFrameRef.current = requestAnimationFrame(animate);

    // إغلاق تلقائي بعد 4 ثوانٍ
    const timer = setTimeout(onClose, 4000);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      clearTimeout(timer);
    };
  }, [show]);

  if (!show) return null;

  const typeLabel = itemType === "game" ? "لعبة جديدة" : "مغامرة جديدة";
  const typeColor = itemType === "game" ? "from-green-400 to-emerald-600" : "from-purple-400 to-violet-600";
  const typeBg = itemType === "game" ? "bg-green-50 border-green-200" : "bg-purple-50 border-purple-200";

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center"
      onClick={onClose}
    >
      {/* confetti canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ width: "100%", height: "100%" }}
      />

      {/* خلفية شبه شفافة */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />

      {/* بطاقة التهنئة */}
      <div
        className="relative z-10 text-center animate-bounce-in"
        style={{
          animation: "unlockPop 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* هالة ضوئية */}
        <div
          className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${typeColor} opacity-20 blur-2xl scale-125`}
        />

        <div className={`relative bg-white rounded-3xl p-8 shadow-2xl border-2 ${typeBg} max-w-xs mx-4`}>
          {/* أيقونة النجاح */}
          <div className="text-7xl mb-3 animate-pulse">{itemEmoji ?? (itemType === "game" ? "🎮" : "⚔️")}</div>

          {/* شارة "مفتوح!" */}
          <div className={`inline-block bg-gradient-to-r ${typeColor} text-white text-xs font-bold px-3 py-1 rounded-full mb-3`}>
            🔓 تم الفتح!
          </div>

          {/* عنوان */}
          <h2 className="text-2xl font-black text-gray-800 mb-1">مبروك! 🎉</h2>
          <p className="text-sm text-gray-500 mb-2">فتحت {typeLabel}</p>

          {/* اسم العنصر */}
          <div className={`rounded-2xl p-3 border ${typeBg} mb-4`}>
            <p className="font-bold text-gray-700 text-base">{itemName}</p>
          </div>

          {/* نجوم زخرفية */}
          <div className="flex justify-center gap-1 mb-4">
            {["⭐", "🌟", "✨", "🌟", "⭐"].map((s, i) => (
              <span
                key={i}
                className="text-lg"
                style={{
                  animation: `starPop 0.3s ease ${i * 0.1}s both`,
                }}
              >
                {s}
              </span>
            ))}
          </div>

          {/* زر الإغلاق */}
          <button
            onClick={onClose}
            className={`w-full py-3 rounded-2xl font-bold text-white bg-gradient-to-r ${typeColor} shadow-lg active:scale-95 transition-transform`}
          >
            ابدأ الآن! 🚀
          </button>
        </div>
      </div>

      <style>{`
        @keyframes unlockPop {
          0% { transform: scale(0.3) rotate(-10deg); opacity: 0; }
          60% { transform: scale(1.1) rotate(2deg); opacity: 1; }
          80% { transform: scale(0.95) rotate(-1deg); }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        @keyframes starPop {
          0% { transform: scale(0); opacity: 0; }
          70% { transform: scale(1.3); }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
