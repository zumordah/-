import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Search, Edit2, Trash2, RotateCcw, Users, Star, BookOpen, ChevronLeft, ChevronRight, Download, MoveRight, Trash } from "lucide-react";
import * as XLSX from "xlsx";

type Child = {
  id: number;
  name: string;
  email: string;
  ageGroup: string;
  gender: string;
  totalPoints: number;
  level: number;
  readingStreak: number;
  isKindergartenStudent: boolean | null;
  classroom: string | null;
  schoolId: number | null;
  lastActiveAt: Date | null;
  createdAt: Date;
};

export default function UsersManagementTab() {
  const [search, setSearch] = useState("");
  const [filterAge, setFilterAge] = useState<string>("all");
  const [filterGender, setFilterGender] = useState<string>("all");
  const [filterDate, setFilterDate] = useState<string>("all");
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 10;

  // Selection state
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  // Edit modal state
  const [editChild, setEditChild] = useState<Child | null>(null);
  const [editForm, setEditForm] = useState({
    name: "", email: "", ageGroup: "", gender: "", totalPoints: 0, level: 1,
  });

  // Delete confirm state
  const [deleteChildId, setDeleteChildId] = useState<number | null>(null);
  const [deleteChildName, setDeleteChildName] = useState("");

  // Bulk delete confirm
  const [showBulkDelete, setShowBulkDelete] = useState(false);

  // Transfer modal
  const [showTransfer, setShowTransfer] = useState(false);
  const [transferSchoolId, setTransferSchoolId] = useState<string>("none");
  const [transferClassroom, setTransferClassroom] = useState<string>("");

  const { data: allChildren, refetch } = trpc.admin.children.useQuery();
  const { data: schoolsList } = trpc.schools.list.useQuery();

  const updateMutation = trpc.admin.updateChild.useMutation({
    onSuccess: () => { toast.success("✅ تم تحديث بيانات المستخدم"); refetch(); setEditChild(null); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.admin.deleteChild.useMutation({
    onSuccess: () => { toast.success("🗑️ تم حذف الحساب"); refetch(); setDeleteChildId(null); },
    onError: (e) => toast.error(e.message),
  });
  const resetMutation = trpc.admin.resetChildPoints.useMutation({
    onSuccess: () => { toast.success("🔄 تم إعادة تصفير النقاط"); refetch(); },
    onError: (e) => toast.error(e.message),
  });
  const bulkDeleteMutation = trpc.admin.bulkDeleteChildren.useMutation({
    onSuccess: (r) => {
      toast.success(`🗑️ تم حذف ${r.deleted} مستخدم`);
      setSelectedIds(new Set());
      setShowBulkDelete(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });
  const bulkTransferMutation = trpc.admin.bulkTransferChildren.useMutation({
    onSuccess: (r) => {
      toast.success(`✅ تم نقل ${r.transferred} مستخدم`);
      setSelectedIds(new Set());
      setShowTransfer(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const children: Child[] = (allChildren as any) || [];

  const filtered = useMemo(() => children.filter((c) => {
    const matchSearch = !search || c.name.includes(search) || c.email.includes(search);
    const matchAge = filterAge === "all" || c.ageGroup === filterAge;
    const matchGender = filterGender === "all" || c.gender === filterGender;
    let matchDate = true;
    if (filterDate !== "all" && c.createdAt) {
      const now = new Date();
      const created = new Date(c.createdAt);
      if (filterDate === "this_week") {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        matchDate = created >= weekAgo;
      } else if (filterDate === "this_month") {
        matchDate = created.getFullYear() === now.getFullYear() && created.getMonth() === now.getMonth();
      }
    }
    return matchSearch && matchAge && matchGender && matchDate;
  }), [children, search, filterAge, filterGender, filterDate]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Selection helpers
  const isAllPageSelected = paginated.length > 0 && paginated.every(c => selectedIds.has(c.id));
  const isAllSelected = filtered.length > 0 && filtered.every(c => selectedIds.has(c.id));

  const toggleOne = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const togglePageAll = () => {
    if (isAllPageSelected) {
      setSelectedIds(prev => { const next = new Set(prev); paginated.forEach(c => next.delete(c.id)); return next; });
    } else {
      setSelectedIds(prev => { const next = new Set(prev); paginated.forEach(c => next.add(c.id)); return next; });
    }
  };
  const selectAll = () => setSelectedIds(new Set(filtered.map(c => c.id)));
  const clearSelection = () => setSelectedIds(new Set());

  const openEdit = (c: Child) => {
    setEditChild(c);
    setEditForm({ name: c.name, email: c.email, ageGroup: c.ageGroup, gender: c.gender, totalPoints: c.totalPoints, level: c.level });
  };
  const handleUpdate = () => {
    if (!editChild) return;
    updateMutation.mutate({
      childId: editChild.id,
      name: editForm.name,
      email: editForm.email,
      ageGroup: editForm.ageGroup as any,
      gender: editForm.gender as any,
      totalPoints: editForm.totalPoints,
      level: editForm.level,
    });
  };
  const formatDate = (d: Date | null) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("ar-SA", { year: "numeric", month: "short", day: "numeric" });
  };
  const exportToExcel = () => {
    const rows = filtered.map((c) => ({
      "الاسم": c.name,
      "البريد الإلكتروني": c.email,
      "الفئة العمرية": `${c.ageGroup} سنة`,
      "الجنس": c.gender === "boy" ? "ولد" : "بنت",
      "النقاط": c.totalPoints,
      "المستوى": c.level,
      "سلسلة القراءة": c.readingStreak,
      "طالب روضة": c.isKindergartenStudent ? "نعم" : "لا",
      "الفصل الدراسي": c.classroom || "—",
      "آخر نشاط": formatDate(c.lastActiveAt),
      "تاريخ التسجيل": formatDate(c.createdAt),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [
      { wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 10 },
      { wch: 10 }, { wch: 10 }, { wch: 12 }, { wch: 12 },
      { wch: 15 }, { wch: 18 }, { wch: 18 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "المستخدمون");
    const date = new Date().toLocaleDateString("ar-SA").replace(/\//g, "-");
    XLSX.writeFile(wb, `مستخدمو_المنصة_${date}.xlsx`);
    toast.success(`✅ تم تصدير ${filtered.length} مستخدم إلى Excel`);
  };

  const handleBulkTransfer = () => {
    const schoolId = transferSchoolId === "none" ? null : parseInt(transferSchoolId);
    const classroom = transferClassroom.trim() || null;
    bulkTransferMutation.mutate({
      childIds: Array.from(selectedIds),
      schoolId: schoolId ?? undefined,
      classroom: classroom ?? undefined,
    });
  };

  return (
    <div className="space-y-4" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold">إدارة المستخدمين</h2>
          <Badge variant="secondary">{filtered.length} مستخدم</Badge>
        </div>
        <Button onClick={exportToExcel} variant="outline" className="gap-2 border-green-500 text-green-700 hover:bg-green-50">
          <Download className="w-4 h-4" />
          تصدير Excel
        </Button>
      </div>

      {/* Bulk actions bar */}
      {selectedIds.size > 0 && (
        <div className="flex items-center gap-3 bg-primary/5 border border-primary/20 rounded-xl px-4 py-3 flex-wrap">
          <span className="font-bold text-primary text-sm">
            ✓ تم تحديد {selectedIds.size} مستخدم
          </span>
          {!isAllSelected && (
            <button onClick={selectAll} className="text-xs text-blue-600 underline hover:no-underline">
              تحديد الكل ({filtered.length})
            </button>
          )}
          <button onClick={clearSelection} className="text-xs text-gray-500 underline hover:no-underline">
            إلغاء التحديد
          </button>
          <div className="flex gap-2 mr-auto">
            <Button size="sm" variant="outline" className="gap-1.5 border-blue-400 text-blue-600 hover:bg-blue-50" onClick={() => setShowTransfer(true)}>
              <MoveRight className="w-3.5 h-3.5" />
              نقل إلى فصل/مدرسة
            </Button>
            <Button size="sm" variant="destructive" className="gap-1.5" onClick={() => setShowBulkDelete(true)}>
              <Trash className="w-3.5 h-3.5" />
              حذف جماعي
            </Button>
          </div>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالاسم أو الإيميل..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                className="pr-9"
              />
            </div>
            <Select value={filterAge} onValueChange={(v) => { setFilterAge(v); setPage(1); }}>
              <SelectTrigger className="w-36"><SelectValue placeholder="الفئة العمرية" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الأعمار</SelectItem>
                <SelectItem value="4-6">4-6 سنوات</SelectItem>
                <SelectItem value="6-8">6-8 سنوات</SelectItem>
                <SelectItem value="8-10">8-10 سنوات</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterGender} onValueChange={(v) => { setFilterGender(v); setPage(1); }}>
              <SelectTrigger className="w-28"><SelectValue placeholder="الجنس" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الجميع</SelectItem>
                <SelectItem value="boy">ولد</SelectItem>
                <SelectItem value="girl">بنت</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterDate} onValueChange={(v) => { setFilterDate(v); setPage(1); }}>
              <SelectTrigger className="w-40"><SelectValue placeholder="تاريخ التسجيل" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل التواريخ</SelectItem>
                <SelectItem value="this_week">هذا الأسبوع</SelectItem>
                <SelectItem value="this_month">هذا الشهر</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="p-3 w-10">
                    <Checkbox
                      checked={isAllPageSelected}
                      onCheckedChange={togglePageAll}
                      aria-label="تحديد الصفحة"
                    />
                  </th>
                  <th className="text-right p-3 font-semibold">المستخدم</th>
                  <th className="text-right p-3 font-semibold">الفئة</th>
                  <th className="text-right p-3 font-semibold">النقاط</th>
                  <th className="text-right p-3 font-semibold">المستوى</th>
                  <th className="text-right p-3 font-semibold">آخر نشاط</th>
                  <th className="text-right p-3 font-semibold">تاريخ التسجيل</th>
                  <th className="text-center p-3 font-semibold">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {paginated.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-muted-foreground">
                      لا يوجد مستخدمون مطابقون للبحث
                    </td>
                  </tr>
                ) : (
                  paginated.map((c) => (
                    <tr key={c.id} className={`border-b transition-colors ${selectedIds.has(c.id) ? 'bg-primary/5' : 'hover:bg-muted/20'}`}>
                      <td className="p-3">
                        <Checkbox
                          checked={selectedIds.has(c.id)}
                          onCheckedChange={() => toggleOne(c.id)}
                        />
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                            {c.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-medium">{c.name}</p>
                            <p className="text-xs text-muted-foreground">{c.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge variant="outline" className="text-xs">{c.ageGroup} سنة</Badge>
                        {c.isKindergartenStudent && (
                          <Badge variant="secondary" className="text-xs mr-1">روضة</Badge>
                        )}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-yellow-500" />
                          <span className="font-semibold">{c.totalPoints.toLocaleString()}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1">
                          <BookOpen className="w-3 h-3 text-blue-500" />
                          <span>المستوى {c.level}</span>
                        </div>
                      </td>
                      <td className="p-3 text-muted-foreground text-xs">{formatDate(c.lastActiveAt)}</td>
                      <td className="p-3 text-muted-foreground text-xs">{formatDate(c.createdAt)}</td>
                      <td className="p-3">
                        <div className="flex items-center justify-center gap-1">
                          <Button size="icon" variant="ghost" className="h-7 w-7 text-blue-600 hover:text-blue-700 hover:bg-blue-50" title="تعديل" onClick={() => openEdit(c)}>
                            <Edit2 className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 text-orange-500 hover:text-orange-600 hover:bg-orange-50" title="إعادة تصفير النقاط"
                            onClick={() => { if (confirm(`هل تريد إعادة تصفير نقاط ${c.name}؟`)) resetMutation.mutate({ childId: c.id }); }}>
                            <RotateCcw className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 text-red-500 hover:text-red-600 hover:bg-red-50" title="حذف الحساب"
                            onClick={() => { setDeleteChildId(c.id); setDeleteChildName(c.name); }}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between p-3 border-t">
              <span className="text-sm text-muted-foreground">
                صفحة {page} من {totalPages} ({filtered.length} مستخدم)
              </span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Modal */}
      <Dialog open={!!editChild} onOpenChange={(o) => !o && setEditChild(null)}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>تعديل بيانات المستخدم</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>الاسم</Label>
              <Input value={editForm.name} onChange={(e) => setEditForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div>
              <Label>البريد الإلكتروني</Label>
              <Input value={editForm.email} onChange={(e) => setEditForm(f => ({ ...f, email: e.target.value }))} dir="ltr" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>الفئة العمرية</Label>
                <Select value={editForm.ageGroup} onValueChange={(v) => setEditForm(f => ({ ...f, ageGroup: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4-6">4-6 سنوات</SelectItem>
                    <SelectItem value="6-8">6-8 سنوات</SelectItem>
                    <SelectItem value="8-10">8-10 سنوات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>الجنس</Label>
                <Select value={editForm.gender} onValueChange={(v) => setEditForm(f => ({ ...f, gender: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="boy">ولد</SelectItem>
                    <SelectItem value="girl">بنت</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>النقاط الكلية</Label>
                <Input type="number" min={0} value={editForm.totalPoints}
                  onChange={(e) => setEditForm(f => ({ ...f, totalPoints: parseInt(e.target.value) || 0 }))} />
              </div>
              <div>
                <Label>المستوى</Label>
                <Input type="number" min={1} value={editForm.level}
                  onChange={(e) => setEditForm(f => ({ ...f, level: parseInt(e.target.value) || 1 }))} />
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditChild(null)}>إلغاء</Button>
            <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? "جاري الحفظ..." : "حفظ التعديلات"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Modal */}
      <Dialog open={deleteChildId !== null} onOpenChange={(o) => !o && setDeleteChildId(null)}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle className="text-red-600">⚠️ تأكيد الحذف</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            هل أنت متأكد من حذف حساب <strong>{deleteChildName}</strong>؟ سيتم حذف جميع بياناته وتقدمه بشكل نهائي ولا يمكن التراجع.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteChildId(null)}>إلغاء</Button>
            <Button variant="destructive" onClick={() => deleteChildId && deleteMutation.mutate({ childId: deleteChildId })}
              disabled={deleteMutation.isPending}>
              {deleteMutation.isPending ? "جاري الحذف..." : "حذف نهائي"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Delete Confirm Modal */}
      <Dialog open={showBulkDelete} onOpenChange={setShowBulkDelete}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle className="text-red-600">⚠️ تأكيد الحذف الجماعي</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            هل أنت متأكد من حذف <strong>{selectedIds.size} مستخدم</strong> محدد؟ سيتم حذف جميع بياناتهم وتقدمهم بشكل نهائي ولا يمكن التراجع.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowBulkDelete(false)}>إلغاء</Button>
            <Button variant="destructive"
              onClick={() => bulkDeleteMutation.mutate({ childIds: Array.from(selectedIds) })}
              disabled={bulkDeleteMutation.isPending}>
              {bulkDeleteMutation.isPending ? "جاري الحذف..." : `حذف ${selectedIds.size} مستخدم`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Modal */}
      <Dialog open={showTransfer} onOpenChange={setShowTransfer}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>🔄 نقل {selectedIds.size} مستخدم</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>نقل إلى مدرسة</Label>
              <Select value={transferSchoolId} onValueChange={setTransferSchoolId}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر مدرسة..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون مدرسة</SelectItem>
                  {(schoolsList as any[] || []).map((s: any) => (
                    <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>نقل إلى فصل دراسي (اختياري)</Label>
              <Input
                placeholder="مثال: الفصل الأول أ"
                value={transferClassroom}
                onChange={(e) => setTransferClassroom(e.target.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">اتركه فارغاً إذا لم تريد تغيير الفصل</p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowTransfer(false)}>إلغاء</Button>
            <Button onClick={handleBulkTransfer} disabled={bulkTransferMutation.isPending}>
              {bulkTransferMutation.isPending ? "جاري النقل..." : `نقل ${selectedIds.size} مستخدم`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
