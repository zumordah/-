/**
 * تحويل الأرقام الإنجليزية إلى أرقام عربية
 * مثال: toAr(5) → "٥"، toAr(12) → "١٢"
 */
export function toAr(n: number | string): string {
  return String(n).replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[+d]);
}

/**
 * تحويل كل الأرقام الإنجليزية في نص مختلط إلى عربية
 * مثال: arabicizeText("5 + 3 = ?") → "٥ + ٣ = ?"
 */
export function arabicizeText(text: string | number | undefined | null): string {
  if (text === undefined || text === null) return '';
  return String(text).replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[+d]);
}
