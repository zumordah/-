import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. حذف "الجغرافيا العربية" (30070) واستبدالها بأعلام الدول ───
await conn.execute('DELETE FROM educational_games WHERE id = 30070');
console.log('✅ حُذفت "الجغرافيا العربية"');

// ─── 2. حذف "الحساب الذهني" (30074) واستبداله بلعبة أسهل ───
await conn.execute('DELETE FROM educational_games WHERE id = 30074');
console.log('✅ حُذف "الحساب الذهني"');

// ─── 3. إضافة "أعلام الدول" ───
const flagsData = {
  instructions: "انظر للعلم واختر اسم الدولة الصحيح",
  rounds: [
    { emoji: "🇸🇦", question: "ما اسم هذه الدولة؟", options: ["السعودية 🇸🇦", "الإمارات 🇦🇪", "الكويت 🇰🇼", "قطر 🇶🇦"], correct: 0 },
    { emoji: "🇦🇪", question: "ما اسم هذه الدولة؟", options: ["البحرين 🇧🇭", "الإمارات 🇦🇪", "عُمان 🇴🇲", "اليمن 🇾🇪"], correct: 1 },
    { emoji: "🇪🇬", question: "ما اسم هذه الدولة؟", options: ["المغرب 🇲🇦", "تونس 🇹🇳", "مصر 🇪🇬", "الجزائر 🇩🇿"], correct: 2 },
    { emoji: "🇯🇴", question: "ما اسم هذه الدولة؟", options: ["لبنان 🇱🇧", "سوريا 🇸🇾", "العراق 🇮🇶", "الأردن 🇯🇴"], correct: 3 },
    { emoji: "🇲🇦", question: "ما اسم هذه الدولة؟", options: ["المغرب 🇲🇦", "تونس 🇹🇳", "ليبيا 🇱🇾", "موريتانيا 🇲🇷"], correct: 0 },
    { emoji: "🇹🇷", question: "ما اسم هذه الدولة؟", options: ["إيران 🇮🇷", "باكستان 🇵🇰", "تركيا 🇹🇷", "أفغانستان 🇦🇫"], correct: 2 },
    { emoji: "🇫🇷", question: "ما اسم هذه الدولة؟", options: ["إيطاليا 🇮🇹", "إسبانيا 🇪🇸", "ألمانيا 🇩🇪", "فرنسا 🇫🇷"], correct: 3 },
    { emoji: "🇺🇸", question: "ما اسم هذه الدولة؟", options: ["كندا 🇨🇦", "أمريكا 🇺🇸", "المكسيك 🇲🇽", "البرازيل 🇧🇷"], correct: 1 },
    { emoji: "🇨🇳", question: "ما اسم هذه الدولة؟", options: ["اليابان 🇯🇵", "كوريا 🇰🇷", "الصين 🇨🇳", "الهند 🇮🇳"], correct: 2 },
    { emoji: "🇬🇧", question: "ما اسم هذه الدولة؟", options: ["أيرلندا 🇮🇪", "بريطانيا 🇬🇧", "هولندا 🇳🇱", "بلجيكا 🇧🇪"], correct: 1 },
  ]
};
await conn.execute(
  'INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, gameData, isPublished, orderIndex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
  ["أعلام الدول", "تعرّف على أعلام دول العالم", "image_match", "hard", "8-10", "🌍", 35, JSON.stringify(flagsData), 1, 30]
);
console.log('✅ أُضيفت "أعلام الدول"');

// ─── 4. إضافة "معلومات ممتعة" بدلاً من الحساب الذهني ───
const funFactsData = {
  instructions: "اختر الإجابة الصحيحة",
  rounds: [
    { emoji: "🌍", question: "كم عدد قارات العالم؟", options: ["5 قارات", "6 قارات", "7 قارات", "8 قارات"], correct: 2 },
    { emoji: "🌊", question: "ما أكبر محيط في العالم؟", options: ["المحيط الهندي", "المحيط الأطلسي", "المحيط المتجمد", "المحيط الهادئ"], correct: 3 },
    { emoji: "🌙", question: "كم يستغرق القمر للدوران حول الأرض؟", options: ["أسبوع", "شهر", "سنة", "يوم"], correct: 1 },
    { emoji: "🦁", question: "ما أضخم حيوان بري؟", options: ["الفيل 🐘", "الزرافة 🦒", "الأسد 🦁", "الحصان 🐴"], correct: 0 },
    { emoji: "🐳", question: "ما أكبر حيوان في العالم؟", options: ["القرش 🦈", "الحوت الأزرق 🐳", "الأخطبوط 🐙", "التمساح 🐊"], correct: 1 },
    { emoji: "☀️", question: "كم يستغرق ضوء الشمس للوصول للأرض؟", options: ["ثانية واحدة", "دقيقة واحدة", "8 دقائق", "ساعة"], correct: 2 },
    { emoji: "🌋", question: "ما أطول جبل في العالم؟", options: ["جبل فوجي 🗻", "جبل إيفرست 🏔️", "جبل كليمنجارو", "جبل الألب"], correct: 1 },
    { emoji: "🦋", question: "كم مرحلة تمر بها الفراشة؟", options: ["مرحلتان", "3 مراحل", "4 مراحل", "5 مراحل"], correct: 2 },
  ]
};
await conn.execute(
  'INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, gameData, isPublished, orderIndex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
  ["معلومات ممتعة", "اختبر معلوماتك عن العالم", "image_match", "hard", "8-10", "🌟", 35, JSON.stringify(funFactsData), 1, 31]
);
console.log('✅ أُضيفت "معلومات ممتعة"');

// ─── 5. تخفيض صعوبة "الأعداد الكبيرة" (30046) ───
const bigNumbersData = {
  instructions: "اقرأ العدد واختر الإجابة الصحيحة",
  rounds: [
    { letter: "15", question: "ما هذا العدد؟", options: ["خمسة عشر", "خمسون", "خمسة", "عشرون"], correct: 0 },
    { letter: "23", question: "ما هذا العدد؟", options: ["اثنان وعشرون", "ثلاثة وعشرون", "ثلاثون", "اثنان وثلاثون"], correct: 1 },
    { letter: "50", question: "ما هذا العدد؟", options: ["خمسة عشر", "خمسة وعشرون", "خمسون", "خمسة وخمسون"], correct: 2 },
    { letter: "100", question: "ما هذا العدد؟", options: ["عشرة", "مئة", "ألف", "عشرون"], correct: 1 },
    { letter: "30 + 20", question: "ما ناتج الجمع؟", options: ["40", "50", "60", "70"], correct: 1 },
    { letter: "80 - 30", question: "ما ناتج الطرح؟", options: ["40", "50", "60", "70"], correct: 1 },
    { letter: "45 + 5", question: "ما ناتج الجمع؟", options: ["40", "45", "50", "55"], correct: 2 },
    { letter: "70 - 20", question: "ما ناتج الطرح؟", options: ["40", "50", "60", "70"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30046', [JSON.stringify(bigNumbersData)]);
console.log('✅ تم تخفيض صعوبة "الأعداد الكبيرة"');

// ─── 6. تخفيض صعوبة "جمع وطرح متقدم" (30047) ───
const advMathData = {
  instructions: "احسب الناتج",
  rounds: [
    { letter: "12 + 8", question: "ما ناتج الجمع؟", options: ["18", "20", "22", "24"], correct: 1 },
    { letter: "15 - 6", question: "ما ناتج الطرح؟", options: ["7", "8", "9", "10"], correct: 2 },
    { letter: "20 + 15", question: "ما ناتج الجمع؟", options: ["30", "35", "40", "45"], correct: 1 },
    { letter: "30 - 12", question: "ما ناتج الطرح؟", options: ["16", "18", "20", "22"], correct: 1 },
    { letter: "25 + 10", question: "ما ناتج الجمع؟", options: ["30", "35", "40", "45"], correct: 1 },
    { letter: "40 - 15", question: "ما ناتج الطرح؟", options: ["20", "25", "30", "35"], correct: 1 },
    { letter: "18 + 7", question: "ما ناتج الجمع؟", options: ["23", "25", "27", "29"], correct: 1 },
    { letter: "50 - 20", question: "ما ناتج الطرح؟", options: ["20", "25", "30", "35"], correct: 2 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30047', [JSON.stringify(advMathData)]);
console.log('✅ تم تخفيض صعوبة "جمع وطرح متقدم"');

// ─── 7. تخفيض صعوبة "الرياضيات المتقدمة" (30069) ───
const advMath2Data = {
  instructions: "حل المسألة الرياضية",
  rounds: [
    { letter: "عند أحمد 10 تفاحات، أكل 3، كم تبقى؟", question: "ما الباقي؟", options: ["5", "6", "7", "8"], correct: 2 },
    { letter: "في السلة 8 برتقالات، أضفنا 4، كم أصبح؟", question: "ما المجموع؟", options: ["10", "11", "12", "13"], correct: 2 },
    { letter: "5 × 2 = ؟", question: "ما ناتج الضرب؟", options: ["8", "10", "12", "14"], correct: 1 },
    { letter: "3 × 3 = ؟", question: "ما ناتج الضرب؟", options: ["6", "9", "12", "15"], correct: 1 },
    { letter: "20 ÷ 4 = ؟", question: "ما ناتج القسمة؟", options: ["4", "5", "6", "7"], correct: 1 },
    { letter: "نصف 12 = ؟", question: "ما نصف 12؟", options: ["4", "5", "6", "7"], correct: 2 },
    { letter: "ربع 8 = ؟", question: "ما ربع 8؟", options: ["1", "2", "3", "4"], correct: 1 },
    { letter: "2 × 5 + 3 = ؟", question: "ما الناتج؟", options: ["11", "13", "15", "17"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30069', [JSON.stringify(advMath2Data)]);
console.log('✅ تم تخفيض صعوبة "الرياضيات المتقدمة"');

// ─── 8. تخفيض صعوبة "التفكير المنطقي" (30068) ───
const logicData = {
  instructions: "فكّر وأجب",
  rounds: [
    { emoji: "🔴🔵🔴🔵🔴?", question: "ما الشكل التالي في النمط؟", options: ["🔴 أحمر", "🔵 أزرق", "🟢 أخضر", "🟡 أصفر"], correct: 1 },
    { emoji: "1, 2, 3, 4, ?", question: "ما العدد التالي؟", options: ["4", "5", "6", "7"], correct: 1 },
    { emoji: "2, 4, 6, 8, ?", question: "ما العدد التالي؟", options: ["9", "10", "11", "12"], correct: 1 },
    { emoji: "🐣→🐥→🐔", question: "ما المرحلة التالية للكتكوت؟", options: ["بيضة 🥚", "دجاجة 🐔", "ديك 🐓", "فرخ 🐣"], correct: 1 },
    { emoji: "🌱→🌿→?", question: "ما المرحلة التالية للنبتة؟", options: ["بذرة 🌰", "شجرة 🌳", "زهرة 🌸", "ثمرة 🍎"], correct: 1 },
    { emoji: "🔵🔵🔴🔵🔵🔴?", question: "ما الشكل التالي في النمط؟", options: ["🔵 أزرق", "🔴 أحمر", "🟢 أخضر", "🟡 أصفر"], correct: 0 },
    { emoji: "10, 20, 30, 40, ?", question: "ما العدد التالي؟", options: ["45", "50", "55", "60"], correct: 1 },
    { emoji: "🌙⭐🌙⭐?", question: "ما الشكل التالي؟", options: ["🌙 قمر", "⭐ نجمة", "☀️ شمس", "🌟 نجمة لامعة"], correct: 0 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30068', [JSON.stringify(logicData)]);
console.log('✅ تم تخفيض صعوبة "التفكير المنطقي"');

// ─── 9. تخفيض صعوبة "النحو والإملاء" (30072) ───
const grammarData = {
  instructions: "اختر الكلمة الصحيحة",
  rounds: [
    { letter: "الكتاب _____ على الطاولة", question: "اختر الفعل الصحيح", options: ["يجلس", "يوجد", "يأكل", "يطير"], correct: 1 },
    { letter: "هذا _____ جميل", question: "اختر الاسم المناسب", options: ["بيت 🏠", "يركض", "كبير", "سريع"], correct: 0 },
    { letter: "الولد _____ إلى المدرسة", question: "اختر الفعل الصحيح", options: ["يأكل", "يذهب", "ينام", "يسبح"], correct: 1 },
    { letter: "السماء _____ اللون", question: "اختر الوصف الصحيح", options: ["حمراء", "خضراء", "زرقاء", "صفراء"], correct: 2 },
    { letter: "القطة _____ الحليب", question: "اختر الفعل الصحيح", options: ["تأكل", "تشرب", "تطير", "تسبح"], correct: 1 },
    { letter: "الشمس _____ في الصباح", question: "اختر الفعل الصحيح", options: ["تغرب", "تشرق", "تنام", "تمطر"], correct: 1 },
    { letter: "الثلج _____ في الشتاء", question: "اختر الفعل الصحيح", options: ["يذوب في الصيف", "يتساقط", "يزهر", "يتفتح"], correct: 1 },
    { letter: "الطائر _____ في السماء", question: "اختر الفعل الصحيح", options: ["يسبح", "يزحف", "يطير", "يقفز"], correct: 2 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30072', [JSON.stringify(grammarData)]);
console.log('✅ تم تخفيض صعوبة "النحو والإملاء"');

// ─── 10. تخفيض صعوبة "العلوم والطبيعة" (30073) ───
const scienceData = {
  instructions: "اختر الإجابة الصحيحة",
  rounds: [
    { emoji: "🌧️", question: "من أين تأتي المطر؟", options: ["من الجبال ⛰️", "من السحاب ☁️", "من البحر 🌊", "من الأشجار 🌳"], correct: 1 },
    { emoji: "🌱", question: "ماذا تحتاج النباتات للنمو؟", options: ["الظلام والبرد", "الماء والشمس 🌞💧", "الثلج فقط ❄️", "الرياح فقط 💨"], correct: 1 },
    { emoji: "🦋", question: "من أين تخرج الفراشة؟", options: ["من البيضة 🥚", "من الشرنقة 🫘", "من الزهرة 🌸", "من التراب 🌍"], correct: 1 },
    { emoji: "🌡️", question: "ما الذي يقيس درجة الحرارة؟", options: ["الميزان ⚖️", "المسطرة 📏", "الترمومتر 🌡️", "الساعة ⏰"], correct: 2 },
    { emoji: "🌙", question: "لماذا نرى القمر في الليل؟", options: ["لأنه يضيء بنفسه", "لأنه يعكس ضوء الشمس ☀️", "لأنه قريب منا", "لأنه كبير جداً"], correct: 1 },
    { emoji: "🐟", question: "كيف تتنفس الأسماك؟", options: ["بالرئتين 🫁", "بالخياشيم 🐟", "بالجلد", "لا تتنفس"], correct: 1 },
    { emoji: "🌈", question: "كم لون في قوس قزح؟", options: ["5 ألوان", "6 ألوان", "7 ألوان", "8 ألوان"], correct: 2 },
    { emoji: "🧲", question: "ما الذي يجذبه المغناطيس؟", options: ["الخشب 🪵", "البلاستيك", "الحديد 🔩", "الورق 📄"], correct: 2 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30073', [JSON.stringify(scienceData)]);
console.log('✅ تم تخفيض صعوبة "العلوم والطبيعة"');

// ─── 11. تخفيض صعوبة "القصة الناقصة" (30067) ───
const missingStoryData = {
  instructions: "اختر الكلمة المناسبة لإكمال القصة",
  rounds: [
    { letter: "ذهب أحمد إلى _____ ليشتري خبزاً", question: "أين ذهب أحمد؟", options: ["المدرسة 🏫", "المخبز 🍞", "الملعب ⚽", "الحديقة 🌳"], correct: 1 },
    { letter: "رأت سارة _____ يطير في السماء", question: "ماذا رأت سارة؟", options: ["سمكة 🐟", "سلحفاة 🐢", "طائراً 🦅", "حصاناً 🐴"], correct: 2 },
    { letter: "في الصباح، يأكل الأطفال _____", question: "ماذا يأكلون في الصباح؟", options: ["العشاء 🌙", "الفطور 🍳", "الغداء ☀️", "الحلوى 🍬"], correct: 1 },
    { letter: "عندما يمطر، نحمل _____", question: "ماذا نحمل في المطر؟", options: ["المظلة ☂️", "الكرة ⚽", "الكتاب 📚", "الزهرة 🌸"], correct: 0 },
    { letter: "الأسد يعيش في _____", question: "أين يعيش الأسد؟", options: ["البحر 🌊", "الجبل ⛰️", "الغابة 🌳", "المنزل 🏠"], correct: 2 },
    { letter: "في الليل، ننظر إلى _____", question: "ماذا ننظر في الليل؟", options: ["الشمس ☀️", "النجوم ⭐", "الأشجار 🌳", "الجبال ⛰️"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30067', [JSON.stringify(missingStoryData)]);
console.log('✅ تم تخفيض صعوبة "القصة الناقصة"');

// ─── 12. تخفيض صعوبة "اكتشف الدخيل" (30048) ───
const intruderData = {
  instructions: "اختر الكلمة التي لا تنتمي للمجموعة",
  rounds: [
    { emoji: "🐕🐈🐟🚗", question: "أي الكلمات ليست حيواناً؟", options: ["🐕 كلب", "🐈 قطة", "🐟 سمكة", "🚗 سيارة"], correct: 3 },
    { emoji: "🍎🍌🍕🍊", question: "أي الكلمات ليست فاكهة؟", options: ["🍎 تفاح", "🍌 موز", "🍕 بيتزا", "🍊 برتقال"], correct: 2 },
    { emoji: "📚✏️🎒🏀", question: "أي الكلمات ليست أداة مدرسية؟", options: ["📚 كتاب", "✏️ قلم", "🎒 حقيبة", "🏀 كرة"], correct: 3 },
    { emoji: "🔴🔵🟢🐘", question: "أي الكلمات ليست لوناً؟", options: ["🔴 أحمر", "🔵 أزرق", "🟢 أخضر", "🐘 فيل"], correct: 3 },
    { emoji: "🚗🚌🚲🏠", question: "أي الكلمات ليست وسيلة نقل؟", options: ["🚗 سيارة", "🚌 حافلة", "🚲 دراجة", "🏠 منزل"], correct: 3 },
    { emoji: "🌹🌷🌻🍌", question: "أي الكلمات ليست زهرة؟", options: ["🌹 وردة", "🌷 زنبق", "🌻 عباد شمس", "🍌 موزة"], correct: 3 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30048', [JSON.stringify(intruderData)]);
console.log('✅ تم تخفيض صعوبة "اكتشف الدخيل"');

// ─── 13. تخفيض صعوبة "الكلمة المخفية" (30041) ───
const hiddenWordData = {
  instructions: "اختر الحرف الناقص لإكمال الكلمة",
  rounds: [
    { letter: "ق_مر", question: "ما الحرف الناقص؟", options: ["أ", "و", "م", "ي"], correct: 1 },
    { letter: "ش_رة", question: "ما الحرف الناقص؟", options: ["ج", "ح", "خ", "ع"], correct: 0 },
    { letter: "ب_ت", question: "ما الحرف الناقص؟", options: ["ا", "ي", "ي", "و"], correct: 0 },
    { letter: "ك_اب", question: "ما الحرف الناقص؟", options: ["ت", "ث", "ب", "ن"], correct: 0 },
    { letter: "ق_ط", question: "ما الحرف الناقص؟", options: ["ط", "ه", "ا", "و"], correct: 2 },
    { letter: "ن_م", question: "ما الحرف الناقص؟", options: ["ج", "و", "ا", "ي"], correct: 2 },
    { letter: "س_ك", question: "ما الحرف الناقص؟", options: ["ا", "م", "ي", "و"], correct: 0 },
    { letter: "ح_ن", question: "ما الحرف الناقص؟", options: ["ص", "ص", "ص", "ص"], correct: 0 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30041', [JSON.stringify(hiddenWordData)]);
console.log('✅ تم تخفيض صعوبة "الكلمة المخفية"');

// ─── 14. تخفيض صعوبة ألعاب الطرح المتقدم ───
const subtractHardData = {
  instructions: "احسب ناتج الطرح",
  rounds: [
    { letter: "15 - 8", question: "ما ناتج الطرح؟", options: ["5", "6", "7", "8"], correct: 2 },
    { letter: "20 - 9", question: "ما ناتج الطرح؟", options: ["9", "10", "11", "12"], correct: 2 },
    { letter: "25 - 7", question: "ما ناتج الطرح؟", options: ["16", "17", "18", "19"], correct: 2 },
    { letter: "30 - 14", question: "ما ناتج الطرح؟", options: ["14", "16", "18", "20"], correct: 1 },
    { letter: "40 - 15", question: "ما ناتج الطرح؟", options: ["20", "25", "30", "35"], correct: 1 },
    { letter: "50 - 23", question: "ما ناتج الطرح؟", options: ["25", "27", "29", "31"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 60006', [JSON.stringify(subtractHardData)]);
console.log('✅ تم تخفيض صعوبة "طرح المتقدم"');

// ─── 15. تخفيض صعوبة جمع الأرقام الكبيرة ───
const addBigData = {
  instructions: "احسب ناتج الجمع",
  rounds: [
    { letter: "15 + 10", question: "ما ناتج الجمع؟", options: ["20", "25", "30", "35"], correct: 1 },
    { letter: "20 + 15", question: "ما ناتج الجمع؟", options: ["30", "35", "40", "45"], correct: 1 },
    { letter: "25 + 20", question: "ما ناتج الجمع؟", options: ["40", "45", "50", "55"], correct: 1 },
    { letter: "30 + 25", question: "ما ناتج الجمع؟", options: ["50", "55", "60", "65"], correct: 1 },
    { letter: "40 + 10", question: "ما ناتج الجمع؟", options: ["45", "50", "55", "60"], correct: 1 },
    { letter: "35 + 15", question: "ما ناتج الجمع؟", options: ["45", "50", "55", "60"], correct: 1 },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 60007', [JSON.stringify(addBigData)]);
console.log('✅ تم تخفيض صعوبة "جمع الأرقام الكبيرة"');

await conn.end();
console.log('\n✅ تم الانتهاء من إصلاح المستوى المتقدم');
