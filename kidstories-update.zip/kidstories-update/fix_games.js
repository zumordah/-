const mysql = require('mysql2/promise');

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  // ─── 1. إصلاح "أكبر أم أصغر؟" - استبدال "أم" بـ "-" ───
  const comparisonData = {
    instructions: "انظر للعددين وأجب على السؤال",
    rounds: [
      { letter: "5 - 3", question: "أيهما أكبر؟", options: ["5 أكبر", "3 أكبر", "متساويان", "لا أعرف"], correct: 0 },
      { letter: "7 - 9", question: "أيهما أصغر؟", options: ["7 أصغر", "9 أصغر", "متساويان", "لا أعرف"], correct: 0 },
      { letter: "4 - 4", question: "أيهما أكبر؟", options: ["4 الأول أكبر", "4 الثاني أكبر", "متساويان", "لا أعرف"], correct: 2 },
      { letter: "8 - 2", question: "أيهما أكبر؟", options: ["8 أكبر", "2 أكبر", "متساويان", "لا أعرف"], correct: 0 },
      { letter: "1 - 6", question: "أيهما أصغر؟", options: ["1 أصغر", "6 أصغر", "متساويان", "لا أعرف"], correct: 0 },
      { letter: "10 - 5", question: "أيهما أكبر؟", options: ["10 أكبر", "5 أكبر", "متساويان", "لا أعرف"], correct: 0 },
      { letter: "3 - 7", question: "أيهما أكبر؟", options: ["3 أكبر", "7 أكبر", "متساويان", "لا أعرف"], correct: 1 },
      { letter: "6 - 6", question: "أيهما أكبر؟", options: ["6 الأول أكبر", "6 الثاني أكبر", "متساويان", "لا أعرف"], correct: 2 },
    ]
  };
  await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30051', [JSON.stringify(comparisonData)]);
  console.log('✅ تم تحديث "أكبر أم أصغر؟"');

  // ─── 2. فحص ألعاب المتوسط ───
  const [medGames] = await conn.execute('SELECT id, title FROM educational_games WHERE level="medium" ORDER BY id');
  console.log('\nألعاب المتوسط:');
  medGames.forEach(g => console.log(`  ${g.id}: ${g.title}`));

  // ─── 3. فحص ألعاب المتقدم ───
  const [hardGames] = await conn.execute('SELECT id, title FROM educational_games WHERE level="hard" ORDER BY id');
  console.log('\nألعاب المتقدم:');
  hardGames.forEach(g => console.log(`  ${g.id}: ${g.title}`));

  await conn.end();
  console.log('\n✅ تم الانتهاء');
}

main().catch(console.error);
