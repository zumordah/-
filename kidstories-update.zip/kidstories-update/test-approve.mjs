import { createConnection } from 'mysql2/promise';

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) { console.error('No DATABASE_URL'); process.exit(1); }

const conn = await createConnection(dbUrl);

// فحص الطلبات المعلقة
const [regs] = await conn.execute('SELECT * FROM school_registrations');
console.log('All registrations:', JSON.stringify(regs, null, 2));

// فحص جدول schools
const [schools] = await conn.execute('SELECT * FROM schools');
console.log('Schools:', JSON.stringify(schools, null, 2));

// فحص admin_accounts
const [admins] = await conn.execute('SELECT id, email, name, role, schoolId FROM admin_accounts');
console.log('Admins:', JSON.stringify(admins, null, 2));

await conn.end();
process.exit(0);
