import mysql from './node_modules/mysql2/promise/index.js';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. إصلاح إكمال الجملة المتقدمة (ID: 30067) ───────────────────────────
// المشكلة: حقل letter يحتوي الجملة لكن question فارغ → المكوّن يعرض "ما الحرف الناقص؟"
// الحل: نقل محتوى letter إلى question وإضافة صورة/إيموجي مناسب لكل جملة
{
  const [rows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30067');
  let d = rows[0].gameData;
  if (typeof d !== 'string') d = JSON.stringify(d);
  const data = JSON.parse(d);

  // تحديث كل سؤال: نقل letter → question، وإضافة emoji مناسب
  const emojiMap = [
    '🍞', // ذهب أحمد للمخبز
    '🦅', // رأت سارة طائراً
    '🍳', // يأكل الأطفال الفطور
    '🌅', // الشمس تشرق من الشرق
    '🌳', // لعبت هيا في الحديقة
    '📖', // يحب سام القصص
    '🌧️', // تسقط الأمطار
    '👩', // تحب نور أمها
    '🛒', // ذهبت ريم للسوق
    '⚽', // يلعب عمر كرة القدم
  ];

  data.rounds = data.rounds.map((r, i) => ({
    question: r.letter || r.question, // الجملة كسؤال
    emoji: emojiMap[i] || '📝',       // إيموجي مناسب
    options: r.options,
    correct: r.correct,
    hint: r.hint,
  }));

  await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30067', [JSON.stringify(data)]);
  console.log('✅ تم إصلاح إكمال الجملة المتقدمة - نقل letter إلى question');
}

// ─── 2. إصلاح التفكير المنطقي - السؤال الخامس (خياران أزرق) ───────────────
{
  const [rows] = await conn.execute("SELECT id, gameData FROM educational_games WHERE title LIKE '%تفكير%'");
  for (const row of rows) {
    let d = row.gameData;
    if (typeof d !== 'string') d = JSON.stringify(d);
    const data = JSON.parse(d);
    
    if (data.rounds && data.rounds[4]) {
      const q5 = data.rounds[4];
      // السؤال 5: 🟦🟦🟥🟦🟦🟥❓ - options: ["🟦","🟥","🟦","🟩"]
      // الخيار 0 و2 كلاهما 🟦 - الإجابة الصحيحة correct:2 = 🟦
      // نصلح بتغيير الخيار 2 إلى شيء آخر (مثل 🟨) وتحديث correct إلى 0
      if (q5.options && q5.options[0] === '🟦' && q5.options[2] === '🟦') {
        q5.options = ['🟦', '🟥', '🟨', '🟩'];
        q5.correct = 0; // 🟦 هو الصحيح
        console.log('✅ تم إصلاح السؤال الخامس في التفكير المنطقي');
      }
      
      await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = ?', [JSON.stringify(data), row.id]);
    }
  }
}

// ─── التحقق ───────────────────────────────────────────────────────────────
{
  const [rows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30067');
  let d = rows[0].gameData;
  if (typeof d !== 'string') d = JSON.stringify(d);
  const data = JSON.parse(d);
  console.log('\nإكمال الجملة المتقدمة - أول سؤال:');
  console.log(JSON.stringify(data.rounds[0]));
}

await conn.end();
console.log('\n✅ اكتمل الإصلاح');
