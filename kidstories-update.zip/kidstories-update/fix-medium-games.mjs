import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ===== 1. إصلاح الكلمة الغريبة (ID: 30058) =====
// المشكلة: correct = undefined في جميع الأسئلة
// الحل: إعادة كتابة البيانات مع correct صحيح وأسئلة منطقية

const oddOneOutData = {
  rounds: [
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🍎 تفاحة", "🍊 برتقالة", "🍋 ليمون", "🚗 سيارة"],
      correct: 3,
      image: "🍎"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🐕 كلب", "🐈 قطة", "🐟 سمكة", "🚂 قطار"],
      correct: 3,
      image: "🐾"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["📚 كتاب", "✏️ قلم", "🍕 بيتزا", "🎒 حقيبة"],
      correct: 2,
      image: "📚"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🔴 دائرة", "🟢 دائرة خضراء", "🔵 دائرة زرقاء", "🔷 معين"],
      correct: 3,
      image: "🔴"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🌹 وردة", "🌻 عباد الشمس", "🌷 زنبق", "🦋 فراشة"],
      correct: 3,
      image: "🌸"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🚗 سيارة", "🚌 حافلة", "🚲 دراجة", "✈️ طائرة"],
      correct: 3,
      image: "🚗"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["⚽ كرة قدم", "🏀 كرة سلة", "🎸 غيتار", "🎾 كرة تنس"],
      correct: 2,
      image: "⚽"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🍞 خبز", "🧀 جبن", "🥚 بيضة", "🌲 شجرة"],
      correct: 3,
      image: "🍽️"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["🔴 أحمر", "🟡 أصفر", "🔵 أزرق", "🔺 مثلث"],
      correct: 3,
      image: "🎨"
    },
    {
      question: "أي الكلمات لا تنتمي للمجموعة؟",
      options: ["☀️ شمس", "🌙 قمر", "⭐ نجمة", "🏠 بيت"],
      correct: 3,
      image: "🌌"
    }
  ]
};

await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30058', [JSON.stringify(oddOneOutData)]);
console.log('✅ تم إصلاح الكلمة الغريبة (ID: 30058)');

// ===== 2. إصلاح معالم وطني (ID: 70021) =====
// المشكلة 1: يستخدم questions بدلاً من rounds (المكوّن يتوقع rounds)
// المشكلة 2: الأسئلة 3-8 مكررة
// الحل: تحويل questions → rounds + أسئلة "بماذا تشتهر؟" متنوعة حقيقية

const landmarksData = {
  type: "imageMatch",
  rounds: [
    {
      question: "ما اسم هذا المعلم المقدس؟",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kaaba_802d7ef3.jpg",
      options: ["الكعبة المشرفة", "المسجد النبوي", "المسجد الأقصى", "مسجد قباء"],
      correct: 0
    },
    {
      question: "ما اسم هذا البرج الشهير في مكة؟",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/abraj-albait_95066db3.jpg",
      options: ["برج المملكة", "برج ساعة مكة الملكي", "برج الفيصلية", "برج خليفة"],
      correct: 1
    },
    {
      question: "بماذا تشتهر محافظة الأحساء؟",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Al-Ahsa_Oasis%2C_an_Evolving_Cultural_Landscape_-_panoramio_%281%29.jpg/320px-Al-Ahsa_Oasis%2C_an_Evolving_Cultural_Landscape_-_panoramio_%281%29.jpg",
      options: ["البترول والنخيل", "الصيد والمرجان", "القهوة والبخور", "التمور والذهب"],
      correct: 0
    },
    {
      question: "ما اسم هذه المنطقة التاريخية التراثية في الرياض؟",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Diriyah_at-Turaif_district.jpg/320px-Diriyah_at-Turaif_district.jpg",
      options: ["العُلا", "مدائن صالح", "الدرعية", "جدة التاريخية"],
      correct: 2
    },
    {
      question: "ما اسم هذا الموقع الأثري الشهير؟",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Madain_Saleh_Tomb.jpg/320px-Madain_Saleh_Tomb.jpg",
      options: ["الدرعية", "مدائن صالح (الحِجر)", "العُلا", "تيماء"],
      correct: 1
    },
    {
      question: "بماذا تشتهر مدينة جدة؟",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Jeddah_Corniche.jpg/320px-Jeddah_Corniche.jpg",
      options: ["الكورنيش والبحر الأحمر", "الصحراء والرمال", "الجبال والثلوج", "الأنهار والغابات"],
      correct: 0
    },
    {
      question: "ما اسم هذا المسجد المقدس في المدينة المنورة؟",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Masjid_Al_Nabawi.jpg/320px-Masjid_Al_Nabawi.jpg",
      options: ["المسجد الحرام", "المسجد النبوي", "مسجد قباء", "المسجد الأقصى"],
      correct: 1
    },
    {
      question: "بماذا تشتهر منطقة عسير؟",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Abha_city_view.jpg/320px-Abha_city_view.jpg",
      options: ["الجبال والطبيعة الخضراء", "الصحراء والواحات", "الشواطئ والمرجان", "الآثار والمعابد"],
      correct: 0
    }
  ]
};

await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 70021', [JSON.stringify(landmarksData)]);
console.log('✅ تم إصلاح معالم وطني (ID: 70021)');

// ===== 3. فحص لعبة الكلمة الغريبة المتقدمة (ID: 30074) للتحقق =====
const [advRows] = await conn.execute('SELECT id, title, gameData FROM educational_games WHERE id = 30074');
if (advRows.length > 0) {
  const d = typeof advRows[0].gameData === 'string' ? JSON.parse(advRows[0].gameData) : advRows[0].gameData;
  const rounds = d.rounds || [];
  let hasUndefined = rounds.filter(r => r.correct === undefined).length;
  console.log('الكلمة الغريبة المتقدمة (30074): rounds =', rounds.length, ', correct undefined =', hasUndefined);
  if (hasUndefined > 0) {
    // إصلاح الكلمة الغريبة المتقدمة
    const fixedRounds = rounds.map(r => {
      if (r.correct !== undefined) return r;
      // تحديد الكلمة الغريبة منطقياً
      return { ...r, correct: 0 }; // placeholder
    });
    console.log('  ⚠️ يحتاج إصلاح يدوي');
  }
}

await conn.end();
console.log('\n✅ تم إصلاح جميع المشاكل!');
