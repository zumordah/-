import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ============================================================
// 1. تصحيح الجسم والصحة - سؤال الكبد
// ============================================================
const [bodyRows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30062');
const bodyData = bodyRows[0].gameData;
bodyData.rounds = bodyData.rounds.map(r => {
  if (r.question && r.question.includes('كبد')) {
    return {
      ...r,
      question: 'أين يقع الكبد في الجسم؟',
      emoji: '🫀',
      options: ['الجانب الأيمن من البطن', 'الصدر', 'الرأس', 'الظهر'],
      correctIndex: 0,
    };
  }
  return r;
});
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30062', [JSON.stringify(bodyData)]);
console.log('✅ تم إصلاح سؤال الكبد');

// ============================================================
// 2. إصلاح لعبة تكوين الجمل - التأكد من أن المكوّن يعرضها
// البيانات صحيحة لكن نوع اللعبة word_build لا يدعم الجمل
// سنغير النوع إلى letter_match مع تعديل البيانات
// ============================================================
const [sentRows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30059');
const sentData = sentRows[0].gameData;
// تحويل البيانات لنمط letter_match حيث كل جولة لها خيارات وإجابة صحيحة
const newSentData = {
  instructions: 'اختر الترتيب الصحيح للكلمات لتكوين جملة مفيدة',
  rounds: sentData.rounds.map(r => ({
    question: `رتّب الكلمات: "${r.letter}"`,
    emoji: '📝',
    options: r.options.map(o => o.replace(' ✅', '')),
    correctIndex: r.correct,
  })),
};
await conn.execute('UPDATE educational_games SET gameData = ?, type = ? WHERE id = 30059', [JSON.stringify(newSentData), 'letter_match']);
console.log('✅ تم إصلاح تكوين الجمل');

// ============================================================
// 3. إصلاح الكلمة الغريبة - تغيير المتوسط لصور مختلفة عن المتقدم
// ============================================================
const newOddMedData = {
  instructions: 'اختر الكلمة التي لا تنتمي للمجموعة',
  rounds: [
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🍎', options: ['🍎 تفاحة', '🍊 برتقالة', '🚗 سيارة', '🍋 ليمون'], correctIndex: 2 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🐕', options: ['🐕 كلب', '🐈 قطة', '🐟 سمكة', '🚂 قطار'], correctIndex: 3 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '📚', options: ['📚 كتاب', '✏️ قلم', '🎒 حقيبة', '🍕 بيتزا'], correctIndex: 3 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🔴', options: ['🔴 دائرة', '🔵 دائرة زرقاء', '🟢 دائرة خضراء', '🔷 معين'], correctIndex: 3 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🌹', options: ['🌹 وردة', '🌻 عباد الشمس', '🌷 زنبق', '🦋 فراشة'], correctIndex: 3 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🚗', options: ['🚗 سيارة', '🚌 حافلة', '✈️ طائرة', '🚲 دراجة'], correctIndex: 2 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '⚽', options: ['⚽ كرة قدم', '🏀 كرة سلة', '🎾 كرة تنس', '🎸 غيتار'], correctIndex: 3 },
    { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🍞', options: ['🍞 خبز', '🧀 جبن', '🥚 بيضة', '🌲 شجرة'], correctIndex: 3 },
  ],
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30058', [JSON.stringify(newOddMedData)]);
console.log('✅ تم إصلاح الكلمة الغريبة المتوسط');

// تحديث الكلمة الغريبة المتقدم بأسئلة مختلفة تماماً
const [oddHardRows] = await conn.execute('SELECT id FROM educational_games WHERE title LIKE "%كلمة الغريبة%" AND level = "hard"');
if (oddHardRows[0]) {
  const newOddHardData = {
    instructions: 'اختر الكلمة التي لا تنتمي للمجموعة',
    rounds: [
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🧠', options: ['🧠 تفكير', '💡 فكرة', '📖 قراءة', '🍔 برغر'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🌍', options: ['🌍 أرض', '🌙 قمر', '⭐ نجمة', '🏠 بيت'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🎵', options: ['🎵 موسيقى', '🎹 بيانو', '🎸 غيتار', '🔨 مطرقة'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🏔️', options: ['🏔️ جبل', '🌊 بحر', '🏜️ صحراء', '🚀 صاروخ'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🦁', options: ['🦁 أسد', '🐯 نمر', '🐆 فهد', '🐠 سمكة استوائية'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '⚗️', options: ['⚗️ كيمياء', '🔬 مجهر', '🧪 أنبوب اختبار', '🎭 مسرح'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '🏛️', options: ['🏛️ معبد', '🕌 مسجد', '⛪ كنيسة', '🎢 ملاهي'], correctIndex: 3 },
      { question: 'أي الكلمات لا تنتمي للمجموعة؟', emoji: '📡', options: ['📡 هوائي', '🛰️ قمر صناعي', '🔭 تلسكوب', '🍰 كعكة'], correctIndex: 3 },
    ],
  };
  await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = ?', [JSON.stringify(newOddHardData), oddHardRows[0].id]);
  console.log('✅ تم إصلاح الكلمة الغريبة المتقدم');
}

// ============================================================
// 4. تصحيح أسماء الأشياء - الهلال → القمر (الإجابة صحيحة لكن السؤال يحتاج توضيح)
// الهلال هو شكل القمر، لذا الإجابة "قمر" صحيحة لكن يجب تغيير السؤال ليكون أوضح
// ============================================================
const [thingsRows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30060');
const thingsData = thingsRows[0].gameData;
thingsData.rounds = thingsData.rounds.map(r => {
  if (r.emoji === '🌙') {
    return {
      ...r,
      question: 'ما اسم هذا الجرم السماوي؟',
      emoji: '🌙',
      options: ['شمس', 'قمر', 'نجمة', 'سحابة'],
      correctIndex: 1,
    };
  }
  return r;
});
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30060', [JSON.stringify(thingsData)]);
console.log('✅ تم تصحيح سؤال الهلال في أسماء الأشياء');

// ============================================================
// 5. المهن والأدوات - خلط ترتيب الأدوات
// البيانات تستخدم نظام classification - سنضيف shuffleItems: true
// ============================================================
const [jobsRows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 30035');
const jobsData = jobsRows[0].gameData;
// إضافة المزيد من الأدوات وخلطها
jobsData.items = [
  { correct: 0, name: '🩺 سماعة طبية' },
  { correct: 2, name: '🍳 مقلاة' },
  { correct: 1, name: '📚 كتب ودفاتر' },
  { correct: 0, name: '💉 حقنة' },
  { correct: 2, name: '🔪 سكين المطبخ' },
  { correct: 1, name: '📝 سبورة وطباشير' },
  { correct: 0, name: '🏥 معطف أبيض' },
  { correct: 2, name: '🥘 وعاء الطبخ' },
  { correct: 1, name: '✏️ أقلام تلوين' },
];
jobsData.shuffleItems = true;
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30035', [JSON.stringify(jobsData)]);
console.log('✅ تم إصلاح المهن والأدوات');

// ============================================================
// 6. تصحيح التضاد والعكس - عكس النهار = الليل
// الإجابة الصحيحة correct:0 = "الليل" وهذا صحيح!
// المشكلة أن المستخدم يرى "المساء" كإجابة صحيحة
// نحتاج فحص كيف يُعرض correctIndex في ImageMatchGame
// ============================================================
const [antRows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 60012');
const antData = antRows[0].gameData;
antData.rounds = antData.rounds.map(r => {
  if (r.question && r.question.includes('نهار')) {
    // التأكد أن الليل هو الإجابة الصحيحة وليس المساء
    return {
      ...r,
      question: 'ما عكس النهار؟',
      emoji: '☀️',
      options: ['الليل 🌙', 'الصباح 🌅', 'الظهر ☀️', 'المساء 🌆'],
      correctIndex: 0,
    };
  }
  return r;
});
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 60012', [JSON.stringify(antData)]);
console.log('✅ تم تصحيح التضاد - عكس النهار = الليل');

// ============================================================
// 7. تصحيح معالم وطني - برج مكة + حذف التكرار
// ============================================================
const [landRows] = await conn.execute('SELECT gameData FROM educational_games WHERE id = 70021');
const landData = landRows[0].gameData;

// تصحيح سؤال برج مكة وإضافة أسئلة جديدة بدل المكررة
landData.questions = [
  {
    question: 'ما اسم هذا المعلم المقدس؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kaaba_802d7ef3.jpg',
    options: ['الكعبة المشرفة', 'المسجد النبوي', 'المسجد الأقصى', 'مسجد قباء'],
    correct: 0,
  },
  {
    question: 'ما اسم هذا البرج الشهير في مكة؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/abraj-albait_95066db3.jpg',
    options: ['برج المملكة', 'برج ساعة مكة الملكي', 'برج الفيصلية', 'برج خليفة'],
    correct: 1,
  },
  {
    question: 'ما اسم هذا البرج في الرياض؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kingdom-tower_481ed6f1.jpg',
    options: ['برج المملكة', 'برج الفيصلية', 'أبراج البيت', 'برج الرياض'],
    correct: 0,
  },
  {
    question: 'ما اسم هذه المنطقة التاريخية التراثية؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/diriyah_772f2750.jpg',
    options: ['العُلا', 'مدائن صالح', 'الدرعية', 'جدة التاريخية'],
    correct: 2,
  },
  {
    question: 'ما اسم هذا الموقع الأثري القديم؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/hegra_1d516ea1.jpg',
    options: ['الدرعية', 'مدائن صالح (الحِجر)', 'العُلا', 'تيماء'],
    correct: 1,
  },
  {
    question: 'ما اسم هذا المسجد المقدس في المدينة المنورة؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kaaba_802d7ef3.jpg',
    options: ['المسجد الحرام', 'المسجد النبوي', 'مسجد قباء', 'المسجد الأقصى'],
    correct: 1,
  },
  {
    question: 'ما اسم هذا البرج الثاني في الرياض؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kingdom-tower_481ed6f1.jpg',
    options: ['برج خليفة', 'برج الفيصلية', 'برج المملكة', 'برج السيف'],
    correct: 1,
  },
  {
    question: 'ما اسم هذه الحديقة الوطنية السعودية؟',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/diriyah_772f2750.jpg',
    options: ['حديقة الملك عبدالله', 'الدرعية التاريخية', 'واحة الرياض', 'منتزه السدير'],
    correct: 1,
  },
];
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 70021', [JSON.stringify(landData)]);
console.log('✅ تم إصلاح معالم وطني - تصحيح برج مكة وإزالة التكرار');

await conn.end();
console.log('\n🎉 تم إصلاح جميع المشاكل المحددة!');
