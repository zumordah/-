import { readFileSync } from 'fs';
import { createConnection } from 'mysql2/promise';
import { config } from 'dotenv';

config({ path: '/home/ubuntu/kidstories-update/.env' });

const data = JSON.parse(readFileSync('/home/ubuntu/adventures_data.json', 'utf-8'));

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('DATABASE_URL not found');
  process.exit(1);
}

console.log('Connecting to database...');
const conn = await createConnection(DATABASE_URL);

try {
  // تحديث المغامرات الموجودة بإضافة نهايات خطيرة
  for (const update of data.updates) {
    await conn.execute(
      'UPDATE story_adventures SET adventureData = ? WHERE id = ?',
      [JSON.stringify(update.adventureData), update.id]
    );
    console.log(`✅ تم تحديث المغامرة ${update.id}`);
  }

  // إضافة المغامرات الجديدة
  for (const adv of data.new_adventures) {
    await conn.execute(
      `INSERT INTO story_adventures 
       (title, description, emoji, level, ageGroup, pointsReward, totalEndings, adventureData, isPublished, orderIndex)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      [
        adv.title,
        adv.description,
        adv.emoji,
        adv.level,
        adv.ageGroup,
        adv.pointsReward,
        adv.totalEndings,
        JSON.stringify(adv.adventureData),
        adv.orderIndex
      ]
    );
    console.log(`✅ تم إضافة مغامرة جديدة: ${adv.title}`);
  }

  // التحقق من العدد الكلي
  const [rows] = await conn.execute('SELECT COUNT(*) as count FROM story_adventures');
  console.log(`\n🎉 تم الانتهاء! إجمالي المغامرات: ${rows[0].count}`);
} catch (err) {
  console.error('خطأ:', err.message);
  console.error(err);
} finally {
  await conn.end();
}
