import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const [rows] = await conn.query('SELECT gameData FROM educational_games WHERE id = 90006');
const data = rows[0].gameData;

// إصلاح الأسئلة:
// 1. سؤال السيف: تغيير السؤال من "ما اسم السيف" إلى سؤال عن أكبر محافظة
// 2. المشروب: تصحيح الإجابة من "القهوة العربية" إلى "القهوة السعودية"
// 3. النخلة: تغيير السؤال من "شجرة" إلى سؤال عن الطعام التقليدي
// 4. الزي: تغيير الإيموجي من 👘 إلى 🥻 أو نص وصفي
// 5. العلم: تغيير السؤال من "الشعار الديني" إلى "ماذا يكتب على العلم"

const fixedRounds = [
  // السؤال 1: استبدال سؤال السيف بسؤال عن أكبر محافظة
  {
    question: "ما أكبر محافظة في المملكة العربية السعودية؟",
    emoji: "🗺️",
    options: ["محافظة جدة", "محافظة الرياض", "محافظة الأحساء", "محافظة مكة"],
    correct: 2
  },
  // السؤال 2: الجمل - يبقى كما هو (صحيح)
  data.rounds[1],
  // السؤال 3: تصحيح المشروب من "القهوة العربية" إلى "القهوة السعودية"
  {
    question: "ما المشروب التقليدي السعودي المشهور؟",
    emoji: "☕",
    options: ["الشاي الأحمر", "القهوة السعودية", "عصير التمر", "اللبن"],
    correct: 1
  },
  // السؤال 4: تغيير سؤال النخلة - بدلاً من "شجرة" نسأل عن الطعام التقليدي
  {
    question: "ما الفاكهة التي تُعدّ من أشهر منتجات المملكة العربية السعودية؟",
    emoji: "🌴",
    options: ["التفاح", "البرتقال", "التمر", "العنب"],
    correct: 2
  },
  // السؤال 5: الدرعية - يبقى كما هو (صحيح)
  data.rounds[4],
  // السؤال 6: العرضة - يبقى كما هو (صحيح)
  data.rounds[5],
  // السؤال 7: الزي - تغيير الإيموجي من 👘 إلى وصف نصي واضح
  {
    question: "ما اسم الزي التقليدي للرجل السعودي؟",
    emoji: "🧕",
    options: ["الجلباب", "الثوب", "العباءة", "الكندورة"],
    correct: 1,
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Traditional_Saudi_clothing.jpg/200px-Traditional_Saudi_clothing.jpg"
  },
  // السؤال 8: تعديل سؤال العلم من "الشعار الديني" إلى "ماذا يكتب"
  {
    question: "ماذا يكتب على علم المملكة العربية السعودية؟",
    emoji: "🇸🇦",
    options: ["بسم الله الرحمن الرحيم", "الحمد لله رب العالمين", "لا إله إلا الله محمد رسول الله", "الله أكبر"],
    correct: 2
  }
];

data.rounds = fixedRounds;

await conn.query(
  'UPDATE educational_games SET gameData = ? WHERE id = 90006',
  [JSON.stringify(data)]
);
console.log('✅ Fixed التراث السعودي questions');

await conn.end();
