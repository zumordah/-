import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// التأكد من أن enum يدعم النوعين الجديدين
await conn.execute(`ALTER TABLE shop_items MODIFY COLUMN type ENUM('avatar','theme','adventure_unlock','avatar_frame','game_pack','adventure_pack','game_unlock','adventure_item_unlock') NOT NULL`);
console.log('✅ تم توسيع enum');

// حذف أي عناصر قديمة من نوع game_unlock أو adventure_item_unlock
await conn.execute(`DELETE FROM shop_items WHERE type IN ('game_unlock','adventure_item_unlock')`);

// الألعاب المقفلة
const lockedGames = [
  {id:30029, title:"الألوان والأشكال", emoji:"🎨", level:"easy", cost:40},
  {id:30030, title:"أجزاء الجسم", emoji:"🧒", level:"easy", cost:40},
  {id:30031, title:"صنّف الأشياء", emoji:"📦", level:"easy", cost:40},
  {id:30032, title:"جمع وطرح سهل", emoji:"➕", level:"easy", cost:40},
  {id:30038, title:"أكمل الجملة", emoji:"💬", level:"easy", cost:40},
  {id:60001, title:"طرح الأرقام الصغيرة", emoji:"➖", level:"easy", cost:40},
  {id:60003, title:"طرح الأرقام الصغيرة (2)", emoji:"➖", level:"easy", cost:40},
  {id:60004, title:"طرح بالصور", emoji:"🖼️", level:"easy", cost:40},
  {id:60009, title:"جمع مع الصفر", emoji:"0️⃣", level:"easy", cost:40},
  {id:60010, title:"أكبر أم أصغر؟ (متقدم)", emoji:"🔢", level:"easy", cost:40},
  {id:30035, title:"المهن والأدوات", emoji:"👨‍⚕️", level:"medium", cost:60},
  {id:30036, title:"ابنِ الكلمة", emoji:"🧩", level:"medium", cost:60},
  {id:30039, title:"صنّف العلوم", emoji:"🔬", level:"medium", cost:60},
  {id:30040, title:"جمع وطرح متوسط", emoji:"🧮", level:"medium", cost:60},
  {id:60005, title:"طرح الأرقام المتوسطة", emoji:"➖", level:"medium", cost:60},
  {id:60011, title:"أكمل الجملة - متوسط", emoji:"📝", level:"medium", cost:60},
  {id:60012, title:"التضاد والعكس", emoji:"🔄", level:"medium", cost:60},
  {id:30043, title:"لعبة الذاكرة", emoji:"🧠", level:"hard", cost:80},
  {id:30047, title:"جمع وطرح متقدم", emoji:"🏆", level:"hard", cost:80},
  {id:30048, title:"اكتشف الدخيل", emoji:"🔎", level:"hard", cost:80},
  {id:60007, title:"جمع الأرقام الكبيرة", emoji:"➕", level:"hard", cost:80},
  {id:60008, title:"جمع ثلاثة أرقام", emoji:"➕", level:"hard", cost:80},
  {id:60013, title:"أعلام الدول", emoji:"🌍", level:"hard", cost:80},
  {id:60014, title:"معلومات ممتعة", emoji:"🌟", level:"hard", cost:80},
];

// المغامرات المقفلة
const lockedAdventures = [
  {id:30001, title:"الولد الذي كذب", emoji:"🤥", level:"easy", cost:70},
  {id:30002, title:"ريم والنهر الخطير", emoji:"🌊", level:"easy", cost:70},
  {id:30004, title:"يوم الاختبار الصعب", emoji:"📝", level:"medium", cost:70},
  {id:30005, title:"الغابة المسحورة", emoji:"🌲", level:"medium", cost:70},
  {id:30008, title:"الاختراع الذي غيّر المدينة", emoji:"🔬", level:"hard", cost:90},
  {id:30009, title:"رحلة إلى المجهول", emoji:"🗺️", level:"hard", cost:90},
  {id:30010, title:"الملك الصغير وقراره الأول", emoji:"👑", level:"hard", cost:90},
];

const levelOrder = { easy: 1, medium: 2, hard: 3 };
let sortOrder = 20;

// إضافة الألعاب
for (const g of lockedGames) {
  const levelRequired = levelOrder[g.level];
  const description = `افتح لعبة «${g.title}» في المستوى ${g.level === 'easy' ? 'المبتدئ' : g.level === 'medium' ? 'المتوسط' : 'المتقدم'}`;
  await conn.execute(
    'INSERT INTO shop_items (type, name, description, icon, value, levelRequired, pointsCost, isEnabled, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)',
    ['game_unlock', g.title, description, g.emoji, `game_${g.id}`, levelRequired, g.cost, sortOrder++]
  );
}
console.log(`✅ تم إضافة ${lockedGames.length} لعبة في المتجر`);

// إضافة المغامرات
for (const a of lockedAdventures) {
  const levelRequired = levelOrder[a.level];
  const description = `افتح مغامرة «${a.title}» في المستوى ${a.level === 'easy' ? 'المبتدئ' : a.level === 'medium' ? 'المتوسط' : 'المتقدم'}`;
  await conn.execute(
    'INSERT INTO shop_items (type, name, description, icon, value, levelRequired, pointsCost, isEnabled, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)',
    ['adventure_item_unlock', a.title, description, a.emoji, `adventure_${a.id}`, levelRequired, a.cost, sortOrder++]
  );
}
console.log(`✅ تم إضافة ${lockedAdventures.length} مغامرة في المتجر`);

const [total] = await conn.execute('SELECT type, COUNT(*) as cnt FROM shop_items GROUP BY type');
console.log('\n📊 إجمالي عناصر المتجر:', total);

await conn.end();
