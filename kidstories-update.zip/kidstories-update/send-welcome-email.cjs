// سكريبت إرسال إيميل الترحيب لمديرة روضة الورود
const { Resend } = require('./node_modules/resend');

async function main() {
  const resend = new Resend(process.env.RESEND_API_KEY);

  const schoolName = 'روضة الورود';
  const email = 'zuza-77@hotmail.com';
  const password = 'Roses2026!';

  const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Arial', sans-serif; background: #f0f4ff; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
    .header { background: linear-gradient(135deg, #6c63ff, #a855f7); padding: 30px; text-align: center; color: white; }
    .header h1 { margin: 0; font-size: 24px; }
    .header p { margin: 8px 0 0; opacity: 0.9; }
    .body { padding: 30px; }
    .body h2 { color: #333; font-size: 20px; }
    .info-box { background: #f8f4ff; border: 2px solid #6c63ff; border-radius: 12px; padding: 20px; margin: 20px 0; }
    .info-row { display: flex; justify-content: space-between; margin: 10px 0; }
    .label { color: #666; font-weight: bold; }
    .value { color: #6c63ff; font-weight: bold; font-size: 16px; }
    .btn { display: block; background: linear-gradient(135deg, #6c63ff, #a855f7); color: white; text-decoration: none; padding: 14px 30px; border-radius: 10px; text-align: center; font-size: 16px; margin: 20px 0; }
    .classrooms { background: #f0fff4; border: 2px solid #10b981; border-radius: 12px; padding: 15px; margin: 15px 0; }
    .footer { background: #f8f8f8; padding: 20px; text-align: center; color: #999; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>📚 قصة وفكرة</h1>
      <p>مرحباً بك في منصتنا التعليمية</p>
    </div>
    <div class="body">
      <h2>مرحباً بمدرسة ${schoolName} 🌹🎉</h2>
      <p>تم إنشاء حسابك بنجاح كمديرة لـ <strong>${schoolName}</strong> في منصة قصة وفكرة التعليمية.</p>
      <p>يمكنك الآن تتبع تقدم طلابك ومشاهدة إحصائياتهم التفصيلية.</p>
      
      <div class="info-box">
        <p style="margin: 0 0 15px; font-weight: bold; color: #333;">بيانات تسجيل الدخول:</p>
        <div class="info-row">
          <span class="label">البريد الإلكتروني:</span>
          <span class="value">${email}</span>
        </div>
        <div class="info-row">
          <span class="label">كلمة المرور:</span>
          <span class="value">${password}</span>
        </div>
      </div>

      <div class="classrooms">
        <p style="margin: 0 0 10px; font-weight: bold; color: #333;">🏫 فصول روضة الورود:</p>
        <p style="margin: 5px 0;">🕯️ فصل الشمعة</p>
        <p style="margin: 5px 0;">🚗 فصل السيارة</p>
        <p style="margin: 5px 0;">🐻 فصل الدب</p>
      </div>

      <p>يمكن للأطفال التسجيل في المنصة واختيار مدرستهم وفصلهم عند إنشاء الحساب.</p>
      
      <a href="https://kidstories-92plgnvs.manus.space" class="btn">🚀 الدخول للمنصة</a>
      
      <p style="color: #888; font-size: 13px;">للدخول للوحة الإدارة: اضغطي على "لديّ حساب - ادخل" ثم اختاري "دخول المعلمين والإدارة"</p>
    </div>
    <div class="footer">© 2026 قصة وفكرة - جميع الحقوق محفوظة</div>
  </div>
</body>
</html>`;

  try {
    const result = await resend.emails.send({
      from: 'قصة وفكرة <onboarding@resend.dev>',
      to: email,
      subject: `🌹 مرحباً بمدرسة ${schoolName} في منصة قصة وفكرة!`,
      html,
    });
    console.log('✅ Email sent successfully:', JSON.stringify(result));
  } catch (err) {
    console.error('❌ Email failed:', err.message);
  }
}

main().catch(e => { console.error(e.message); process.exit(1); });
