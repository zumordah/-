const mysql = require('./node_modules/mysql2/promise');

const toArabic = (str) => {
  if (typeof str !== 'string') return str;
  return str.replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[parseInt(d)]);
};

function convertObj(obj) {
  if (typeof obj === 'string') return toArabic(obj);
  if (Array.isArray(obj)) return obj.map(convertObj);
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      result[k] = convertObj(v);
    }
    return result;
  }
  return obj;
}

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  const [rows] = await conn.execute('SELECT id, title, gameData FROM educational_games');
  
  let updated = 0;
  let skipped = 0;

  for (const row of rows) {
    const original = row.gameData;
    if (!original || typeof original !== 'object') { skipped++; continue; }
    
    const converted = convertObj(original);
    const origStr = JSON.stringify(original);
    const convStr = JSON.stringify(converted);
    
    if (origStr !== convStr) {
      await conn.execute(
        'UPDATE educational_games SET gameData = ? WHERE id = ?',
        [convStr, row.id]
      );
      console.log(`✅ Updated: [${row.id}] ${row.title}`);
      updated++;
    } else {
      skipped++;
    }
  }

  console.log(`\nDone: ${updated} updated, ${skipped} skipped`);
  await conn.end();
}

main().catch(e => { console.error(e.message); process.exit(1); });
