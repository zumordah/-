import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Clear existing games first
await conn.query('DELETE FROM educational_games');

const games = [];
let orderIdx = 0;

// ═══════════════════════════════════════════════════════════════════════════
// المستوى السهل (easy) - ألعاب مبتدئة
// ═══════════════════════════════════════════════════════════════════════════

// 1. تعرّف على الحروف (letter_match) - سهل
games.push({
  title: "تعرّف على الحروف",
  description: "تعلّم الحروف العربية بطريقة ممتعة",
  type: "letter_match",
  level: "easy",
  ageGroup: "4-6",
  emoji: "🔤",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الإجابة الصحيحة لكل حرف",
    rounds: [
      { letter: "أ", question: "ما اسم هذا الحرف؟", options: ["ألف", "باء", "تاء", "ثاء"], correct: 0 },
      { letter: "ب", question: "ما اسم هذا الحرف؟", options: ["جيم", "باء", "نون", "سين"], correct: 1 },
      { letter: "ت", question: "ما اسم هذا الحرف؟", options: ["تاء", "ثاء", "حاء", "خاء"], correct: 0 },
      { letter: "ث", question: "ما اسم هذا الحرف؟", options: ["سين", "شين", "ثاء", "ذال"], correct: 2 },
      { letter: "ج", question: "ما اسم هذا الحرف؟", options: ["حاء", "خاء", "جيم", "دال"], correct: 2 },
    ]
  })
});

// 2. عدّ الأشكال (count_objects) - سهل
games.push({
  title: "عدّ الأشكال",
  description: "تعلّم العدّ بطريقة مرحة",
  type: "count_objects",
  level: "easy",
  ageGroup: "4-6",
  emoji: "🔢",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "كم عدد الأشكال؟",
    rounds: [
      { emoji: "🌟", count: 3, question: "كم نجمة ترى؟", options: [2, 3, 4, 5], correct: 1 },
      { emoji: "🍎", count: 5, question: "كم تفاحة ترى؟", options: [3, 4, 5, 6], correct: 2 },
      { emoji: "🐱", count: 2, question: "كم قطة ترى؟", options: [1, 2, 3, 4], correct: 1 },
      { emoji: "🌸", count: 4, question: "كم زهرة ترى؟", options: [2, 3, 4, 5], correct: 2 },
      { emoji: "🐦", count: 6, question: "كم عصفور ترى؟", options: [4, 5, 6, 7], correct: 2 },
    ]
  })
});

// 3. تطابق الصور (image_match) - سهل
games.push({
  title: "تطابق الصور",
  description: "طابق الصورة مع اسمها الصحيح",
  type: "image_match",
  level: "easy",
  ageGroup: "4-6",
  emoji: "🖼️",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "ما اسم هذا الشيء؟",
    rounds: [
      { emoji: "🌞", question: "ما هذا؟", options: ["شمس", "قمر", "نجمة", "سحابة"], correct: 0 },
      { emoji: "🌙", question: "ما هذا؟", options: ["شمس", "قمر", "نجمة", "كوكب"], correct: 1 },
      { emoji: "🌳", question: "ما هذا؟", options: ["زهرة", "عشب", "شجرة", "ورقة"], correct: 2 },
      { emoji: "🐟", question: "ما هذا؟", options: ["طائر", "سمكة", "قطة", "أرنب"], correct: 1 },
      { emoji: "🏠", question: "ما هذا؟", options: ["مدرسة", "مسجد", "بيت", "سوق"], correct: 2 },
    ]
  })
});

// 4. صوت الحرف (منقول من المستوى الصعب إلى السهل)
games.push({
  title: "صوت الحرف",
  description: "تعرّف على أصوات الحروف العربية",
  type: "letter_match",
  level: "easy",
  ageGroup: "4-6",
  emoji: "🔊",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الكلمة التي تبدأ بهذا الحرف",
    rounds: [
      { letter: "ب", question: "أي كلمة تبدأ بحرف الباء؟", options: ["بطة", "تمر", "جمل", "دب"], correct: 0 },
      { letter: "س", question: "أي كلمة تبدأ بحرف السين؟", options: ["شمس", "سمكة", "صقر", "ضفدع"], correct: 1 },
      { letter: "ك", question: "أي كلمة تبدأ بحرف الكاف؟", options: ["لعبة", "كتاب", "ملعب", "نجمة"], correct: 1 },
      { letter: "و", question: "أي كلمة تبدأ بحرف الواو؟", options: ["هدية", "وردة", "يد", "أسد"], correct: 1 },
      { letter: "م", question: "أي كلمة تبدأ بحرف الميم؟", options: ["نحلة", "هلال", "موز", "ورقة"], correct: 2 },
    ]
  })
});

// 5. الألوان والأشكال (بديل عن الحيوانات وأصواتها المحذوفة)
games.push({
  title: "الألوان والأشكال",
  description: "تعرّف على الألوان والأشكال الهندسية",
  type: "image_match",
  level: "easy",
  ageGroup: "4-6",
  emoji: "🎨",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الإجابة الصحيحة",
    rounds: [
      { emoji: "🔴", question: "ما لون هذه الدائرة؟", options: ["أحمر", "أزرق", "أخضر", "أصفر"], correct: 0 },
      { emoji: "🟡", question: "ما لون هذه الدائرة؟", options: ["برتقالي", "أخضر", "أصفر", "بنفسجي"], correct: 2 },
      { emoji: "🟢", question: "ما لون هذه الدائرة؟", options: ["أزرق", "أخضر", "أحمر", "أبيض"], correct: 1 },
      { emoji: "🔵", question: "ما لون هذه الدائرة؟", options: ["أصفر", "أحمر", "أخضر", "أزرق"], correct: 3 },
      { emoji: "🟣", question: "ما لون هذه الدائرة؟", options: ["بنفسجي", "وردي", "أزرق", "أحمر"], correct: 0 },
    ]
  })
});

// 6. أجزاء الجسم (بديل عن الأضداد المحذوفة)
games.push({
  title: "أجزاء الجسم",
  description: "تعرّف على أجزاء جسم الإنسان",
  type: "image_match",
  level: "easy",
  ageGroup: "4-6",
  emoji: "🧒",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الإجابة الصحيحة",
    rounds: [
      { emoji: "👁️", question: "ما هذا الجزء من الجسم؟", options: ["أنف", "عين", "فم", "أذن"], correct: 1 },
      { emoji: "👂", question: "ما هذا الجزء من الجسم؟", options: ["عين", "يد", "أذن", "قدم"], correct: 2 },
      { emoji: "✋", question: "ما هذا الجزء من الجسم؟", options: ["قدم", "يد", "رأس", "كتف"], correct: 1 },
      { emoji: "🦶", question: "ما هذا الجزء من الجسم؟", options: ["يد", "ركبة", "قدم", "ذراع"], correct: 2 },
      { emoji: "👃", question: "ما هذا الجزء من الجسم؟", options: ["فم", "أذن", "عين", "أنف"], correct: 3 },
    ]
  })
});

// 7. تصنيف بسيط (classification) - سهل
games.push({
  title: "صنّف الأشياء",
  description: "صنّف الأشياء في مجموعاتها الصحيحة",
  type: "classification",
  level: "easy",
  ageGroup: "4-6",
  emoji: "📦",
  pointsReward: 15,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "في أي مجموعة ينتمي هذا الشيء؟",
    categories: ["فواكه 🍎", "حيوانات 🐱"],
    items: [
      { name: "🍌 موز", correct: 0 },
      { name: "🐕 كلب", correct: 1 },
      { name: "🍊 برتقال", correct: 0 },
      { name: "🐈 قطة", correct: 1 },
      { name: "🍇 عنب", correct: 0 },
      { name: "🐦 عصفور", correct: 1 },
    ]
  })
});

// 8. جمع وطرح سهل (math) - سهل
games.push({
  title: "جمع وطرح سهل",
  description: "تعلّم الجمع والطرح بأرقام صغيرة",
  type: "math_addition",
  level: "easy",
  ageGroup: "4-6",
  emoji: "➕",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "احسب الناتج الصحيح",
    rounds: [
      { emoji: "🔢", count: 0, question: "١ + ١ = ؟", options: [1, 2, 3, 4], correct: 1 },
      { emoji: "🔢", count: 0, question: "٢ + ١ = ؟", options: [2, 3, 4, 5], correct: 1 },
      { emoji: "🔢", count: 0, question: "٣ - ١ = ؟", options: [1, 2, 3, 4], correct: 1 },
      { emoji: "🔢", count: 0, question: "٢ + ٢ = ؟", options: [3, 4, 5, 6], correct: 1 },
      { emoji: "🔢", count: 0, question: "٥ - ٢ = ؟", options: [2, 3, 4, 1], correct: 1 },
      { emoji: "🔢", count: 0, question: "١ + ٣ = ؟", options: [3, 4, 5, 2], correct: 1 },
    ]
  })
});

// ═══════════════════════════════════════════════════════════════════════════
// المستوى المتوسط (medium) - ألعاب متوسطة
// ═══════════════════════════════════════════════════════════════════════════
orderIdx = 0;

// 1. الحرف الناقص (مدمج - بدون تكرار) - مع إصلاح كلمة مكتب
games.push({
  title: "الحرف الناقص",
  description: "أكمل الكلمة بالحرف الناقص",
  type: "missing_letter",
  level: "medium",
  ageGroup: "6-8",
  emoji: "✏️",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الحرف الناقص لإكمال الكلمة",
    rounds: [
      { word: "_ـتاب", hint: "نقرأ فيه القصص 📚", options: ["ب", "ك", "ت", "م"], correct: 1 },
      { word: "م_رسة", hint: "نتعلم فيها 🏫", options: ["ك", "د", "ب", "ت"], correct: 1 },
      { word: "شم_", hint: "تضيء النهار ☀️", options: ["ص", "س", "ش", "ض"], correct: 1 },
      { word: "قم_", hint: "يضيء الليل 🌙", options: ["ل", "ن", "ر", "م"], correct: 2 },
      { word: "_حر", hint: "فيه ماء كثير 🌊", options: ["ب", "ن", "م", "ت"], correct: 0 },
      { word: "مك_ب", hint: "نكتب عليه 🪑", options: ["ط", "ت", "ث", "د"], correct: 1 },
    ]
  })
});

// 2. الفصول الأربعة (مصحح - بدون كشف الإجابة في السؤال)
games.push({
  title: "الفصول الأربعة",
  description: "تعرّف على فصول السنة وخصائصها",
  type: "classification",
  level: "medium",
  ageGroup: "6-8",
  emoji: "🍂",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "في أي فصل من السنة نجد هذا؟",
    categories: ["الصيف ☀️", "الشتاء ❄️", "الربيع 🌸", "الخريف 🍂"],
    items: [
      { name: "🏖️ السباحة في البحر", correct: 0 },
      { name: "❄️ تساقط الثلوج", correct: 1 },
      { name: "🌷 تفتح الأزهار", correct: 2 },
      { name: "🍁 تساقط أوراق الشجر", correct: 3 },
      { name: "🧥 ارتداء المعاطف الثقيلة", correct: 1 },
      { name: "🦋 ظهور الفراشات", correct: 2 },
      { name: "🍉 أكل البطيخ البارد", correct: 0 },
      { name: "🌧️ هبوب الرياح القوية", correct: 3 },
    ]
  })
});

// 3. المهن والأدوات (classification) - متوسط
games.push({
  title: "المهن والأدوات",
  description: "طابق كل مهنة مع أدواتها",
  type: "classification",
  level: "medium",
  ageGroup: "6-8",
  emoji: "👨‍⚕️",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "لمن تنتمي هذه الأداة؟",
    categories: ["طبيب 👨‍⚕️", "معلم 👨‍🏫", "طباخ 👨‍🍳"],
    items: [
      { name: "🩺 سماعة طبية", correct: 0 },
      { name: "📚 كتب ودفاتر", correct: 1 },
      { name: "🍳 مقلاة", correct: 2 },
      { name: "💉 حقنة", correct: 0 },
      { name: "📝 سبورة وطباشير", correct: 1 },
      { name: "🔪 سكين المطبخ", correct: 2 },
    ]
  })
});

// 4. ابنِ الكلمة (word_build) - متوسط
games.push({
  title: "ابنِ الكلمة",
  description: "رتّب الحروف لتكوين كلمة صحيحة",
  type: "word_build",
  level: "medium",
  ageGroup: "6-8",
  emoji: "🧩",
  pointsReward: 25,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "رتّب الحروف لتكوين الكلمة",
    rounds: [
      { word: "كتاب", letters: ["ك", "ت", "ا", "ب"], hint: "نقرأ فيه 📖" },
      { word: "قلم", letters: ["ق", "ل", "م"], hint: "نكتب به ✏️" },
      { word: "شمس", letters: ["ش", "م", "س"], hint: "تضيء السماء ☀️" },
      { word: "ورد", letters: ["و", "ر", "د"], hint: "زهرة جميلة 🌹" },
      { word: "بحر", letters: ["ب", "ح", "ر"], hint: "فيه ماء كثير 🌊" },
    ]
  })
});

// 5. رتّب الأحداث (number_order) - متوسط
games.push({
  title: "رتّب الأحداث",
  description: "رتّب أحداث اليوم بالترتيب الصحيح",
  type: "number_order",
  level: "medium",
  ageGroup: "6-8",
  emoji: "📋",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "رتّب أحداث اليوم من الصباح إلى المساء",
    items: ["🌅 الاستيقاظ", "🪥 تنظيف الأسنان", "🏫 الذهاب للمدرسة", "📚 الدراسة", "🏠 العودة للبيت", "🌙 النوم"],
    correctOrder: [0, 1, 2, 3, 4, 5]
  })
});

// 6. تطابق متقدم (image_match) - متوسط
games.push({
  title: "أكمل الجملة",
  description: "اختر الكلمة المناسبة لإكمال الجملة",
  type: "letter_match",
  level: "medium",
  ageGroup: "6-8",
  emoji: "💬",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الكلمة المناسبة لإكمال الجملة",
    rounds: [
      { letter: "📖", question: "الطفل يقرأ ___", options: ["كتاباً", "كرسياً", "حذاءً", "سريراً"], correct: 0 },
      { letter: "🌧️", question: "في الشتاء تنزل ___", options: ["الشمس", "الأمطار", "الأزهار", "الفراشات"], correct: 1 },
      { letter: "🐱", question: "القطة تشرب ___", options: ["عصيراً", "شاياً", "حليباً", "قهوة"], correct: 2 },
      { letter: "🌻", question: "الزهرة تحتاج إلى ___ لتنمو", options: ["ظلام", "ماء", "ثلج", "رمل"], correct: 1 },
      { letter: "🏫", question: "نتعلم في ___", options: ["السوق", "المستشفى", "المدرسة", "المطعم"], correct: 2 },
    ]
  })
});

// 7. صنّف العلوم (classification) - متوسط
games.push({
  title: "صنّف العلوم",
  description: "صنّف الكائنات الحية وغير الحية",
  type: "classification",
  level: "medium",
  ageGroup: "6-8",
  emoji: "🔬",
  pointsReward: 20,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "هل هذا كائن حي أم غير حي؟",
    categories: ["كائن حي 🌱", "غير حي 🪨"],
    items: [
      { name: "🌳 شجرة", correct: 0 },
      { name: "🪨 صخرة", correct: 1 },
      { name: "🐝 نحلة", correct: 0 },
      { name: "💧 ماء", correct: 1 },
      { name: "🌸 زهرة", correct: 0 },
      { name: "⭐ نجمة", correct: 1 },
      { name: "🐠 سمكة", correct: 0 },
      { name: "🏔️ جبل", correct: 1 },
    ]
  })
});

// 8. جمع وطرح متوسط
games.push({
  title: "جمع وطرح متوسط",
  description: "تحدّى نفسك بعمليات حسابية أصعب",
  type: "math_addition",
  level: "medium",
  ageGroup: "6-8",
  emoji: "🧮",
  pointsReward: 25,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "احسب الناتج الصحيح",
    rounds: [
      { emoji: "🔢", count: 0, question: "٥ + ٣ = ؟", options: [6, 7, 8, 9], correct: 2 },
      { emoji: "🔢", count: 0, question: "١٠ - ٤ = ؟", options: [5, 6, 7, 8], correct: 1 },
      { emoji: "🔢", count: 0, question: "٧ + ٥ = ؟", options: [10, 11, 12, 13], correct: 2 },
      { emoji: "🔢", count: 0, question: "١٥ - ٧ = ؟", options: [6, 7, 8, 9], correct: 2 },
      { emoji: "🔢", count: 0, question: "٩ + ٦ = ؟", options: [13, 14, 15, 16], correct: 2 },
      { emoji: "🔢", count: 0, question: "٢٠ - ٨ = ؟", options: [10, 11, 12, 13], correct: 2 },
    ]
  })
});

// ═══════════════════════════════════════════════════════════════════════════
// المستوى الصعب (hard) - ألعاب متقدمة
// ═══════════════════════════════════════════════════════════════════════════
orderIdx = 0;

// 1. الكلمة المخفية (word_build) - صعب
games.push({
  title: "الكلمة المخفية",
  description: "اكتشف الكلمة المخفية من التلميحات",
  type: "word_build",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🔍",
  pointsReward: 30,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "رتّب الحروف لتكوين الكلمة المخفية",
    rounds: [
      { word: "مستشفى", letters: ["م", "س", "ت", "ش", "ف", "ى"], hint: "نذهب إليه عندما نمرض 🏥" },
      { word: "طائرة", letters: ["ط", "ا", "ئ", "ر", "ة"], hint: "تطير في السماء ✈️" },
      { word: "مكتبة", letters: ["م", "ك", "ت", "ب", "ة"], hint: "فيها كتب كثيرة 📚" },
      { word: "حديقة", letters: ["ح", "د", "ي", "ق", "ة"], hint: "فيها أزهار وأشجار 🌳" },
    ]
  })
});

// 2. الألغاز الذكية (letter_match) - صعب (محتوى جديد بدلاً من المكرر)
games.push({
  title: "ألغاز وتحديات",
  description: "حل الألغاز الذكية واختبر ذكاءك",
  type: "letter_match",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🧠",
  pointsReward: 30,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الإجابة الصحيحة",
    rounds: [
      { letter: "❓", question: "شيء له أسنان ولا يأكل، ما هو؟", options: ["المشط", "السكين", "القلم", "الكتاب"], correct: 0 },
      { letter: "❓", question: "كلما أخذت منه كبر، ما هو؟", options: ["البالون", "الحفرة", "الكرة", "الصندوق"], correct: 1 },
      { letter: "❓", question: "يمشي بلا أرجل ويبكي بلا عيون، ما هو؟", options: ["الريح", "السحاب", "النهر", "القطار"], correct: 1 },
      { letter: "❓", question: "له عين واحدة ولا يرى، ما هو؟", options: ["الإبرة", "المفتاح", "الزر", "الخاتم"], correct: 0 },
      { letter: "❓", question: "يسمع بلا أذن ويتكلم بلا لسان، ما هو؟", options: ["الراديو", "التلفاز", "الهاتف", "الكتاب"], correct: 2 },
    ]
  })
});

// 3. لعبة الذاكرة (memory) - صعب - جديدة!
games.push({
  title: "لعبة الذاكرة",
  description: "اكشف الصورة واحفظها ثم رتّب أجزاءها",
  type: "memory_game",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🧠",
  pointsReward: 35,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "احفظ ترتيب الصور ثم أعد ترتيبها بالشكل الصحيح",
    rounds: [
      { question: "احفظ ترتيب هذه الحيوانات", emoji: "🐱🐶🐰🐻", options: ["🐱🐶🐰🐻", "🐶🐱🐻🐰", "🐰🐻🐱🐶", "🐻🐰🐶🐱"], correct: 0 },
      { question: "احفظ ترتيب هذه الفواكه", emoji: "🍎🍌🍊🍇", options: ["🍌🍎🍇🍊", "🍎🍌🍊🍇", "🍊🍇🍎🍌", "🍇🍊🍌🍎"], correct: 1 },
      { question: "احفظ ترتيب هذه الأشكال", emoji: "⭐🌙☀️🌈", options: ["🌙⭐🌈☀️", "☀️🌈⭐🌙", "⭐🌙☀️🌈", "🌈☀️🌙⭐"], correct: 2 },
      { question: "احفظ ترتيب هذه الألوان", emoji: "🔴🟡🟢🔵🟣", options: ["🟡🔴🟢🔵🟣", "🔴🟡🟢🔵🟣", "🟢🔵🟣🔴🟡", "🔵🟣🔴🟡🟢"], correct: 1 },
      { question: "احفظ ترتيب وسائل النقل", emoji: "🚗🚌🚂✈️🚢", options: ["🚌🚗✈️🚂🚢", "🚗🚌🚂✈️🚢", "✈️🚢🚗🚌🚂", "🚂✈️🚢🚗🚌"], correct: 1 },
    ]
  })
});

// 4. الخريطة الذهنية (مصحح - محتوى منطقي)
games.push({
  title: "الخريطة الذهنية",
  description: "اربط المفاهيم ببعضها بشكل منطقي",
  type: "classification",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🗺️",
  pointsReward: 30,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "صنّف كل عنصر في المجموعة الصحيحة",
    categories: ["أدوات مدرسية 📚", "أدوات طبخ 🍳", "أدوات رياضية ⚽"],
    items: [
      { name: "📏 مسطرة", correct: 0 },
      { name: "🥄 ملعقة كبيرة", correct: 1 },
      { name: "⚽ كرة قدم", correct: 2 },
      { name: "✏️ قلم رصاص", correct: 0 },
      { name: "🍲 قدر طبخ", correct: 1 },
      { name: "🏸 مضرب ريشة", correct: 2 },
      { name: "📐 منقلة", correct: 0 },
      { name: "🔪 سكين مطبخ", correct: 1 },
      { name: "🏀 كرة سلة", correct: 2 },
    ]
  })
});

// 5. رتّب أحداث القصة - متقدم (number_order) - صعب
games.push({
  title: "رتّب أحداث القصة",
  description: "رتّب أحداث القصة بالترتيب الصحيح",
  type: "number_order",
  level: "hard",
  ageGroup: "8-10",
  emoji: "📖",
  pointsReward: 30,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "رتّب أحداث قصة الأرنب والسلحفاة بالترتيب الصحيح",
    items: ["🐇 تحدّى الأرنب السلحفاة", "🏁 بدأ السباق", "😴 نام الأرنب في الطريق", "🐢 استمرت السلحفاة بالمشي", "🏆 فازت السلحفاة بالسباق", "📝 تعلّم الأرنب الدرس"],
    correctOrder: [0, 1, 2, 3, 4, 5]
  })
});

// 6. الأعداد الكبيرة (count_objects) - صعب
games.push({
  title: "الأعداد الكبيرة",
  description: "تعرّف على الأعداد الكبيرة وقارن بينها",
  type: "letter_match",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🔢",
  pointsReward: 25,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "اختر الإجابة الصحيحة",
    rounds: [
      { letter: "📊", question: "أي عدد أكبر: ٢٥٠ أم ٢٠٥؟", options: ["٢٠٥", "٢٥٠", "متساويان", "لا أعرف"], correct: 1 },
      { letter: "📊", question: "ما ناتج ١٠٠ + ٥٠؟", options: ["١٠٥", "١٥٠", "٥٠٠", "١٥٥"], correct: 1 },
      { letter: "📊", question: "كم عشرة في العدد ٧٠؟", options: ["٥", "٦", "٧", "٨"], correct: 2 },
      { letter: "📊", question: "ما العدد الذي يأتي بعد ٩٩؟", options: ["٩٨", "١٠٠", "١٠١", "٩٩٩"], correct: 1 },
      { letter: "📊", question: "رتّب: ٣٥، ٥٣، ٣٣ من الأصغر", options: ["٣٣، ٣٥، ٥٣", "٣٥، ٣٣، ٥٣", "٥٣، ٣٥، ٣٣", "٣٣، ٥٣، ٣٥"], correct: 0 },
    ]
  })
});

// 7. جمع وطرح صعب
games.push({
  title: "جمع وطرح متقدم",
  description: "عمليات حسابية متقدمة للأذكياء",
  type: "math_addition",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🏆",
  pointsReward: 35,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "احسب الناتج الصحيح",
    rounds: [
      { emoji: "🔢", count: 0, question: "٢٥ + ١٧ = ؟", options: [40, 41, 42, 43], correct: 2 },
      { emoji: "🔢", count: 0, question: "٥٠ - ٢٣ = ؟", options: [25, 26, 27, 28], correct: 2 },
      { emoji: "🔢", count: 0, question: "٣٤ + ٢٨ = ؟", options: [60, 61, 62, 63], correct: 2 },
      { emoji: "🔢", count: 0, question: "١٠٠ - ٤٥ = ؟", options: [53, 54, 55, 56], correct: 2 },
      { emoji: "🔢", count: 0, question: "٦٧ + ٣٣ = ؟", options: [98, 99, 100, 101], correct: 2 },
      { emoji: "🔢", count: 0, question: "٨٨ - ٢٩ = ؟", options: [57, 58, 59, 60], correct: 2 },
    ]
  })
});

// 8. اكتشف الدخيل (classification) - صعب (بديل عن الحروف المتشابهة المكررة)
games.push({
  title: "اكتشف الدخيل",
  description: "اكتشف العنصر الذي لا ينتمي للمجموعة",
  type: "letter_match",
  level: "hard",
  ageGroup: "8-10",
  emoji: "🔎",
  pointsReward: 30,
  orderIndex: orderIdx++,
  gameData: JSON.stringify({
    instructions: "أي عنصر لا ينتمي للمجموعة؟",
    rounds: [
      { letter: "🤔", question: "أيهم ليس فاكهة؟", options: ["🍎 تفاح", "🥕 جزر", "🍌 موز", "🍊 برتقال"], correct: 1 },
      { letter: "🤔", question: "أيهم ليس وسيلة نقل؟", options: ["🚗 سيارة", "🚌 حافلة", "🪑 كرسي", "✈️ طائرة"], correct: 2 },
      { letter: "🤔", question: "أيهم ليس من الحواس الخمس؟", options: ["👁️ البصر", "👂 السمع", "🦶 المشي", "👃 الشم"], correct: 2 },
      { letter: "🤔", question: "أيهم ليس كوكباً؟", options: ["المريخ", "الشمس", "زحل", "المشتري"], correct: 1 },
      { letter: "🤔", question: "أيهم ليس من أيام الأسبوع؟", options: ["السبت", "الأحد", "يناير", "الثلاثاء"], correct: 2 },
    ]
  })
});

// Insert all games
for (const game of games) {
  await conn.query(
    `INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, orderIndex, gameData, isPublished) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    [game.title, game.description, game.type, game.level, game.ageGroup, game.emoji, game.pointsReward, game.orderIndex, game.gameData]
  );
}

const [count] = await conn.query('SELECT COUNT(*) as cnt FROM educational_games');
console.log(`✅ Successfully seeded ${count[0].cnt} games!`);

const [byLevel] = await conn.query('SELECT level, COUNT(*) as cnt FROM educational_games GROUP BY level ORDER BY FIELD(level, "easy", "medium", "hard")');
for (const row of byLevel) {
  console.log(`  ${row.level}: ${row.cnt} games`);
}

await conn.end();
