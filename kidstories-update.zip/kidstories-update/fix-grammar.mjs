import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. إصلاح لعبة الكلمة المخفية (30041) - إزالة سؤال "ما الحرف الناقص؟" من الـ question وجعل الكلمة هي المعروضة
const hiddenWordData = {
  instructions: "انظر للكلمة الناقصة حرف واختر الحرف الصحيح",
  rounds: [
    { correct: 1, letter: "ق_مر", options: ["أ", "و", "م", "ي"] },
    { correct: 0, letter: "ش_رة", options: ["ج", "ح", "خ", "ع"] },
    { correct: 0, letter: "ب_ت", options: ["ا", "ي", "ه", "و"] },
    { correct: 0, letter: "ك_اب", options: ["ت", "ث", "ب", "ن"] },
    { correct: 2, letter: "م_رسة", options: ["د", "ذ", "د", "ض"] },
    { correct: 1, letter: "ط_ير", options: ["أ", "ا", "ي", "و"] },
    { correct: 0, letter: "ح_صان", options: ["ص", "س", "ز", "ش"] },
    { correct: 3, letter: "ن_فذة", options: ["أ", "ا", "ي", "ا"] },
  ]
};
// إصلاح: ب_ت → بيت (correct: 1 لـ "ي")، ك_اب → كتاب (correct: 0 لـ "ت")، م_رسة → مدرسة (correct: 0 لـ "د")
const hiddenWordFixed = {
  instructions: "انظر للكلمة الناقصة حرف واختر الحرف الصحيح",
  rounds: [
    { correct: 1, letter: "ق_مر", options: ["أ", "و", "م", "ي"] },
    { correct: 0, letter: "ش_رة", options: ["ج", "ح", "خ", "ع"] },
    { correct: 1, letter: "ب_ت", options: ["ا", "ي", "ه", "و"] },
    { correct: 0, letter: "ك_اب", options: ["ت", "ث", "ب", "ن"] },
    { correct: 0, letter: "م_رسة", options: ["د", "ذ", "ر", "ض"] },
    { correct: 1, letter: "ط_ير", options: ["أ", "ا", "ي", "و"] },
    { correct: 0, letter: "ح_صان", options: ["ص", "س", "ز", "ش"] },
    { correct: 1, letter: "ن_فذة", options: ["أ", "ا", "ي", "و"] },
    { correct: 2, letter: "س_ارة", options: ["أ", "ا", "ي", "و"] },
    { correct: 0, letter: "ق_لم", options: ["ا", "و", "ي", "أ"] },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30041', [JSON.stringify(hiddenWordFixed)]);
console.log('✅ Fixed hidden word game (30041)');

// ─── 2. إصلاح لعبة إكمال الجملة (30067) - إزالة السؤال من تحت الجملة، تصحيح المؤنث/المذكر
const sentenceData = {
  instructions: "اقرأ الجملة واختر الكلمة المناسبة لإكمالها",
  rounds: [
    {
      correct: 1,
      letter: "ذهب أحمدُ إلى _____ ليشتريَ خبزاً",
      options: ["المدرسة 🏫", "المخبز 🍞", "الملعب ⚽", "الحديقة 🌳"]
    },
    {
      correct: 2,
      letter: "في الصباح الباكر، رأتْ سارةُ من نافذتها _____ يطيرُ في السماء",
      options: ["سمكةً 🐟", "سلحفاةً 🐢", "طائراً 🦅", "حصاناً 🐴"]
    },
    {
      correct: 1,
      letter: "في الصباح، يأكلُ الأطفالُ _____",
      options: ["العشاء 🌙", "الفطور 🍳", "الغداء ☀️", "الحلوى 🍬"]
    },
    {
      correct: 0,
      letter: "الشمسُ تشرقُ من _____",
      options: ["الشرق 🌅", "الغرب 🌇", "الشمال ⬆️", "الجنوب ⬇️"]
    },
    {
      correct: 2,
      letter: "لعبتْ هيا في _____ مع صديقاتها",
      options: ["الفصل 📚", "المطبخ 🍳", "الحديقة 🌳", "المكتبة 📖"]
    },
    {
      correct: 1,
      letter: "يحبُّ سامٌ أن يقرأَ _____ قبل النوم",
      options: ["التلفاز 📺", "القصص 📖", "الألعاب 🎮", "الطعام 🍽️"]
    },
    {
      correct: 3,
      letter: "تسقطُ _____ من السماء في الشتاء",
      options: ["الأوراق 🍂", "الرمال 🏜️", "الأزهار 🌸", "الأمطار 🌧️"]
    },
    {
      correct: 0,
      letter: "تحبُّ نورُ أن تساعدَ _____ في المنزل",
      options: ["أمَّها 👩", "كتابَها 📚", "لعبتَها 🧸", "حقيبتَها 🎒"]
    },
    {
      correct: 2,
      letter: "ذهبتْ ريمُ مع أبيها إلى _____ لشراء الخضار",
      options: ["المدرسة 🏫", "المسجد 🕌", "السوق 🛒", "الحديقة 🌳"]
    },
    {
      correct: 1,
      letter: "يلعبُ عمرٌ كرةَ القدم في _____",
      options: ["الفصل 📚", "الملعب ⚽", "المطبخ 🍳", "الحمام 🚿"]
    },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30067', [JSON.stringify(sentenceData)]);
console.log('✅ Fixed sentence completion game (30067)');

// ─── 3. إصلاح لعبة النحو والإملاء (30072) - تصحيح الصياغة
const grammarData = {
  instructions: "اختر الإجابة الصحيحة نحوياً",
  rounds: [
    {
      correct: 0,
      emoji: "🏠",
      question: "أيٌّ من هذه الكلمات اسمٌ؟",
      options: ["بيتٌ 🏠", "يجري 🏃", "كبيرٌ 📏", "سريعاً 💨"]
    },
    {
      correct: 2,
      emoji: "📝",
      question: "أيٌّ من هذه الكلمات فعلٌ؟",
      options: ["قلمٌ ✏️", "طويلٌ 📏", "يكتبُ ✍️", "جميلٌ 🌸"]
    },
    {
      correct: 1,
      emoji: "🌸",
      question: "أيٌّ من هذه الكلمات صفةٌ (نعت)؟",
      options: ["يلعبُ ⚽", "جميلةٌ 🌸", "مدرسةٌ 🏫", "ذهبَ 🚶"]
    },
    {
      correct: 0,
      emoji: "👦",
      question: "أكملِ الجملة: أحمدُ _____ إلى المدرسة",
      options: ["ذهبَ 🚶", "ذهبتْ 👧", "ذهبنا 👨‍👩‍👧", "ذهبتُ 🙋"]
    },
    {
      correct: 1,
      emoji: "👧",
      question: "أكملِ الجملة: سارةُ _____ الكتابَ",
      options: ["قرأَ 👦", "قرأتْ 👧", "قرأنا 👨‍👩‍👧", "قرأتُم 👥"]
    },
    {
      correct: 2,
      emoji: "🌳",
      question: "أيٌّ من هذه الجمل صحيحةٌ؟",
      options: ["الولدُ يلعبُ الكرةَ الملعبِ", "الولدُ يلعبُ في الكرةِ", "يلعبُ الولدُ الكرةَ في الملعبِ", "الكرةَ يلعبُ الولدُ الملعبِ"]
    },
    {
      correct: 3,
      emoji: "✏️",
      question: "ما مفردُ كلمة (كتبٌ)؟",
      options: ["كتبةٌ", "كتابةٌ", "كاتبٌ", "كتابٌ"]
    },
    {
      correct: 0,
      emoji: "📚",
      question: "ما جمعُ كلمة (قلمٌ)؟",
      options: ["أقلامٌ ✏️", "قلمةٌ", "قلومٌ", "أقلمةٌ"]
    },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30072', [JSON.stringify(grammarData)]);
console.log('✅ Fixed grammar game (30072)');

// ─── 4. إصلاح لعبة العلوم والطبيعة (30073) - تصحيح "من أين تأتي المطر" → "من أين يأتي المطر"
const scienceData = {
  instructions: "اختر الإجابة الصحيحة عن العلوم والطبيعة",
  rounds: [
    {
      correct: 1,
      emoji: "🌧️",
      question: "من أين يأتي المطرُ؟",
      options: ["من الجبال ⛰️", "من السحاب ☁️", "من البحر 🌊", "من الأشجار 🌳"]
    },
    {
      correct: 1,
      emoji: "🌱",
      question: "ماذا تحتاجُ النباتاتُ للنمو؟",
      options: ["الظلامُ والبردُ ❄️", "الماءُ والشمسُ 🌞💧", "الثلجُ فقط ❄️", "الريحُ فقط 💨"]
    },
    {
      correct: 1,
      emoji: "🦋",
      question: "من أين تخرجُ الفراشةُ؟",
      options: ["من البيضة 🥚", "من الشرنقة 🫘", "من الزهرة 🌸", "من التراب 🌍"]
    },
    {
      correct: 0,
      emoji: "☀️",
      question: "ما مصدرُ الضوء والدفء للأرض؟",
      options: ["الشمس ☀️", "القمر 🌙", "النجوم ⭐", "الغيوم ☁️"]
    },
    {
      correct: 2,
      emoji: "🌊",
      question: "ما أكثرَ شيء في كوكب الأرض؟",
      options: ["الجبال ⛰️", "الصحراء 🏜️", "الماء 🌊", "الغابات 🌲"]
    },
    {
      correct: 1,
      emoji: "🌙",
      question: "لماذا يظهرُ القمرُ في الليل؟",
      options: ["لأنه يُضيء بنفسه 💡", "لأنه يعكسُ ضوءَ الشمس ☀️", "لأنه نجمٌ كبير ⭐", "لأنه أقربُ من الشمس 🔭"]
    },
    {
      correct: 0,
      emoji: "🐛",
      question: "ما المرحلةُ الأولى في حياة الفراشة؟",
      options: ["البيضة 🥚", "اليرقة 🐛", "الشرنقة 🫘", "الفراشة 🦋"]
    },
    {
      correct: 3,
      emoji: "🌡️",
      question: "ما الفصلُ الأكثرُ حرارةً في السنة؟",
      options: ["الربيع 🌸", "الخريف 🍂", "الشتاء ❄️", "الصيف ☀️"]
    },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30073', [JSON.stringify(scienceData)]);
console.log('✅ Fixed science game (30073)');

// ─── 5. إصلاح لعبة التفكير المنطقي (30068) - تصحيح الخيارات لتكون أعلاماً فقط بدون نص
const logicData = {
  instructions: "فكِّرْ جيداً واختر الإجابة الصحيحة",
  rounds: [
    {
      correct: 1,
      emoji: "🔴🔵🔴🔵🔴❓",
      question: "ما الشكلُ التالي في النمط؟",
      options: ["🔴", "🔵", "🟢", "🟡"]
    },
    {
      correct: 1,
      emoji: "١، ٢، ٣، ٤، ❓",
      question: "ما العددُ التالي؟",
      options: ["٤", "٥", "٦", "٧"]
    },
    {
      correct: 1,
      emoji: "٢، ٤، ٦، ٨، ❓",
      question: "ما العددُ التالي في هذا النمط؟",
      options: ["٩", "١٠", "١١", "١٢"]
    },
    {
      correct: 0,
      emoji: "🐣 ← 🐥 ← 🐔",
      question: "ما المرحلةُ التي تسبقُ الفرخَ الصغير؟",
      options: ["البيضة 🥚", "الدجاجة 🐔", "الديك 🐓", "الفرخُ الكبير 🐥"]
    },
    {
      correct: 2,
      emoji: "🟦🟦🟥🟦🟦🟥❓",
      question: "ما الشكلُ التالي في النمط؟",
      options: ["🟦", "🟥", "🟦", "🟩"]
    },
    {
      correct: 1,
      emoji: "١٠، ٢٠، ٣٠، ٤٠، ❓",
      question: "ما العددُ التالي؟",
      options: ["٤٥", "٥٠", "٦٠", "٥٥"]
    },
    {
      correct: 3,
      emoji: "🌱 ← 🌿 ← 🌳 ← ❓",
      question: "ما المرحلةُ التالية لنمو الشجرة؟",
      options: ["بذرة 🌰", "شجيرة 🌿", "زهرة 🌸", "ثمرة 🍎"]
    },
    {
      correct: 0,
      emoji: "٣، ٦، ٩، ١٢، ❓",
      question: "ما العددُ التالي في جدول الثلاثة؟",
      options: ["١٥", "١٤", "١٦", "١٣"]
    },
  ]
};
await conn.execute('UPDATE educational_games SET gameData = ? WHERE id = 30068', [JSON.stringify(logicData)]);
console.log('✅ Fixed logic puzzle game (30068)');

await conn.end();
console.log('\n✅ All grammar fixes applied!');
