import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── ID:5 المطر والزهرة الصغيرة - من 2 إلى 5 نهايات ────────────────────────
const adventure5 = {
  startNodeId: "start",
  nodes: [
    {
      id: "start",
      emoji: "🌧️",
      text: "زهرة صغيرة في الحديقة تعاني من الجفاف. السماء ملبدة بالغيوم لكن المطر لا يأتي. طفل صغير اسمه ياسر يراها تذبل. ماذا يفعل؟",
      choices: [
        { id: "c1", text: "يسقيها من خرطوم الماء", emoji: "💧", type: "safe", points: 10, nextNodeId: "water_hose" },
        { id: "c2", text: "يغني للغيوم ليطلب المطر", emoji: "🎵", type: "adventure", points: 20, nextNodeId: "sing_clouds" },
        { id: "c3", text: "يحفر حولها لتجمع الماء", emoji: "⛏️", type: "learning", points: 5, nextNodeId: "dig_around" },
      ]
    },
    {
      id: "water_hose",
      emoji: "💧🌸",
      text: "سقى ياسر الزهرة بعناية. الزهرة بدأت تنتعش وتفتح بتلاتها. لكن الجارة العجوز قالت: 'الزهرة تحتاج مطرًا حقيقيًا لا ماء الخرطوم فقط.'",
      choices: [
        { id: "c4", text: "يواصل السقي يومياً", emoji: "📅", type: "safe", points: 10, nextNodeId: "daily_water" },
        { id: "c5", text: "يطلب من أبيه تركيب نظام ري", emoji: "🔧", type: "learning", points: 5, nextNodeId: "irrigation" },
      ]
    },
    {
      id: "sing_clouds",
      emoji: "🎵☁️",
      text: "غنى ياسر بصوت جميل: 'يا غيوم يا غيوم، هطلي هطلي!' الغيوم تجمعت وبدأت تتحرك نحو الحديقة. هل ستمطر؟",
      choices: [
        { id: "c6", text: "يواصل الغناء بحماس", emoji: "🎤", type: "adventure", points: 20, nextNodeId: "rain_comes" },
        { id: "c7", text: "يدعو أصدقاءه للغناء معه", emoji: "👫", type: "safe", points: 10, nextNodeId: "friends_sing" },
      ]
    },
    {
      id: "dig_around",
      emoji: "⛏️🌱",
      text: "حفر ياسر حول الزهرة وصنع حوضًا صغيرًا. عندما سقط المطر لاحقًا، تجمع الماء حول الزهرة وشربت منه طويلاً. الزهرة أصبحت أجمل من قبل!",
      isEnding: true, endingKey: "dig_smart_end", endingType: "learning",
      endingTitle: "الذكاء يحل المشكلة"
    },
    {
      id: "daily_water",
      emoji: "🌺",
      text: "سقى ياسر الزهرة كل يوم بانتظام. بعد أسبوع أصبحت أجمل زهرة في الحديقة وفازت بجائزة أجمل حديقة في الحي!",
      isEnding: true, endingKey: "child_help", endingType: "good",
      endingTitle: "المثابرة تُزهر"
    },
    {
      id: "irrigation",
      emoji: "🔧💧",
      text: "ركّب أبو ياسر نظام ري ذكياً. الزهرة والحديقة كلها أصبحت خضراء طوال السنة. الجيران تعلموا الفكرة وطبقوها في بيوتهم!",
      isEnding: true, endingKey: "irrigation_end", endingType: "great",
      endingTitle: "فكرة تغير الحي"
    },
    {
      id: "rain_comes",
      emoji: "🌧️🌈",
      text: "هطل المطر بغزارة! الزهرة شربت وشربت وفتحت بتلاتها الجميلة. قوس قزح ظهر في السماء. ياسر سعيد أن أغنيته نجحت!",
      isEnding: true, endingKey: "cloud_rain", endingType: "great",
      endingTitle: "أغنية المطر"
    },
    {
      id: "friends_sing",
      emoji: "👫🎵🌧️",
      text: "اجتمع أصدقاء ياسر وغنوا معًا. المطر هطل وسقت كل الحديقة. الأطفال رقصوا في المطر فرحين. الزهرة الصغيرة أصبحت سبب فرح الجميع!",
      isEnding: true, endingKey: "friends_rain_end", endingType: "surprise",
      endingTitle: "فرحة المطر المشتركة"
    },
  ]
};

// ─── ID:6 الولد الشجاع والتنين - من 3 إلى 5 نهايات ─────────────────────────
const [adv6rows] = await conn.execute('SELECT adventureData FROM story_adventures WHERE id = 6');
const adv6data = typeof adv6rows[0].adventureData === 'string' ? JSON.parse(adv6rows[0].adventureData) : adv6rows[0].adventureData;

// إضافة نهايتين جديدتين وعقدة جديدة
adv6data.nodes.push(
  {
    id: "peace_talk",
    emoji: "🕊️",
    text: "قرر أحمد أن يتكلم مع التنين بهدوء بدلاً من القتال. قال: 'لماذا تخيف الناس؟' التنين بكى: 'أنا وحيد ولا أحد يلعب معي.' أحمد صار صديقه!",
    isEnding: true, endingKey: "peace_talk_end", endingType: "great",
    endingTitle: "الحوار أقوى من السيف"
  },
  {
    id: "clever_trap",
    emoji: "🪤",
    text: "نصب أحمد فخًا ذكيًا للتنين باستخدام طعامه المفضل. لكن التنين كان أذكى وتجنب الفخ. ضحك التنين: 'حاولت بذكاء! أنت شجاع. لن أؤذي قريتك.'",
    isEnding: true, endingKey: "clever_trap_end", endingType: "good",
    endingTitle: "الذكاء يفوز بدون قتال"
  }
);

// ─── ID:13 المحقق الصغير - من 3 إلى 5 نهايات ───────────────────────────────
const [adv13rows] = await conn.execute('SELECT adventureData FROM story_adventures WHERE id = 13');
const adv13data = typeof adv13rows[0].adventureData === 'string' ? JSON.parse(adv13rows[0].adventureData) : adv13rows[0].adventureData;

adv13data.nodes.push(
  {
    id: "team_solve",
    emoji: "👥🔍",
    text: "جمع المحقق الصغير كل الأدلة وعقد اجتماعًا مع أصدقائه. معًا حللوا الأدلة وكشفوا السارق. المدير قال: 'العمل الجماعي أقوى من عمل فرد واحد!'",
    isEnding: true, endingKey: "team_solve_end", endingType: "great",
    endingTitle: "قوة الفريق"
  },
  {
    id: "unexpected_twist",
    emoji: "😮",
    text: "اكتشف المحقق الصغير أن 'السرقة' لم تكن سرقة أصلاً! الطائر طار بنفسه لأن القفص كان مفتوحًا. الجميع ضحك وتعلموا أن التحقق من الحقائق مهم قبل الاتهام.",
    isEnding: true, endingKey: "unexpected_twist_end", endingType: "surprise",
    endingTitle: "ليست سرقة!"
  }
);

// ─── ID:30001 الولد الذي كذب - إضافة نهاية خامسة ───────────────────────────
const [adv30001rows] = await conn.execute('SELECT adventureData FROM story_adventures WHERE id = 30001');
const adv30001data = typeof adv30001rows[0].adventureData === 'string' ? JSON.parse(adv30001rows[0].adventureData) : adv30001rows[0].adventureData;

adv30001data.nodes.push(
  {
    id: "help_others",
    emoji: "🤝",
    text: "بعد أن اعترف بالحقيقة، قرر أن يساعد الجميع في إصلاح ما أفسده كذبه. عمل بجد وكسب ثقة الجميع من جديد. الصدق بناء، والكذب هدم.",
    isEnding: true, endingKey: "help_others_end", endingType: "good",
    endingTitle: "الصدق يُعيد الثقة"
  }
);

// ─── تحديث قاعدة البيانات ───────────────────────────────────────────────────
const updates = [
  [5, adventure5, 5],
  [6, adv6data, 5],
  [13, adv13data, 5],
  [30001, adv30001data, 5],
  // تحديث totalEndings للمغامرات التي لديها endings أكثر من totalEndings
  [30004, null, 5],
  [30005, null, 6],
  [30006, null, 7],
  [30009, null, 7],
  [30010, null, 6],
];

for (const [id, data, ends] of updates) {
  if (data) {
    const [r] = await conn.execute(
      'UPDATE story_adventures SET adventureData = ?, totalEndings = ? WHERE id = ?',
      [JSON.stringify(data), ends, id]
    );
    console.log(`Updated ID:${id} data+ends=${ends} - rows: ${r.affectedRows}`);
  } else {
    const [r] = await conn.execute(
      'UPDATE story_adventures SET totalEndings = ? WHERE id = ?',
      [ends, id]
    );
    console.log(`Updated ID:${id} ends=${ends} - rows: ${r.affectedRows}`);
  }
}

console.log('\nFinal check:');
const [rows] = await conn.execute('SELECT id, title, totalEndings FROM story_adventures ORDER BY id');
rows.forEach(r => console.log(`ID:${r.id} ${r.title} | totalEndings:${r.totalEndings}`));

await conn.end();
