import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const [rows] = await conn.execute('SELECT id, title, adventureData, totalEndings FROM story_adventures ORDER BY id');
let issues = [];
let summary = [];

for (const r of rows) {
  try {
    const data = typeof r.adventureData === 'string' ? JSON.parse(r.adventureData) : r.adventureData;
    if (!data || !data.nodes || !data.startNodeId) {
      issues.push(`ID:${r.id} ${r.title} - MISSING DATA`);
      continue;
    }
    const startNode = data.nodes.find(n => n.id === data.startNodeId);
    if (!startNode) {
      issues.push(`ID:${r.id} ${r.title} - startNodeId '${data.startNodeId}' NOT FOUND`);
      continue;
    }
    const nodeIds = new Set(data.nodes.map(n => n.id));
    let brokenLinks = [];
    for (const n of data.nodes) {
      if (n.choices) {
        for (const c of n.choices) {
          if (!nodeIds.has(c.nextNodeId)) {
            brokenLinks.push(c.nextNodeId);
          }
        }
      }
    }
    const endings = data.nodes.filter(n => n.isEnding);
    summary.push(`ID:${r.id} ${r.title} | nodes:${data.nodes.length} endings:${endings.length} dbEnds:${r.totalEndings}${brokenLinks.length > 0 ? ' BROKEN:'+brokenLinks.join(',') : ''}`);
    if (brokenLinks.length > 0) {
      issues.push(`ID:${r.id} ${r.title} - BROKEN LINKS: ${brokenLinks.join(', ')}`);
    }
  } catch(e) {
    issues.push(`ID:${r.id} ${r.title} - JSON ERROR: ${e.message}`);
  }
}

console.log('=== Summary ===');
summary.forEach(s => console.log(s));
console.log('\n=== Issues ===');
if (issues.length === 0) {
  console.log('No issues found!');
} else {
  issues.forEach(i => console.log(' -', i));
}
await conn.end();
