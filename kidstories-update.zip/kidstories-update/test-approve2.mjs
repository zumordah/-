import { createConnection } from 'mysql2/promise';
import bcrypt from 'bcrypt';

const dbUrl = process.env.DATABASE_URL;
const conn = await createConnection(dbUrl);

// محاكاة approveRegistration للطلب id=1
const regId = 1;

// 1. جلب الطلب
const [[reg]] = await conn.execute('SELECT * FROM school_registrations WHERE id = ?', [regId]);
if (!reg) { console.error('Registration not found'); process.exit(1); }
console.log('Registration:', reg);

// 2. محاولة إنشاء مدرسة
try {
  await conn.execute(
    'INSERT INTO schools (name, email, adminEmail) VALUES (?, ?, ?)',
    [reg.schoolName, reg.adminEmail, reg.adminEmail]
  );
  console.log('School created successfully');
} catch (err) {
  console.error('Error creating school:', err.message);
  // إذا كان المدرسة موجودة بالفعل، نجلبها
  const [[existing]] = await conn.execute('SELECT * FROM schools WHERE email = ?', [reg.adminEmail]);
  if (existing) {
    console.log('School already exists:', existing);
  }
}

// 3. جلب المدرسة
const [[school]] = await conn.execute('SELECT * FROM schools WHERE email = ?', [reg.adminEmail]);
console.log('School:', school);

// 4. محاولة إنشاء admin account
try {
  const [[existingAdmin]] = await conn.execute('SELECT * FROM admin_accounts WHERE email = ?', [reg.adminEmail]);
  if (!existingAdmin) {
    await conn.execute(
      'INSERT INTO admin_accounts (email, name, password, role, schoolId, isActive) VALUES (?, ?, ?, ?, ?, ?)',
      [reg.adminEmail, reg.adminName, reg.passwordHash, 'school_admin', school?.id ?? null, 1]
    );
    console.log('Admin account created');
  } else {
    await conn.execute(
      'UPDATE admin_accounts SET schoolId = ?, role = "school_admin", isActive = 1, password = ? WHERE email = ?',
      [school?.id ?? null, reg.passwordHash, reg.adminEmail]
    );
    console.log('Admin account updated');
  }
} catch (err) {
  console.error('Error with admin account:', err.message);
}

// 5. تحديث الطلب إلى approved
await conn.execute(
  'UPDATE school_registrations SET status = "approved", reviewedAt = NOW() WHERE id = ?',
  [regId]
);
console.log('Registration approved!');

await conn.end();
process.exit(0);
