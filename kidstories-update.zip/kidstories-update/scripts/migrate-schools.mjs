import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const sqls = [
  `CREATE TABLE IF NOT EXISTS \`school_classrooms\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`schoolId\` int NOT NULL,
    \`name\` varchar(100) NOT NULL,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    CONSTRAINT \`school_classrooms_id\` PRIMARY KEY(\`id\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`schools\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`name\` varchar(200) NOT NULL,
    \`email\` varchar(320) NOT NULL,
    \`adminEmail\` varchar(320) NOT NULL,
    \`isActive\` boolean NOT NULL DEFAULT true,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    \`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT \`schools_id\` PRIMARY KEY(\`id\`),
    CONSTRAINT \`schools_email_unique\` UNIQUE(\`email\`)
  )`,
  `ALTER TABLE \`admin_accounts\` ADD COLUMN \`schoolId\` int DEFAULT NULL`,
  `ALTER TABLE \`admin_accounts\` ADD COLUMN \`role\` enum('founder','school_admin') NOT NULL DEFAULT 'school_admin'`,
  `ALTER TABLE \`children\` ADD COLUMN \`schoolId\` int DEFAULT NULL`,
  `ALTER TABLE \`children\` ADD COLUMN \`schoolClassroom\` varchar(100) DEFAULT NULL`,
];

for (let i = 0; i < sqls.length; i++) {
  try {
    await conn.execute(sqls[i]);
    console.log(`✅ SQL ${i} done`);
  } catch (err) {
    if (err.message.includes('Duplicate column') || err.message.includes('already exists')) {
      console.log(`ℹ️ SQL ${i} already applied`);
    } else {
      console.error(`❌ SQL ${i} error:`, err.message);
    }
  }
}

// تحديث الأدمن المؤسس ليكون role = founder
try {
  await conn.execute(
    "UPDATE admin_accounts SET role = 'founder' WHERE email = 'zumorda77@hotmail.com'"
  );
  console.log('✅ Updated founder role');
} catch (e) {
  console.log('ℹ️ Founder update skipped:', e.message);
}

await conn.end();
console.log('✅ Migration complete');
