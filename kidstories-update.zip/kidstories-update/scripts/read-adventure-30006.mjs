import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
dotenv.config({ path: '/home/ubuntu/kidstories-update/.env' });

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const [rows] = await conn.execute('SELECT id, title, adventureData FROM story_adventures WHERE id = 30006');

for (const r of rows) {
  const data = typeof r.adventureData === 'string' ? JSON.parse(r.adventureData) : r.adventureData;
  const nodes = data.nodes || [];
  console.log('Total nodes:', nodes.length);
  for (const n of nodes) {
    const hasChoices = n.choices && n.choices.length > 0;
    if (!hasChoices) {
      console.log('\n=== END NODE:', n.id, '===');
      console.log('Text:', n.text);
    }
  }
}

await conn.end();
