import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config({ path: '/home/ubuntu/kidstories-update/.env' });

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  try {
    // ===== أنشطة قصة "محبة الوطن" (storyId: 60017) =====

    // نشاط 1: اختبار فهم القصة
    const [act1] = await conn.execute(
      `INSERT INTO activities (storyId, title, type, description, pointsReward, ageGroup, isPublished)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [60017, 'اختبار قصة محبة الوطن 🇸🇦', 'quiz', 'اختبر فهمك لقصة محبة الوطن وتعرّف على تاريخ المملكة العربية السعودية', 25, 'all', 1]
    );
    const actId1 = act1.insertId;
    console.log(`✅ نشاط 1 (اختبار محبة الوطن) - ID: ${actId1}`);

    const questions1 = [
      {
        questionText: 'مَا اسْمُ الوَلَدِ الَّذِي يُحِبُّ وَطَنَهُ فِي القِصَّةِ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['مُحَمَّدٌ', 'عَلِيٌّ', 'أُسَامَةُ', 'يُوسُفُ']),
        correctAnswer: 'مُحَمَّدٌ',
        explanation: 'مُحَمَّدٌ هُوَ بَطَلُ القِصَّةِ الَّذِي يُحِبُّ وَطَنَهُ المَمْلَكَةَ العَرَبِيَّةَ السَّعُودِيَّةَ.',
        orderIndex: 1,
      },
      {
        questionText: 'مَا لَوْنُ عَلَمِ المَمْلَكَةِ العَرَبِيَّةِ السَّعُودِيَّةِ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['الأَخْضَرُ', 'الأَحْمَرُ', 'الأَزْرَقُ', 'الأَصْفَرُ']),
        correctAnswer: 'الأَخْضَرُ',
        explanation: 'عَلَمُ المَمْلَكَةِ أَخْضَرُ اللَّوْنِ وَيَحْمِلُ السَّيْفَ وَالشَّهَادَةَ.',
        orderIndex: 2,
      },
      {
        questionText: 'مَاذَا يَرْمُزُ السَّيْفُ فِي عَلَمِ المَمْلَكَةِ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['القُوَّةُ', 'السَّلَامُ', 'الثَّرْوَةُ', 'الجَمَالُ']),
        correctAnswer: 'القُوَّةُ',
        explanation: 'السَّيْفُ فِي عَلَمِ المَمْلَكَةِ يَدُلُّ عَلَى القُوَّةِ وَالعِزَّةِ.',
        orderIndex: 3,
      },
      {
        questionText: 'مَا اسْمُ المَدِينَةِ المُقَدَّسَةِ الَّتِي ذَكَرَهَا المُعَلِّمُ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['مَكَّةُ المُكَرَّمَةُ', 'الرِّيَاضُ', 'جِدَّةُ', 'الدَّمَّامُ']),
        correctAnswer: 'مَكَّةُ المُكَرَّمَةُ',
        explanation: 'مَكَّةُ المُكَرَّمَةُ وَالمَدِينَةُ المُنَوَّرَةُ هُمَا المَدِينَتَانِ المُقَدَّسَتَانِ فِي الإِسْلَامِ.',
        orderIndex: 4,
      },
      {
        questionText: 'مَا هِيَ رُؤْيَةُ المَمْلَكَةِ الَّتِي ذَكَرَهَا المُعَلِّمُ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['رُؤْيَةُ 2030', 'رُؤْيَةُ 2020', 'رُؤْيَةُ 2040', 'رُؤْيَةُ 2025']),
        correctAnswer: 'رُؤْيَةُ 2030',
        explanation: 'رُؤْيَةُ المَمْلَكَةِ 2030 هِيَ خَطَّةٌ لِتَطْوِيرِ المَمْلَكَةِ وَتَنْوِيعِ اقْتِصَادِهَا.',
        orderIndex: 5,
      },
    ];

    for (const q of questions1) {
      await conn.execute(
        `INSERT INTO activity_questions (activityId, questionText, questionType, options, correctAnswer, explanation, orderIndex)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [actId1, q.questionText, q.questionType, q.options, q.correctAnswer, q.explanation, q.orderIndex]
      );
    }
    console.log(`  ✅ ${questions1.length} أسئلة مضافة لنشاط 1`);

    // نشاط 2: مطابقة (رموز المملكة)
    const [act2] = await conn.execute(
      `INSERT INTO activities (storyId, title, type, description, pointsReward, ageGroup, isPublished)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [60017, 'رموز المملكة 🗺️', 'matching', 'طابق بين رموز المملكة ومعانيها', 20, 'all', 1]
    );
    const actId2 = act2.insertId;
    console.log(`✅ نشاط 2 (مطابقة رموز المملكة) - ID: ${actId2}`);

    const matchQ1 = {
      questionText: 'طَابِقْ بَيْنَ رُمُوزِ المَمْلَكَةِ وَمَعَانِيهَا',
      questionType: 'matching',
      options: JSON.stringify({
        pairs: [
          { left: 'السَّيْفُ', right: 'القُوَّةُ وَالعِزَّةُ' },
          { left: 'اللَّوْنُ الأَخْضَرُ', right: 'السَّلَامُ وَالإِسْلَامُ' },
          { left: 'النَّخْلَةُ', right: 'الخَيْرُ وَالعَطَاءُ' },
          { left: 'الشَّهَادَةُ', right: 'التَّوْحِيدُ وَالإِيمَانُ' },
        ],
      }),
      correctAnswer: 'السَّيْفُ=القُوَّةُ وَالعِزَّةُ|اللَّوْنُ الأَخْضَرُ=السَّلَامُ وَالإِسْلَامُ|النَّخْلَةُ=الخَيْرُ وَالعَطَاءُ|الشَّهَادَةُ=التَّوْحِيدُ وَالإِيمَانُ',
      explanation: 'رُمُوزُ المَمْلَكَةِ تَعْكِسُ قِيَمَهَا الإِسْلَامِيَّةَ وَتَارِيخَهَا العَرِيقَ.',
      orderIndex: 1,
    };
    await conn.execute(
      `INSERT INTO activity_questions (activityId, questionText, questionType, options, correctAnswer, explanation, orderIndex)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [actId2, matchQ1.questionText, matchQ1.questionType, matchQ1.options, matchQ1.correctAnswer, matchQ1.explanation, matchQ1.orderIndex]
    );
    console.log(`  ✅ سؤال مطابقة مضاف لنشاط 2`);

    // ===== أنشطة قصة "عالم البركة" (storyId: 90017) =====

    // نشاط 3: اختبار فهم القصة
    const [act3] = await conn.execute(
      `INSERT INTO activities (storyId, title, type, description, pointsReward, ageGroup, isPublished)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [90017, 'اختبار قصة عالم البركة ✨', 'quiz', 'اختبر فهمك لقصة عالم البركة وتعلّم قيم الصلاة والصدقة', 30, 'all', 1]
    );
    const actId3 = act3.insertId;
    console.log(`✅ نشاط 3 (اختبار عالم البركة) - ID: ${actId3}`);

    const questions3 = [
      {
        questionText: 'مَا اسْمُ العَالَمِ الَّذِي اكْتَشَفَهُ عَبْدُ الرَّحْمَنِ وَيُوسُفُ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['عَالَمُ البَرَكَةِ', 'عَالَمُ الأَحْلَامِ', 'عَالَمُ السَّحَرِ', 'عَالَمُ النُّجُومِ']),
        correctAnswer: 'عَالَمُ البَرَكَةِ',
        explanation: 'عَالَمُ البَرَكَةِ هُوَ العَالَمُ السِّحْرِيُّ الَّذِي اكْتَشَفَهُ الوَلَدَانِ.',
        orderIndex: 1,
      },
      {
        questionText: 'مَاذَا أَعْطَى الحَكِيمُ لِلْوَلَدَيْنِ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['حَقِيبَتَيْنِ سِحْرِيَّتَيْنِ', 'كِتَابَيْنِ', 'عَصَا سِحْرِيَّةً', 'خَاتَمَيْنِ']),
        correctAnswer: 'حَقِيبَتَيْنِ سِحْرِيَّتَيْنِ',
        explanation: 'أَعْطَى الحَكِيمُ لِكُلِّ وَلَدٍ حَقِيبَةً سِحْرِيَّةً تَمْتَلِئُ بِالبَرَكَةِ كُلَّمَا سَاعَدَا الآخَرِينَ.',
        orderIndex: 2,
      },
      {
        questionText: 'مَاذَا فَعَلَ عَبْدُ الرَّحْمَنِ حِينَ وَجَدَ طِفْلًا جَائِعًا؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['أَعْطَاهُ طَعَامًا', 'مَشَى بَعِيدًا', 'طَلَبَ المُسَاعَدَةَ', 'لَمْ يَفْعَلْ شَيْئًا']),
        correctAnswer: 'أَعْطَاهُ طَعَامًا',
        explanation: 'أَخْرَجَ عَبْدُ الرَّحْمَنِ طَعَامًا مِنْ حَقِيبَتِهِ وَأَعْطَاهُ لِلطِّفْلِ الجَائِعِ.',
        orderIndex: 3,
      },
      {
        questionText: 'مَاذَا فَعَلَ الوَلَدَانِ حِينَ سَمِعَا أَذَانَ الصَّلَاةِ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['ذَهَبَا لِلصَّلَاةِ فَوْرًا', 'وَاصَلَا اللَّعِبَ', 'نَامَا', 'أَكَلَا الطَّعَامَ']),
        correctAnswer: 'ذَهَبَا لِلصَّلَاةِ فَوْرًا',
        explanation: 'تَوَجَّهَ الوَلَدَانِ إِلَى المَسْجِدِ فَوْرًا حِينَ سَمِعَا الأَذَانَ.',
        orderIndex: 4,
      },
      {
        questionText: 'مَا الدَّرْسُ الَّذِي تَعَلَّمَهُ الوَلَدَانِ مِنَ القِصَّةِ؟',
        questionType: 'multiple_choice',
        options: JSON.stringify([
          'الصَّلَاةُ وَمُسَاعَدَةُ الآخَرِينَ تَجْلِبَانِ البَرَكَةَ',
          'اللَّعِبُ أَهَمُّ مِنَ الصَّلَاةِ',
          'المَالُ يَجْلِبُ السَّعَادَةَ',
          'السَّفَرُ مُمْتِعٌ',
        ]),
        correctAnswer: 'الصَّلَاةُ وَمُسَاعَدَةُ الآخَرِينَ تَجْلِبَانِ البَرَكَةَ',
        explanation: 'الدَّرْسُ الأَسَاسِيُّ هُوَ أَنَّ الصَّلَاةَ وَالصَّدَقَةَ وَمُسَاعَدَةَ الآخَرِينَ تَجْلِبُ البَرَكَةَ فِي الحَيَاةِ.',
        orderIndex: 5,
      },
      {
        questionText: 'مَاذَا فَعَلَ يُوسُفُ حِينَ وَجَدَ عَامِلًا فَقِيرًا؟',
        questionType: 'multiple_choice',
        options: JSON.stringify(['أَعْطَاهُ صَدَقَةً', 'مَرَّ بِجَانِبِهِ', 'طَلَبَ مِنْهُ المُسَاعَدَةَ', 'أَخْبَرَ الحَكِيمَ']),
        correctAnswer: 'أَعْطَاهُ صَدَقَةً',
        explanation: 'أَخْرَجَ يُوسُفُ نُقُودًا مِنْ حَقِيبَتِهِ وَأَعْطَاهَا لِلْعَامِلِ الفَقِيرِ صَدَقَةً لِوَجْهِ اللهِ.',
        orderIndex: 6,
      },
    ];

    for (const q of questions3) {
      await conn.execute(
        `INSERT INTO activity_questions (activityId, questionText, questionType, options, correctAnswer, explanation, orderIndex)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [actId3, q.questionText, q.questionType, q.options, q.correctAnswer, q.explanation, q.orderIndex]
      );
    }
    console.log(`  ✅ ${questions3.length} أسئلة مضافة لنشاط 3`);

    // نشاط 4: مطابقة (قيم البركة)
    const [act4] = await conn.execute(
      `INSERT INTO activities (storyId, title, type, description, pointsReward, ageGroup, isPublished)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [90017, 'قيم البركة 🌟', 'matching', 'طابق بين الفعل الصالح وثمرته', 20, 'all', 1]
    );
    const actId4 = act4.insertId;
    console.log(`✅ نشاط 4 (مطابقة قيم البركة) - ID: ${actId4}`);

    const matchQ4 = {
      questionText: 'طَابِقْ بَيْنَ الفِعْلِ الصَّالِحِ وَثَمَرَتِهِ',
      questionType: 'matching',
      options: JSON.stringify({
        pairs: [
          { left: 'الصَّلَاةُ', right: 'تُعْطِي القُوَّةَ وَالسَّكِينَةَ' },
          { left: 'الصَّدَقَةُ', right: 'تُضَاعِفُ البَرَكَةَ' },
          { left: 'مُسَاعَدَةُ الآخَرِينَ', right: 'تَجْلِبُ الفَرَحَ وَالرِّضَا' },
          { left: 'الأَمَانَةُ', right: 'تَبْنِي الثِّقَةَ بَيْنَ النَّاسِ' },
        ],
      }),
      correctAnswer: 'الصَّلَاةُ=تُعْطِي القُوَّةَ وَالسَّكِينَةَ|الصَّدَقَةُ=تُضَاعِفُ البَرَكَةَ|مُسَاعَدَةُ الآخَرِينَ=تَجْلِبُ الفَرَحَ وَالرِّضَا|الأَمَانَةُ=تَبْنِي الثِّقَةَ بَيْنَ النَّاسِ',
      explanation: 'كُلُّ فِعْلٍ صَالِحٍ لَهُ ثَمَرَةٌ طَيِّبَةٌ فِي الدُّنْيَا وَالآخِرَةِ.',
      orderIndex: 1,
    };
    await conn.execute(
      `INSERT INTO activity_questions (activityId, questionText, questionType, options, correctAnswer, explanation, orderIndex)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [actId4, matchQ4.questionText, matchQ4.questionType, matchQ4.options, matchQ4.correctAnswer, matchQ4.explanation, matchQ4.orderIndex]
    );
    console.log(`  ✅ سؤال مطابقة مضاف لنشاط 4`);

    console.log('\n🎉 تمت إضافة 4 أنشطة لقصتي "محبة الوطن" و"عالم البركة"!');
    console.log('  - نشاط 1: اختبار محبة الوطن (5 أسئلة) - ID:', actId1);
    console.log('  - نشاط 2: مطابقة رموز المملكة - ID:', actId2);
    console.log('  - نشاط 3: اختبار عالم البركة (6 أسئلة) - ID:', actId3);
    console.log('  - نشاط 4: مطابقة قيم البركة - ID:', actId4);
  } finally {
    await conn.end();
  }
}

main().catch(console.error);
