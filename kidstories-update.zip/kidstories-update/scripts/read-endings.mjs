import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
dotenv.config({ path: '/home/ubuntu/kidstories-update/.env' });

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const [rows] = await conn.execute('SELECT id, title, adventureData FROM story_adventures WHERE level = "hard" ORDER BY id');

for (const r of rows) {
  const data = typeof r.adventureData === 'string' ? JSON.parse(r.adventureData) : r.adventureData;
  const nodes = data.nodes || [];
  // نبحث عن النهايات (nodes بدون choices أو choices فارغة)
  const endNodes = nodes.filter(n => {
    const choices = n.choices;
    return !choices || choices.length === 0;
  });
  
  if (endNodes.length > 0) {
    console.log('=== ID:', r.id, 'Title:', r.title, '===');
    for (const en of endNodes) {
      console.log('  Node ID:', en.id, '| Type:', en.type || 'N/A');
      console.log('  Text:', (en.text || '').substring(0, 300));
      console.log('');
    }
  }
}

await conn.end();
