import mysql from 'mysql2/promise';

const newGames = [
  // ─── مبتدئ (easy) - 9 ألعاب جديدة ───────────────────────────────────────────
  {
    title: "الحيوانات ومنازلها",
    description: "صل كل حيوان بمنزله الصحيح",
    type: "image_match",
    level: "easy",
    emoji: "🏠",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "صل كل حيوان بالمكان الذي يعيش فيه",
      rounds: [
        { question: "أين يعيش السمك؟", emoji: "🐟", options: ["البحر 🌊", "الغابة 🌳", "الصحراء 🏜️", "الجبل ⛰️"], correct: 0 },
        { question: "أين يعيش الأسد؟", emoji: "🦁", options: ["البحر 🌊", "الغابة 🌳", "المنزل 🏠", "الثلج ❄️"], correct: 1 },
        { question: "أين يعيش الجمل؟", emoji: "🐪", options: ["الغابة 🌳", "البحر 🌊", "الصحراء 🏜️", "الثلج ❄️"], correct: 2 },
        { question: "أين يعيش الدب القطبي؟", emoji: "🐻‍❄️", options: ["الصحراء 🏜️", "البحر 🌊", "الغابة 🌳", "الثلج ❄️"], correct: 3 },
        { question: "أين يعيش القرد؟", emoji: "🐒", options: ["الغابة 🌳", "البحر 🌊", "الصحراء 🏜️", "الثلج ❄️"], correct: 0 },
      ]
    })
  },
  {
    title: "الفواكه والخضروات",
    description: "هل هو فاكهة أم خضروات؟",
    type: "classification",
    level: "easy",
    emoji: "🍎",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "صنّف كل عنصر: هل هو فاكهة أم خضروات؟",
      categories: ["فاكهة 🍎", "خضروات 🥦"],
      items: [
        { name: "🍎 تفاح", correct: 0 },
        { name: "🥦 بروكلي", correct: 1 },
        { name: "🍌 موز", correct: 0 },
        { name: "🥕 جزر", correct: 1 },
        { name: "🍇 عنب", correct: 0 },
        { name: "🧅 بصل", correct: 1 },
        { name: "🍓 فراولة", correct: 0 },
        { name: "🍅 طماطم", correct: 1 },
      ]
    })
  },
  {
    title: "أكبر أم أصغر؟",
    description: "قارن بين الأعداد",
    type: "letter_match",
    level: "easy",
    emoji: "⚖️",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الإجابة الصحيحة: أيهما أكبر؟",
      rounds: [
        { question: "أيهما أكبر؟", letter: "5 أم 3", options: ["5 أكبر", "3 أكبر", "متساويان", "لا أعرف"], correct: 0 },
        { question: "أيهما أصغر؟", letter: "7 أم 9", options: ["7 أصغر", "9 أصغر", "متساويان", "لا أعرف"], correct: 0 },
        { question: "أيهما أكبر؟", letter: "10 أم 6", options: ["6 أكبر", "10 أكبر", "متساويان", "لا أعرف"], correct: 1 },
        { question: "أيهما أصغر؟", letter: "2 أم 8", options: ["8 أصغر", "2 أصغر", "متساويان", "لا أعرف"], correct: 1 },
        { question: "أيهما أكبر؟", letter: "4 أم 4", options: ["الأول أكبر", "الثاني أكبر", "متساويان", "لا أعرف"], correct: 2 },
      ]
    })
  },
  {
    title: "أشكال هندسية",
    description: "تعرّف على الأشكال الهندسية",
    type: "image_match",
    level: "easy",
    emoji: "🔷",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر اسم الشكل الهندسي الصحيح",
      rounds: [
        { question: "ما اسم هذا الشكل؟", emoji: "⭕", options: ["دائرة", "مثلث", "مربع", "مستطيل"], correct: 0 },
        { question: "ما اسم هذا الشكل؟", emoji: "🔺", options: ["دائرة", "مثلث", "مربع", "مستطيل"], correct: 1 },
        { question: "ما اسم هذا الشكل؟", emoji: "🔷", options: ["دائرة", "معين", "مربع", "مستطيل"], correct: 1 },
        { question: "ما اسم هذا الشكل؟", emoji: "⬛", options: ["دائرة", "مثلث", "مربع", "مستطيل"], correct: 2 },
        { question: "كم ضلعاً للمثلث؟", emoji: "🔺", options: ["2", "3", "4", "5"], correct: 1 },
        { question: "كم ضلعاً للمربع؟", emoji: "⬛", options: ["2", "3", "4", "5"], correct: 2 },
      ]
    })
  },
  {
    title: "أيام الأسبوع",
    description: "رتّب أيام الأسبوع بالترتيب الصحيح",
    type: "number_order",
    level: "easy",
    emoji: "📅",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "رتّب أيام الأسبوع من الأحد إلى السبت",
      items: ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"],
      correctOrder: [0, 1, 2, 3, 4, 5, 6]
    })
  },
  {
    title: "الطقس والفصول",
    description: "ما الطقس المناسب لكل فصل؟",
    type: "image_match",
    level: "easy",
    emoji: "☀️",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الطقس المناسب لكل فصل",
      rounds: [
        { question: "ما طقس الصيف؟", emoji: "☀️", options: ["حار ومشمس", "بارد وثلجي", "ممطر وعاصف", "معتدل"], correct: 0 },
        { question: "ما طقس الشتاء؟", emoji: "❄️", options: ["حار جداً", "بارد وممطر", "جاف ومشمس", "معتدل"], correct: 1 },
        { question: "ما طقس الربيع؟", emoji: "🌸", options: ["حار جداً", "بارد وثلجي", "معتدل ومزهر", "عاصف"], correct: 2 },
        { question: "ما طقس الخريف؟", emoji: "🍂", options: ["حار جداً", "معتدل وأوراق تتساقط", "ثلجي", "ممطر جداً"], correct: 1 },
        { question: "في أي فصل تتفتح الزهور؟", emoji: "🌺", options: ["الشتاء", "الصيف", "الربيع", "الخريف"], correct: 2 },
      ]
    })
  },
  {
    title: "المركبات والوسائل",
    description: "تعرّف على وسائل النقل",
    type: "classification",
    level: "easy",
    emoji: "🚗",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "صنّف وسائل النقل: براً أم بحراً أم جواً؟",
      categories: ["براً 🚗", "بحراً 🚢", "جواً ✈️"],
      items: [
        { name: "🚗 سيارة", correct: 0 },
        { name: "🚢 سفينة", correct: 1 },
        { name: "✈️ طائرة", correct: 2 },
        { name: "🚂 قطار", correct: 0 },
        { name: "⛵ قارب", correct: 1 },
        { name: "🚁 مروحية", correct: 2 },
        { name: "🚌 حافلة", correct: 0 },
        { name: "🛸 مركبة فضائية", correct: 2 },
      ]
    })
  },
  {
    title: "الأرقام والكميات",
    description: "عدّ وصل الرقم بالكمية",
    type: "count_objects",
    level: "easy",
    emoji: "🔢",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "عدّ الأشياء واختر الرقم الصحيح",
      rounds: [
        { emoji: "⭐", count: 4, options: [3, 4, 5, 6], correct: 1 },
        { emoji: "🌙", count: 7, options: [5, 6, 7, 8], correct: 2 },
        { emoji: "🌟", count: 2, options: [1, 2, 3, 4], correct: 1 },
        { emoji: "❤️", count: 9, options: [7, 8, 9, 10], correct: 2 },
        { emoji: "🔵", count: 6, options: [4, 5, 6, 7], correct: 2 },
        { emoji: "🌈", count: 3, options: [2, 3, 4, 5], correct: 1 },
      ]
    })
  },
  {
    title: "الكلمات المتضادة",
    description: "اعرف الكلمة المعاكسة",
    type: "letter_match",
    level: "easy",
    emoji: "↔️",
    ageGroup: "all",
    pointsReward: 15,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الكلمة المعاكسة (الضد)",
      rounds: [
        { question: "ما ضد كلمة 'كبير'؟", letter: "كبير", options: ["صغير", "طويل", "سريع", "ثقيل"], correct: 0 },
        { question: "ما ضد كلمة 'سريع'؟", letter: "سريع", options: ["قوي", "بطيء", "طويل", "كبير"], correct: 1 },
        { question: "ما ضد كلمة 'نهار'؟", letter: "نهار", options: ["صباح", "مساء", "ليل", "ظهر"], correct: 2 },
        { question: "ما ضد كلمة 'حار'؟", letter: "حار", options: ["دافئ", "بارد", "جاف", "رطب"], correct: 1 },
        { question: "ما ضد كلمة 'فوق'؟", letter: "فوق", options: ["جانب", "أمام", "تحت", "خلف"], correct: 2 },
        { question: "ما ضد كلمة 'فرح'؟", letter: "فرح", options: ["خوف", "حزن", "غضب", "تعب"], correct: 1 },
      ]
    })
  },

  // ─── متوسط (medium) - 9 ألعاب جديدة ─────────────────────────────────────────
  {
    title: "الكلمة الغريبة",
    description: "اكتشف الكلمة التي لا تنتمي للمجموعة",
    type: "letter_match",
    level: "medium",
    emoji: "🔍",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الكلمة التي لا تنتمي للمجموعة",
      rounds: [
        { question: "أيها لا ينتمي للمجموعة؟", letter: "🍎🍌🍇", options: ["تفاح", "موز", "جزر", "عنب"], correct: 2, hint: "المجموعة: فواكه" },
        { question: "أيها لا ينتمي للمجموعة؟", letter: "🐕🐈🐟🦁", options: ["كلب", "قطة", "سمكة", "طاولة"], correct: 3, hint: "المجموعة: حيوانات" },
        { question: "أيها لا ينتمي للمجموعة؟", letter: "🚗🚌🚂", options: ["سيارة", "حافلة", "قطار", "طائرة"], correct: 3, hint: "المجموعة: مركبات برية" },
        { question: "أيها لا ينتمي للمجموعة؟", letter: "📚✏️🖊️", options: ["كتاب", "قلم", "مقص", "دفتر"], correct: 2, hint: "المجموعة: أدوات الكتابة" },
        { question: "أيها لا ينتمي للمجموعة؟", letter: "🔴🔵🟡", options: ["أحمر", "أزرق", "أصفر", "مثلث"], correct: 3, hint: "المجموعة: ألوان" },
      ]
    })
  },
  {
    title: "تكوين الجمل",
    description: "رتّب الكلمات لتكوين جملة صحيحة",
    type: "word_build",
    level: "medium",
    emoji: "📝",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "رتّب الحروف لتكوين الكلمة الصحيحة",
      rounds: [
        { word: "مدرسة", hint: "المكان الذي نتعلم فيه", letters: ["م", "د", "ر", "س", "ة"] },
        { word: "سماء", hint: "فوق رؤوسنا", letters: ["س", "م", "ا", "ء"] },
        { word: "شجرة", hint: "نبات كبير له أغصان", letters: ["ش", "ج", "ر", "ة"] },
        { word: "كتاب", hint: "نقرأ منه", letters: ["ك", "ت", "ا", "ب"] },
        { word: "قمر", hint: "يضيء الليل", letters: ["ق", "م", "ر"] },
      ]
    })
  },
  {
    title: "أسماء الأشياء",
    description: "صل الصورة بالاسم الصحيح",
    type: "image_match",
    level: "medium",
    emoji: "🏷️",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الاسم الصحيح لكل صورة",
      rounds: [
        { question: "ما اسم هذا؟", emoji: "🌙", options: ["شمس", "قمر", "نجمة", "سحابة"], correct: 1 },
        { question: "ما اسم هذا؟", emoji: "🌊", options: ["بحر", "نهر", "بحيرة", "مطر"], correct: 0 },
        { question: "ما اسم هذا؟", emoji: "⛰️", options: ["تل", "جبل", "وادٍ", "صحراء"], correct: 1 },
        { question: "ما اسم هذا؟", emoji: "🌈", options: ["غيمة", "برق", "قوس قزح", "شمس"], correct: 2 },
        { question: "ما اسم هذا؟", emoji: "🦋", options: ["نحلة", "ذبابة", "فراشة", "دودة"], correct: 2 },
        { question: "ما اسم هذا؟", emoji: "🌻", options: ["وردة", "زنبق", "عباد الشمس", "ياسمين"], correct: 2 },
      ]
    })
  },
  {
    title: "ألعاب الطرح المتوسط",
    description: "احسب نتيجة الطرح",
    type: "math_subtraction",
    level: "medium",
    emoji: "➖",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "احسب نتيجة الطرح واختر الإجابة الصحيحة",
      rounds: [
        { question: "10 - 3 = ؟", options: [5, 6, 7, 8], correct: 2 },
        { question: "15 - 7 = ؟", options: [6, 7, 8, 9], correct: 2 },
        { question: "12 - 5 = ؟", options: [5, 6, 7, 8], correct: 2 },
        { question: "20 - 8 = ؟", options: [10, 11, 12, 13], correct: 2 },
        { question: "9 - 4 = ؟", options: [3, 4, 5, 6], correct: 2 },
        { question: "18 - 9 = ؟", options: [7, 8, 9, 10], correct: 2 },
      ]
    })
  },
  {
    title: "الجسم والصحة",
    description: "تعلّم عن جسم الإنسان",
    type: "image_match",
    level: "medium",
    emoji: "🫀",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الإجابة الصحيحة عن جسم الإنسان",
      rounds: [
        { question: "ماذا نستخدم للتنفس؟", emoji: "🫁", options: ["القلب", "الرئتان", "المعدة", "الدماغ"], correct: 1 },
        { question: "ماذا يضخ الدم في الجسم؟", emoji: "🫀", options: ["الرئة", "الكبد", "القلب", "الكلية"], correct: 2 },
        { question: "كم عدد أصابع اليدين معاً؟", emoji: "🤲", options: ["8", "9", "10", "12"], correct: 2 },
        { question: "ماذا نستخدم للسمع؟", emoji: "👂", options: ["العين", "الأنف", "الأذن", "الفم"], correct: 2 },
        { question: "ماذا نستخدم للشم؟", emoji: "👃", options: ["الأذن", "الأنف", "العين", "اللسان"], correct: 1 },
      ]
    })
  },
  {
    title: "الأرقام والعمليات",
    description: "حل مسائل رياضية بسيطة",
    type: "letter_match",
    level: "medium",
    emoji: "🔢",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الإجابة الصحيحة للمسألة",
      rounds: [
        { question: "عندي 5 تفاحات وأكلت 2، كم بقي؟", letter: "🍎🍎🍎🍎🍎", options: ["1", "2", "3", "4"], correct: 2 },
        { question: "في الفصل 10 طلاب، جاء 3 آخرون، كم صاروا؟", letter: "👧👦", options: ["11", "12", "13", "14"], correct: 2 },
        { question: "لدي 8 حلوى وأعطيت 3، كم بقي؟", letter: "🍬🍬🍬🍬🍬🍬🍬🍬", options: ["3", "4", "5", "6"], correct: 2 },
        { question: "اشتريت 4 كتب ثم 6 كتب، كم المجموع؟", letter: "📚", options: ["8", "9", "10", "11"], correct: 2 },
        { question: "في الحديقة 12 زهرة، ذبلت 4، كم بقي؟", letter: "🌸", options: ["6", "7", "8", "9"], correct: 2 },
      ]
    })
  },
  {
    title: "الكلمات والمعاني",
    description: "اختر المعنى الصحيح للكلمة",
    type: "letter_match",
    level: "medium",
    emoji: "📖",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر المعنى الصحيح للكلمة",
      rounds: [
        { question: "ما معنى 'شجاع'؟", letter: "شجاع", options: ["خائف", "لا يخاف", "حزين", "كسول"], correct: 1 },
        { question: "ما معنى 'كريم'؟", letter: "كريم", options: ["بخيل", "غاضب", "يحب العطاء", "خائف"], correct: 2 },
        { question: "ما معنى 'ذكي'؟", letter: "ذكي", options: ["قوي", "سريع التعلم", "طويل", "جميل"], correct: 1 },
        { question: "ما معنى 'صادق'؟", letter: "صادق", options: ["كاذب", "يقول الحقيقة", "شجاع", "قوي"], correct: 1 },
        { question: "ما معنى 'متعاون'؟", letter: "متعاون", options: ["يساعد الآخرين", "يأخذ من الآخرين", "يكذب", "يتشاجر"], correct: 0 },
      ]
    })
  },
  {
    title: "الأنشطة اليومية",
    description: "رتّب أنشطة اليوم بالترتيب الصحيح",
    type: "number_order",
    level: "medium",
    emoji: "🌅",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "رتّب أنشطة اليوم من الصباح إلى المساء",
      items: ["الاستيقاظ ☀️", "الإفطار 🍳", "المدرسة 🏫", "الغداء 🍽️", "اللعب 🎮", "العشاء 🌙", "النوم 😴"],
      correctOrder: [0, 1, 2, 3, 4, 5, 6]
    })
  },
  {
    title: "الحيوانات والأصوات",
    description: "صل الحيوان بصوته",
    type: "image_match",
    level: "medium",
    emoji: "🔊",
    ageGroup: "all",
    pointsReward: 20,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الصوت الذي يصدره كل حيوان",
      rounds: [
        { question: "ماذا يقول الأسد؟", emoji: "🦁", options: ["مياو", "هاو هاو", "زئير", "ثغاء"], correct: 2 },
        { question: "ماذا تقول القطة؟", emoji: "🐱", options: ["مياو", "هاو هاو", "زئير", "ثغاء"], correct: 0 },
        { question: "ماذا يقول الكلب؟", emoji: "🐶", options: ["مياو", "هاو هاو", "زئير", "ثغاء"], correct: 1 },
        { question: "ماذا تقول الخروف؟", emoji: "🐑", options: ["مياو", "هاو هاو", "زئير", "ثغاء"], correct: 3 },
        { question: "ماذا تقول البقرة؟", emoji: "🐄", options: ["خوار", "هاو هاو", "زئير", "ثغاء"], correct: 0 },
      ]
    })
  },

  // ─── متقدم (hard) - 8 ألعاب جديدة ──────────────────────────────────────────
  {
    title: "القصة الناقصة",
    description: "أكمل الفقرة بالكلمة المناسبة",
    type: "missing_letter",
    level: "hard",
    emoji: "📖",
    ageGroup: "all",
    pointsReward: 25,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الكلمة المناسبة لإكمال الجملة",
      rounds: [
        { question: "ذهب الطفل إلى _____ ليتعلم", missing: "المدرسة", options: ["المدرسة", "الملعب", "السوق", "البيت"], correct: 0, hint: "مكان التعلم" },
        { question: "الشمس تشرق من _____ وتغرب في الغرب", missing: "الشرق", options: ["الشمال", "الجنوب", "الشرق", "الغرب"], correct: 2, hint: "اتجاه" },
        { question: "الماء يغلي عند درجة حرارة _____ مئوية", missing: "100", options: ["50", "75", "100", "150"], correct: 2, hint: "رقم" },
        { question: "النحلة تصنع _____ من الزهور", missing: "العسل", options: ["السكر", "العسل", "الحليب", "الدقيق"], correct: 1, hint: "طعام حلو" },
        { question: "الأرض تدور حول _____ مرة كل سنة", missing: "الشمس", options: ["القمر", "المريخ", "الشمس", "النجوم"], correct: 2, hint: "نجم كبير" },
      ]
    })
  },
  {
    title: "التفكير المنطقي",
    description: "حل الألغاز المنطقية",
    type: "letter_match",
    level: "hard",
    emoji: "🧩",
    ageGroup: "all",
    pointsReward: 25,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "فكّر جيداً وحل اللغز",
      rounds: [
        { question: "لي أربعة أرجل ولا أمشي، وعليّ تجلس. ما أنا؟", letter: "🪑", options: ["سرير", "كرسي", "طاولة", "خزانة"], correct: 1 },
        { question: "أنا دائماً أمامك لكن لا يمكنك رؤيتي. ما أنا؟", letter: "🔮", options: ["الماضي", "المستقبل", "الحاضر", "الحلم"], correct: 1 },
        { question: "كلما أخذت منه أكبر. ما هو؟", letter: "🕳️", options: ["الجبل", "الحفرة", "البحر", "الغابة"], correct: 1 },
        { question: "ما الشيء الذي له أسنان لكن لا يعض؟", letter: "🪥", options: ["الكلب", "المشط", "السكين", "الأسد"], correct: 1 },
        { question: "أنا أسبق الشمس وأتبع القمر. ما أنا؟", letter: "🌅", options: ["الليل", "النهار", "الفجر", "الغروب"], correct: 2 },
      ]
    })
  },
  {
    title: "الرياضيات المتقدمة",
    description: "حل مسائل رياضية متقدمة",
    type: "math_addition",
    level: "hard",
    emoji: "🔣",
    ageGroup: "all",
    pointsReward: 30,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "حل المسألة الرياضية",
      rounds: [
        { question: "25 + 37 = ؟", options: [60, 61, 62, 63], correct: 2 },
        { question: "48 - 19 = ؟", options: [27, 28, 29, 30], correct: 2 },
        { question: "6 × 7 = ؟", options: [40, 41, 42, 43], correct: 2 },
        { question: "56 ÷ 8 = ؟", options: [5, 6, 7, 8], correct: 2 },
        { question: "100 - 43 = ؟", options: [55, 56, 57, 58], correct: 2 },
        { question: "9 × 9 = ؟", options: [79, 80, 81, 82], correct: 2 },
      ]
    })
  },
  {
    title: "الجغرافيا العربية",
    description: "تعلّم عن الوطن العربي",
    type: "image_match",
    level: "hard",
    emoji: "🗺️",
    ageGroup: "all",
    pointsReward: 25,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الإجابة الصحيحة عن الوطن العربي",
      rounds: [
        { question: "ما عاصمة المملكة العربية السعودية؟", emoji: "🇸🇦", options: ["جدة", "الرياض", "مكة", "المدينة"], correct: 1 },
        { question: "ما أطول نهر في العالم؟", emoji: "🌊", options: ["الفرات", "دجلة", "النيل", "الأمازون"], correct: 2 },
        { question: "في أي قارة يقع الوطن العربي؟", emoji: "🌍", options: ["آسيا فقط", "أفريقيا فقط", "آسيا وأفريقيا", "أوروبا"], correct: 2 },
        { question: "ما أكبر صحراء في العالم؟", emoji: "🏜️", options: ["صحراء العرب", "الصحراء الكبرى", "صحراء غوبي", "صحراء النفود"], correct: 1 },
        { question: "ما أعلى جبل في العالم؟", emoji: "⛰️", options: ["جبل أحد", "جبل إيفرست", "جبل لبنان", "جبل الأطلس"], correct: 1 },
      ]
    })
  },
  {
    title: "لعبة الذاكرة المتقدمة",
    description: "تحدٍّ للذاكرة - تسلسلات أطول",
    type: "memory_game",
    level: "hard",
    emoji: "🧠",
    ageGroup: "all",
    pointsReward: 30,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "احفظ التسلسل ثم اختر الترتيب الصحيح",
      rounds: [
        {
          question: "ما الترتيب الصحيح؟",
          emoji: "🍎🍊🍋🍇🍓",
          options: ["🍎🍊🍋🍇🍓", "🍊🍎🍋🍇🍓", "🍎🍋🍊🍇🍓", "🍇🍎🍊🍋🍓"],
          correct: 0
        },
        {
          question: "ما الترتيب الصحيح؟",
          emoji: "🐶🐱🐭🐹🐰",
          options: ["🐱🐶🐭🐹🐰", "🐶🐱🐭🐹🐰", "🐶🐭🐱🐹🐰", "🐹🐶🐱🐭🐰"],
          correct: 1
        },
        {
          question: "ما الترتيب الصحيح؟",
          emoji: "🔴🟡🟢🔵🟣",
          options: ["🔴🟡🟢🔵🟣", "🟡🔴🟢🔵🟣", "🔴🟢🟡🔵🟣", "🟣🔴🟡🟢🔵"],
          correct: 0
        },
        {
          question: "ما الترتيب الصحيح؟",
          emoji: "1️⃣2️⃣3️⃣4️⃣5️⃣",
          options: ["2️⃣1️⃣3️⃣4️⃣5️⃣", "1️⃣3️⃣2️⃣4️⃣5️⃣", "1️⃣2️⃣3️⃣4️⃣5️⃣", "1️⃣2️⃣4️⃣3️⃣5️⃣"],
          correct: 2
        },
      ]
    })
  },
  {
    title: "النحو والإملاء",
    description: "اختر الكلمة المكتوبة صحيحاً",
    type: "letter_match",
    level: "hard",
    emoji: "✍️",
    ageGroup: "all",
    pointsReward: 25,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الكلمة المكتوبة بشكل صحيح",
      rounds: [
        { question: "أيهما مكتوب صحيحاً؟", letter: "✏️", options: ["مدرسه", "مدرسة", "مدرسا", "مدرسي"], correct: 1 },
        { question: "أيهما مكتوب صحيحاً؟", letter: "📚", options: ["كتاب", "كتابه", "كتابا", "كتابي"], correct: 0 },
        { question: "أيهما مكتوب صحيحاً؟", letter: "🏠", options: ["بيت", "بيط", "بيد", "بيز"], correct: 0 },
        { question: "أيهما مكتوب صحيحاً؟", letter: "🌳", options: ["شجره", "شجرة", "شجرا", "شجري"], correct: 1 },
        { question: "أيهما مكتوب صحيحاً؟", letter: "🌟", options: ["نجمه", "نجمة", "نجما", "نجمي"], correct: 1 },
        { question: "أيهما مكتوب صحيحاً؟", letter: "🌙", options: ["قمر", "قمار", "قمير", "قمور"], correct: 0 },
      ]
    })
  },
  {
    title: "العلوم والطبيعة",
    description: "اكتشف أسرار الطبيعة",
    type: "letter_match",
    level: "hard",
    emoji: "🔬",
    ageGroup: "all",
    pointsReward: 25,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "اختر الإجابة العلمية الصحيحة",
      rounds: [
        { question: "ما مصدر ضوء الشمس؟", letter: "☀️", options: ["النار", "الكهرباء", "الاندماج النووي", "الانعكاس"], correct: 2 },
        { question: "كم كوكباً في المجموعة الشمسية؟", letter: "🪐", options: ["7", "8", "9", "10"], correct: 1 },
        { question: "ما أصغر كوكب في المجموعة الشمسية؟", letter: "🔭", options: ["الأرض", "الزهرة", "عطارد", "المريخ"], correct: 2 },
        { question: "ما الغاز الذي نتنفسه؟", letter: "💨", options: ["ثاني أكسيد الكربون", "الأكسجين", "النيتروجين", "الهيدروجين"], correct: 1 },
        { question: "ما الذي تصنعه النباتات من الضوء؟", letter: "🌱", options: ["الماء", "الهواء", "الغذاء", "الملح"], correct: 2 },
      ]
    })
  },
  {
    title: "الحساب الذهني",
    description: "احسب بسرعة في ذهنك",
    type: "math_addition",
    level: "hard",
    emoji: "⚡",
    ageGroup: "all",
    pointsReward: 30,
    isActive: true,
    gameData: JSON.stringify({
      instructions: "احسب بسرعة واختر الإجابة الصحيحة",
      rounds: [
        { question: "15 + 27 + 8 = ؟", options: [48, 49, 50, 51], correct: 2 },
        { question: "100 - 35 - 15 = ؟", options: [48, 49, 50, 51], correct: 2 },
        { question: "4 × 6 + 4 = ؟", options: [26, 27, 28, 29], correct: 2 },
        { question: "50 ÷ 5 + 12 = ؟", options: [20, 21, 22, 23], correct: 2 },
        { question: "3 × 3 × 3 = ؟", options: [25, 26, 27, 28], correct: 2 },
        { question: "45 + 55 - 50 = ؟", options: [48, 49, 50, 51], correct: 2 },
      ]
    })
  },
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  let added = 0;
  for (const game of newGames) {
    await conn.execute(
      `INSERT INTO educational_games (title, description, type, level, emoji, ageGroup, pointsReward, isPublished, gameData, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [game.title, game.description, game.type, game.level, game.emoji, game.ageGroup, game.pointsReward, 1, game.gameData]
    );
    added++;
    console.log(`✅ Added: ${game.emoji} ${game.title} [${game.level}]`);
  }
  
  const [rows] = await conn.query('SELECT COUNT(*) as total FROM educational_games');
  console.log(`\n📊 Total games in DB: ${rows[0].total}`);
  console.log(`✨ Added ${added} new games`);
  
  await conn.end();
}

main().catch(console.error);
