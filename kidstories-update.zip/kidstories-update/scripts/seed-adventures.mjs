import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const adventures = [
  // ─── EASY (مبتدئ) ───────────────────────────────────────────────────────────
  {
    title: "الأرنب الجائع",
    description: "أرنب صغير يبحث عن طعامه في الغابة. ماذا سيجد؟",
    emoji: "🐰",
    level: "easy",
    ageGroup: "4-6",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 1,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🌲",
          text: "أرنب صغير اسمه قفزون يشعر بالجوع في الغابة. رأى طريقين أمامه: طريق يؤدي إلى حقل الجزر، وطريق يؤدي إلى بيت الجدة.",
          choices: [
            { id: "c1a", text: "أذهب إلى حقل الجزر", emoji: "🥕", type: "safe", points: 10, nextNodeId: "carrot_field" },
            { id: "c1b", text: "أزور بيت الجدة أولاً", emoji: "🏠", type: "adventure", points: 20, nextNodeId: "grandma_house" }
          ]
        },
        {
          id: "carrot_field",
          emoji: "🥕",
          text: "وجد قفزون حقلاً مليئاً بالجزر الطازج! لكنه رأى ثعلباً ينظر إليه. هل يأكل بسرعة أم يشارك الثعلب؟",
          choices: [
            { id: "c2a", text: "آكل بسرعة وأهرب", emoji: "🏃", type: "learning", points: 5, nextNodeId: "ending_alone" },
            { id: "c2b", text: "أشارك الثعلب الطعام", emoji: "🤝", type: "safe", points: 10, nextNodeId: "ending_friends" }
          ]
        },
        {
          id: "grandma_house",
          emoji: "🏠",
          text: "في بيت الجدة، وجد قفزون كعكة جزر لذيذة! قالت الجدة: 'خذ معك بعضها لأصدقائك.' ماذا يفعل؟",
          choices: [
            { id: "c3a", text: "أحمل الكعكة لأصدقائي", emoji: "🎁", type: "adventure", points: 20, nextNodeId: "ending_hero" },
            { id: "c3b", text: "آكلها وحدي لأنني جائع", emoji: "😋", type: "learning", points: 5, nextNodeId: "ending_alone" }
          ]
        },
        {
          id: "ending_friends",
          emoji: "🌟",
          text: "شارك قفزون الثعلب الجزر، وأصبحا أصدقاء مقربين! الثعلب أخبره عن حقل تفاح سري. الصداقة تفتح أبواباً جديدة!",
          isEnding: true, endingKey: "friends", endingType: "great",
          endingTitle: "تعلمت أن المشاركة تجلب الأصدقاء الجدد!"
        },
        {
          id: "ending_hero",
          emoji: "🏆",
          text: "عاد قفزون بالكعكة وأطعم كل أصدقائه! صاروا يحبونه كثيراً وسمّوه 'أرنب القلب الكبير'!",
          isEnding: true, endingKey: "hero", endingType: "great",
          endingTitle: "الكرم يجعلك بطلاً في قلوب الجميع!"
        },
        {
          id: "ending_alone",
          emoji: "😔",
          text: "أكل قفزون وحده وشعر بالوحدة. أدرك أن الطعام يكون ألذ حين نتشاركه مع الآخرين. في اليوم التالي قرر أن يكون أكثر كرماً.",
          isEnding: true, endingKey: "alone", endingType: "learning",
          endingTitle: "تعلمنا: المشاركة تجعل الحياة أجمل!"
        }
      ]
    }
  },
  {
    title: "الطائر الصغير يتعلم الطيران",
    description: "طائر صغير يريد أن يطير لأول مرة. هل سيجرؤ؟",
    emoji: "🐦",
    level: "easy",
    ageGroup: "4-6",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 2,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🌤️",
          text: "زيزو الطائر الصغير يجلس على حافة العش للمرة الأولى. الأرض بعيدة جداً! أمه تشجعه. ماذا يفعل؟",
          choices: [
            { id: "c1a", text: "أجرب الطيران الآن!", emoji: "🦅", type: "adventure", points: 20, nextNodeId: "try_fly" },
            { id: "c1b", text: "أنتظر وأشاهد الطيور الأخرى أولاً", emoji: "👀", type: "safe", points: 10, nextNodeId: "watch_first" }
          ]
        },
        {
          id: "try_fly",
          emoji: "💨",
          text: "قفز زيزو! بدأ يسقط... ثم فتح جناحيه وطار! لكنه لا يعرف كيف يهبط. ماذا يفعل؟",
          choices: [
            { id: "c2a", text: "أصرخ طلباً للمساعدة", emoji: "📢", type: "safe", points: 10, nextNodeId: "ending_rescued" },
            { id: "c2b", text: "أحاول الهبوط وحدي", emoji: "💪", type: "adventure", points: 20, nextNodeId: "ending_champion" }
          ]
        },
        {
          id: "watch_first",
          emoji: "🔍",
          text: "شاهد زيزو الطيور الأخرى وتعلم كيف تطير. أمه علّمته: 'افرد جناحيك ببطء.' هل يجرب الآن؟",
          choices: [
            { id: "c3a", text: "أجرب بعد أن تعلمت", emoji: "✅", type: "safe", points: 10, nextNodeId: "ending_wise" },
            { id: "c3b", text: "أنتظر أكثر، أنا خائف", emoji: "😨", type: "learning", points: 5, nextNodeId: "ending_wait" }
          ]
        },
        {
          id: "ending_champion",
          emoji: "🏆",
          text: "هبط زيزو بنجاح! صار أشجع طائر في الغابة وعلّم الطيور الصغيرة الأخرى كيف تطير!",
          isEnding: true, endingKey: "champion", endingType: "great",
          endingTitle: "الشجاعة والمحاولة تصنعان البطل!"
        },
        {
          id: "ending_rescued",
          emoji: "🌟",
          text: "جاءت أمه وساعدته على الهبوط بأمان. قالت: 'طلب المساعدة شجاعة أيضاً يا بني!'",
          isEnding: true, endingKey: "rescued", endingType: "good",
          endingTitle: "طلب المساعدة عند الحاجة أمر حكيم!"
        },
        {
          id: "ending_wise",
          emoji: "🌈",
          text: "طار زيزو بثقة بعد أن تعلم جيداً! الاستعداد قبل المحاولة يجعل النجاح أسهل!",
          isEnding: true, endingKey: "wise", endingType: "great",
          endingTitle: "التعلم قبل التجربة طريق الحكماء!"
        },
        {
          id: "ending_wait",
          emoji: "😔",
          text: "بقي زيزو في العش وحيداً بينما طارت الطيور الأخرى. في اليوم التالي قرر أن يتغلب على خوفه.",
          isEnding: true, endingKey: "wait", endingType: "learning",
          endingTitle: "الخوف طبيعي، لكن لا تدعه يوقفك!"
        }
      ]
    }
  },
  {
    title: "السمكة الضائعة",
    description: "سمكة صغيرة ابتعدت عن أسرتها في البحر الكبير. كيف ستجدهم؟",
    emoji: "🐠",
    level: "easy",
    ageGroup: "4-6",
    pointsReward: 50,
    totalEndings: 2,
    orderIndex: 3,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🌊",
          text: "لولو السمكة الصغيرة كانت تلعب وابتعدت عن أسرتها. البحر واسع جداً! رأت سمكة كبيرة وسلحفاة.",
          choices: [
            { id: "c1a", text: "أسأل السمكة الكبيرة عن طريق البيت", emoji: "🐟", type: "safe", points: 10, nextNodeId: "ask_fish" },
            { id: "c1b", text: "أتبع السلحفاة البطيئة", emoji: "🐢", type: "adventure", points: 20, nextNodeId: "follow_turtle" }
          ]
        },
        {
          id: "ask_fish",
          emoji: "💬",
          text: "قالت السمكة الكبيرة: 'أسرتك في الشعاب المرجانية الحمراء!' لكن الطريق طويل. هل تذهب وحدها؟",
          choices: [
            { id: "c2a", text: "أذهب وحدي بشجاعة", emoji: "💪", type: "adventure", points: 20, nextNodeId: "ending_brave" },
            { id: "c2b", text: "أطلب من السمكة الكبيرة مرافقتي", emoji: "🤝", type: "safe", points: 10, nextNodeId: "ending_together" }
          ]
        },
        {
          id: "follow_turtle",
          emoji: "🐢",
          text: "السلحفاة تعرف كل مكان في البحر! قادت لولو عبر حدائق المرجان الجميلة وأوصلتها لأسرتها.",
          isEnding: true, endingKey: "turtle", endingType: "great",
          endingTitle: "الصبر والثقة بالآخرين يوصلانك للبيت!"
        },
        {
          id: "ending_brave",
          emoji: "🌟",
          text: "وجدت لولو طريقها وحدها! أسرتها فرحت كثيراً وقالوا: 'أنتِ شجاعة جداً يا لولو!'",
          isEnding: true, endingKey: "brave", endingType: "great",
          endingTitle: "الشجاعة تجعلك تجد طريقك دائماً!"
        },
        {
          id: "ending_together",
          emoji: "🏠",
          text: "رافقتها السمكة الكبيرة بأمان إلى البيت. تعلمت لولو أن طلب المساعدة أمر جيد!",
          isEnding: true, endingKey: "together", endingType: "good",
          endingTitle: "لا بأس في طلب المساعدة من الكبار!"
        }
      ]
    }
  },
  {
    title: "الدب الصغير والعسل",
    description: "دب صغير يريد العسل لكن النحل يحرسه. ماذا سيفعل؟",
    emoji: "🐻",
    level: "easy",
    ageGroup: "4-6",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 4,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🍯",
          text: "دبدوب الدب الصغير يشم رائحة العسل اللذيذ. الخلية في الشجرة الكبيرة. النحل يطير حولها. ماذا يفعل؟",
          choices: [
            { id: "c1a", text: "أتسلق الشجرة بهدوء", emoji: "🌳", type: "adventure", points: 20, nextNodeId: "climb_tree" },
            { id: "c1b", text: "أنتظر حتى يغيب النحل", emoji: "⏰", type: "safe", points: 10, nextNodeId: "wait_bees" }
          ]
        },
        {
          id: "climb_tree",
          emoji: "🐝",
          text: "تسلق دبدوب الشجرة لكن النحل لاحظه! هل يهرب أم يبقى؟",
          choices: [
            { id: "c2a", text: "أهرب بسرعة!", emoji: "🏃", type: "safe", points: 10, nextNodeId: "ending_escape" },
            { id: "c2b", text: "أبقى وأحاول أخذ العسل", emoji: "😤", type: "learning", points: 5, nextNodeId: "ending_stung" }
          ]
        },
        {
          id: "wait_bees",
          emoji: "🌙",
          text: "في الليل، ذهب النحل للنوم. تسلق دبدوب بهدوء وأخذ قليلاً من العسل دون إيذاء أحد.",
          isEnding: true, endingKey: "patient", endingType: "great",
          endingTitle: "الصبر والانتظار يجلبان النتائج الجيدة!"
        },
        {
          id: "ending_escape",
          emoji: "😅",
          text: "هرب دبدوب بدون عسل لكنه سليم! قرر أن يعود ليلاً حين ينام النحل. الحكمة أفضل من العجلة!",
          isEnding: true, endingKey: "escape", endingType: "good",
          endingTitle: "أحياناً التراجع الذكي أفضل من المضي قدماً!"
        },
        {
          id: "ending_stung",
          emoji: "😢",
          text: "لسعه النحل وبكى دبدوب! لكنه تعلم درساً مهماً: لا تأخذ ما ليس لك بالقوة. في اليوم التالي انتظر بصبر.",
          isEnding: true, endingKey: "stung", endingType: "learning",
          endingTitle: "الصبر أفضل من العجلة والأذى!"
        }
      ]
    }
  },
  {
    title: "المطر والزهرة الصغيرة",
    description: "زهرة صغيرة تحتاج ماء لكن السماء صافية. من سيساعدها؟",
    emoji: "🌸",
    level: "easy",
    ageGroup: "4-6",
    pointsReward: 50,
    totalEndings: 2,
    orderIndex: 5,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "☀️",
          text: "زهرة صغيرة اسمها وردة تشعر بالعطش. الشمس حارة والأرض جافة. رأت طفلاً يمر بجانبها وسحابة بعيدة.",
          choices: [
            { id: "c1a", text: "أتمايل بلطف لأجذب انتباه الطفل", emoji: "🧒", type: "safe", points: 10, nextNodeId: "attract_child" },
            { id: "c1b", text: "أنادي السحابة بعيداً", emoji: "☁️", type: "adventure", points: 20, nextNodeId: "call_cloud" }
          ]
        },
        {
          id: "attract_child",
          emoji: "💧",
          text: "لاحظ الطفل الزهرة وسقاها من زجاجة مائه. قالت وردة بقلبها: 'شكراً لك أيها الطفل الطيب!'",
          isEnding: true, endingKey: "child_help", endingType: "good",
          endingTitle: "الطيبون دائماً يلاحظون من يحتاج مساعدة!"
        },
        {
          id: "call_cloud",
          emoji: "🌧️",
          text: "سمعت السحابة نداء وردة وجاءت وأمطرت عليها وعلى كل الحديقة! فرحت كل الزهور والأشجار.",
          isEnding: true, endingKey: "cloud_rain", endingType: "great",
          endingTitle: "صوتك يُسمع حين تطلب المساعدة بصدق!"
        }
      ]
    }
  },

  // ─── MEDIUM (متوسط) ──────────────────────────────────────────────────────────
  {
    title: "الولد الشجاع والتنين",
    description: "ولد صغير يواجه تنيناً يخيف القرية. هل سيكون شجاعاً؟",
    emoji: "🐉",
    level: "medium",
    ageGroup: "6-8",
    pointsReward: 50,
    totalEndings: 4,
    orderIndex: 6,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🏰",
          text: "يوسف الولد الشجاع يسمع أن تنيناً يخيف قريته. الجميع خائف. يوسف يفكر: هل يواجه التنين أم يطلب المساعدة؟",
          choices: [
            { id: "c1a", text: "أذهب لمواجهة التنين وحدي", emoji: "⚔️", type: "adventure", points: 20, nextNodeId: "face_dragon" },
            { id: "c1b", text: "أجمع أهل القرية للمساعدة", emoji: "👥", type: "safe", points: 10, nextNodeId: "gather_help" }
          ]
        },
        {
          id: "face_dragon",
          emoji: "🔥",
          text: "وجد يوسف التنين! لكنه لاحظ أن التنين يبكي. سألته: 'لماذا تبكي؟' قال التنين: 'أنا وحيد ولا أحد يريد الاقتراب مني.'",
          choices: [
            { id: "c2a", text: "أصادق التنين الوحيد", emoji: "🤝", type: "safe", points: 10, nextNodeId: "ending_friend_dragon" },
            { id: "c2b", text: "أطرده من القرية", emoji: "👊", type: "learning", points: 5, nextNodeId: "ending_chase" }
          ]
        },
        {
          id: "gather_help",
          emoji: "🏘️",
          text: "جمع يوسف أهل القرية. معاً ذهبوا للتنين. اكتشفوا أنه يبكي من الوحدة. ماذا يفعلون؟",
          choices: [
            { id: "c3a", text: "ندعوه للعيش بسلام بيننا", emoji: "🏡", type: "adventure", points: 20, nextNodeId: "ending_village_hero" },
            { id: "c3b", text: "نطرده بعيداً", emoji: "🚫", type: "learning", points: 5, nextNodeId: "ending_chase" }
          ]
        },
        {
          id: "ending_friend_dragon",
          emoji: "🌟",
          text: "صار يوسف والتنين أصدقاء! التنين حمى القرية من الأعداء وأصبح بطل القرية الجديد!",
          isEnding: true, endingKey: "friend_dragon", endingType: "great",
          endingTitle: "التعاطف مع الآخرين يحول الأعداء إلى أصدقاء!"
        },
        {
          id: "ending_village_hero",
          emoji: "🏆",
          text: "عاش التنين مع أهل القرية بسلام. أصبح يوسف بطلاً لأنه علّم الجميع أن الحوار أقوى من الخوف!",
          isEnding: true, endingKey: "village_hero", endingType: "great",
          endingTitle: "القائد الحقيقي يجمع الناس ولا يفرقهم!"
        },
        {
          id: "ending_chase",
          emoji: "😔",
          text: "طردوا التنين لكنه عاد بعد أيام أكثر حزناً وخوفاً. أدركوا أن الطرد لم يحل المشكلة. الحل الحقيقي هو الفهم.",
          isEnding: true, endingKey: "chase", endingType: "learning",
          endingTitle: "الخوف لا يُحل بالطرد بل بالتفاهم!"
        }
      ]
    }
  },
  {
    title: "الفتاة والغابة السحرية",
    description: "فتاة تدخل غابة سحرية وتجد مفترق طرق غريب. أي طريق تختار؟",
    emoji: "🌲",
    level: "medium",
    ageGroup: "6-8",
    pointsReward: 50,
    totalEndings: 4,
    orderIndex: 7,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🧚",
          text: "سارة تدخل الغابة السحرية وتجد ثلاثة طرق: طريق الأزهار الملونة، طريق الأشجار العملاقة، وطريق النهر المتلألئ.",
          choices: [
            { id: "c1a", text: "أسلك طريق الأزهار", emoji: "🌺", type: "safe", points: 10, nextNodeId: "flower_path" },
            { id: "c1b", text: "أسلك طريق الأشجار العملاقة", emoji: "🌳", type: "adventure", points: 20, nextNodeId: "tree_path" }
          ]
        },
        {
          id: "flower_path",
          emoji: "🌈",
          text: "الأزهار تتحدث! قالت زهرة: 'إذا أجبتِ على سؤالي، أريكِ كنزاً.' السؤال: ما اسم أكبر كوكب في المجموعة الشمسية؟",
          choices: [
            { id: "c2a", text: "المشتري!", emoji: "🪐", type: "safe", points: 10, nextNodeId: "ending_treasure" },
            { id: "c2b", text: "الشمس!", emoji: "☀️", type: "learning", points: 5, nextNodeId: "ending_try_again" }
          ]
        },
        {
          id: "tree_path",
          emoji: "🦉",
          text: "بومة حكيمة تجلس على شجرة عملاقة. قالت: 'من يتعلم من أخطائه يجد الطريق الصحيح دائماً.' عرضت عليها مهمة.",
          choices: [
            { id: "c3a", text: "أقبل المهمة", emoji: "✅", type: "adventure", points: 20, nextNodeId: "ending_wise_owl" },
            { id: "c3b", text: "أرفض وأعود للبيت", emoji: "🏠", type: "learning", points: 5, nextNodeId: "ending_home" }
          ]
        },
        {
          id: "ending_treasure",
          emoji: "💎",
          text: "أجابت سارة بصواب! وجدت كنزاً من الكتب السحرية التي علّمتها أسرار الغابة. العلم هو أعظم كنز!",
          isEnding: true, endingKey: "treasure", endingType: "great",
          endingTitle: "العلم والمعرفة أثمن من الذهب!"
        },
        {
          id: "ending_wise_owl",
          emoji: "🌟",
          text: "أكملت سارة مهمة البومة وأنقذت الغابة من سحر شرير! صارت حارسة الغابة السحرية إلى الأبد!",
          isEnding: true, endingKey: "wise_owl", endingType: "great",
          endingTitle: "قبول التحديات يصنع الأبطال!"
        },
        {
          id: "ending_try_again",
          emoji: "📚",
          text: "الإجابة خاطئة! قالت الزهرة بلطف: 'الشمس نجم وليست كوكباً. حاولي مرة أخرى بعد التعلم!'",
          isEnding: true, endingKey: "try_again", endingType: "learning",
          endingTitle: "الخطأ فرصة للتعلم، ليس للاستسلام!"
        },
        {
          id: "ending_home",
          emoji: "🏡",
          text: "عادت سارة للبيت بأمان لكنها تساءلت ماذا كانت ستجد لو قبلت المهمة. في اليوم التالي عادت بشجاعة أكبر.",
          isEnding: true, endingKey: "home", endingType: "learning",
          endingTitle: "أحياناً نحتاج وقتاً لنكون مستعدين!"
        }
      ]
    }
  },
  {
    title: "المخترع الصغير",
    description: "طفل يريد اختراع آلة لمساعدة أمه. هل سينجح؟",
    emoji: "🔧",
    level: "medium",
    ageGroup: "6-8",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 8,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "💡",
          text: "كريم يريد اختراع آلة لمساعدة أمه في تنظيف البيت. عنده قطع معدنية وبطارية قديمة. من أين يبدأ؟",
          choices: [
            { id: "c1a", text: "أرسم الفكرة أولاً على ورقة", emoji: "✏️", type: "safe", points: 10, nextNodeId: "draw_plan" },
            { id: "c1b", text: "أبدأ التجميع مباشرة", emoji: "🔨", type: "adventure", points: 20, nextNodeId: "build_direct" }
          ]
        },
        {
          id: "draw_plan",
          emoji: "📐",
          text: "رسم كريم خطة رائعة! لكن يحتاج مساعدة في التوصيلات الكهربائية. يسأل أباه أم يجرب وحده؟",
          choices: [
            { id: "c2a", text: "أطلب مساعدة أبي", emoji: "👨", type: "safe", points: 10, nextNodeId: "ending_dad_help" },
            { id: "c2b", text: "أجرب وحدي", emoji: "⚡", type: "adventure", points: 20, nextNodeId: "ending_genius" }
          ]
        },
        {
          id: "build_direct",
          emoji: "🔌",
          text: "بدأ كريم بدون خطة وتشابكت القطع! أدرك أنه يحتاج تنظيماً. هل يبدأ من جديد بخطة؟",
          choices: [
            { id: "c3a", text: "أبدأ من جديد بخطة منظمة", emoji: "🔄", type: "safe", points: 10, nextNodeId: "ending_restart" },
            { id: "c3b", text: "أكمل رغم الفوضى", emoji: "😤", type: "learning", points: 5, nextNodeId: "ending_chaos" }
          ]
        },
        {
          id: "ending_dad_help",
          emoji: "🌟",
          text: "ساعده أبوه وأنجزا الآلة معاً! أمه فرحت جداً وقالت: 'أنت مخترع رائع يا كريم!'",
          isEnding: true, endingKey: "dad_help", endingType: "great",
          endingTitle: "العمل مع الآخرين يجعل الأحلام حقيقة!"
        },
        {
          id: "ending_genius",
          emoji: "🏆",
          text: "نجح كريم وحده! الآلة تعمل! أمه قالت: 'أنت عبقري حقيقي!' وعرضت مدرسته مشروعه في معرض العلوم.",
          isEnding: true, endingKey: "genius", endingType: "great",
          endingTitle: "الإصرار والتخطيط يصنعان العباقرة!"
        },
        {
          id: "ending_restart",
          emoji: "💪",
          text: "بدأ كريم من جديد بخطة واضحة ونجح! تعلم أن التنظيم والتخطيط أساس كل نجاح.",
          isEnding: true, endingKey: "restart", endingType: "good",
          endingTitle: "البداية من جديد بحكمة أفضل من الاستمرار بفوضى!"
        },
        {
          id: "ending_chaos",
          emoji: "😅",
          text: "الآلة لم تعمل بسبب الفوضى. لكن كريم لم ييأس! في اليوم التالي رسم خطة ونجح.",
          isEnding: true, endingKey: "chaos", endingType: "learning",
          endingTitle: "الفشل درس، والمحاولة مرة أخرى هو الطريق!"
        }
      ]
    }
  },
  {
    title: "رحلة إلى الفضاء",
    description: "طفلة تحلم بالسفر للفضاء. هل ستحقق حلمها؟",
    emoji: "🚀",
    level: "medium",
    ageGroup: "6-8",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 9,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "⭐",
          text: "نورا تحلم بالسفر للفضاء. معلمها قال: 'لتصبحي رائدة فضاء تحتاجين الرياضيات والعلوم.' نورا تفكر: من أين تبدأ؟",
          choices: [
            { id: "c1a", text: "أدرس الرياضيات والعلوم بجد", emoji: "📚", type: "safe", points: 10, nextNodeId: "study_hard" },
            { id: "c1b", text: "أبني صاروخاً من الورق وأجرب", emoji: "✈️", type: "adventure", points: 20, nextNodeId: "build_rocket" }
          ]
        },
        {
          id: "study_hard",
          emoji: "🎓",
          text: "درست نورا بجد لسنوات. حصلت على أعلى الدرجات! الآن أمامها فرصة: مسابقة علمية أو معسكر فضاء.",
          choices: [
            { id: "c2a", text: "أشارك في مسابقة العلوم", emoji: "🏆", type: "safe", points: 10, nextNodeId: "ending_scientist" },
            { id: "c2b", text: "أذهب لمعسكر الفضاء", emoji: "🌌", type: "adventure", points: 20, nextNodeId: "ending_astronaut" }
          ]
        },
        {
          id: "build_rocket",
          emoji: "🛸",
          text: "بنت نورا صاروخاً ورقياً رائعاً! معلمها أعجب بإبداعها وأخبرها عن مسابقة اختراعات للأطفال.",
          choices: [
            { id: "c3a", text: "أشارك في المسابقة", emoji: "🎯", type: "adventure", points: 20, nextNodeId: "ending_inventor" },
            { id: "c3b", text: "أكتفي بالصاروخ الورقي", emoji: "😊", type: "learning", points: 5, nextNodeId: "ending_dream_on" }
          ]
        },
        {
          id: "ending_astronaut",
          emoji: "👩‍🚀",
          text: "في معسكر الفضاء، اختارت وكالة الفضاء نورا لتكون رائدة فضاء مستقبلية! حلمها أصبح حقيقة!",
          isEnding: true, endingKey: "astronaut", endingType: "great",
          endingTitle: "الدراسة والشجاعة يوصلانك للنجوم!"
        },
        {
          id: "ending_scientist",
          emoji: "🔬",
          text: "فازت نورا بالمسابقة واخترعت تلسكوباً صغيراً! صارت عالمة فضاء شهيرة وألّفت كتباً للأطفال.",
          isEnding: true, endingKey: "scientist", endingType: "great",
          endingTitle: "العلم طريق لا نهاية له من الاكتشافات!"
        },
        {
          id: "ending_inventor",
          emoji: "🌟",
          text: "فازت نورا بالمسابقة بصاروخها الورقي المطور! دعتها ناسا لزيارة مركز الفضاء. الإبداع يفتح أبواباً لا تتوقعها!",
          isEnding: true, endingKey: "inventor", endingType: "great",
          endingTitle: "الإبداع والمحاولة يصنعان المستقبل!"
        },
        {
          id: "ending_dream_on",
          emoji: "💭",
          text: "بقيت نورا تحلم فقط. لكن حلمها لم يموت! في اليوم التالي قررت أن تتخذ خطوة حقيقية نحو هدفها.",
          isEnding: true, endingKey: "dream_on", endingType: "learning",
          endingTitle: "الأحلام الجميلة تحتاج خطوات حقيقية!"
        }
      ]
    }
  },
  {
    title: "سر الكنز المخفي",
    description: "خريطة قديمة تقود مجموعة أصدقاء إلى مغامرة لا تُنسى!",
    emoji: "🗺️",
    level: "medium",
    ageGroup: "6-8",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 10,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "📜",
          text: "وجد سامي خريطة قديمة في العلية تشير إلى كنز مخفي! أخبر أصدقاءه. يجب أن يقرروا: هل يذهبون معاً أم يخبرون الكبار أولاً؟",
          choices: [
            { id: "c1a", text: "نخبر الكبار ونذهب معاً", emoji: "👨‍👩‍👧‍👦", type: "safe", points: 10, nextNodeId: "tell_adults" },
            { id: "c1b", text: "نذهب وحدنا للمغامرة!", emoji: "🏃", type: "adventure", points: 20, nextNodeId: "go_alone" }
          ]
        },
        {
          id: "tell_adults",
          emoji: "🧭",
          text: "ذهبوا مع والد سامي. وجدوا المكان! أمام الكنز لغز: 'ما الشيء الذي كلما أخذت منه زاد؟'",
          choices: [
            { id: "c2a", text: "الحفرة!", emoji: "🕳️", type: "safe", points: 10, nextNodeId: "ending_treasure_found" },
            { id: "c2b", text: "العلم!", emoji: "📚", type: "adventure", points: 20, nextNodeId: "ending_wisdom" }
          ]
        },
        {
          id: "go_alone",
          emoji: "🌲",
          text: "ضاعوا في الغابة! لكن سامي تذكر دروس الكشافة. استخدم الشمس للاتجاه ووجدوا الطريق. وصلوا للكنز!",
          choices: [
            { id: "c3a", text: "نفتح الكنز!", emoji: "🔓", type: "adventure", points: 20, nextNodeId: "ending_adventure_treasure" },
            { id: "c3b", text: "نعود ونخبر الكبار أولاً", emoji: "🏠", type: "safe", points: 10, nextNodeId: "ending_treasure_found" }
          ]
        },
        {
          id: "ending_wisdom",
          emoji: "📖",
          text: "الكنز كان مكتبة قديمة مليئة بالكتب النادرة! 'العلم أعظم كنز' قرأوا على اللوحة. تبرعوا بها للمدرسة.",
          isEnding: true, endingKey: "wisdom", endingType: "great",
          endingTitle: "الكنز الحقيقي هو العلم والمعرفة!"
        },
        {
          id: "ending_treasure_found",
          emoji: "💰",
          text: "وجدوا صندوقاً قديماً مليئاً بعملات نادرة! أعطوها للمتحف وصارت قصتهم مشهورة في المدينة.",
          isEnding: true, endingKey: "treasure_found", endingType: "great",
          endingTitle: "الأمانة والتعاون يصنعان قصصاً خالدة!"
        },
        {
          id: "ending_adventure_treasure",
          emoji: "🌟",
          text: "الكنز كان مجموعة ألعاب قديمة نادرة! أكثر شيء أسعدهم هو المغامرة نفسها والذكريات الجميلة.",
          isEnding: true, endingKey: "adventure_treasure", endingType: "good",
          endingTitle: "أحياناً المغامرة نفسها هي الكنز الحقيقي!"
        }
      ]
    }
  },

  // ─── HARD (متقدم) ────────────────────────────────────────────────────────────
  {
    title: "القائد الصغير",
    description: "طفل يُختار قائداً لفريقه في مشروع مدرسي مهم. كيف سيقود؟",
    emoji: "👑",
    level: "hard",
    ageGroup: "8-10",
    pointsReward: 50,
    totalEndings: 4,
    orderIndex: 11,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🏫",
          text: "اختار المعلم عمر قائداً لمشروع العلوم الكبير. الفريق مكون من 5 أطفال ولكل منهم رأي مختلف. كيف يبدأ عمر؟",
          choices: [
            { id: "c1a", text: "أستمع لآراء الجميع وأختار الأفضل", emoji: "👂", type: "safe", points: 10, nextNodeId: "listen_all" },
            { id: "c1b", text: "أقرر وحدي لأنني القائد", emoji: "👆", type: "learning", points: 5, nextNodeId: "decide_alone" },
            { id: "c1c", text: "أقسم المهام حسب مواهب كل شخص", emoji: "🎯", type: "adventure", points: 20, nextNodeId: "delegate_tasks" }
          ]
        },
        {
          id: "listen_all",
          emoji: "💬",
          text: "استمع عمر للجميع وجمع أفضل الأفكار. لكن عضو في الفريق يرفض التعاون ويقول إن فكرته هي الأفضل فقط.",
          choices: [
            { id: "c2a", text: "أتحدث معه بهدوء وأفهم موقفه", emoji: "🤝", type: "safe", points: 10, nextNodeId: "ending_diplomat" },
            { id: "c2b", text: "أتجاهله وأكمل بدونه", emoji: "🚶", type: "learning", points: 5, nextNodeId: "ending_incomplete" }
          ]
        },
        {
          id: "decide_alone",
          emoji: "😤",
          text: "قرر عمر وحده وغضب الفريق! الجميع يشعر أن رأيه لا يُحترم. المشروع يتعثر.",
          choices: [
            { id: "c3a", text: "أعتذر وأبدأ من جديد بالتشاور", emoji: "🙏", type: "safe", points: 10, nextNodeId: "ending_diplomat" },
            { id: "c3b", text: "أكمل وحدي وأثبت أنني على صواب", emoji: "💪", type: "learning", points: 5, nextNodeId: "ending_alone_fail" }
          ]
        },
        {
          id: "delegate_tasks",
          emoji: "⚡",
          text: "قسّم عمر المهام بذكاء! كل شخص يعمل في ما يجيده. المشروع يتقدم بسرعة. لكن يوم التقديم اقترب وهناك جزء ناقص.",
          choices: [
            { id: "c4a", text: "أطلب من الفريق العمل إضافياً", emoji: "⏰", type: "adventure", points: 20, nextNodeId: "ending_champion_leader" },
            { id: "c4b", text: "أقدم المشروع ناقصاً", emoji: "😔", type: "learning", points: 5, nextNodeId: "ending_incomplete" }
          ]
        },
        {
          id: "ending_champion_leader",
          emoji: "🏆",
          text: "عمل الفريق معاً وأكملوا المشروع! فازوا بالمركز الأول. المعلم قال: 'عمر قائد حقيقي يعرف كيف يستخرج أفضل ما في كل شخص!'",
          isEnding: true, endingKey: "champion_leader", endingType: "great",
          endingTitle: "القائد الحقيقي يُعلي من شأن فريقه!"
        },
        {
          id: "ending_diplomat",
          emoji: "🌟",
          text: "تحدث عمر بهدوء مع العضو المتمرد وفهم أنه يشعر بأن أحداً لا يسمعه. أعطاه دوراً مهماً وصار أكثر عضو متحمس!",
          isEnding: true, endingKey: "diplomat", endingType: "great",
          endingTitle: "الاستماع الحقيقي يحل أصعب المشكلات!"
        },
        {
          id: "ending_incomplete",
          emoji: "📝",
          text: "قدموا المشروع ناقصاً وخسروا. لكن المعلم قال: 'الفشل درس. القيادة تعني الاهتمام بكل فرد في الفريق.'",
          isEnding: true, endingKey: "incomplete", endingType: "learning",
          endingTitle: "القيادة مسؤولية وليست سلطة فقط!"
        },
        {
          id: "ending_alone_fail",
          emoji: "😞",
          text: "أكمل عمر وحده لكن المشروع كان ضعيفاً. أدرك أن القوة الحقيقية في الفريق وليس في الفرد.",
          isEnding: true, endingKey: "alone_fail", endingType: "learning",
          endingTitle: "الفريق دائماً أقوى من الفرد!"
        }
      ]
    }
  },
  {
    title: "لغز المدينة المنسية",
    description: "مغامرة في مدينة قديمة مليئة بالألغاز والأسرار التاريخية.",
    emoji: "🏛️",
    level: "hard",
    ageGroup: "8-10",
    pointsReward: 50,
    totalEndings: 4,
    orderIndex: 12,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🔍",
          text: "ليلى وأخوها يكتشفان مدينة قديمة تحت الأرض! هناك ثلاثة أبواب: باب النجوم، باب الأسد، وباب الماء. أيها يختارون؟",
          choices: [
            { id: "c1a", text: "باب النجوم - يبدو علمياً", emoji: "⭐", type: "safe", points: 10, nextNodeId: "star_door" },
            { id: "c1b", text: "باب الأسد - يبدو مثيراً", emoji: "🦁", type: "adventure", points: 20, nextNodeId: "lion_door" }
          ]
        },
        {
          id: "star_door",
          emoji: "🌌",
          text: "وجدوا مرصداً فلكياً قديماً! على الجدار لغز: 'أنا لا أُرى في النهار وأضيء الليل. ما أنا؟' للمضي قدماً يجب الإجابة.",
          choices: [
            { id: "c2a", text: "النجوم!", emoji: "✨", type: "safe", points: 10, nextNodeId: "ending_astronomer" },
            { id: "c2b", text: "القمر!", emoji: "🌙", type: "adventure", points: 20, nextNodeId: "ending_moon_secret" }
          ]
        },
        {
          id: "lion_door",
          emoji: "⚔️",
          text: "وجدوا قاعة المحاربين القدامى! تمثال أسد يسألهم: 'ما أقوى سلاح في العالم؟' يجب الإجابة للمضي.",
          choices: [
            { id: "c3a", text: "السيف!", emoji: "⚔️", type: "learning", points: 5, nextNodeId: "ending_wrong_answer" },
            { id: "c3b", text: "العقل والحكمة!", emoji: "🧠", type: "adventure", points: 20, nextNodeId: "ending_warrior_wisdom" }
          ]
        },
        {
          id: "ending_astronomer",
          emoji: "🌟",
          text: "الإجابة صحيحة! فتح الباب وكشف عن خريطة نجوم قديمة تحدد مواقع مدن مخفية أخرى. ليلى وأخوها صارا مستكشفَين مشهورَين!",
          isEnding: true, endingKey: "astronomer", endingType: "great",
          endingTitle: "العلم والمعرفة يفتحان أبواب المجهول!"
        },
        {
          id: "ending_moon_secret",
          emoji: "💎",
          text: "القمر أيضاً صحيح! وجدوا غرفة سرية بها مخطوطات تاريخية نادرة تروي قصة الحضارة القديمة. أهدياها للمتحف الوطني.",
          isEnding: true, endingKey: "moon_secret", endingType: "great",
          endingTitle: "أحياناً أكثر من إجابة واحدة تكون صحيحة!"
        },
        {
          id: "ending_warrior_wisdom",
          emoji: "🏆",
          text: "أعجب تمثال الأسد بالإجابة! قال: 'الحكمة هي أقوى سلاح عرفته البشرية.' كشف عن كنز معرفي هائل.",
          isEnding: true, endingKey: "warrior_wisdom", endingType: "great",
          endingTitle: "الحكمة تتغلب على القوة دائماً!"
        },
        {
          id: "ending_wrong_answer",
          emoji: "📚",
          text: "الإجابة خاطئة! قال التمثال: 'السيف يكسر، أما العقل فيبني.' أعطاهم فرصة ثانية بعد التفكير.",
          isEnding: true, endingKey: "wrong_answer", endingType: "learning",
          endingTitle: "الأسلحة تدمر، والعقل يبني الحضارات!"
        }
      ]
    }
  },
  {
    title: "المحقق الصغير",
    description: "طفل يحل لغزاً في حيه: من سرق كعكة الجيران؟",
    emoji: "🔎",
    level: "hard",
    ageGroup: "8-10",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 13,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🎂",
          text: "اختفت كعكة الجيران من نافذتهم! الجيران يتهمون القط أو الطفل الجديد في الحي. زياد المحقق الصغير يقرر التحقيق.",
          choices: [
            { id: "c1a", text: "أبحث عن أدلة في المكان أولاً", emoji: "🔍", type: "safe", points: 10, nextNodeId: "search_clues" },
            { id: "c1b", text: "أسأل الشهود في الحي", emoji: "💬", type: "adventure", points: 20, nextNodeId: "ask_witnesses" }
          ]
        },
        {
          id: "search_clues",
          emoji: "👣",
          text: "وجد زياد آثار أقدام صغيرة وفتات كعكة تؤدي إلى الحديقة. وجد أيضاً ريشة طائر. ماذا يستنتج؟",
          choices: [
            { id: "c2a", text: "الطائر أخذ الكعكة!", emoji: "🐦", type: "adventure", points: 20, nextNodeId: "ending_bird_thief" },
            { id: "c2b", text: "أتبع آثار الأقدام", emoji: "👣", type: "safe", points: 10, nextNodeId: "ending_real_thief" }
          ]
        },
        {
          id: "ask_witnesses",
          emoji: "👴",
          text: "قال الجد العجوز: 'رأيت الطفل الجديد يمشي قرب النافذة.' قالت الجارة: 'رأيت طائراً كبيراً يحوم.' من المتهم؟",
          choices: [
            { id: "c3a", text: "الطفل الجديد متهم!", emoji: "👦", type: "learning", points: 5, nextNodeId: "ending_wrong_accusation" },
            { id: "c3b", text: "أجمع المزيد من الأدلة قبل الحكم", emoji: "🧐", type: "safe", points: 10, nextNodeId: "ending_real_thief" }
          ]
        },
        {
          id: "ending_bird_thief",
          emoji: "🐦",
          text: "وجد زياد عش طائر في الشجرة مليئاً بفتات الكعكة! الطائر أخذها لأفراخه. الجيران ضحكوا وقالوا: 'محقق ذكي!'",
          isEnding: true, endingKey: "bird_thief", endingType: "great",
          endingTitle: "الأدلة لا تكذب، الاستنتاج الصحيح يحل اللغز!"
        },
        {
          id: "ending_real_thief",
          emoji: "🌟",
          text: "آثار الأقدام قادته للقط! القط أسقط الكعكة والطائر أخذها. زياد كشف الحقيقة الكاملة وبرّأ الجميع!",
          isEnding: true, endingKey: "real_thief", endingType: "great",
          endingTitle: "المحقق الجيد يجمع كل الأدلة قبل الحكم!"
        },
        {
          id: "ending_wrong_accusation",
          emoji: "😔",
          text: "اتهم زياد الطفل الجديد خطأً! الطفل بكى وأثبت براءته. تعلم زياد: لا تتهم أحداً بدون دليل قاطع.",
          isEnding: true, endingKey: "wrong_accusation", endingType: "learning",
          endingTitle: "الاتهام بدون دليل ظلم. الأدلة أولاً دائماً!"
        }
      ]
    }
  },
  {
    title: "حارس البيئة",
    description: "طفل يكتشف أن مصنعاً يلوث النهر. هل يستطيع إيقافه؟",
    emoji: "🌍",
    level: "hard",
    ageGroup: "8-10",
    pointsReward: 50,
    totalEndings: 4,
    orderIndex: 14,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "🏭",
          text: "لاحظ ماجد أن النهر القريب تغير لونه وماتت بعض الأسماك. يشك في مصنع قريب. ماذا يفعل؟",
          choices: [
            { id: "c1a", text: "أجمع عينات من الماء كدليل", emoji: "🧪", type: "safe", points: 10, nextNodeId: "collect_samples" },
            { id: "c1b", text: "أذهب للمصنع مباشرة وأواجههم", emoji: "🚶", type: "adventure", points: 20, nextNodeId: "confront_factory" }
          ]
        },
        {
          id: "collect_samples",
          emoji: "🔬",
          text: "أخذ ماجد عينات وأرسلها لمعلم العلوم. النتائج أثبتت التلوث! الآن يحتاج إلى خطة عمل.",
          choices: [
            { id: "c2a", text: "أكتب عريضة وأجمع توقيعات الجيران", emoji: "✍️", type: "safe", points: 10, nextNodeId: "ending_petition" },
            { id: "c2b", text: "أتواصل مع وسائل الإعلام", emoji: "📺", type: "adventure", points: 20, nextNodeId: "ending_media_hero" }
          ]
        },
        {
          id: "confront_factory",
          emoji: "🏭",
          text: "ذهب ماجد للمصنع وقابل المدير. المدير قال: 'نحن نتبع القوانين.' لكن ماجد لاحظ أنابيب سرية.",
          choices: [
            { id: "c3a", text: "أصور الأنابيب السرية كدليل", emoji: "📸", type: "adventure", points: 20, nextNodeId: "ending_exposed" },
            { id: "c3b", text: "أصدق المدير وأرجع للبيت", emoji: "🏠", type: "learning", points: 5, nextNodeId: "ending_gave_up" }
          ]
        },
        {
          id: "ending_media_hero",
          emoji: "📺",
          text: "نشرت قناة تلفزيونية قصة ماجد! المصنع أُجبر على تنظيف النهر. ماجد صار رمزاً للناشطين البيئيين الصغار!",
          isEnding: true, endingKey: "media_hero", endingType: "great",
          endingTitle: "الصوت الواحد يمكن أن يغير العالم!"
        },
        {
          id: "ending_petition",
          emoji: "🌿",
          text: "جمع ماجد 200 توقيع! البلدية أوقفت المصنع وأعادت تنظيف النهر. الوحدة قوة والتضامن أقوى!",
          isEnding: true, endingKey: "petition", endingType: "great",
          endingTitle: "معاً نستطيع حماية بيئتنا!"
        },
        {
          id: "ending_exposed",
          emoji: "🏆",
          text: "الصور كانت دليلاً قاطعاً! أُغلق المصنع ونُظّف النهر. ماجد حصل على جائزة حماية البيئة للشباب!",
          isEnding: true, endingKey: "exposed", endingType: "great",
          endingTitle: "الشجاعة والدليل يهزمان الظلم!"
        },
        {
          id: "ending_gave_up",
          emoji: "😔",
          text: "رجع ماجد لكن النهر ازداد تلوثاً. أدرك أنه كان يجب أن يثق بحدسه ويبحث عن الدليل. في اليوم التالي عاد بكاميرا.",
          isEnding: true, endingKey: "gave_up", endingType: "learning",
          endingTitle: "لا تستسلم حين تعرف أن هناك ظلماً!"
        }
      ]
    }
  },
  {
    title: "الفيلسوف الصغير",
    description: "طفل يواجه سؤالاً فلسفياً كبيراً: ما معنى الصداقة الحقيقية؟",
    emoji: "🤔",
    level: "hard",
    ageGroup: "8-10",
    pointsReward: 50,
    totalEndings: 3,
    orderIndex: 15,
    adventureData: {
      startNodeId: "start",
      nodes: [
        {
          id: "start",
          emoji: "💭",
          text: "أمير لديه صديقان: خالد الذي يضحكه دائماً، وسلطان الذي يصدقه دائماً حتى حين يكون مخطئاً. ومن صديق حقيقي؟",
          choices: [
            { id: "c1a", text: "خالد! الصداقة تعني الفرح", emoji: "😄", type: "learning", points: 5, nextNodeId: "fun_friend" },
            { id: "c1b", text: "سلطان! الصداقة تعني الصدق", emoji: "🤝", type: "safe", points: 10, nextNodeId: "honest_friend" },
            { id: "c1c", text: "كلاهما بطريقة مختلفة", emoji: "💡", type: "adventure", points: 20, nextNodeId: "both_friends" }
          ]
        },
        {
          id: "fun_friend",
          emoji: "🎭",
          text: "أمضى أمير وقته مع خالد فقط. لكن حين واجه مشكلة في المدرسة، خالد لم يساعده. أدرك أن الضحك وحده لا يكفي.",
          choices: [
            { id: "c2a", text: "أعيد النظر في معنى الصداقة", emoji: "🔄", type: "safe", points: 10, nextNodeId: "ending_growth" },
            { id: "c2b", text: "أبحث عن أصدقاء جدد", emoji: "👥", type: "adventure", points: 20, nextNodeId: "ending_new_friends" }
          ]
        },
        {
          id: "honest_friend",
          emoji: "🌟",
          text: "سلطان أخبر أميراً بصدق حين أخطأ وساعده على التحسن. أمير أدرك أن الصديق الحقيقي يقول الحق.",
          choices: [
            { id: "c3a", text: "أشكر سلطان وأكون صادقاً معه أيضاً", emoji: "🙏", type: "safe", points: 10, nextNodeId: "ending_true_friendship" },
            { id: "c3b", text: "أغضب من صدقه الجارح", emoji: "😤", type: "learning", points: 5, nextNodeId: "ending_misunderstand" }
          ]
        },
        {
          id: "both_friends",
          emoji: "🌈",
          text: "أمير يفهم أن لكل صداقة قيمتها! خالد يجلب الفرح وسلطان يجلب الصدق. الحياة تحتاج كليهما.",
          isEnding: true, endingKey: "both_friends", endingType: "great",
          endingTitle: "الحكمة هي فهم أن لكل علاقة قيمتها الخاصة!"
        },
        {
          id: "ending_true_friendship",
          emoji: "🏆",
          text: "صار أمير وسلطان أصدقاء حقيقيين يصدقان بعضهما دائماً. الصداقة الحقيقية تقوم على الصدق والاحترام.",
          isEnding: true, endingKey: "true_friendship", endingType: "great",
          endingTitle: "الصداقة الحقيقية تبنى على الصدق والاحترام المتبادل!"
        },
        {
          id: "ending_growth",
          emoji: "🌱",
          text: "أعاد أمير تعريف الصداقة: 'الصديق الحقيقي من يكون معك في الفرح والحزن.' نضج فكره وصار أكثر حكمة.",
          isEnding: true, endingKey: "growth", endingType: "good",
          endingTitle: "النضج يأتي حين نتعلم من تجاربنا!"
        },
        {
          id: "ending_new_friends",
          emoji: "👫",
          text: "وجد أمير أصدقاء جدد يجمعون بين الفرح والصدق. أدرك أن الصداقة المثالية تحتاج كلا الجانبين.",
          isEnding: true, endingKey: "new_friends", endingType: "good",
          endingTitle: "الصديق المثالي يجمع بين الفرح والصدق!"
        },
        {
          id: "ending_misunderstand",
          emoji: "😔",
          text: "ابتعد أمير عن سلطان وندم لاحقاً. الصدق الجارح أحياناً أفضل من الكذب المريح. تعلم أن يقدر الصادقين.",
          isEnding: true, endingKey: "misunderstand", endingType: "learning",
          endingTitle: "الصدق هدية حتى لو كان مؤلماً في البداية!"
        }
      ]
    }
  }
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  // Check if adventures already exist
  const [existing] = await conn.execute("SELECT COUNT(*) as count FROM story_adventures");
  const count = existing[0].count;
  
  if (count > 0) {
    console.log(`Already have ${count} adventures. Skipping seed.`);
    await conn.end();
    return;
  }

  console.log(`Inserting ${adventures.length} adventures...`);
  
  for (const adv of adventures) {
    await conn.execute(
      `INSERT INTO story_adventures (title, description, emoji, level, ageGroup, pointsReward, totalEndings, adventureData, isPublished, orderIndex)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      [
        adv.title,
        adv.description,
        adv.emoji,
        adv.level,
        adv.ageGroup,
        adv.pointsReward,
        adv.totalEndings,
        JSON.stringify(adv.adventureData),
        adv.orderIndex
      ]
    );
    console.log(`✅ Added: ${adv.title}`);
  }
  
  console.log(`\n🎉 Done! Added ${adventures.length} adventures.`);
  await conn.end();
}

main().catch(console.error);
