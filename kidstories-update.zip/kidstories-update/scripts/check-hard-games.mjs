import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const ids = [30042, 30043, 30044, 30046, 30047, 30048, 30068, 30072, 30073, 30069];
for (const id of ids) {
  const [rows] = await conn.execute('SELECT id, title, type, gameData FROM educational_games WHERE id = ?', [id]);
  const r = rows[0];
  const data = r.gameData;
  const keys = Object.keys(data);
  const hasContent = keys.some(k => Array.isArray(data[k]) && data[k].length > 0);
  console.log(`[${r.id}] ${r.title} | type: ${r.type} | keys: ${keys.join(',')} | hasContent: ${hasContent}`);
  if (!hasContent) {
    console.log('  EMPTY DATA:', JSON.stringify(data).substring(0, 150));
  } else {
    // Show first item
    const firstKey = keys.find(k => Array.isArray(data[k]));
    if (firstKey && data[firstKey][0]) {
      console.log('  Sample:', JSON.stringify(data[firstKey][0]).substring(0, 150));
    }
  }
}
await conn.end();
