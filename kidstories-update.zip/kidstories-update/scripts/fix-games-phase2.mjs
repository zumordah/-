import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. إصلاح لعبة "أعرف وطني" (90002) ───────────────────────────────────────
// حذف سؤال مجلس الشورى (index 3) وتعديل سؤال الحج (index 1) وإضافة خط حماية الطفل
{
  const [rows] = await conn.query('SELECT gameData FROM educational_games WHERE id = 90002');
  const gd = rows[0].gameData;
  
  // تعديل سؤال الحج: حذف "رمضان" من الخيارات
  // السؤال الحالي: ["رمضان","الحج","العيد","النوروز"] correct:1
  // نريد: ["الحج","العيد","النوروز","شعبان"] correct:0
  gd.rounds[1] = {
    correct: 0,
    letter: "🕋",
    options: ["الحج", "العيد", "شعبان", "رجب"],
    question: "ما أهم موسم ديني في المملكة؟"
  };
  
  // حذف سؤال مجلس الشورى (index 3)
  gd.rounds.splice(3, 1);
  
  // إضافة سؤال خط حماية الطفل
  gd.rounds.push({
    correct: 2,
    letter: "📞",
    options: ["911", "999", "1١٦١١١", "112"],
    question: "ما رقم خط حماية الطفل في المملكة؟"
  });

  // تصحيح رقم الخط ليكون نصياً صحيحاً
  gd.rounds[gd.rounds.length - 1].options = ["٩١١", "٩٩٩", "١١٦١١١", "١١٢"];
  gd.rounds[gd.rounds.length - 1].correct = 2;
  
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 90002', [JSON.stringify(gd)]);
  console.log('✅ 90002 أعرف وطني: تم تعديل سؤال الحج وحذف مجلس الشورى وإضافة خط حماية الطفل');
  console.log('   الأسئلة الآن:', gd.rounds.length);
}

// ─── 2. إضافة سؤال خط حماية الطفل في لعبة "معلوماتي عن وطني" (90001) أيضاً ───
// (اختياري - نضيفه في 90002 فقط كما طُلب)

await conn.end();
console.log('\n✅ انتهى إصلاح المرحلة الثانية');
