import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
dotenv.config({ path: '/home/ubuntu/kidstories-update/.env' });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// قراءة المغامرة
const [rows] = await conn.execute('SELECT id, adventureData FROM story_adventures WHERE id = 30006');
const r = rows[0];
const data = typeof r.adventureData === 'string' ? JSON.parse(r.adventureData) : r.adventureData;

// تعديل النهاية الحزينة المبالغ فيها
for (const node of data.nodes) {
  if (node.id === 'ending_regret') {
    const oldText = node.text;
    // النهاية الجديدة: حزينة وتربوية بدون وفاة
    node.text = 'لاحقاً عرف زياد أن المال كان لعلاج طفلة مريضة، وبسبب التأخير ازداد مرضها وأمضت أسابيع في المستشفى. أبوها كان يبكي في الشارع. زياد شعر بثقل كبير في قلبه وقال لنفسه: "كان بإمكاني أن أساعد وما فعلت." الضمير لا يكذب!';
    console.log('Updated ending_regret:');
    console.log('OLD:', oldText);
    console.log('NEW:', node.text);
  }
}

// حفظ التعديل
await conn.execute(
  'UPDATE story_adventures SET adventureData = ? WHERE id = 30006',
  [JSON.stringify(data)]
);

console.log('\n✅ Updated successfully!');
await conn.end();
