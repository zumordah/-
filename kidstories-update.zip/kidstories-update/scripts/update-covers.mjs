import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// صورة غلاف "محبة الوطن" (id: 60017) - المستوى المتوسط
const watanCover = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/cover-67Xgfuw4KZ8ZsaVJhJWH2P.webp';

// صورة غلاف "عالم البركة" (id: 90017) - المستوى المتقدم
const barakaCover = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/cover-DSQ9DbqATmRRnsMsy9fv22.webp';

// تحديث صورة الغلاف لقصة "محبة الوطن"
const [r1] = await conn.execute(
  'UPDATE stories SET coverImage = ? WHERE id = 60017',
  [watanCover]
);
console.log('محبة الوطن cover updated:', r1.affectedRows, 'rows');

// تحديث صورة الغلاف لقصة "عالم البركة"
const [r2] = await conn.execute(
  'UPDATE stories SET coverImage = ? WHERE id = 90017',
  [barakaCover]
);
console.log('عالم البركة cover updated:', r2.affectedRows, 'rows');

// التحقق من النتيجة
const [rows] = await conn.execute(
  'SELECT id, title, coverImage FROM stories WHERE id IN (60017, 90017)'
);
console.log('Updated stories:');
rows.forEach(r => console.log(`  [${r.id}] ${r.title}: ${r.coverImage?.substring(0, 60)}...`));

await conn.end();
console.log('✅ Done!');
