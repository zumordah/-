import { readFileSync } from 'fs';
const content = readFileSync('server/db.ts', 'utf8');
const lines = content.split('\n');
// Look for lines where a function definition is missing closing brace before another export async function
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  // Find lines that have 'async' but are not properly starting a function
  if (line.includes('eexport') || line.includes('export export')) {
    console.log('DUPLICATE EXPORT Line ' + (i+1) + ': ' + line);
  }
}
// Check for missing semicolons or syntax issues around line 964
console.log('\n--- Context around line 960-975 ---');
for (let i = 959; i < 975; i++) {
  console.log('Line ' + (i+1) + ': ' + lines[i]);
}
