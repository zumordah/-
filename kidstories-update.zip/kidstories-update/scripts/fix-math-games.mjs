import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── المبتدئ: حذف 60003 و60004 (مكررتان تماماً مع 60001 و60002) ───────────────
await conn.query('DELETE FROM child_game_progress WHERE gameId IN (60003, 60004)');
await conn.query('DELETE FROM educational_games WHERE id IN (60003, 60004)');
console.log('✅ حذف 60003 و60004 (مكررتان مع 60001 و60002)');

// ─── المبتدئ: تحديث 30032 ليكون أرقاماً صغيرة جداً (1-5) بأسلوب مرئي ──────────
{
  const gd = {
    instructions: "احسب الجمع والطرح!",
    rounds: [
      { correct: 1, emoji: "🍎", options: [1, 2, 3, 4], question: "١ + ١ = ؟" },
      { correct: 2, emoji: "🍊", options: [1, 2, 3, 4], question: "٢ + ١ = ؟" },
      { correct: 1, emoji: "🌟", options: [1, 2, 3, 4], question: "٣ - ١ = ؟" },
      { correct: 3, emoji: "🎈", options: [1, 2, 3, 4], question: "٢ + ٢ = ؟" },
      { correct: 2, emoji: "🐥", options: [1, 2, 3, 4], question: "٤ - ١ = ؟" },
      { correct: 2, emoji: "🍓", options: [1, 2, 3, 4], question: "١ + ٢ = ؟" },
      { correct: 0, emoji: "🌸", options: [2, 3, 4, 5], question: "٥ - ٣ = ؟" },
      { correct: 3, emoji: "🦋", options: [1, 2, 3, 4], question: "١ + ٣ = ؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 30032', [JSON.stringify(gd)]);
  console.log('✅ 30032 جمع وطرح سهل: تحديث بأرقام صغيرة متنوعة');
}

// ─── المبتدئ: تحديث 60001 بأرقام مختلفة عن 30032 ──────────────────────────────
{
  const gd = {
    instructions: "احسب الطرح!",
    rounds: [
      { correct: 2, emoji: "🍎", options: ["١", "٢", "٣", "٤"], question: "٥ - ٢ = ؟" },
      { correct: 2, emoji: "🍊", options: ["١", "٢", "٣", "٤"], question: "٤ - ١ = ؟" },
      { correct: 2, emoji: "🍋", options: ["١", "٢", "٣", "٤"], question: "٦ - ٣ = ؟" },
      { correct: 1, emoji: "🍇", options: ["١", "٢", "٣", "٤"], question: "٣ - ١ = ؟" },
      { correct: 2, emoji: "🍓", options: ["١", "٢", "٣", "٤"], question: "٧ - ٤ = ؟" },
      { correct: 1, emoji: "🥝", options: ["١", "٢", "٣", "٤"], question: "٥ - ٣ = ؟" },
      { correct: 2, emoji: "🍑", options: ["١", "٢", "٣", "٤"], question: "٨ - ٥ = ؟" },
      { correct: 2, emoji: "🍒", options: ["٢", "٣", "٤", "٥"], question: "٦ - ٢ = ؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 60001', [JSON.stringify(gd)]);
  console.log('✅ 60001 طرح الأرقام الصغيرة: تحديث بأرقام عربية');
}

// ─── المتوسط: إصلاح 30040 (جمع وطرح متوسط) بأرقام 10-30 غير مكررة ─────────────
{
  const gd = {
    instructions: "احسب الجمع والطرح!",
    rounds: [
      { correct: 1, emoji: "🔢", options: ["١٢", "١٤", "١٦", "١٨"], question: "٧ + ٧ = ؟" },
      { correct: 2, emoji: "🔢", options: ["٨", "٩", "١٠", "١١"], question: "١٦ - ٦ = ؟" },
      { correct: 0, emoji: "🔢", options: ["٢٠", "٢٢", "٢٤", "٢٦"], question: "١٢ + ٨ = ؟" },
      { correct: 1, emoji: "🔢", options: ["١١", "١٣", "١٥", "١٧"], question: "٢٠ - ٧ = ؟" },
      { correct: 2, emoji: "🔢", options: ["١٤", "١٦", "١٨", "٢٠"], question: "٩ + ٩ = ؟" },
      { correct: 1, emoji: "🔢", options: ["١٠", "١٢", "١٤", "١٦"], question: "٢٥ - ١٣ = ؟" },
      { correct: 0, emoji: "🔢", options: ["٢٧", "٢٩", "٣١", "٣٣"], question: "١٥ + ١٢ = ؟" },
      { correct: 2, emoji: "🔢", options: ["١٣", "١٤", "١٥", "١٦"], question: "٢٢ - ٧ = ؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 30040', [JSON.stringify(gd)]);
  console.log('✅ 30040 جمع وطرح متوسط: تحديث بأرقام 7-25');
}

// ─── المتوسط: إصلاح 30061 (ألعاب الطرح المتوسط) بأرقام مختلفة ──────────────────
{
  const gd = {
    instructions: "احسب الطرح!",
    rounds: [
      { correct: 1, options: ["٤", "٥", "٦", "٧"], question: "١٤ - ٩ = ؟" },
      { correct: 0, options: ["٨", "٩", "١٠", "١١"], question: "١٧ - ٩ = ؟" },
      { correct: 2, options: ["٩", "١٠", "١١", "١٢"], question: "٢٣ - ١٢ = ؟" },
      { correct: 1, options: ["١١", "١٢", "١٣", "١٤"], question: "٢٨ - ١٦ = ؟" },
      { correct: 2, options: ["٦", "٧", "٨", "٩"], question: "١٩ - ١١ = ؟" },
      { correct: 0, options: ["١٤", "١٥", "١٦", "١٧"], question: "٣٠ - ١٦ = ؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 30061', [JSON.stringify(gd)]);
  console.log('✅ 30061 ألعاب الطرح المتوسط: تحديث بأرقام 14-30');
}

// ─── المتوسط: إصلاح 60005 (طرح الأرقام المتوسطة) بأرقام مختلفة ─────────────────
{
  const gd = {
    instructions: "احسب الطرح!",
    rounds: [
      { correct: 1, emoji: "🔢", options: ["١٠", "١١", "١٢", "١٣"], question: "٢٠ - ٩ = ؟" },
      { correct: 2, emoji: "🔢", options: ["١٢", "١٣", "١٤", "١٥"], question: "٢٥ - ١١ = ؟" },
      { correct: 0, emoji: "🔢", options: ["١٦", "١٧", "١٨", "١٩"], question: "٢٦ - ١٠ = ؟" },
      { correct: 1, emoji: "🔢", options: ["١٣", "١٤", "١٥", "١٦"], question: "٢٩ - ١٥ = ؟" },
      { correct: 2, emoji: "🔢", options: ["٩", "١٠", "١١", "١٢"], question: "٢١ - ١٠ = ؟" },
      { correct: 0, emoji: "🔢", options: ["١٥", "١٦", "١٧", "١٨"], question: "٢٤ - ٩ = ؟" },
      { correct: 1, emoji: "🔢", options: ["١٢", "١٣", "١٤", "١٥"], question: "٢٧ - ١٤ = ؟" },
      { correct: 2, emoji: "🔢", options: ["١٠", "١١", "١٢", "١٣"], question: "٢٢ - ١٠ = ؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 60005', [JSON.stringify(gd)]);
  console.log('✅ 60005 طرح الأرقام المتوسطة: تحديث بأرقام 20-30 مختلفة');
}

// ─── المتقدم: إصلاح 60006 (طرح المتقدم) بأرقام كبيرة حقيقية ──────────────────
{
  const gd = {
    instructions: "احسب الطرح!",
    rounds: [
      { correct: 2, letter: "٤٥ - ١٨", options: ["٢٤", "٢٦", "٢٧", "٢٨"], question: "ما ناتج الطرح؟" },
      { correct: 1, letter: "٦٠ - ٢٤", options: ["٣٤", "٣٦", "٣٨", "٤٠"], question: "ما ناتج الطرح؟" },
      { correct: 0, letter: "٧٢ - ٣٥", options: ["٣٧", "٣٩", "٤١", "٤٣"], question: "ما ناتج الطرح؟" },
      { correct: 2, letter: "٨٠ - ٤٣", options: ["٣٥", "٣٦", "٣٧", "٣٨"], question: "ما ناتج الطرح؟" },
      { correct: 1, letter: "٩٥ - ٤٨", options: ["٤٥", "٤٧", "٤٩", "٥١"], question: "ما ناتج الطرح؟" },
      { correct: 0, letter: "١٠٠ - ٦٣", options: ["٣٧", "٣٩", "٤١", "٤٣"], question: "ما ناتج الطرح؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 60006', [JSON.stringify(gd)]);
  console.log('✅ 60006 طرح المتقدم: تحديث بأرقام 45-100');
}

// ─── المتقدم: إصلاح 60007 (جمع الأرقام الكبيرة) بأرقام أكبر ──────────────────
{
  const gd = {
    instructions: "احسب الجمع!",
    rounds: [
      { correct: 1, letter: "٣٥ + ٢٨", options: ["٦٠", "٦٣", "٦٦", "٦٩"], question: "ما ناتج الجمع؟" },
      { correct: 2, letter: "٤٧ + ٣٦", options: ["٧٩", "٨١", "٨٣", "٨٥"], question: "ما ناتج الجمع؟" },
      { correct: 0, letter: "٥٢ + ٤٩", options: ["١٠١", "١٠٣", "١٠٥", "١٠٧"], question: "ما ناتج الجمع؟" },
      { correct: 1, letter: "٦٤ + ٢٧", options: ["٨٨", "٩١", "٩٤", "٩٧"], question: "ما ناتج الجمع؟" },
      { correct: 2, letter: "٧٣ + ١٨", options: ["٨٧", "٨٩", "٩١", "٩٣"], question: "ما ناتج الجمع؟" },
      { correct: 0, letter: "٨٦ + ١٤", options: ["١٠٠", "١٠٢", "١٠٤", "١٠٦"], question: "ما ناتج الجمع؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 60007', [JSON.stringify(gd)]);
  console.log('✅ 60007 جمع الأرقام الكبيرة: تحديث بأرقام 35-100');
}

// ─── المتقدم: إصلاح 30047 (جمع وطرح متقدم) بأرقام مختلفة عن 60006/60007 ──────
{
  const gd = {
    instructions: "احسب الجمع والطرح!",
    rounds: [
      { correct: 1, letter: "٢٣ + ١٩", options: ["٣٩", "٤٢", "٤٥", "٤٨"], question: "ما ناتج الجمع؟" },
      { correct: 2, letter: "٥٤ - ٢٧", options: ["٢٤", "٢٦", "٢٧", "٢٨"], question: "ما ناتج الطرح؟" },
      { correct: 0, letter: "٣٨ + ٢٤", options: ["٦٢", "٦٤", "٦٦", "٦٨"], question: "ما ناتج الجمع؟" },
      { correct: 1, letter: "٧٥ - ٣٨", options: ["٣٥", "٣٧", "٣٩", "٤١"], question: "ما ناتج الطرح؟" },
      { correct: 2, letter: "٤٦ + ٣٣", options: ["٧٥", "٧٧", "٧٩", "٨١"], question: "ما ناتج الجمع؟" },
      { correct: 1, letter: "٩٠ - ٤٦", options: ["٤٢", "٤٤", "٤٦", "٤٨"], question: "ما ناتج الطرح؟" },
      { correct: 0, letter: "٥٧ + ٢٦", options: ["٨٣", "٨٥", "٨٧", "٨٩"], question: "ما ناتج الجمع؟" },
      { correct: 2, letter: "٨٤ - ٤٩", options: ["٣٢", "٣٤", "٣٥", "٣٦"], question: "ما ناتج الطرح؟" },
    ]
  };
  await conn.query('UPDATE educational_games SET gameData = ? WHERE id = 30047', [JSON.stringify(gd)]);
  console.log('✅ 30047 جمع وطرح متقدم: تحديث بأرقام 23-90 متنوعة');
}

await conn.end();
console.log('\n✅ انتهى إصلاح ألعاب الجمع والطرح');
