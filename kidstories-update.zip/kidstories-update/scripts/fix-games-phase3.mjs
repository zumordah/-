import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 1. تحديث أسئلة لعبة المملكة المتقدم (id=90003)
const kingdomHardData = {
  instructions: "اختر الإجابة الصحيحة عن المملكة العربية السعودية",
  rounds: [
    {
      question: "ما عملة المملكة العربية السعودية؟",
      options: ["الدرهم", "الريال السعودي", "الدينار", "الجنيه"],
      correct: 1
    },
    {
      question: "من هو ولي العهد الأمير محمد بن سلمان؟",
      options: ["رئيس الوزراء", "ولي العهد ورئيس مجلس الوزراء", "وزير الدفاع فقط", "الملك"],
      correct: 1
    },
    {
      question: "ما رقم الشرطة في المملكة العربية السعودية؟",
      options: ["911", "999", "998", "112"],
      correct: 2
    },
    {
      question: "ما معنى كلمة 'السعودية'؟",
      options: ["نسبة إلى الملك عبدالعزيز آل سعود", "اسم مدينة قديمة", "كلمة عربية تعني الجمال", "نسبة إلى جبل السعد"],
      correct: 0
    },
    {
      question: "ما نسبة مساحة المملكة من مساحة شبه الجزيرة العربية تقريباً؟",
      options: ["٢٥٪", "٤٠٪", "٨٠٪", "٦٠٪"],
      correct: 2
    },
    {
      question: "ما رقم الإسعاف في المملكة العربية السعودية؟",
      options: ["997", "911", "999", "112"],
      correct: 0
    },
    {
      question: "ما رقم الدفاع المدني (الإطفاء) في المملكة؟",
      options: ["997", "998", "911", "999"],
      correct: 1
    },
    {
      question: "ما عاصمة المملكة العربية السعودية؟",
      options: ["جدة", "مكة المكرمة", "الرياض", "المدينة المنورة"],
      correct: 2
    }
  ]
};

await conn.execute(
  'UPDATE educational_games SET gameData = ? WHERE id = 90003',
  [JSON.stringify(kingdomHardData)]
);
console.log('✅ تم تحديث أسئلة لعبة المملكة المتقدم (90003)');

// 2. نقل لعبة أعلام الدول العربية من hard إلى medium (id=90005)
await conn.execute(
  "UPDATE educational_games SET level = 'medium' WHERE id = 90005",
  []
);
console.log('✅ تم نقل لعبة أعلام الدول العربية إلى المتوسط');

// 3. إضافة لعبة أعلام دول العالم للمتقدم
const worldFlagsData = {
  instructions: "تعرّف على أعلام دول العالم الكبرى",
  questions: [
    {
      question: "ما علم الولايات المتحدة الأمريكية؟",
      image: "🇺🇸",
      options: ["🇬🇧 بريطانيا", "🇺🇸 أمريكا", "🇦🇺 أستراليا", "🇳🇿 نيوزيلندا"],
      correct: 1
    },
    {
      question: "ما علم المملكة المتحدة (بريطانيا)؟",
      image: "🇬🇧",
      options: ["🇫🇷 فرنسا", "🇳🇱 هولندا", "🇬🇧 بريطانيا", "🇩🇰 الدنمارك"],
      correct: 2
    },
    {
      question: "ما علم تركيا؟",
      image: "🇹🇷",
      options: ["🇹🇳 تونس", "🇵🇰 باكستان", "🇹🇷 تركيا", "🇦🇿 أذربيجان"],
      correct: 2
    },
    {
      question: "ما علم الصين؟",
      image: "🇨🇳",
      options: ["🇯🇵 اليابان", "🇰🇷 كوريا", "🇻🇳 فيتنام", "🇨🇳 الصين"],
      correct: 3
    },
    {
      question: "ما علم فرنسا؟",
      image: "🇫🇷",
      options: ["🇫🇷 فرنسا", "🇮🇹 إيطاليا", "🇧🇪 بلجيكا", "🇱🇺 لوكسمبورغ"],
      correct: 0
    },
    {
      question: "ما علم ألمانيا؟",
      image: "🇩🇪",
      options: ["🇦🇹 النمسا", "🇧🇪 بلجيكا", "🇩🇪 ألمانيا", "🇨🇭 سويسرا"],
      correct: 2
    },
    {
      question: "ما علم اليابان؟",
      image: "🇯🇵",
      options: ["🇨🇳 الصين", "🇯🇵 اليابان", "🇰🇷 كوريا", "🇸🇬 سنغافورة"],
      correct: 1
    },
    {
      question: "ما علم البرازيل؟",
      image: "🇧🇷",
      options: ["🇦🇷 الأرجنتين", "🇲🇽 المكسيك", "🇧🇷 البرازيل", "🇨🇴 كولومبيا"],
      correct: 2
    }
  ]
};

// التحقق من وجود اللعبة أولاً
const [existing] = await conn.execute(
  "SELECT id FROM educational_games WHERE title LIKE '%أعلام دول العالم%' AND level = 'hard'",
  []
);

if (existing.length === 0) {
  await conn.execute(
    `INSERT INTO educational_games (title, description, type, level, ageGroup, emoji, pointsReward, gameData, isPublished, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())`,
    [
      'أعلام دول العالم 🌍',
      'تعرّف على أعلام الدول الكبرى في العالم',
      'image_match',
      'hard',
      'all',
      '🌍',
      30,
      JSON.stringify(worldFlagsData)
    ]
  );
  console.log('✅ تم إضافة لعبة أعلام دول العالم للمتقدم');
} else {
  console.log('ℹ️ لعبة أعلام دول العالم موجودة مسبقاً');
}

await conn.end();
console.log('✅ اكتملت جميع التحديثات');
