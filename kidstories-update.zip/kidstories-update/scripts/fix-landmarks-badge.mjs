import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. تحديث لعبة معالم وطني (70021) بصور حقيقية ───────────────────────────
{
  const KAABA = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kaaba_802d7ef3.jpg';
  const ABRAJ = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/abraj-albait_95066db3.jpg';
  const KINGDOM = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/kingdom-tower_481ed6f1.jpg';
  const DIRIYAH = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/diriyah_772f2750.jpg';
  const HEGRA = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/hegra_1d516ea1.jpg';

  const gd = {
    instructions: "انظر إلى الصورة واختر الاسم الصحيح للمعلم السعودي!",
    questions: [
      {
        correct: 0,
        image: KAABA,
        options: ["الكعبة المشرفة", "المسجد النبوي", "المسجد الأقصى", "مسجد قباء"],
        question: "ما اسم هذا المعلم المقدس؟"
      },
      {
        correct: 1,
        image: ABRAJ,
        options: ["برج المملكة", "أبراج البيت", "برج الفيصلية", "برج خليفة"],
        question: "ما اسم هذا البرج الشهير في مكة؟"
      },
      {
        correct: 0,
        image: KINGDOM,
        options: ["برج المملكة", "برج الفيصلية", "أبراج البيت", "برج الرياض"],
        question: "ما اسم هذا البرج في الرياض؟"
      },
      {
        correct: 2,
        image: DIRIYAH,
        options: ["العُلا", "مدائن صالح", "الدرعية", "جدة التاريخية"],
        question: "ما اسم هذه المنطقة التاريخية التراثية؟"
      },
      {
        correct: 1,
        image: HEGRA,
        options: ["الدرعية", "مدائن صالح (الحِجر)", "العُلا", "تيماء"],
        question: "ما اسم هذا الموقع الأثري القديم؟"
      },
      {
        correct: 0,
        image: KAABA,
        options: ["مكة المكرمة", "المدينة المنورة", "الطائف", "جدة"],
        question: "في أي مدينة توجد الكعبة المشرفة؟"
      },
      {
        correct: 2,
        image: KINGDOM,
        options: ["مكة", "جدة", "الرياض", "الدمام"],
        question: "في أي مدينة يقع برج المملكة؟"
      },
      {
        correct: 1,
        image: DIRIYAH,
        options: ["جدة", "الرياض", "الدمام", "الطائف"],
        question: "في أي مدينة تقع الدرعية التاريخية؟"
      }
    ]
  };

  await conn.query('UPDATE educational_games SET gameData = ?, title = ?, description = ? WHERE id = 70021',
    [JSON.stringify(gd), 'معالم وطني 🏛️', 'تعرّف على المعالم السعودية من خلال الصور الحقيقية']);
  console.log('✅ 70021 معالم وطني: تم التحديث بصور حقيقية (8 أسئلة)');
}

// ─── 2. إضافة شارة "مستكشف الوطن" ─────────────────────────────────────────────
// البنية: key, title, description, emoji, condition, conditionValue, pointsReward
{
  const [existing] = await conn.query("SELECT id FROM achievements WHERE `key` = 'explorer_watan'");
  if (existing.length === 0) {
    // conditionValue يخزن JSON كـ integer - نحتاج نعدّل البنية
    // نستخدم condition='complete_specific_games' وconditionValue=2 (عدد الألعاب)
    // ونضيف حقل metadata لاحقاً، أو نستخدم description لتخزين IDs
    // الحل: نضيف الشارة بـ condition خاص ونتحقق منه في db.ts
    await conn.query(`INSERT INTO achievements 
      (\`key\`, title, description, emoji, \`condition\`, conditionValue, pointsReward)
      VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        'explorer_watan',
        'مستكشف الوطن',
        'أتممت لعبتَي التراث السعودي ومعالم وطني | gameIds:90006,70021',
        '🗺️',
        'complete_specific_games',
        2,
        100
      ]);
    console.log('✅ تم إضافة شارة "مستكشف الوطن" (explorer_watan)');
  } else {
    console.log('ℹ️ شارة "مستكشف الوطن" موجودة بالفعل');
  }
}

await conn.end();
console.log('\n✅ انتهى تحديث المعالم والشارة');
