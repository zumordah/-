import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
dotenv.config({ path: '/home/ubuntu/kidstories-update/.env' });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// كلمات تدل على مبالغة
const badKeywords = ['مات', 'ماتت', 'وفاة', 'توفي', 'توفيت', 'قتل', 'قُتل', 'دمر', 'دمّر', 'انتحر', 'ينتحر'];

const [rows] = await conn.execute('SELECT id, title, level, adventureData FROM story_adventures ORDER BY level, id');

let found = false;
for (const r of rows) {
  const data = typeof r.adventureData === 'string' ? JSON.parse(r.adventureData) : r.adventureData;
  const nodes = data.nodes || [];
  
  for (const node of nodes) {
    const hasChoices = node.choices && node.choices.length > 0;
    if (!hasChoices && node.text) {
      for (const kw of badKeywords) {
        if (node.text.includes(kw)) {
          console.log(`\n⚠️  ID: ${r.id} | ${r.level} | ${r.title}`);
          console.log(`   Node: ${node.id}`);
          console.log(`   Text: ${node.text}`);
          found = true;
          break;
        }
      }
    }
  }
}

if (!found) {
  console.log('✅ لا توجد نهايات مبالغ فيها في أي مغامرة!');
}

await conn.end();
