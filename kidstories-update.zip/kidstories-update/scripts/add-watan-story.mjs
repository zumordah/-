import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
dotenv.config({ path: '/home/ubuntu/kidstories-update/.env' });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// CDN URLs للصور (compressed webp)
const images = {
  1: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page1-T6jTktCq7BCuf9QnXMht5P.webp',
  2: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page2-GxHdQwtzwCNTx7ceENoxoy.webp',
  3: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page3-Mo3ihmwMzBPC8kHUYnmE4y.webp',
  4: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page4-mPAzBzHFJThesLgHjWxogw.webp',
  5: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page5-SismcpfTepb7GEfUrKUxbT.webp',
  6: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page6-aLNqKRFYFZbmm7n4iqeJtP.webp',
  7: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page7-c7zr9qD2c3QcXJbP9yQVJ8.webp',
  8: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page8-YQpe6URWXnt5tDUH7GBeNU.webp',
  9: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page9-g6KCWcgobzC4krxKD3wcfU.webp',
  10: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/page10-2dSAT9MppRFZoxtbdVDc2i.webp',
};

// CDN URLs للصوت
const audios = {
  1: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio1_474780ce.wav',
  2: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio2_54ab707c.wav',
  3: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio3_63554bc2.wav',
  4: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio4_ecabf88f.wav',
  5: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio5_fcf0eea1.wav',
  6: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio6_d4bc34c9.wav',
  7: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio7_e417ee53.wav',
  8: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio8_953936db.wav',
  9: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio9_a305fe22.wav',
  10: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544141140/92pLgnvstqxt4C3g5hVjXC/audio10_090acc01.wav',
};

const pages = [
  {
    pageNumber: 1,
    text: 'كَانَ هُنَاكَ وَلَدٌ اسْمُهُ مُحَمَّدٌ. كَانَ مُحَمَّدٌ يُحِبُّ وَطَنَهُ المَمْلَكَةَ العَرَبِيَّةَ السَّعُودِيَّةَ، وَكَانَ دَائِمًا يَفْتَخِرُ بِهَا. كُلَّمَا تَحَدَّثَ مَعَ أَصْدِقَائِهِ، كَانَ يَذْكُرُ كَيْفَ أَنَّ المَمْلَكَةَ جَمِيلَةٌ وَعَظِيمَةٌ.',
    imageUrl: images[1],
    audioUrl: audios[1],
  },
  {
    pageNumber: 2,
    text: 'فِي يَوْمٍ مِنَ الأَيَّامِ، ذَهَبَ مُحَمَّدٌ إِلَى المَدْرَسَةِ. وَهُوَ فِي الطَّرِيقِ، بَدَأَ يَتَحَدَّثُ عَنْ عَلَمِ المَمْلَكَةِ. قَالَ مُحَمَّدٌ: "عَلَمُنا هُوَ رَمْزُ الفَخْرِ، فِيهِ الأَخْضَرُ الَّذِي يَعْبُرُ عَنْ سَلاَمَتِنَا، وَالسَّيْفُ الَّذِي يَدُلُّ عَلَى قُوَّتِنَا."',
    imageUrl: images[2],
    audioUrl: audios[2],
  },
  {
    pageNumber: 3,
    text: 'فَجْأَةً، سَأَلَ أَصْدِقَاؤُهُ: "لِمَاذَا نُحِبُّ وَطَنَنَا؟" أَجَابَ مُحَمَّدٌ بِاِبْتِسَامَةٍ: "نُحِبُّ وَطَنَنَا لِأَنَّهُ يُعْطِينَا الأَمَانَ، وَالتَّعْلِيمَ، وَالمُسْتَقْبَلَ الجَمِيلَ."',
    imageUrl: images[3],
    audioUrl: audios[3],
  },
  {
    pageNumber: 4,
    text: 'بَعْدَ قَلِيلٍ، جَلَسُوا فِي سَاحَةِ المَدْرَسَةِ. وَكَانَ هُنَاكَ عَلَمُ المَمْلَكَةِ يَرْفُرُفُ فَوْقَ المَبْنَى. قَالَتْ سَارَةُ: "أَنَا أَيْضًا أُحِبُّ وَطَنِي! أُمِّي تَقُولُ دَائِمًا أَنَّ السَّعُودِيَّةَ مِنْ أَقْوَى الدُّوَلِ."',
    imageUrl: images[4],
    audioUrl: audios[4],
  },
  {
    pageNumber: 5,
    text: 'بَيْنَمَا كَانَ الطُّلَّابُ يَتَحَدَّثُونَ، دَخَلَ المُعَلِّمُ وَكَانَ يَحْمِلُ كِتَابًا عَنْ تَارِيخِ المَمْلَكَةِ. قَالَ المُعَلِّمُ: "هَلْ تَعْرِفُونَ مَتَى تَأَسَّسَتِ المَمْلَكَةُ؟ تَأَسَّسَتْ فِي 23 سِبْتَمْبَرَ 1932م عَلَى يَدِ المَلِكِ عَبْدِ العَزِيزِ رَحِمَهُ اللهُ."',
    imageUrl: images[5],
    audioUrl: audios[5],
  },
  {
    pageNumber: 6,
    text: 'قَالَ مُحَمَّدٌ: "أَنَا أُحِبُّ المَلِكَ عَبْدَ العَزِيزِ، لِأَنَّهُ أَسَّسَ وَطَنَنَا وَأَعْطَانَا الأَمَانَ وَالِاسْتِقْرَارَ." أَجَابَ المُعَلِّمُ: "نَعَمْ، هُوَ الَّذِي وَحَّدَ المَمْلَكَةَ وَأَعْطَاهَا القُوَّةَ وَالعِزَّ."',
    imageUrl: images[6],
    audioUrl: audios[6],
  },
  {
    pageNumber: 7,
    text: 'ثُمَّ أَخْبَرَ المُعَلِّمُ الطُّلَّابَ عَنْ مَدِينَةِ الرِّيَاضِ وَكَيْفَ تَطَوَّرَتْ حَتَّى أَصْبَحَتْ عَاصِمَةً لِلْمَمْلَكَةِ. قَالَ مُحَمَّدٌ: "أَنَا أُحِبُّ الرِّيَاضَ، فَهِيَ تَجْمَعُ بَيْنَ الأَصَالَةِ وَالتَّطَوُّرِ، وَفِيهَا أَكْبَرُ المَشَارِيعِ. كَمَا أَنَّ رُؤْيَةَ المَمْلَكَةِ 2030 تَجْعَلُنَا أَكْثَرَ تَطَوُّرًا فِي المُسْتَقْبَلِ."',
    imageUrl: images[7],
    audioUrl: audios[7],
  },
  {
    pageNumber: 8,
    text: 'قَالَ عَلِيٌّ: "هَلْ يُمْكِنُنِي أَنْ أَزُورَ مَكَّةَ وَالْمَدِينَةَ؟" أَجَابَ المُعَلِّمُ: "بِالطَّبْعِ! مَكَّةُ المَكْرَمَةِ وَالْمَدِينَةُ المُنَوَّرَةُ هُمَا مَكَانَانِ مُقَدَّسَانِ، حَيْثُ يَتَوَجَّهُ المُسْلِمُونَ مِنْ جَمِيعِ أَنْحَاءِ العَالَمِ لِأَدَاءِ مَنَاسِكِ الحَجِّ."',
    imageUrl: images[8],
    audioUrl: audios[8],
  },
  {
    pageNumber: 9,
    text: 'قَالَ أُسَامَةُ: "أَنَا فَخُورٌ بِأَنَّنِي سَعُودِيٌّ." أَجَابَ مُحَمَّدٌ: "وَنَحْنُ جَمِيعًا فَخُورُونَ. نَحْنُ جُزْءٌ مِنْ هَذَا الوَطَنِ العَظِيمِ، وَلَنْ نَدَّخِرَ جُهْدًا فِي خِدْمَتِهِ."',
    imageUrl: images[9],
    audioUrl: audios[9],
  },
  {
    pageNumber: 10,
    text: 'وَفِي نِهَايَةِ اليَوْمِ، عَادَ مُحَمَّدٌ إِلَى مَنْزِلِهِ وَهُوَ يَشْعُرُ بِالفَخْرِ. وَقَالَ لِأُمِّهِ: "اليَوْمَ تَعَلَّمْتُ الكَثِيرَ عَنْ تَارِيخِ وَطَنِنَا وَكَيْفَ يَجِبُ عَلَيْنَا أَنْ نُحِبَّهُ وَنَعْتَنِيَ بِهِ."',
    imageUrl: images[10],
    audioUrl: audios[10],
  },
];

// إضافة القصة
const [result] = await conn.execute(
  `INSERT INTO stories (title, description, coverImage, ageGroup, totalPages, difficulty, pointsReward, isPublished, createdAt, updatedAt)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
  [
    'محبة الوطن',
    'قصة عن فخر الأطفال بوطنهم، وتعرفهم على تاريخ المملكة، وقيم الانتماء، وأهمية رؤية المملكة 2030',
    images[1],
    '6-8',
    10,
    'medium',
    30,
    1,
  ]
);

const storyId = result.insertId;
console.log('✅ Story created with ID:', storyId);

// إضافة الصفحات
for (const page of pages) {
  await conn.execute(
    `INSERT INTO story_pages (storyId, pageNumber, text, imageUrl, audioUrl)
     VALUES (?, ?, ?, ?, ?)`,
    [storyId, page.pageNumber, page.text, page.imageUrl, page.audioUrl]
  );
  console.log(`  ✅ Page ${page.pageNumber} added`);
}

console.log('\n🎉 قصة "محبة الوطن" أضيفت بنجاح!');
console.log('Story ID:', storyId);
console.log('Pages:', pages.length);

await conn.end();
