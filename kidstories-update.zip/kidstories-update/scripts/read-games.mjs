import * as dotenv from 'dotenv';
import { readFileSync } from 'fs';

// Load env
const envPath = '/home/ubuntu/kidstories-update/.env';
try {
  dotenv.config({ path: envPath });
} catch(e) {}

// Try to get DATABASE_URL from environment
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('DATABASE_URL not found');
  process.exit(1);
}

import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(DATABASE_URL);
const [rows] = await conn.execute('SELECT id, title, level, type FROM educational_games ORDER BY level, id');
console.log(JSON.stringify(rows, null, 2));
await conn.end();
