import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── المغامرات المكسورة - بيانات كاملة جديدة ───────────────────────────────

const adventure7 = {
  startNodeId: "start",
  nodes: [
    {
      id: "start",
      emoji: "🌲",
      text: "ليلى فتاة صغيرة تحب الغابة. ذات يوم وجدت بابًا سحريًا في جذع شجرة عملاقة. من الباب تسمع أصواتًا غريبة وترى ضوءًا ذهبيًا. ماذا تفعل؟",
      choices: [
        { id: "c1", text: "تدخل الباب بشجاعة", emoji: "🚪", type: "adventure", points: 20, nextNodeId: "enter" },
        { id: "c2", text: "تنادي أصدقاءها أولاً", emoji: "👫", type: "safe", points: 10, nextNodeId: "call_friends" },
        { id: "c3", text: "تنظر من الباب بحذر", emoji: "👀", type: "learning", points: 5, nextNodeId: "peek" },
      ]
    },
    {
      id: "enter",
      emoji: "✨",
      text: "دخلت ليلى الباب ووجدت نفسها في غابة سحرية مليئة بالحيوانات المتكلمة! أرنب بقبعة يقول: 'أهلاً! أنت ضيفتنا. هل تريدين مساعدة الغابة أم استكشافها؟'",
      choices: [
        { id: "c4", text: "تساعد الغابة في مشكلتها", emoji: "💚", type: "safe", points: 10, nextNodeId: "help_forest" },
        { id: "c5", text: "تستكشف الغابة السحرية", emoji: "🗺️", type: "adventure", points: 20, nextNodeId: "explore" },
      ]
    },
    {
      id: "call_friends",
      emoji: "👧👦",
      text: "نادت ليلى أصدقاءها سامي وريم. جاؤوا معها وقرروا الدخول معًا. داخل الغابة وجدوا شجرة تبكي لأن أحدهم قطع غصنها.",
      choices: [
        { id: "c6", text: "يعتذرون للشجرة ويعالجونها", emoji: "🌿", type: "safe", points: 10, nextNodeId: "heal_tree" },
        { id: "c7", text: "يبحثون عن من قطع الغصن", emoji: "🔍", type: "adventure", points: 20, nextNodeId: "find_culprit" },
      ]
    },
    {
      id: "peek",
      emoji: "🦋",
      text: "نظرت ليلى بحذر فرأت فراشات ملونة تطير وزهورًا تتكلم. فجأة فراشة كبيرة تقول: 'لا تخافي! الغابة السحرية تحتاج مساعدتك. شرير يسرق ألوان الزهور!'",
      choices: [
        { id: "c8", text: "تدخل وتساعد الزهور", emoji: "🌸", type: "adventure", points: 20, nextNodeId: "help_flowers" },
        { id: "c9", text: "ترجع للبيت وتخبر والديها", emoji: "🏠", type: "safe", points: 10, nextNodeId: "go_home" },
      ]
    },
    {
      id: "help_forest",
      emoji: "🌳",
      text: "أخبرها الأرنب أن ساحرًا شريرًا يسرق ماء النهر السحري. بدون الماء ستذبل كل الأشجار. ليلى تفكر في الحل...",
      choices: [
        { id: "c10", text: "تواجه الساحر مباشرة", emoji: "⚔️", type: "adventure", points: 20, nextNodeId: "face_wizard" },
        { id: "c11", text: "تجمع حيوانات الغابة لمساعدتها", emoji: "🦁", type: "safe", points: 10, nextNodeId: "gather_animals" },
      ]
    },
    {
      id: "explore",
      emoji: "🗺️",
      text: "استكشفت ليلى الغابة ووجدت جبلاً من الكريستال وبحيرة من الذهب! لكن وجدت أيضًا قفصًا فيه طائر سحري حزين.",
      choices: [
        { id: "c12", text: "تحرر الطائر السحري", emoji: "🕊️", type: "safe", points: 10, nextNodeId: "free_bird" },
        { id: "c13", text: "تأخذ كنزًا من البحيرة الذهبية", emoji: "💰", type: "adventure", points: 20, nextNodeId: "take_treasure" },
      ]
    },
    {
      id: "heal_tree",
      emoji: "🌱",
      text: "اعتذروا للشجرة وربطوا غصنها بعناية. الشجرة شكرتهم وأعطتهم ثمارًا سحرية تمنح القوة. لكن الغابة لا تزال تحتاج مساعدة.",
      isEnding: true, endingKey: "heal_tree_end", endingType: "good",
      endingTitle: "أطفال الطبيعة الطيبون"
    },
    {
      id: "find_culprit",
      emoji: "🔍",
      text: "بحثوا وبحثوا حتى وجدوا قنفذًا صغيرًا يبكي. قال: 'أنا من قطع الغصن خطأً وأنا آسف جدًا!' تعلموا أن الاعتراف بالخطأ شجاعة.",
      isEnding: true, endingKey: "find_culprit_end", endingType: "learning",
      endingTitle: "الاعتراف بالخطأ شجاعة"
    },
    {
      id: "help_flowers",
      emoji: "🌈",
      text: "دخلت ليلى ووجدت الشرير يملأ جرته بألوان الزهور. صرخت: 'أعد الألوان!' فخاف وهرب وسقطت الجرة وعادت الألوان لأصحابها. الغابة احتفلت بها!",
      isEnding: true, endingKey: "help_flowers_end", endingType: "great",
      endingTitle: "بطلة الغابة السحرية"
    },
    {
      id: "go_home",
      emoji: "🏠",
      text: "رجعت ليلى وأخبرت والديها. أبوها قال: 'الحذر جيد، لكن أحيانًا الآخرون يحتاجون مساعدتنا.' في اليوم التالي ذهبت مع أبيها وساعدوا الغابة معًا.",
      isEnding: true, endingKey: "go_home_end", endingType: "learning",
      endingTitle: "الحذر والشجاعة معًا"
    },
    {
      id: "face_wizard",
      emoji: "⚡",
      text: "واجهت ليلى الساحر بشجاعة وقالت: 'الماء ليس ملكك!' الساحر ضحك وألقى تعويذة عليها. لكن قلبها الطيب كسر التعويذة وأعاد الماء للنهر!",
      isEnding: true, endingKey: "face_wizard_end", endingType: "great",
      endingTitle: "قلب طيب يكسر السحر"
    },
    {
      id: "gather_animals",
      emoji: "🦊🐻🦁",
      text: "جمعت ليلى الأسد والثعلب والدب وخططوا معًا. الأسد أخاف الساحر، الثعلب سرق مفتاح الخزان، والدب أعاد الماء للنهر. فازوا بالتعاون!",
      isEnding: true, endingKey: "gather_animals_end", endingType: "good",
      endingTitle: "قوة التعاون"
    },
    {
      id: "free_bird",
      emoji: "🕊️✨",
      text: "حررت ليلى الطائر السحري. الطائر قال: 'شكرًا! أنا طائر الأمنيات. لك أمنية واحدة.' تمنت ليلى أن تكون الغابة السحرية بأمان دائمًا. تحققت الأمنية!",
      isEnding: true, endingKey: "free_bird_end", endingType: "great",
      endingTitle: "أمنية القلب الطيب"
    },
    {
      id: "take_treasure",
      emoji: "💰😢",
      text: "أخذت ليلى كنزًا من البحيرة. لكن الغابة بدأت تتلاشى! الكنز كان سر الغابة. أعادته بسرعة وعادت الغابة. تعلمت أن بعض الكنوز لا تُؤخذ.",
      isEnding: true, endingKey: "take_treasure_end", endingType: "learning",
      endingTitle: "بعض الكنوز لا تُؤخذ"
    },
  ]
};

const adventure10 = {
  startNodeId: "start",
  nodes: [
    {
      id: "start",
      emoji: "🗺️",
      text: "وجد كريم خريطة قديمة في علية بيت جده. الخريطة تقول: 'الكنز المخفي في المكان الذي تبدأ منه كل الرحلات.' كريم يفكر أين يبدأ؟",
      choices: [
        { id: "c1", text: "يذهب لبيت الجد - حيث بدأت العائلة", emoji: "🏠", type: "safe", points: 10, nextNodeId: "grandpa_house" },
        { id: "c2", text: "يذهب للمدرسة - حيث تبدأ رحلة التعلم", emoji: "🏫", type: "learning", points: 5, nextNodeId: "school" },
        { id: "c3", text: "يذهب للميناء - حيث تبدأ الرحلات البحرية", emoji: "⚓", type: "adventure", points: 20, nextNodeId: "harbor" },
      ]
    },
    {
      id: "grandpa_house",
      emoji: "🏠",
      text: "في بيت الجد وجد كريم غرفة سرية خلف الرف الكبير! في الغرفة صناديق قديمة وصور عائلية. وجد رسالة من جده الأكبر تقول: 'الكنز الحقيقي في القلب.'",
      choices: [
        { id: "c4", text: "يفتح الصناديق القديمة", emoji: "📦", type: "adventure", points: 20, nextNodeId: "open_boxes" },
        { id: "c5", text: "يقرأ الرسائل القديمة", emoji: "📜", type: "learning", points: 5, nextNodeId: "read_letters" },
      ]
    },
    {
      id: "school",
      emoji: "🏫",
      text: "في المدرسة سأل المعلم عن الخريطة. المعلم قال: 'هذه خريطة الجزيرة القديمة! جدك كان مستكشفًا شهيرًا. الكنز في الجزيرة الصغيرة جنوب المدينة.'",
      choices: [
        { id: "c6", text: "يذهب للجزيرة فورًا", emoji: "🏝️", type: "adventure", points: 20, nextNodeId: "island" },
        { id: "c7", text: "يستعد جيدًا قبل الرحلة", emoji: "🎒", type: "safe", points: 10, nextNodeId: "prepare" },
      ]
    },
    {
      id: "harbor",
      emoji: "⚓",
      text: "في الميناء وجد كريم بحارًا عجوزًا يعرف الخريطة! قال: 'هذه خريطة جدك. الكنز في كهف تحت الماء. لكن الطريق خطير!'",
      choices: [
        { id: "c8", text: "يغامر ويذهب للكهف", emoji: "🤿", type: "adventure", points: 20, nextNodeId: "underwater_cave" },
        { id: "c9", text: "يطلب من البحار مرافقته", emoji: "👴", type: "safe", points: 10, nextNodeId: "with_sailor" },
      ]
    },
    {
      id: "open_boxes",
      emoji: "💎",
      text: "في الصناديق وجد كريم مجوهرات قديمة وعملات نادرة! لكن وجد أيضًا مذكرات جده التي تحكي قصص مغامراته. الكنز المادي موجود، لكن قصص الجد أثمن!",
      isEnding: true, endingKey: "open_boxes_end", endingType: "good",
      endingTitle: "كنز العائلة الحقيقي"
    },
    {
      id: "read_letters",
      emoji: "📜❤️",
      text: "قرأ كريم الرسائل وعرف قصة جده الأكبر الذي بنى المدينة بيده. الكنز الحقيقي كان قصص العائلة والحب الذي تركه الأجداد. شارك القصص مع عائلته.",
      isEnding: true, endingKey: "read_letters_end", endingType: "learning",
      endingTitle: "الكنز الذي لا يُقدَّر"
    },
    {
      id: "island",
      emoji: "🏝️",
      text: "ذهب كريم للجزيرة وحده. وجد الكنز لكن تاه في الطريق للعودة! أمضى الليل وحيدًا خائفًا. في الصباح أنقذه الصيادون. تعلم أن الاستعداد مهم.",
      isEnding: true, endingKey: "island_alone_end", endingType: "danger",
      endingTitle: "الاستعداد قبل المغامرة"
    },
    {
      id: "prepare",
      emoji: "🎒🗺️",
      text: "استعد كريم جيدًا وأخذ معه أصدقاءه وبوصلة وطعامًا. وصلوا للجزيرة ووجدوا الكنز: صندوق من الكتب النادرة والخرائط القديمة! كنز المعرفة!",
      isEnding: true, endingKey: "prepare_end", endingType: "great",
      endingTitle: "كنز المعرفة"
    },
    {
      id: "underwater_cave",
      emoji: "🌊",
      text: "غاص كريم وحده ووجد الكهف. لكن التيار جرفه! بالكاد نجا. الكنز لا يزال في الكهف لكن كريم تعلم أن الشجاعة بدون تخطيط تصبح تهورًا.",
      isEnding: true, endingKey: "underwater_cave_end", endingType: "bad",
      endingTitle: "الشجاعة تحتاج تخطيطًا"
    },
    {
      id: "with_sailor",
      emoji: "👴⚓",
      text: "رافق البحار العجوز كريمًا. في الكهف وجدا صندوقًا من الذهب والجواهر. البحار قال: 'جدك أودعه هنا ليجده من يستحقه.' كريم أعطى نصف الكنز للمدرسة.",
      isEnding: true, endingKey: "with_sailor_end", endingType: "great",
      endingTitle: "الكنز يُشارَك"
    },
  ]
};

const adventure12 = {
  startNodeId: "start",
  nodes: [
    {
      id: "start",
      emoji: "🏛️",
      text: "سمع سلطان عن مدينة قديمة منسية تحت الرمال. الخريطة تقول إنها تحتوي على سر عظيم. وصل سلطان لمدخل المدينة المدفونة. ماذا يفعل؟",
      choices: [
        { id: "c1", text: "يدخل المدينة مباشرة", emoji: "🚶", type: "adventure", points: 20, nextNodeId: "enter_city" },
        { id: "c2", text: "يدرس الخريطة أولاً", emoji: "🗺️", type: "learning", points: 5, nextNodeId: "study_map" },
        { id: "c3", text: "يبحث عن مرشد محلي", emoji: "👤", type: "safe", points: 10, nextNodeId: "find_guide" },
      ]
    },
    {
      id: "enter_city",
      emoji: "🏛️✨",
      text: "دخل سلطان المدينة ووجد شوارع مرصوفة بالرخام وأعمدة ضخمة! في المركز وجد نافورة جافة وحولها نقوش تقول: 'أعد الماء وستعود المدينة للحياة.'",
      choices: [
        { id: "c4", text: "يبحث عن مصدر الماء", emoji: "💧", type: "adventure", points: 20, nextNodeId: "find_water" },
        { id: "c5", text: "يقرأ النقوش بعناية", emoji: "📖", type: "learning", points: 5, nextNodeId: "read_inscriptions" },
      ]
    },
    {
      id: "study_map",
      emoji: "🗺️",
      text: "درس سلطان الخريطة وفهم أن المدينة لها ثلاثة مداخل: باب الملوك، باب التجار، وباب الحكماء. كل باب يؤدي لسر مختلف.",
      choices: [
        { id: "c6", text: "يدخل من باب الملوك", emoji: "👑", type: "adventure", points: 20, nextNodeId: "kings_gate" },
        { id: "c7", text: "يدخل من باب الحكماء", emoji: "📚", type: "learning", points: 5, nextNodeId: "wise_gate" },
      ]
    },
    {
      id: "find_guide",
      emoji: "👴",
      text: "وجد سلطان شيخًا عجوزًا يعرف المدينة جيدًا. قال: 'أنا آخر أحفاد سكانها. المدينة اختفت بسبب خيانة. السر في مكتبة الملك.'",
      choices: [
        { id: "c8", text: "يذهب للمكتبة مع الشيخ", emoji: "📚", type: "safe", points: 10, nextNodeId: "library" },
        { id: "c9", text: "يسأل الشيخ عن الخيانة", emoji: "❓", type: "learning", points: 5, nextNodeId: "ask_betrayal" },
      ]
    },
    {
      id: "find_water",
      emoji: "💧🌊",
      text: "وجد سلطان نهرًا تحت الأرض محجوبًا بصخرة ضخمة. بجهد كبير حرك الصخرة وعاد الماء للنافورة. المدينة بدأت تضيء وأشباح سكانها ظهرت شاكرةً إياه!",
      isEnding: true, endingKey: "find_water_end", endingType: "great",
      endingTitle: "محرر المدينة المنسية"
    },
    {
      id: "read_inscriptions",
      emoji: "📖✨",
      text: "قرأ سلطان النقوش وفهم تاريخ المدينة كاملاً. كتب كل شيء في كتاب وأعاد المدينة للتاريخ. أصبح عالمًا مشهورًا بسبب اكتشافه العظيم.",
      isEnding: true, endingKey: "read_inscriptions_end", endingType: "good",
      endingTitle: "العالم الصغير"
    },
    {
      id: "kings_gate",
      emoji: "👑💎",
      text: "في باب الملوك وجد سلطان قاعة العرش وتاجًا ذهبيًا! لكن التاج محمي بلغز: 'ما الذي يملكه الملك العادل ولا يملكه الملك الظالم؟' أجاب: 'محبة الشعب!' فانفتح الباب.",
      isEnding: true, endingKey: "kings_gate_end", endingType: "great",
      endingTitle: "حكمة الملك العادل"
    },
    {
      id: "wise_gate",
      emoji: "📚🌟",
      text: "في باب الحكماء وجد سلطان مكتبة ضخمة بكتب لا تُعد! كتب في الطب والفلك والرياضيات. أمضى أيامًا يقرأ وتعلم أسرار الكون. المعرفة كانت الكنز الحقيقي.",
      isEnding: true, endingKey: "wise_gate_end", endingType: "learning",
      endingTitle: "كنز المعرفة الأبدي"
    },
    {
      id: "library",
      emoji: "📚🔍",
      text: "في المكتبة وجد سلطان والشيخ كتاب التاريخ السري. عرفا أن المدينة اختفت لأن أهلها تركوا العلم والعمل. الشيخ بكى وقال: 'نسيان التاريخ يكرره.' نشر سلطان القصة.",
      isEnding: true, endingKey: "library_end", endingType: "learning",
      endingTitle: "التاريخ درس للمستقبل"
    },
    {
      id: "ask_betrayal",
      emoji: "😢",
      text: "حكى الشيخ أن وزيرًا خائنًا باع المدينة للأعداء. لكن الملك العادل دفن المدينة بسحر لحمايتها حتى يأتي من يستحق. سلطان أثبت أنه يستحق وعادت المدينة!",
      isEnding: true, endingKey: "ask_betrayal_end", endingType: "surprise",
      endingTitle: "الأمانة تُعيد المدينة"
    },
  ]
};

// ─── تحديث المغامرات في قاعدة البيانات ─────────────────────────────────────

async function updateAdventure(id, adventureData, totalEndings) {
  const [result] = await conn.execute(
    'UPDATE story_adventures SET adventureData = ?, totalEndings = ? WHERE id = ?',
    [JSON.stringify(adventureData), totalEndings, id]
  );
  console.log(`Updated ID:${id} - affected rows: ${result.affectedRows}`);
}

// إصلاح المغامرات المكسورة
await updateAdventure(7, adventure7, 7);
await updateAdventure(10, adventure10, 6);
await updateAdventure(12, adventure12, 6);

// تحديث المغامرات التي لديها أقل من 5 نهايات في قاعدة البيانات
// (تحديث totalEndings فقط لتتطابق مع الواقع)
const fixes = [
  [1, 5], [2, 4], [3, 5], [4, 5], [6, 3], [8, 4], [9, 4], [11, 4],
  [13, 3], [14, 4], [15, 5], [30001, 4], [30002, 6], [30007, 6], [30008, 6]
];
for (const [id, ends] of fixes) {
  const [r] = await conn.execute('UPDATE story_adventures SET totalEndings = ? WHERE id = ?', [ends, id]);
  console.log(`Updated totalEndings for ID:${id} to ${ends} - rows: ${r.affectedRows}`);
}

console.log('\nDone! Checking results...');
const [rows] = await conn.execute('SELECT id, title, totalEndings FROM story_adventures ORDER BY id');
rows.forEach(r => console.log(`ID:${r.id} ${r.title} | totalEndings:${r.totalEndings}`));

await conn.end();
